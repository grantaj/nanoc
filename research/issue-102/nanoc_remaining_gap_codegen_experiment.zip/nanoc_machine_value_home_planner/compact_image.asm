* = $0800
    jmp __experiment_entry
ASSEMBLE_OK:
    byte 0
ASSEMBLE_BAD_STATEMENT:
    byte 1
ASSEMBLE_BAD_SYMBOL:
    byte 2
ASSEMBLE_SYMBOL_FULL:
    byte 3
ASSEMBLE_SCOPE_ERROR:
    byte 4
ASSEMBLE_BAD_INSTRUCTION:
    byte 5
ASSEMBLE_UNDEFINED:
    byte 6
ASSEMBLE_EMIT_ERROR:
    byte 7
ASSEMBLE_BAD_DATA:
    byte 9
ASSEMBLE_BAD_ORIGIN:
    byte 10
ASSEMBLE_WORK_FULL:
    byte 11
ASSEMBLE_IO_ERROR:
    byte 12
ASSEMBLE_LINE_TOO_LONG:
    byte 13
ASSEMBLE_INCLUDE_DEPTH:
    byte 14
MODE_IMPLIED:
    byte 0
MODE_ACCUMULATOR:
    byte 1
MODE_IMMEDIATE:
    byte 2
MODE_ZERO_PAGE:
    byte 3
MODE_ZERO_PAGE_X:
    byte 4
MODE_ZERO_PAGE_Y:
    byte 5
MODE_ABSOLUTE:
    byte 6
MODE_ABSOLUTE_X:
    byte 7
MODE_ABSOLUTE_Y:
    byte 8
MODE_INDIRECT:
    byte 9
MODE_INDIRECT_X:
    byte 10
MODE_INDIRECT_Y:
    byte 11
MODE_RELATIVE:
    byte 12
mode_width:
    byte 0,0,1,1,1,1,2,2,2,2,1,1,1,0
mnemonic_table:
    byte 65,68,67,65,78,68,65,83,76,66,67,67,66,67,83,66
    byte 69,81,66,73,84,66,77,73,66,78,69,66,80,76,66,82
    byte 75,66,86,67,66,86,83,67,76,67,67,76,68,67,76,73
    byte 67,76,86,67,77,80,67,80,88,67,80,89,68,69,67,68
    byte 69,88,68,69,89,69,79,82,73,78,67,73,78,88,73,78
    byte 89,74,77,80,74,83,82,76,68,65,76,68,88,76,68,89
    byte 76,83,82,78,79,80,79,82,65,80,72,65,80,72,80,80
    byte 76,65,80,76,80,82,79,76,82,79,82,82,84,73,82,84
    byte 83,83,66,67,83,69,67,83,69,68,83,69,73,83,84,65
    byte 83,84,88,83,84,89,84,65,88,84,65,89,84,83,88,84
    byte 88,65,84,88,83,84,89,65,63,63,63,0
opcode_mnemonic:
    byte 10,34,56,56,56,34,2,56,36,34,2,56,56,34,2,56
    byte 9,34,56,56,56,34,2,56,13,34,56,56,56,34,2,56
    byte 28,1,56,56,6,1,39,56,38,1,39,56,6,1,39,56
    byte 7,1,56,56,56,1,39,56,44,1,56,56,56,1,39,56
    byte 41,23,56,56,56,23,32,56,35,23,32,56,27,23,32,56
    byte 11,23,56,56,56,23,32,56,15,23,56,56,56,23,32,56
    byte 42,0,56,56,56,0,40,56,37,0,40,56,27,0,40,56
    byte 12,0,56,56,56,0,40,56,46,0,56,56,56,0,40,56
    byte 56,47,56,56,49,47,48,56,22,56,53,56,49,47,48,56
    byte 3,47,56,56,49,47,48,56,55,47,54,56,56,47,56,56
    byte 31,29,30,56,31,29,30,56,51,29,50,56,31,29,30,56
    byte 4,29,56,56,31,29,30,56,16,29,52,56,31,29,30,56
    byte 19,17,56,56,19,17,20,56,26,17,21,56,19,17,20,56
    byte 8,17,56,56,56,17,20,56,14,17,56,56,56,17,20,56
    byte 18,43,56,56,18,43,24,56,25,43,33,56,18,43,24,56
    byte 5,43,56,56,56,43,24,56,45,43,56,56,56,43,24,56
opcode_mode:
    byte 0,10,13,13,13,3,3,13,0,2,1,13,13,6,6,13
    byte 12,11,13,13,13,4,4,13,0,8,13,13,13,7,7,13
    byte 6,10,13,13,3,3,3,13,0,2,1,13,6,6,6,13
    byte 12,11,13,13,13,4,4,13,0,8,13,13,13,7,7,13
    byte 0,10,13,13,13,3,3,13,0,2,1,13,6,6,6,13
    byte 12,11,13,13,13,4,4,13,0,8,13,13,13,7,7,13
    byte 0,10,13,13,13,3,3,13,0,2,1,13,9,6,6,13
    byte 12,11,13,13,13,4,4,13,0,8,13,13,13,7,7,13
    byte 13,10,13,13,3,3,3,13,0,13,0,13,6,6,6,13
    byte 12,11,13,13,4,4,5,13,0,8,0,13,13,7,13,13
    byte 2,10,2,13,3,3,3,13,0,2,0,13,6,6,6,13
    byte 12,11,13,13,4,4,5,13,0,8,0,13,7,7,8,13
    byte 2,10,13,13,3,3,3,13,0,2,0,13,6,6,6,13
    byte 12,11,13,13,13,4,4,13,0,8,13,13,13,7,7,13
    byte 2,10,13,13,3,3,3,13,0,2,0,13,6,6,6,13
    byte 12,11,13,13,13,4,4,13,0,8,13,13,13,7,7,13
SYMBOL_CONSTANT:
    byte 0
SYMBOL_LABEL_UNDEFINED:
    byte 1
SYMBOL_LABEL_DEFINED:
    byte 2
VALUE_OK:
    byte 0
VALUE_UNRESOLVED:
    byte 1
VALUE_BAD:
    byte 2
VALUE_SYMBOL_FULL:
    byte 3
VALUE_SCOPE_ERROR:
    byte 4
VALUE_PREFIX_NONE:
    byte 0
VALUE_PREFIX_LOW:
    byte 1
VALUE_PREFIX_HIGH:
    byte 2
FIXUP_NONE:
    byte 0
FIXUP_BYTE:
    byte 1
FIXUP_WORD:
    byte 2
FIXUP_RELATIVE:
    byte 3
FIXUP_DATA_BYTE:
    byte 4
upper_char:
__F_upper_char_entry:
    sta __L_upper_char_c
    cmp #$61
    bcc __F_upper_char_join_3
__F_upper_char_yes_1:
    cmp #$7a
    bcc __F_upper_char_yes_4
    bne __F_upper_char_join_3
__F_upper_char_yes_4:
    lda __L_upper_char_c
    sec
    sbc #$20
    rts
__F_upper_char_join_3:
    lda __L_upper_char_c
    rts
same_text:
__F_same_text_entry:
    sta __L_same_text_b_length
    lda __L_same_text_a_length
    cmp __L_same_text_b_length
    beq __F_same_text_join_3
__F_same_text_yes_1:
    lda #$00
    rts
__F_same_text_join_3:
    lda #$00
    sta __L_same_text_i
    ldy __L_same_text_i
    lda __L_same_text_a
    sta __ap
    lda __L_same_text_a+1
    sta __ap+1
    lda __L_same_text_b
    sta __ix
    lda __L_same_text_b+1
    sta __ix+1
__F_same_text_while_4:
    cpy __L_same_text_a_length
    bcs __F_same_text_after_6
__F_same_text_body_5:
    lda (__ap),y
    sta __tmp0
    lda (__ix),y
    cmp __tmp0
    beq __F_same_text_join_9
__F_same_text_yes_7:
    lda #$00
    rts
__F_same_text_join_9:
    inc __L_same_text_i
    iny
    jmp __F_same_text_while_4
__F_same_text_after_6:
    lda #$01
    rts
apply_byte_prefix:
__F_apply_byte_prefix_entry:
    sta __L_apply_byte_prefix_prefix
    cmp VALUE_PREFIX_LOW
    bne __F_apply_byte_prefix_join_3
__F_apply_byte_prefix_yes_1:
    lda __L_apply_byte_prefix_value
    rts
__F_apply_byte_prefix_join_3:
    lda __L_apply_byte_prefix_value+1
    rts
hex_nibble:
__F_hex_nibble_entry:
    sta __L_hex_nibble_c
    lda __L_hex_nibble_c
    jsr upper_char
    sta __L_hex_nibble_c
    cmp #$30
    bcc __F_hex_nibble_join_3
__F_hex_nibble_yes_1:
    cmp #$39
    bcc __F_hex_nibble_yes_4
    bne __F_hex_nibble_join_3
__F_hex_nibble_yes_4:
    lda __L_hex_nibble_c
    sec
    sbc #$30
    jsr __outline_25
    ldx __tmp1
    rts
__F_hex_nibble_join_3:
    cmp #$41
    bcc __F_hex_nibble_join_9
__F_hex_nibble_yes_7:
    cmp #$46
    bcc __F_hex_nibble_yes_10
    bne __F_hex_nibble_join_9
__F_hex_nibble_yes_10:
    lda __L_hex_nibble_c
    sec
    sbc #$41
    jsr __outline_25
    clc
    adc #$0a
    sta __tmp2
    lda __tmp1
    adc #$00
    sta __tmp3
    lda __tmp2
    ldx __tmp3
    rts
__F_hex_nibble_join_9:
    lda #$ff
    ldx #$ff
    rts
append_fixup:
__F_append_fixup_entry:
    sta __L_append_fixup_prefix
    lda fixup_count
    sta __L_append_fixup_n
    lda fixup_count+1
    sta __L_append_fixup_n+1
    eor #$80
    cmp #$82
    bcc __F_append_fixup_join_3
    bne __F_append_fixup_yes_1
    lda __L_append_fixup_n
    cmp #$80
    bcc __F_append_fixup_join_3
__F_append_fixup_yes_1:
    lda ASSEMBLE_WORK_FULL
    rts
__F_append_fixup_join_3:
    clc
    lda __L_append_fixup_n
    adc #<fixup_kind
    sta __ap
    lda __L_append_fixup_n+1
    adc #>fixup_kind
    sta __ap+1
    ldy #$00
    lda __L_append_fixup_kind
    jsr __outline_10
    adc #<fixup_stage
    sta __ap
    lda __ix+1
    adc #>fixup_stage
    sta __ap+1
    ldy #$00
    lda __L_append_fixup_stage
    sta (__ap),y
    iny
    lda __L_append_fixup_stage+1
    jsr __outline_10
    adc #<fixup_symbol
    sta __ap
    lda __ix+1
    adc #>fixup_symbol
    sta __ap+1
    ldy #$00
    lda __L_append_fixup_symbol
    sta (__ap),y
    iny
    lda __L_append_fixup_symbol+1
    jsr __outline_10
    adc #<fixup_addend
    sta __ap
    lda __ix+1
    adc #>fixup_addend
    sta __ap+1
    ldy #$00
    lda __L_append_fixup_addend
    sta (__ap),y
    iny
    lda __L_append_fixup_addend+1
    sta (__ap),y
    clc
    lda __L_append_fixup_n
    adc #<fixup_prefix
    sta __ap
    lda __L_append_fixup_n+1
    adc #>fixup_prefix
    sta __ap+1
    ldy #$00
    lda __L_append_fixup_prefix
    sta (__ap),y
    lda __L_append_fixup_n
    clc
    adc #$01
    sta fixup_count
    lda __L_append_fixup_n+1
    adc #$00
    sta fixup_count+1
    lda ASSEMBLE_OK
    rts
relative_byte:
__F_relative_byte_entry:
    lda __L_relative_byte_target
    sec
    sbc __L_relative_byte_base
    sta __tmp0
    lda __L_relative_byte_target+1
    sbc __L_relative_byte_base+1
    sta __tmp1
    lda __tmp0
    sta __L_relative_byte_difference
    lda __tmp1
    sta __L_relative_byte_difference+1
    cmp #$00
    bcc __F_relative_byte_yes_1
    bne __F_relative_byte_join_3
    lda __L_relative_byte_difference
    cmp #$7f
    bcc __F_relative_byte_yes_1
    bne __F_relative_byte_join_3
__F_relative_byte_yes_1:
    lda __L_relative_byte_difference
    ldx __L_relative_byte_difference+1
    rts
__F_relative_byte_join_3:
    lda __L_relative_byte_difference+1
    cmp #$ff
    bcc __F_relative_byte_join_6
    bne __F_relative_byte_yes_4
    lda __L_relative_byte_difference
    cmp #$80
    bcc __F_relative_byte_join_6
__F_relative_byte_yes_4:
    lda __L_relative_byte_difference
    ldx #$00
    rts
__F_relative_byte_join_6:
    lda #$ff
    ldx #$ff
    rts
trim_fixups:
__F_trim_fixups_entry:
__F_trim_fixups_while_1:
    lda fixup_count+1
    eor #$80
    cmp #$80
    bcc __F_trim_fixups_after_3
    bne __F_trim_fixups_body_2
    lda fixup_count
    cmp #$00
    bcc __F_trim_fixups_after_3
    beq __F_trim_fixups_after_3
__F_trim_fixups_body_2:
    jsr __outline_29
    clc
    lda __tmp0
    adc #<fixup_kind
    sta __ap
    lda __tmp1
    adc #>fixup_kind
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp FIXUP_NONE
    beq __F_trim_fixups_join_6
__F_trim_fixups_yes_4:
    lda ASSEMBLE_OK
    rts
__F_trim_fixups_join_6:
    jsr __outline_29
    lda __tmp0
    sta fixup_count
    lda __tmp1
    sta fixup_count+1
    jmp __F_trim_fixups_while_1
__F_trim_fixups_after_3:
    lda ASSEMBLE_OK
    rts
resolve_fixups_for_symbol:
__F_resolve_fixups_for_symbol_entry:
    lda #$00
    sta __L_resolve_fixups_for_symbol_i
    sta __L_resolve_fixups_for_symbol_i+1
__F_resolve_fixups_for_symbol_while_1:
    lda fixup_count+1
    eor #$80
    sta __rh
    lda __L_resolve_fixups_for_symbol_i+1
    eor #$80
    cmp __rh
    bcc __F_resolve_fixups_for_symbol_body_2
    beq __F_resolve_fixups_for_symbol___far_skip_0
    jmp __F_resolve_fixups_for_symbol_after_3
__F_resolve_fixups_for_symbol___far_skip_0:
    lda __L_resolve_fixups_for_symbol_i
    cmp fixup_count
    bcc __F_resolve_fixups_for_symbol_body_2
    jmp __F_resolve_fixups_for_symbol_after_3
__F_resolve_fixups_for_symbol_body_2:
    jsr __outline_30
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_NONE
    bne __F_resolve_fixups_for_symbol_yes_4
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol_yes_4:
    jsr __outline_17
    adc #<fixup_symbol
    sta __ap
    lda __ix+1
    adc #>fixup_symbol
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __tmp0
    iny
    lda (__ap),y
    cmp __L_resolve_fixups_for_symbol_symbol+1
    beq __F_resolve_fixups_for_symbol___far_skip_1
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol___far_skip_1:
    lda __tmp0
    cmp __L_resolve_fixups_for_symbol_symbol
    beq __F_resolve_fixups_for_symbol_yes_7
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol_yes_7:
    lda __L_resolve_fixups_for_symbol_symbol
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_symbol+1
    jsr __outline_03
    jsr __outline_36
    jsr __outline_17
    adc #<fixup_addend
    sta __ap
    lda __ix+1
    adc #>fixup_addend
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __tmp2
    iny
    lda (__ap),y
    sta __tmp3
    lda __tmp0
    clc
    adc __tmp2
    sta __tmp4
    lda __tmp1
    adc __tmp3
    sta __tmp5
    lda __tmp4
    sta __L_resolve_fixups_for_symbol_value
    lda __tmp5
    sta __L_resolve_fixups_for_symbol_value+1
    clc
    lda __L_resolve_fixups_for_symbol_i
    adc #<fixup_prefix
    sta __ap
    lda __L_resolve_fixups_for_symbol_i+1
    adc #>fixup_prefix
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __tmp0
    cmp VALUE_PREFIX_NONE
    beq __F_resolve_fixups_for_symbol_join_12
__F_resolve_fixups_for_symbol_yes_10:
    lda __L_resolve_fixups_for_symbol_value
    sta __call_apply_byte_prefix_0
    lda __L_resolve_fixups_for_symbol_value+1
    sta __call_apply_byte_prefix_0+1
    lda __tmp0
    jsr apply_byte_prefix
    sta __tmp0
    lda __tmp0
    sta __L_resolve_fixups_for_symbol_value
    lda #$00
    sta __L_resolve_fixups_for_symbol_value+1
__F_resolve_fixups_for_symbol_join_12:
    jsr __outline_17
    adc #<fixup_stage
    sta __ap
    lda __ix+1
    adc #>fixup_stage
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_stage
    iny
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_stage+1
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_WORD
    bne __F_resolve_fixups_for_symbol_no_14
__F_resolve_fixups_for_symbol_yes_13:
    jsr __outline_11
    lda __L_resolve_fixups_for_symbol_value
    sta (__ap),y
    lda __L_resolve_fixups_for_symbol_stage
    clc
    adc #$01
    sta __tmp0
    lda __L_resolve_fixups_for_symbol_stage+1
    jsr __outline_20
    lda __L_resolve_fixups_for_symbol_value+1
    sta (__ap),y
    jmp __F_resolve_fixups_for_symbol_join_15
__F_resolve_fixups_for_symbol_no_14:
    cmp FIXUP_RELATIVE
    bne __F_resolve_fixups_for_symbol_no_17
__F_resolve_fixups_for_symbol_yes_16:
    lda ass_origin
    clc
    adc __L_resolve_fixups_for_symbol_stage
    sta __tmp0
    lda ass_origin+1
    adc __L_resolve_fixups_for_symbol_stage+1
    sta __tmp1
    lda __tmp0
    clc
    adc #$01
    sta __tmp2
    lda __tmp1
    adc #$00
    sta __tmp3
    lda __L_resolve_fixups_for_symbol_value
    sta __call_relative_byte_0
    lda __L_resolve_fixups_for_symbol_value+1
    sta __call_relative_byte_0+1
    lda __tmp2
    sta __call_relative_byte_1
    lda __tmp3
    sta __call_relative_byte_1+1
    jsr relative_byte
    sta __L_resolve_fixups_for_symbol_relative
    stx __L_resolve_fixups_for_symbol_relative+1
    lda __L_resolve_fixups_for_symbol_relative+1
    bpl __F_resolve_fixups_for_symbol_join_21
__F_resolve_fixups_for_symbol_yes_19:
    lda ASSEMBLE_EMIT_ERROR
    rts
__F_resolve_fixups_for_symbol_join_21:
    jsr __outline_11
    lda __L_resolve_fixups_for_symbol_relative
    sta (__ap),y
    jmp __F_resolve_fixups_for_symbol_join_15
__F_resolve_fixups_for_symbol_no_17:
    lda __L_resolve_fixups_for_symbol_value+1
    cmp #$00
    bcc __F_resolve_fixups_for_symbol_join_24
    bne __F_resolve_fixups_for_symbol_yes_22
    lda __L_resolve_fixups_for_symbol_value
    cmp #$ff
    bcc __F_resolve_fixups_for_symbol_join_24
    beq __F_resolve_fixups_for_symbol_join_24
__F_resolve_fixups_for_symbol_yes_22:
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_DATA_BYTE
    bne __F_resolve_fixups_for_symbol_join_27
__F_resolve_fixups_for_symbol_yes_25:
    lda ASSEMBLE_BAD_DATA
    rts
__F_resolve_fixups_for_symbol_join_27:
    lda ASSEMBLE_EMIT_ERROR
    rts
__F_resolve_fixups_for_symbol_join_24:
    jsr __outline_11
    lda __L_resolve_fixups_for_symbol_value
    sta (__ap),y
__F_resolve_fixups_for_symbol_join_15:
    jsr __outline_30
    lda FIXUP_NONE
    sta (__ap),y
__F_resolve_fixups_for_symbol_join_6:
    lda __L_resolve_fixups_for_symbol_i
    clc
    adc #$01
    sta __tmp0
    lda __L_resolve_fixups_for_symbol_i+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta __L_resolve_fixups_for_symbol_i
    lda __tmp1
    sta __L_resolve_fixups_for_symbol_i+1
    jmp __F_resolve_fixups_for_symbol_while_1
__F_resolve_fixups_for_symbol_after_3:
    jsr trim_fixups
    rts
scope_for_name:
__F_scope_for_name_entry:
    sta __L_scope_for_name_length
    cmp #$00
    bne __F_scope_for_name_join_3
__F_scope_for_name_yes_1:
    lda #$ff
    ldx #$ff
    rts
__F_scope_for_name_join_3:
    ldy #$00
    lda __L_scope_for_name_name
    sta __ap
    lda __L_scope_for_name_name+1
    sta __ap+1
    lda (__ap),y
    cmp #$2e
    bne __F_scope_for_name_join_6
__F_scope_for_name_yes_4:
    lda current_scope
    cmp #$00
    bne __F_scope_for_name_join_9
__F_scope_for_name_yes_7:
    lda #$ff
    ldx #$ff
    rts
__F_scope_for_name_join_9:
    lda current_scope
    ldx #$00
    rts
__F_scope_for_name_join_6:
    lda #$00
    ldx #$00
    rts
find_symbol:
__F_find_symbol_entry:
    sta __L_find_symbol_length
    lda __L_find_symbol_name
    sta __call_scope_for_name_0
    lda __L_find_symbol_name+1
    sta __call_scope_for_name_0+1
    lda __L_find_symbol_length
    jsr scope_for_name
    sta __L_find_symbol_wanted_scope
    stx __L_find_symbol_wanted_scope+1
    lda __L_find_symbol_wanted_scope+1
    bpl __F_find_symbol_join_3
__F_find_symbol_yes_1:
    lda #$fe
    ldx #$ff
    rts
__F_find_symbol_join_3:
    lda #$00
    sta __L_find_symbol_i
    sta __L_find_symbol_i+1
__F_find_symbol_while_4:
    lda symbol_count+1
    eor #$80
    sta __rh
    lda __L_find_symbol_i+1
    eor #$80
    cmp __rh
    bcc __F_find_symbol_body_5
    beq __F_find_symbol___far_skip_0
    jmp __F_find_symbol_after_6
__F_find_symbol___far_skip_0:
    lda __L_find_symbol_i
    cmp symbol_count
    bcc __F_find_symbol_body_5
    jmp __F_find_symbol_after_6
__F_find_symbol_body_5:
    clc
    lda __L_find_symbol_i
    adc #<symbol_scope
    sta __ap
    lda __L_find_symbol_i+1
    adc #>symbol_scope
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __tmp0
    lda #$00
    cmp __L_find_symbol_wanted_scope+1
    bne __F_find_symbol_join_9
__F_find_symbol___far_skip_1:
    lda __tmp0
    cmp __L_find_symbol_wanted_scope
    bne __F_find_symbol_join_9
__F_find_symbol_yes_7:
    clc
    lda __L_find_symbol_i
    adc #<symbol_name_length
    sta __ap
    lda __L_find_symbol_i+1
    adc #>symbol_name_length
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp __L_find_symbol_length
    bne __F_find_symbol_join_9
__F_find_symbol_yes_10:
    lda __L_find_symbol_i
    asl
    sta __ix
    lda __L_find_symbol_i+1
    jsr __outline_23
    lda (__ap),y
    sta __L_find_symbol_offset
    iny
    lda (__ap),y
    sta __L_find_symbol_offset+1
    lda #$01
    tax
    lda #$00
    sta __L_find_symbol_j
    ldy __L_find_symbol_j
    lda __L_find_symbol_name
    sta __ap
    lda __L_find_symbol_name+1
    sta __ap+1
    clc
    lda __L_find_symbol_offset
    adc #<symbol_name_bytes
    sta __ix
    lda __L_find_symbol_offset+1
    adc #>symbol_name_bytes
    sta __ix+1
__F_find_symbol_while_13:
    cpy __L_find_symbol_length
    bcs __F_find_symbol_after_15
__F_find_symbol_body_14:
    lda (__ix),y
    sta __tmp0
    lda (__ap),y
    cmp __tmp0
    beq __F_find_symbol_join_18
__F_find_symbol_yes_16:
    lda #$00
    tax
__F_find_symbol_join_18:
    inc __L_find_symbol_j
    iny
    jmp __F_find_symbol_while_13
__F_find_symbol_after_15:
    txa
    cmp #$00
    beq __F_find_symbol_join_9
__F_find_symbol_yes_19:
    lda __L_find_symbol_i
    ldx __L_find_symbol_i+1
    rts
__F_find_symbol_join_9:
    lda __L_find_symbol_i
    clc
    adc #$01
    sta __tmp0
    lda __L_find_symbol_i+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta __L_find_symbol_i
    lda __tmp1
    sta __L_find_symbol_i+1
    jmp __F_find_symbol_while_4
__F_find_symbol_after_6:
    lda #$ff
    ldx #$ff
    rts
allocate_symbol:
__F_allocate_symbol_entry:
    lda __L_allocate_symbol_name
    sta __call_scope_for_name_0
    lda __L_allocate_symbol_name+1
    sta __call_scope_for_name_0+1
    lda __L_allocate_symbol_length
    jsr scope_for_name
    sta __L_allocate_symbol_scope
    stx __L_allocate_symbol_scope+1
    lda __L_allocate_symbol_scope+1
    bpl __F_allocate_symbol_join_3
__F_allocate_symbol_yes_1:
    lda #$fe
    ldx #$ff
    rts
__F_allocate_symbol_join_3:
    lda symbol_count+1
    eor #$80
    cmp #$83
    bcc __F_allocate_symbol_join_6
    bne __F_allocate_symbol_yes_4
    lda symbol_count
    cmp #$80
    bcc __F_allocate_symbol_join_6
__F_allocate_symbol_yes_4:
    lda #$fd
    ldx #$ff
    rts
__F_allocate_symbol_join_6:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_length
    sta __tmp0
    lda symbol_name_used+1
    adc #$00
    eor #$80
    cmp #$a4
    bcc __F_allocate_symbol_join_9
    bne __F_allocate_symbol_yes_7
    lda __tmp0
    cmp #$80
    bcc __F_allocate_symbol_join_9
    beq __F_allocate_symbol_join_9
__F_allocate_symbol_yes_7:
    lda #$fd
    ldx #$ff
    rts
__F_allocate_symbol_join_9:
    lda symbol_count
    sta __L_allocate_symbol_n
    lda symbol_count+1
    sta __L_allocate_symbol_n+1
    lda __L_allocate_symbol_n
    asl
    sta __ix
    lda __L_allocate_symbol_n+1
    jsr __outline_23
    lda symbol_name_used
    sta (__ap),y
    iny
    lda symbol_name_used+1
    sta (__ap),y
    clc
    lda __L_allocate_symbol_n
    adc #<symbol_name_length
    sta __ap
    lda __L_allocate_symbol_n+1
    adc #>symbol_name_length
    sta __ap+1
    ldy #$00
    lda __L_allocate_symbol_length
    sta (__ap),y
    lda __L_allocate_symbol_n
    asl
    sta __ix
    lda __L_allocate_symbol_n+1
    jsr __outline_03
    lda __L_allocate_symbol_payload
    sta (__ap),y
    iny
    lda __L_allocate_symbol_payload+1
    sta (__ap),y
    clc
    lda __L_allocate_symbol_n
    adc #<symbol_scope
    sta __ap
    lda __L_allocate_symbol_n+1
    adc #>symbol_scope
    sta __ap+1
    ldy #$00
    lda __L_allocate_symbol_scope
    sta (__ap),y
    clc
    lda __L_allocate_symbol_n
    adc #<symbol_kind
    sta __ap
    lda __L_allocate_symbol_n+1
    adc #>symbol_kind
    sta __ap+1
    ldy #$00
    lda __L_allocate_symbol_kind
    sta (__ap),y
    lda #$00
    sta __L_allocate_symbol_i
__F_allocate_symbol_while_10:
    lda __L_allocate_symbol_i
    cmp __L_allocate_symbol_length
    bcs __F_allocate_symbol_after_12
__F_allocate_symbol_body_11:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_i
    sta __tmp0
    lda symbol_name_used+1
    adc #$00
    sta __tmp1
    ldy __L_allocate_symbol_i
    lda __L_allocate_symbol_name
    sta __ap
    lda __L_allocate_symbol_name+1
    sta __ap+1
    lda (__ap),y
    sta __tmp2
    clc
    lda __tmp0
    adc #<symbol_name_bytes
    sta __ap
    lda __tmp1
    adc #>symbol_name_bytes
    sta __ap+1
    ldy #$00
    lda __tmp2
    sta (__ap),y
    inc __L_allocate_symbol_i
    jmp __F_allocate_symbol_while_10
__F_allocate_symbol_after_12:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_length
    sta __tmp0
    lda symbol_name_used+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta symbol_name_used
    lda __tmp1
    sta symbol_name_used+1
    lda __L_allocate_symbol_n
    clc
    adc #$01
    sta symbol_count
    lda __L_allocate_symbol_n+1
    adc #$00
    sta symbol_count+1
    lda __L_allocate_symbol_n
    ldx __L_allocate_symbol_n+1
    rts
intern_label:
__F_intern_label_entry:
    sta __L_intern_label_length
    lda __L_intern_label_name
    sta __call_find_symbol_0
    lda __L_intern_label_name+1
    sta __call_find_symbol_0+1
    lda __L_intern_label_length
    jsr find_symbol
    sta __L_intern_label_symbol
    stx __L_intern_label_symbol+1
    lda __L_intern_label_symbol+1
    bmi __F_intern_label_join_3
__F_intern_label_yes_1:
    clc
    lda __L_intern_label_symbol
    adc #<symbol_kind
    sta __ap
    lda __L_intern_label_symbol+1
    adc #>symbol_kind
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp SYMBOL_CONSTANT
    bne __F_intern_label_join_6
__F_intern_label_yes_4:
    lda #$fc
    ldx #$ff
    rts
__F_intern_label_join_6:
    lda __L_intern_label_symbol
    ldx __L_intern_label_symbol+1
    rts
__F_intern_label_join_3:
    cmp #$ff
    bne __F_intern_label_join_9
    lda __L_intern_label_symbol
    cmp #$fe
    bne __F_intern_label_join_9
__F_intern_label_yes_7:
    lda #$fe
    ldx #$ff
    rts
__F_intern_label_join_9:
    lda __L_intern_label_name
    sta __call_allocate_symbol_0
    lda __L_intern_label_name+1
    sta __call_allocate_symbol_0+1
    lda __L_intern_label_length
    sta __call_allocate_symbol_1
    lda SYMBOL_LABEL_UNDEFINED
    sta __call_allocate_symbol_2
    lda #$00
    sta __call_allocate_symbol_3
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    rts
define_constant:
__F_define_constant_entry:
    lda __L_define_constant_name
    sta __call_find_symbol_0
    lda __L_define_constant_name+1
    sta __call_find_symbol_0+1
    lda __L_define_constant_length
    jsr find_symbol
    sta __L_define_constant_symbol
    stx __L_define_constant_symbol+1
    lda __L_define_constant_symbol+1
    bmi __F_define_constant_join_3
__F_define_constant_yes_1:
    lda ASSEMBLE_BAD_SYMBOL
    rts
__F_define_constant_join_3:
    cmp #$ff
    bne __F_define_constant_join_6
    lda __L_define_constant_symbol
    cmp #$fe
    bne __F_define_constant_join_6
__F_define_constant_yes_4:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_define_constant_join_6:
    lda __L_define_constant_name
    sta __call_allocate_symbol_0
    lda __L_define_constant_name+1
    sta __call_allocate_symbol_0+1
    lda __L_define_constant_length
    sta __call_allocate_symbol_1
    lda SYMBOL_CONSTANT
    sta __call_allocate_symbol_2
    lda __L_define_constant_value
    sta __call_allocate_symbol_3
    lda __L_define_constant_value+1
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    sta __L_define_constant_symbol
    stx __L_define_constant_symbol+1
    lda __L_define_constant_symbol+1
    cmp #$ff
    bne __F_define_constant_join_9
    lda __L_define_constant_symbol
    cmp #$fe
    bne __F_define_constant_join_9
__F_define_constant_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_define_constant_join_9:
    lda __L_define_constant_symbol+1
    bpl __F_define_constant_join_12
__F_define_constant_yes_10:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_define_constant_join_12:
    lda ASSEMBLE_OK
    rts
patch_word_chain:
__F_patch_word_chain_entry:
__F_patch_word_chain_while_1:
    lda __L_patch_word_chain_head
    ora __L_patch_word_chain_head+1
    beq __F_patch_word_chain_after_3
__F_patch_word_chain_body_2:
    lda __L_patch_word_chain_head
    sec
    sbc #$01
    sta __L_patch_word_chain_stage
    lda __L_patch_word_chain_head+1
    sbc #$00
    sta __L_patch_word_chain_stage+1
    jsr __outline_31
    lda (__ap),y
    sta __tmp0
    lda __L_patch_word_chain_stage
    clc
    adc #$01
    sta __tmp1
    lda __L_patch_word_chain_stage+1
    adc #$00
    sta __tmp2
    clc
    lda __tmp1
    adc #<ass_image
    sta __ap
    lda __tmp2
    adc #>ass_image
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __tmp1
    lda #$00
    sta __tmp2
    jsr __outline_27
    jsr __outline_27
    lda __tmp0
    ora __tmp1
    sta __tmp3
    lda #$00
    ora __tmp2
    sta __tmp4
    lda __tmp3
    sta __L_patch_word_chain_next
    lda __tmp4
    sta __L_patch_word_chain_next+1
    jsr __outline_31
    lda __L_patch_word_chain_value
    sta (__ap),y
    lda __L_patch_word_chain_stage
    clc
    adc #$01
    sta __tmp0
    lda __L_patch_word_chain_stage+1
    jsr __outline_20
    lda __L_patch_word_chain_value+1
    sta (__ap),y
    lda __L_patch_word_chain_next
    sta __L_patch_word_chain_head
    lda __L_patch_word_chain_next+1
    sta __L_patch_word_chain_head+1
    jmp __F_patch_word_chain_while_1
__F_patch_word_chain_after_3:
    lda ASSEMBLE_OK
    rts
define_label:
__F_define_label_entry:
    lda __L_define_label_name
    sta __call_find_symbol_0
    lda __L_define_label_name+1
    sta __call_find_symbol_0+1
    lda __L_define_label_length
    jsr find_symbol
    sta __L_define_label_symbol
    stx __L_define_label_symbol+1
    lda __L_define_label_symbol+1
    cmp #$ff
    bne __F_define_label_join_3
    lda __L_define_label_symbol
    cmp #$fe
    bne __F_define_label_join_3
__F_define_label_yes_1:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_define_label_join_3:
    lda __L_define_label_symbol+1
    bpl __F_define_label_join_6
__F_define_label_yes_4:
    lda __L_define_label_name
    sta __call_allocate_symbol_0
    lda __L_define_label_name+1
    sta __call_allocate_symbol_0+1
    lda __L_define_label_length
    sta __call_allocate_symbol_1
    lda SYMBOL_LABEL_DEFINED
    sta __call_allocate_symbol_2
    lda __L_define_label_value
    sta __call_allocate_symbol_3
    lda __L_define_label_value+1
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    sta __L_define_label_symbol
    stx __L_define_label_symbol+1
    lda __L_define_label_symbol+1
    cmp #$ff
    bne __F_define_label_join_9
    lda __L_define_label_symbol
    cmp #$fe
    bne __F_define_label_join_9
__F_define_label_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_define_label_join_9:
    lda __L_define_label_symbol+1
    bpl __F_define_label_join_12
__F_define_label_yes_10:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_define_label_join_12:
    lda ASSEMBLE_OK
    rts
__F_define_label_join_6:
    jsr __outline_32
    lda (__ap),y
    cmp SYMBOL_LABEL_UNDEFINED
    beq __F_define_label_join_15
__F_define_label_yes_13:
    lda ASSEMBLE_BAD_SYMBOL
    rts
__F_define_label_join_15:
    lda __L_define_label_symbol
    asl
    sta __ix
    lda __L_define_label_symbol+1
    jsr __outline_03
    jsr __outline_36
    lda __tmp0
    sta __L_define_label_old_head
    lda __tmp1
    sta __L_define_label_old_head+1
    ldy #$00
    lda __L_define_label_value
    sta (__ap),y
    iny
    lda __L_define_label_value+1
    sta (__ap),y
    jsr __outline_32
    lda SYMBOL_LABEL_DEFINED
    sta (__ap),y
    lda __L_define_label_old_head
    sta __call_patch_word_chain_0
    lda __L_define_label_old_head+1
    sta __call_patch_word_chain_0+1
    lda __L_define_label_value
    sta __call_patch_word_chain_1
    lda __L_define_label_value+1
    sta __call_patch_word_chain_1+1
    jsr patch_word_chain
    sta __L_define_label_status
    cmp ASSEMBLE_OK
    beq __F_define_label_join_18
__F_define_label_yes_16:
    lda __L_define_label_status
    rts
__F_define_label_join_18:
    lda __L_define_label_symbol
    sta __call_resolve_fixups_for_symbol_0
    lda __L_define_label_symbol+1
    sta __call_resolve_fixups_for_symbol_0+1
    jsr resolve_fixups_for_symbol
    rts
parse_atom:
__F_parse_atom_entry:
    sta __L_parse_atom_length
    lda #$00
    sta atom_used
    lda __L_parse_atom_length
    cmp #$00
    bne __F_parse_atom_join_3
__F_parse_atom_yes_1:
    lda VALUE_BAD
    rts
__F_parse_atom_join_3:
    ldy #$00
    jsr __outline_16
    cmp #$24
    beq __F_parse_atom_yes_4
    jmp __F_parse_atom_join_6
__F_parse_atom_yes_4:
    lda #$01
    sta __L_parse_atom_i
    lda #$00
    sta __L_parse_atom_value
    sta __L_parse_atom_value+1
__F_parse_atom_while_7:
    lda __L_parse_atom_i
    cmp __L_parse_atom_length
    bcs __F_parse_atom_after_9
__F_parse_atom_body_8:
    ldy __L_parse_atom_i
    jsr __outline_16
    sta __tmp0
    cmp #$2b
    beq __F_parse_atom_after_9
__F_parse_atom_no_11:
    cmp #$2d
    beq __F_parse_atom_after_9
__F_parse_atom_no_14:
    lda __tmp0
    jsr hex_nibble
    sta __L_parse_atom_digit
    stx __L_parse_atom_digit+1
    lda __L_parse_atom_digit+1
    bpl __F_parse_atom_join_18
__F_parse_atom_yes_16:
    lda VALUE_BAD
    rts
__F_parse_atom_join_18:
    lda atom_used
    cmp #$04
    bcc __F_parse_atom_join_21
__F_parse_atom_yes_19:
    lda VALUE_BAD
    rts
__F_parse_atom_join_21:
    lda __L_parse_atom_value
    sta __tmp0
    lda __L_parse_atom_value+1
    sta __tmp1
    asl __tmp0
    rol __tmp1
    asl __tmp0
    rol __tmp1
    asl __tmp0
    rol __tmp1
    asl __tmp0
    rol __tmp1
    lda __tmp0
    ora __L_parse_atom_digit
    sta __tmp2
    lda __tmp1
    ora __L_parse_atom_digit+1
    jsr __outline_33
    jmp __F_parse_atom_while_7
__F_parse_atom_after_9:
    lda atom_used
    cmp #$00
    bne __F_parse_atom_join_24
__F_parse_atom_yes_22:
    lda VALUE_BAD
    rts
__F_parse_atom_join_24:
    inc atom_used
    lda __L_parse_atom_value
    sta atom_value
    lda __L_parse_atom_value+1
    jsr __outline_22
    rts
__F_parse_atom_join_6:
    cmp #$27
    bne __F_parse_atom_join_27
__F_parse_atom_yes_25:
    lda __L_parse_atom_length
    cmp #$03
    bcs __F_parse_atom_join_30
__F_parse_atom_yes_28:
    lda VALUE_BAD
    rts
__F_parse_atom_join_30:
    ldy #$02
    jsr __outline_16
    cmp #$27
    beq __F_parse_atom_join_33
__F_parse_atom_yes_31:
    lda VALUE_BAD
    rts
__F_parse_atom_join_33:
    ldy #$01
    jsr __outline_16
    sta atom_value
    lda #$00
    sta atom_value+1
    lda #$03
    sta atom_used
    lda #$00
    sta atom_kind
    lda VALUE_OK
    rts
__F_parse_atom_join_27:
    cmp #$30
    bcc __F_parse_atom_join_36
__F_parse_atom_yes_34:
    cmp #$39
    bcc __F_parse_atom_yes_37
    bne __F_parse_atom_join_36
__F_parse_atom_yes_37:
    lda #$00
    sta __L_parse_atom_i
    sta __L_parse_atom_value
    sta __L_parse_atom_value+1
    ldy __L_parse_atom_i
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
__F_parse_atom_while_40:
    cpy __L_parse_atom_length
    bcs __F_parse_atom_after_42
__F_parse_atom_body_41:
    lda (__ap),y
    sta __tmp0
    cmp #$2b
    beq __F_parse_atom_after_42
__F_parse_atom___far_skip_0:
__F_parse_atom_no_44:
    cmp #$2d
    beq __F_parse_atom_after_42
__F_parse_atom_no_47:
    cmp #$30
    bcs __F_parse_atom_join_51
__F_parse_atom_yes_49:
    lda VALUE_BAD
    rts
__F_parse_atom_join_51:
    cmp #$39
    bcc __F_parse_atom_join_54
    beq __F_parse_atom_join_54
__F_parse_atom_yes_52:
    lda VALUE_BAD
    rts
__F_parse_atom_join_54:
    lda #$00
    sta __tmp2
    sta __tmp3
    lda __L_parse_atom_value
    sta __mw
    lda __L_parse_atom_value+1
    sta __mw+1
    jsr __outline_24
    asl __mw
    rol __mw+1
    jsr __outline_24
    lda __tmp2
    clc
    adc __tmp0
    sta __tmp0
    lda __tmp3
    adc #$00
    sta __tmp1
    lda __tmp0
    sec
    sbc #$30
    sta __tmp2
    lda __tmp1
    sbc #$00
    jsr __outline_33
    iny
    jmp __F_parse_atom_while_40
__F_parse_atom_after_42:
    lda __L_parse_atom_value
    sta atom_value
    lda __L_parse_atom_value+1
    jsr __outline_22
    rts
__F_parse_atom_join_36:
    lda #$00
    sta __L_parse_atom_i
    ldy __L_parse_atom_i
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
__F_parse_atom_while_55:
    cpy __L_parse_atom_length
    bcs __F_parse_atom_after_57
__F_parse_atom_body_56:
    lda (__ap),y
    cmp #$2b
    beq __F_parse_atom_after_57
__F_parse_atom_no_59:
    cmp #$2d
    beq __F_parse_atom_after_57
__F_parse_atom_no_62:
    inc atom_used
    inc __L_parse_atom_i
    iny
    jmp __F_parse_atom_while_55
__F_parse_atom_after_57:
    lda atom_used
    cmp #$00
    bne __F_parse_atom_join_66
__F_parse_atom_yes_64:
    lda VALUE_BAD
    rts
__F_parse_atom_join_66:
    lda __L_parse_atom_text
    sta __call_find_symbol_0
    lda __L_parse_atom_text+1
    sta __call_find_symbol_0+1
    lda atom_used
    jsr find_symbol
    sta __L_parse_atom_symbol
    stx __L_parse_atom_symbol+1
    lda __L_parse_atom_symbol+1
    cmp #$ff
    bne __F_parse_atom_join_69
    lda __L_parse_atom_symbol
    cmp #$fe
    bne __F_parse_atom_join_69
__F_parse_atom_yes_67:
    lda VALUE_SCOPE_ERROR
    rts
__F_parse_atom_join_69:
    lda __L_parse_atom_symbol+1
    bpl __F_parse_atom_join_72
__F_parse_atom_yes_70:
    lda __L_parse_atom_text
    sta __call_intern_label_0
    lda __L_parse_atom_text+1
    sta __call_intern_label_0+1
    lda atom_used
    jsr intern_label
    sta __L_parse_atom_symbol
    stx __L_parse_atom_symbol+1
    lda __L_parse_atom_symbol+1
    cmp #$ff
    bne __F_parse_atom_join_75
    lda __L_parse_atom_symbol
    cmp #$fe
    bne __F_parse_atom_join_75
__F_parse_atom_yes_73:
    lda VALUE_SCOPE_ERROR
    rts
__F_parse_atom_join_75:
    lda __L_parse_atom_symbol+1
    cmp #$ff
    bne __F_parse_atom_join_78
    lda __L_parse_atom_symbol
    cmp #$fd
    bne __F_parse_atom_join_78
__F_parse_atom_yes_76:
    lda VALUE_SYMBOL_FULL
    rts
__F_parse_atom_join_78:
    lda __L_parse_atom_symbol+1
    bpl __F_parse_atom_join_72
__F_parse_atom_yes_79:
    lda VALUE_BAD
    rts
__F_parse_atom_join_72:
    clc
    lda __L_parse_atom_symbol
    adc #<symbol_kind
    sta __ap
    lda __L_parse_atom_symbol+1
    adc #>symbol_kind
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp SYMBOL_LABEL_UNDEFINED
    bne __F_parse_atom_join_84
__F_parse_atom_yes_82:
    lda __L_parse_atom_symbol
    sta atom_symbol
    lda __L_parse_atom_symbol+1
    sta atom_symbol+1
    lda #$01
    sta atom_kind
    lda VALUE_UNRESOLVED
    rts
__F_parse_atom_join_84:
    lda __L_parse_atom_symbol
    asl
    sta __ix
    lda __L_parse_atom_symbol+1
    jsr __outline_03
    lda (__ap),y
    sta atom_value
    iny
    lda (__ap),y
    jsr __outline_22
    rts
parse_value:
__F_parse_value_entry:
    sta __L_parse_value_length
    lda #$ff
    sta captured_symbol
    sta captured_symbol+1
    lda #$00
    sta captured_addend
    sta captured_addend+1
    lda VALUE_PREFIX_NONE
    sta captured_prefix
    lda __L_parse_value_length
    cmp #$00
    bne __F_parse_value_join_3
__F_parse_value_yes_1:
    lda VALUE_BAD
    rts
__F_parse_value_join_3:
    lda #$00
    sta __L_parse_value_position
    ldy __L_parse_value_position
    lda __L_parse_value_text
    sta __ap
    lda __L_parse_value_text+1
    sta __ap+1
    lda (__ap),y
    cmp #$3c
    bne __F_parse_value_no_5
__F_parse_value_yes_4:
    lda VALUE_PREFIX_LOW
    sta captured_prefix
    inc __L_parse_value_position
    jmp __F_parse_value_join_6
__F_parse_value_no_5:
    cmp #$3e
    bne __F_parse_value_join_6
__F_parse_value_yes_7:
    lda VALUE_PREFIX_HIGH
    sta captured_prefix
    inc __L_parse_value_position
__F_parse_value_join_6:
    jsr __outline_08
    jsr parse_atom
    sta __L_parse_value_status
    cmp VALUE_OK
    beq __F_parse_value_join_12
__F_parse_value_yes_10:
    cmp VALUE_UNRESOLVED
    beq __F_parse_value_join_12
__F_parse_value_yes_13:
    lda __L_parse_value_status
    rts
__F_parse_value_join_12:
    lda atom_kind
    sta __L_parse_value_first_kind
    lda atom_value
    sta __L_parse_value_first_value
    lda atom_value+1
    sta __L_parse_value_first_value+1
    lda atom_symbol
    sta __L_parse_value_first_symbol
    lda atom_symbol+1
    sta __L_parse_value_first_symbol+1
    lda __L_parse_value_position
    clc
    adc atom_used
    sta __L_parse_value_position
    lda __L_parse_value_first_kind
    cmp #$00
    bne __F_parse_value_no_17
__F_parse_value_yes_16:
    lda __L_parse_value_first_value
    sta captured_addend
    lda __L_parse_value_first_value+1
    sta captured_addend+1
    jmp __F_parse_value_join_18
__F_parse_value_no_17:
    lda __L_parse_value_first_symbol
    sta captured_symbol
    lda __L_parse_value_first_symbol+1
    sta captured_symbol+1
    lda #$00
    sta captured_addend
    sta captured_addend+1
__F_parse_value_join_18:
    lda __L_parse_value_position
    cmp __L_parse_value_length
    bcc __F_parse_value_yes_19
    jmp __F_parse_value_join_21
__F_parse_value_yes_19:
    ldy __L_parse_value_position
    lda __L_parse_value_text
    sta __ap
    lda __L_parse_value_text+1
    sta __ap+1
    lda (__ap),y
    sta __L_parse_value_operation
    cmp #$2b
    beq __F_parse_value_join_24
__F_parse_value_yes_22:
    cmp #$2d
    beq __F_parse_value_join_24
__F_parse_value_yes_25:
    lda VALUE_BAD
    rts
__F_parse_value_join_24:
    inc __L_parse_value_position
    jsr __outline_08
    jsr parse_atom
    sta __L_parse_value_status
    cmp VALUE_OK
    beq __F_parse_value_join_30
__F_parse_value_yes_28:
    cmp VALUE_UNRESOLVED
    beq __F_parse_value_join_30
__F_parse_value_yes_31:
    lda __L_parse_value_status
    rts
__F_parse_value_join_30:
    lda atom_kind
    tax
    lda __L_parse_value_position
    clc
    adc atom_used
    cmp __L_parse_value_length
    beq __F_parse_value_join_36
__F_parse_value_yes_34:
    lda VALUE_BAD
    rts
__F_parse_value_join_36:
    txa
    cmp #$00
    bne __F_parse_value_no_38
__F_parse_value_yes_37:
    lda __L_parse_value_operation
    cmp #$2b
    bne __F_parse_value_no_41
__F_parse_value_yes_40:
    lda captured_addend
    clc
    adc atom_value
    sta __tmp0
    lda captured_addend+1
    adc atom_value+1
    sta __tmp1
    lda __tmp0
    sta captured_addend
    lda __tmp1
    sta captured_addend+1
    jmp __F_parse_value_join_21
__F_parse_value_no_41:
    lda captured_addend
    sec
    sbc atom_value
    sta __tmp0
    lda captured_addend+1
    sbc atom_value+1
    sta __tmp1
    lda __tmp0
    sta captured_addend
    lda __tmp1
    sta captured_addend+1
    jmp __F_parse_value_join_21
__F_parse_value_no_38:
    lda captured_symbol+1
    bmi __F_parse_value_join_45
__F_parse_value_yes_43:
    lda VALUE_BAD
    rts
__F_parse_value_join_45:
    lda __L_parse_value_operation
    cmp #$2b
    beq __F_parse_value_join_48
__F_parse_value_yes_46:
    lda VALUE_BAD
    rts
__F_parse_value_join_48:
    lda atom_symbol
    sta captured_symbol
    lda atom_symbol+1
    sta captured_symbol+1
__F_parse_value_join_21:
    lda captured_symbol+1
    bmi __F_parse_value_join_51
__F_parse_value_yes_49:
    lda VALUE_UNRESOLVED
    rts
__F_parse_value_join_51:
    lda captured_addend
    sta value_result
    lda captured_addend+1
    sta value_result+1
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    beq __F_parse_value_join_54
__F_parse_value_yes_52:
    lda captured_addend
    sta __call_apply_byte_prefix_0
    lda captured_addend+1
    sta __call_apply_byte_prefix_0+1
    lda captured_prefix
    jsr apply_byte_prefix
    sta __tmp0
    lda __tmp0
    sta value_result
    lda #$00
    sta value_result+1
__F_parse_value_join_54:
    lda VALUE_OK
    rts
find_mnemonic:
__F_find_mnemonic_entry:
    sta __L_find_mnemonic_length
    cmp #$03
    beq __F_find_mnemonic_join_3
__F_find_mnemonic_yes_1:
    lda #$ff
    ldx #$ff
    rts
__F_find_mnemonic_join_3:
    lda #$00
    sta __L_find_mnemonic_candidate
__F_find_mnemonic_while_4:
    lda __L_find_mnemonic_candidate
    cmp #$38
    bcs __F_find_mnemonic_after_6
__F_find_mnemonic_body_5:
    lda #$00
    sta __tmp0
    lda __L_find_mnemonic_candidate
    sta __mw
    clc
    lda __tmp0
    adc __mw
    sta __tmp0
    asl __mw
    clc
    lda __tmp0
    adc __mw
    sta __L_find_mnemonic_offset
    ldy #$00
    jsr __outline_26
    jsr upper_char
    sta __tmp0
    ldy __L_find_mnemonic_offset
    lda mnemonic_table,y
    cmp __tmp0
    bne __F_find_mnemonic_join_9
__F_find_mnemonic_yes_7:
    ldy #$01
    jsr __outline_26
    jsr upper_char
    sta __tmp2
    lda __L_find_mnemonic_offset
    clc
    adc #$01
    jsr __outline_09
    bne __F_find_mnemonic_join_9
__F_find_mnemonic_yes_10:
    ldy #$02
    jsr __outline_26
    jsr upper_char
    sta __tmp2
    lda __L_find_mnemonic_offset
    clc
    adc #$02
    jsr __outline_09
    bne __F_find_mnemonic_join_9
__F_find_mnemonic_yes_13:
    lda __L_find_mnemonic_candidate
    ldx #$00
    rts
__F_find_mnemonic_join_9:
    inc __L_find_mnemonic_candidate
    jmp __F_find_mnemonic_while_4
__F_find_mnemonic_after_6:
    lda #$ff
    ldx #$ff
    rts
find_opcode:
__F_find_opcode_entry:
    sta __L_find_opcode_mode
    lda #$00
    ldy #$00
__F_find_opcode_while_1:
__F_find_opcode_body_2:
    lda opcode_mnemonic,y
    cmp __L_find_opcode_mnemonic
    bne __F_find_opcode_join_6
__F_find_opcode_yes_4:
    lda opcode_mode,y
    cmp __L_find_opcode_mode
    bne __F_find_opcode_join_6
__F_find_opcode_yes_7:
    tya
    ldx #$00
    rts
__F_find_opcode_join_6:
    iny
    bne __F_find_opcode_while_1
__F_find_opcode_after_3:
    lda #$ff
    ldx #$ff
    rts
stage_byte:
__F_stage_byte_entry:
    sta __L_stage_byte_value
    lda ass_image_length+1
    eor #$80
    cmp #$ac
    bcc __F_stage_byte_join_3
    bne __F_stage_byte_yes_1
    lda ass_image_length
    cmp #$00
    bcc __F_stage_byte_join_3
__F_stage_byte_yes_1:
    lda ASSEMBLE_WORK_FULL
    rts
__F_stage_byte_join_3:
    clc
    lda ass_image_length
    adc #<ass_image
    sta __ap
    lda ass_image_length+1
    adc #>ass_image
    sta __ap+1
    ldy #$00
    lda __L_stage_byte_value
    sta (__ap),y
    lda ass_image_length
    clc
    adc #$01
    sta __tmp0
    lda ass_image_length+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta ass_image_length
    lda __tmp1
    sta ass_image_length+1
    lda ASSEMBLE_OK
    rts
stage_plain_word_reference:
__F_stage_plain_word_reference_entry:
    lda ass_image_length
    sta __L_stage_plain_word_reference_stage
    lda ass_image_length+1
    sta __L_stage_plain_word_reference_stage+1
    lda __L_stage_plain_word_reference_symbol
    asl
    sta __ix
    lda __L_stage_plain_word_reference_symbol+1
    jsr __outline_03
    jsr __outline_36
    lda __tmp0
    sta __L_stage_plain_word_reference_old_head
    lda __tmp1
    sta __L_stage_plain_word_reference_old_head+1
    lda __L_stage_plain_word_reference_old_head
    jsr stage_byte
    sta __L_stage_plain_word_reference_status
    cmp ASSEMBLE_OK
    beq __F_stage_plain_word_reference_join_3
__F_stage_plain_word_reference_yes_1:
    lda __L_stage_plain_word_reference_status
    rts
__F_stage_plain_word_reference_join_3:
    lda __L_stage_plain_word_reference_old_head+1
    jsr stage_byte
    sta __L_stage_plain_word_reference_status
    cmp ASSEMBLE_OK
    beq __F_stage_plain_word_reference_join_6
__F_stage_plain_word_reference_yes_4:
    lda __L_stage_plain_word_reference_status
    rts
__F_stage_plain_word_reference_join_6:
    lda __L_stage_plain_word_reference_stage
    clc
    adc #$01
    sta __tmp0
    lda __L_stage_plain_word_reference_stage+1
    adc #$00
    sta __tmp1
    lda __L_stage_plain_word_reference_symbol
    asl
    sta __ix
    lda __L_stage_plain_word_reference_symbol+1
    jsr __outline_03
    lda __tmp0
    sta (__ap),y
    iny
    lda __tmp1
    sta (__ap),y
    lda ASSEMBLE_OK
    rts
stage_resolved_instruction:
__F_stage_resolved_instruction_entry:
    ldy __L_stage_resolved_instruction_mode
    lda mode_width,y
    sta __L_stage_resolved_instruction_width
    cmp #$01
    bne __F_stage_resolved_instruction_join_3
__F_stage_resolved_instruction_yes_1:
    lda __L_stage_resolved_instruction_value+1
    cmp #$00
    bcc __F_stage_resolved_instruction_join_3
    bne __F_stage_resolved_instruction_yes_4
    lda __L_stage_resolved_instruction_value
    cmp #$ff
    bcc __F_stage_resolved_instruction_join_3
    beq __F_stage_resolved_instruction_join_3
__F_stage_resolved_instruction_yes_4:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_stage_resolved_instruction_join_3:
    lda __L_stage_resolved_instruction_opcode
    jsr stage_byte
    sta __L_stage_resolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_resolved_instruction_join_9
__F_stage_resolved_instruction_yes_7:
    lda __L_stage_resolved_instruction_status
    rts
__F_stage_resolved_instruction_join_9:
    lda __L_stage_resolved_instruction_width
    cmp #$00
    bne __F_stage_resolved_instruction_join_12
__F_stage_resolved_instruction_yes_10:
    lda ASSEMBLE_OK
    rts
__F_stage_resolved_instruction_join_12:
    lda __L_stage_resolved_instruction_value
    jsr stage_byte
    sta __L_stage_resolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_resolved_instruction_join_15
__F_stage_resolved_instruction_yes_13:
    lda __L_stage_resolved_instruction_status
    rts
__F_stage_resolved_instruction_join_15:
    lda __L_stage_resolved_instruction_width
    cmp #$02
    bne __F_stage_resolved_instruction_join_18
__F_stage_resolved_instruction_yes_16:
    lda __L_stage_resolved_instruction_value+1
    jsr stage_byte
    rts
__F_stage_resolved_instruction_join_18:
    lda ASSEMBLE_OK
    rts
stage_resolved_relative:
__F_stage_resolved_relative_entry:
    jsr __outline_21
    clc
    adc #$02
    sta __tmp2
    lda __tmp1
    adc #$00
    sta __tmp3
    lda __tmp2
    sta __L_stage_resolved_relative_base
    lda __tmp3
    sta __L_stage_resolved_relative_base+1
    lda __L_stage_resolved_relative_target
    sta __call_relative_byte_0
    lda __L_stage_resolved_relative_target+1
    sta __call_relative_byte_0+1
    lda __L_stage_resolved_relative_base
    sta __call_relative_byte_1
    lda __L_stage_resolved_relative_base+1
    sta __call_relative_byte_1+1
    jsr relative_byte
    sta __L_stage_resolved_relative_relative
    stx __L_stage_resolved_relative_relative+1
    lda __L_stage_resolved_relative_relative+1
    bpl __F_stage_resolved_relative_join_3
__F_stage_resolved_relative_yes_1:
    lda ASSEMBLE_EMIT_ERROR
    rts
__F_stage_resolved_relative_join_3:
    lda __L_stage_resolved_relative_opcode
    jsr stage_byte
    sta __L_stage_resolved_relative_status
    cmp ASSEMBLE_OK
    beq __F_stage_resolved_relative_join_6
__F_stage_resolved_relative_yes_4:
    lda __L_stage_resolved_relative_status
    rts
__F_stage_resolved_relative_join_6:
    lda __L_stage_resolved_relative_relative
    jsr stage_byte
    rts
stage_unresolved_instruction:
__F_stage_unresolved_instruction_entry:
    sta __L_stage_unresolved_instruction_prefix
    ldy __L_stage_unresolved_instruction_mode
    lda mode_width,y
    sta __L_stage_unresolved_instruction_width
    lda __L_stage_unresolved_instruction_opcode
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_unresolved_instruction_join_3
__F_stage_unresolved_instruction_yes_1:
    lda __L_stage_unresolved_instruction_status
    rts
__F_stage_unresolved_instruction_join_3:
    lda ass_image_length
    sta __L_stage_unresolved_instruction_stage
    lda ass_image_length+1
    sta __L_stage_unresolved_instruction_stage+1
    lda __L_stage_unresolved_instruction_width
    cmp #$02
    bne __F_stage_unresolved_instruction_join_6
__F_stage_unresolved_instruction_yes_4:
    lda __L_stage_unresolved_instruction_prefix
    cmp VALUE_PREFIX_NONE
    bne __F_stage_unresolved_instruction_join_9
__F_stage_unresolved_instruction_yes_7:
    lda __L_stage_unresolved_instruction_addend
    ora __L_stage_unresolved_instruction_addend+1
    bne __F_stage_unresolved_instruction_join_9
__F_stage_unresolved_instruction_yes_10:
    lda __L_stage_unresolved_instruction_symbol
    sta __call_stage_plain_word_reference_0
    lda __L_stage_unresolved_instruction_symbol+1
    sta __call_stage_plain_word_reference_0+1
    jsr stage_plain_word_reference
    rts
__F_stage_unresolved_instruction_join_9:
    lda #$00
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_unresolved_instruction_join_15
__F_stage_unresolved_instruction_yes_13:
    lda __L_stage_unresolved_instruction_status
    rts
__F_stage_unresolved_instruction_join_15:
    lda #$00
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_unresolved_instruction_join_18
__F_stage_unresolved_instruction_yes_16:
    lda __L_stage_unresolved_instruction_status
    rts
__F_stage_unresolved_instruction_join_18:
    lda FIXUP_WORD
    jsr __outline_06
    jsr append_fixup
    rts
__F_stage_unresolved_instruction_join_6:
    cmp #$01
    beq __F_stage_unresolved_instruction_join_21
__F_stage_unresolved_instruction_yes_19:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_stage_unresolved_instruction_join_21:
    lda #$00
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_unresolved_instruction_join_24
__F_stage_unresolved_instruction_yes_22:
    lda __L_stage_unresolved_instruction_status
    rts
__F_stage_unresolved_instruction_join_24:
    lda FIXUP_BYTE
    tax
    lda __L_stage_unresolved_instruction_mode
    cmp MODE_RELATIVE
    bne __F_stage_unresolved_instruction_join_27
__F_stage_unresolved_instruction_yes_25:
    lda FIXUP_RELATIVE
    tax
__F_stage_unresolved_instruction_join_27:
    txa
    jsr __outline_06
    jsr append_fixup
    rts
short_mode_for_index:
__F_short_mode_for_index_entry:
    sta __L_short_mode_for_index_index
    cmp #$01
    bne __F_short_mode_for_index_join_3
__F_short_mode_for_index_yes_1:
    lda MODE_ZERO_PAGE_X
    rts
__F_short_mode_for_index_join_3:
    cmp #$02
    bne __F_short_mode_for_index_join_6
__F_short_mode_for_index_yes_4:
    lda MODE_ZERO_PAGE_Y
    rts
__F_short_mode_for_index_join_6:
    lda MODE_ZERO_PAGE
    rts
long_mode_for_index:
__F_long_mode_for_index_entry:
    sta __L_long_mode_for_index_index
    cmp #$01
    bne __F_long_mode_for_index_join_3
__F_long_mode_for_index_yes_1:
    lda MODE_ABSOLUTE_X
    rts
__F_long_mode_for_index_join_3:
    cmp #$02
    bne __F_long_mode_for_index_join_6
__F_long_mode_for_index_yes_4:
    lda MODE_ABSOLUTE_Y
    rts
__F_long_mode_for_index_join_6:
    lda MODE_ABSOLUTE
    rts
assemble_mode_value:
__F_assemble_mode_value_entry:
    sta __L_assemble_mode_value_length
    lda __L_assemble_mode_value_mnemonic
    sta __call_find_opcode_0
    lda __L_assemble_mode_value_mode
    jsr find_opcode
    sta __L_assemble_mode_value_opcode
    stx __L_assemble_mode_value_opcode+1
    lda __L_assemble_mode_value_opcode+1
    bpl __F_assemble_mode_value_join_3
__F_assemble_mode_value_yes_1:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_mode_value_join_3:
    lda __L_assemble_mode_value_text
    sta __call_parse_value_0
    lda __L_assemble_mode_value_text+1
    sta __call_parse_value_0+1
    lda __L_assemble_mode_value_length
    jsr parse_value
    sta __L_assemble_mode_value_status
    cmp VALUE_OK
    bne __F_assemble_mode_value_join_6
__F_assemble_mode_value_yes_4:
    lda __L_assemble_mode_value_mode
    cmp MODE_RELATIVE
    bne __F_assemble_mode_value_join_9
__F_assemble_mode_value_yes_7:
    lda __L_assemble_mode_value_opcode
    sta __call_stage_resolved_relative_0
    lda value_result
    sta __call_stage_resolved_relative_1
    lda value_result+1
    sta __call_stage_resolved_relative_1+1
    jsr stage_resolved_relative
    rts
__F_assemble_mode_value_join_9:
    lda __L_assemble_mode_value_opcode
    sta __call_stage_resolved_instruction_0
    lda __L_assemble_mode_value_mode
    jsr __outline_18
    jsr stage_resolved_instruction
    rts
__F_assemble_mode_value_join_6:
    cmp VALUE_UNRESOLVED
    bne __F_assemble_mode_value_join_12
__F_assemble_mode_value_yes_10:
    lda __L_assemble_mode_value_opcode
    sta __call_stage_unresolved_instruction_0
    lda __L_assemble_mode_value_mode
    jsr __outline_13
    jsr stage_unresolved_instruction
    rts
__F_assemble_mode_value_join_12:
    cmp VALUE_SYMBOL_FULL
    bne __F_assemble_mode_value_join_15
__F_assemble_mode_value_yes_13:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_assemble_mode_value_join_15:
    cmp VALUE_SCOPE_ERROR
    bne __F_assemble_mode_value_join_18
__F_assemble_mode_value_yes_16:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_assemble_mode_value_join_18:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
assemble_direct_value:
__F_assemble_direct_value_entry:
    sta __L_assemble_direct_value_index
    cmp #$00
    bne __F_assemble_direct_value_join_3
__F_assemble_direct_value_yes_1:
    lda __L_assemble_direct_value_mnemonic
    sta __call_find_opcode_0
    lda MODE_RELATIVE
    jsr find_opcode
    stx __L_assemble_direct_value_opcode+1
    lda __L_assemble_direct_value_opcode+1
    bmi __F_assemble_direct_value_join_3
__F_assemble_direct_value_yes_4:
    lda __L_assemble_direct_value_mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_RELATIVE
    sta __call_assemble_mode_value_1
    lda __L_assemble_direct_value_text
    sta __call_assemble_mode_value_2
    lda __L_assemble_direct_value_text+1
    sta __call_assemble_mode_value_2+1
    lda __L_assemble_direct_value_length
    jsr assemble_mode_value
    rts
__F_assemble_direct_value_join_3:
    lda __L_assemble_direct_value_text
    sta __call_parse_value_0
    lda __L_assemble_direct_value_text+1
    sta __call_parse_value_0+1
    lda __L_assemble_direct_value_length
    jsr parse_value
    sta __L_assemble_direct_value_status
    cmp VALUE_OK
    beq __F_assemble_direct_value_join_9
__F_assemble_direct_value_yes_7:
    cmp VALUE_UNRESOLVED
    beq __F_assemble_direct_value_join_9
__F_assemble_direct_value_yes_10:
    cmp VALUE_SYMBOL_FULL
    bne __F_assemble_direct_value_join_15
__F_assemble_direct_value_yes_13:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_assemble_direct_value_join_15:
    cmp VALUE_SCOPE_ERROR
    bne __F_assemble_direct_value_join_18
__F_assemble_direct_value_yes_16:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_assemble_direct_value_join_18:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_direct_value_join_9:
    lda __L_assemble_direct_value_index
    jsr short_mode_for_index
    sta __L_assemble_direct_value_short_mode
    lda __L_assemble_direct_value_index
    jsr long_mode_for_index
    sta __L_assemble_direct_value_long_mode
    lda __L_assemble_direct_value_mnemonic
    sta __call_find_opcode_0
    lda __L_assemble_direct_value_short_mode
    jsr find_opcode
    sta __L_assemble_direct_value_short_opcode
    stx __L_assemble_direct_value_short_opcode+1
    lda __L_assemble_direct_value_mnemonic
    sta __call_find_opcode_0
    lda __L_assemble_direct_value_long_mode
    jsr find_opcode
    sta __L_assemble_direct_value_long_opcode
    stx __L_assemble_direct_value_long_opcode+1
    lda __L_assemble_direct_value_status
    cmp VALUE_OK
    bne __F_assemble_direct_value_join_21
__F_assemble_direct_value_yes_19:
    lda value_result+1
    cmp #$00
    bcc __F_assemble_direct_value_yes_22
    bne __F_assemble_direct_value_join_24
    lda value_result
    cmp #$ff
    bcc __F_assemble_direct_value_yes_22
    bne __F_assemble_direct_value_join_24
__F_assemble_direct_value_yes_22:
    lda __L_assemble_direct_value_short_opcode+1
    bmi __F_assemble_direct_value_join_24
__F_assemble_direct_value_yes_25:
    lda __L_assemble_direct_value_short_opcode
    sta __call_stage_resolved_instruction_0
    lda __L_assemble_direct_value_short_mode
    jsr __outline_18
    jsr stage_resolved_instruction
    rts
__F_assemble_direct_value_join_24:
    lda __L_assemble_direct_value_long_opcode+1
    bmi __F_assemble_direct_value_join_30
__F_assemble_direct_value_yes_28:
    lda __L_assemble_direct_value_long_opcode
    sta __call_stage_resolved_instruction_0
    lda __L_assemble_direct_value_long_mode
    jsr __outline_18
    jsr stage_resolved_instruction
    rts
__F_assemble_direct_value_join_30:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_direct_value_join_21:
    lda __L_assemble_direct_value_long_mode
    tax
    lda __L_assemble_direct_value_long_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_long_opcode+1
    sta __L_assemble_direct_value_opcode+1
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    beq __F_assemble_direct_value_no_32
__F_assemble_direct_value_yes_31:
    lda __L_assemble_direct_value_short_mode
    tax
    lda __L_assemble_direct_value_short_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_short_opcode+1
    sta __L_assemble_direct_value_opcode+1
    jmp __F_assemble_direct_value_join_33
__F_assemble_direct_value_no_32:
    lda __L_assemble_direct_value_long_opcode+1
    bpl __F_assemble_direct_value_join_33
__F_assemble_direct_value_yes_34:
    lda __L_assemble_direct_value_short_mode
    tax
    lda __L_assemble_direct_value_short_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_short_opcode+1
    sta __L_assemble_direct_value_opcode+1
__F_assemble_direct_value_join_33:
    lda __L_assemble_direct_value_opcode+1
    bpl __F_assemble_direct_value_join_39
__F_assemble_direct_value_yes_37:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_direct_value_join_39:
    lda __L_assemble_direct_value_opcode
    sta __call_stage_unresolved_instruction_0
    txa
    jsr __outline_13
    jsr stage_unresolved_instruction
    rts
assemble_instruction:
__F_assemble_instruction_entry:
    sta __L_assemble_instruction_argument_length
    lda __L_assemble_instruction_name
    sta __call_find_mnemonic_0
    lda __L_assemble_instruction_name+1
    sta __call_find_mnemonic_0+1
    lda __L_assemble_instruction_name_length
    jsr find_mnemonic
    sta __L_assemble_instruction_mnemonic
    stx __L_assemble_instruction_mnemonic+1
    lda __L_assemble_instruction_mnemonic+1
    bpl __F_assemble_instruction_join_3
__F_assemble_instruction_yes_1:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_3:
    lda __L_assemble_instruction_argument_length
    cmp #$00
    bne __F_assemble_instruction_join_6
__F_assemble_instruction_yes_4:
    lda __L_assemble_instruction_mnemonic
    sta __call_find_opcode_0
    lda MODE_IMPLIED
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda __L_assemble_instruction_opcode+1
    bmi __F_assemble_instruction_join_9
__F_assemble_instruction_yes_7:
    lda __L_assemble_instruction_opcode
    sta __call_stage_resolved_instruction_0
    lda MODE_IMPLIED
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    rts
__F_assemble_instruction_join_9:
    lda __L_assemble_instruction_mnemonic
    sta __call_find_opcode_0
    lda MODE_ACCUMULATOR
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda __L_assemble_instruction_opcode+1
    bmi __F_assemble_instruction_join_12
__F_assemble_instruction_yes_10:
    jsr __outline_34
    jsr stage_resolved_instruction
    rts
__F_assemble_instruction_join_12:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_6:
    cmp #$01
    bne __F_assemble_instruction_join_15
__F_assemble_instruction_yes_13:
    ldy #$00
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda (__ap),y
    jsr upper_char
    cmp #$41
    bne __F_assemble_instruction_join_15
__F_assemble_instruction_yes_16:
    lda __L_assemble_instruction_mnemonic
    sta __call_find_opcode_0
    lda MODE_ACCUMULATOR
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda __L_assemble_instruction_opcode+1
    bpl __F_assemble_instruction_join_21
__F_assemble_instruction_yes_19:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_21:
    jsr __outline_34
    jsr stage_resolved_instruction
    rts
__F_assemble_instruction_join_15:
    ldy #$00
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda (__ap),y
    cmp #$23
    bne __F_assemble_instruction_join_24
__F_assemble_instruction_yes_22:
    lda __L_assemble_instruction_argument_length
    cmp #$02
    bcs __F_assemble_instruction_join_27
__F_assemble_instruction_yes_25:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_27:
    jsr __outline_05
    lda __L_assemble_instruction_argument_length
    jsr __outline_12
    lda __L_assemble_instruction_mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_IMMEDIATE
    sta __call_assemble_mode_value_1
    lda __tmp0
    jsr assemble_mode_value
    rts
__F_assemble_instruction_join_24:
    cmp #$28
    beq __F_assemble_instruction_yes_28
    jmp __F_assemble_instruction_join_30
__F_assemble_instruction_yes_28:
    lda __L_assemble_instruction_argument_length
    cmp #$03
    bcs __F_assemble_instruction_join_33
__F_assemble_instruction_yes_31:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_33:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    jsr __outline_02
    jsr __outline_01
    jsr upper_char
    cmp #$59
    bne __F_assemble_instruction_join_36
__F_assemble_instruction_yes_34:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    jsr __outline_02
    jsr __outline_01
    cmp #$2c
    bne __F_assemble_instruction_join_36
__F_assemble_instruction_yes_37:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$03
    jsr __outline_02
    jsr __outline_01
    cmp #$29
    beq __F_assemble_instruction_join_42
__F_assemble_instruction_yes_40:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_42:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$04
    sta __L_assemble_instruction_core_length
    cmp #$00
    bcc __F_assemble_instruction_yes_43
    bne __F_assemble_instruction_join_45
__F_assemble_instruction_yes_43:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_45:
    jsr __outline_05
    lda __L_assemble_instruction_mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_INDIRECT_Y
    sta __call_assemble_mode_value_1
    lda __L_assemble_instruction_core_length
    jsr assemble_mode_value
    rts
__F_assemble_instruction_join_36:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    jsr __outline_02
    jsr __outline_01
    cmp #$29
    beq __F_assemble_instruction_join_48
__F_assemble_instruction_yes_46:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_48:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    jsr __outline_02
    jsr __outline_01
    jsr upper_char
    cmp #$58
    bne __F_assemble_instruction_join_51
__F_assemble_instruction_yes_49:
    lda __L_assemble_instruction_argument_length
    cmp #$05
    bcs __F_assemble_instruction_join_54
__F_assemble_instruction_yes_52:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_54:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$03
    jsr __outline_02
    jsr __outline_01
    cmp #$2c
    beq __F_assemble_instruction_join_57
__F_assemble_instruction_yes_55:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_57:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$04
    sta __L_assemble_instruction_core_length
    jsr __outline_05
    lda __L_assemble_instruction_mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_INDIRECT_X
    sta __call_assemble_mode_value_1
    lda __L_assemble_instruction_core_length
    jsr assemble_mode_value
    rts
__F_assemble_instruction_join_51:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
    jsr __outline_05
    lda __L_assemble_instruction_mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_INDIRECT
    sta __call_assemble_mode_value_1
    lda __L_assemble_instruction_core_length
    jsr assemble_mode_value
    rts
__F_assemble_instruction_join_30:
    lda #$00
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sta __L_assemble_instruction_core_length
    cmp #$03
    bcc __F_assemble_instruction_join_60
__F_assemble_instruction_yes_58:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    jsr __outline_02
    jsr __outline_01
    cmp #$2c
    bne __F_assemble_instruction_join_60
__F_assemble_instruction_yes_61:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    jsr __outline_02
    jsr __outline_01
    jsr upper_char
    cmp #$58
    bne __F_assemble_instruction_no_65
__F_assemble_instruction_yes_64:
    lda #$01
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
    jmp __F_assemble_instruction_join_60
__F_assemble_instruction_no_65:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    jsr __outline_02
    jsr __outline_01
    jsr upper_char
    cmp #$59
    bne __F_assemble_instruction_join_60
__F_assemble_instruction_yes_67:
    lda #$02
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
__F_assemble_instruction_join_60:
    lda __L_assemble_instruction_mnemonic
    sta __call_assemble_direct_value_0
    lda __L_assemble_instruction_argument
    sta __call_assemble_direct_value_1
    lda __L_assemble_instruction_argument+1
    sta __call_assemble_direct_value_1+1
    lda __L_assemble_instruction_core_length
    sta __call_assemble_direct_value_2
    lda __L_assemble_instruction_index
    jsr assemble_direct_value
    rts
stage_data_value:
__F_stage_data_value_entry:
    sta __L_stage_data_value_width
    lda __L_stage_data_value_text
    sta __call_parse_value_0
    lda __L_stage_data_value_text+1
    sta __call_parse_value_0+1
    lda __L_stage_data_value_length
    jsr parse_value
    sta __L_stage_data_value_status
    cmp VALUE_OK
    bne __F_stage_data_value_join_3
__F_stage_data_value_yes_1:
    lda __L_stage_data_value_width
    cmp #$01
    bne __F_stage_data_value_join_6
__F_stage_data_value_yes_4:
    lda value_result+1
    cmp #$00
    bcc __F_stage_data_value_join_9
    bne __F_stage_data_value_yes_7
    lda value_result
    cmp #$ff
    bcc __F_stage_data_value_join_9
    beq __F_stage_data_value_join_9
__F_stage_data_value_yes_7:
    lda ASSEMBLE_BAD_DATA
    rts
__F_stage_data_value_join_9:
    lda value_result
    jsr stage_byte
    rts
__F_stage_data_value_join_6:
    lda value_result
    jsr stage_byte
    sta __L_stage_data_value_status
    cmp ASSEMBLE_OK
    beq __F_stage_data_value_join_12
__F_stage_data_value_yes_10:
    lda __L_stage_data_value_status
    rts
__F_stage_data_value_join_12:
    lda value_result+1
    jsr stage_byte
    rts
__F_stage_data_value_join_3:
    cmp VALUE_UNRESOLVED
    beq __F_stage_data_value_yes_13
    jmp __F_stage_data_value_join_15
__F_stage_data_value_yes_13:
    lda __L_stage_data_value_width
    cmp #$02
    bne __F_stage_data_value_join_18
__F_stage_data_value_yes_16:
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    bne __F_stage_data_value_join_18
__F_stage_data_value_yes_19:
    lda captured_addend
    ora captured_addend+1
    bne __F_stage_data_value_join_18
__F_stage_data_value_yes_22:
    lda captured_symbol
    sta __call_stage_plain_word_reference_0
    lda captured_symbol+1
    sta __call_stage_plain_word_reference_0+1
    jsr stage_plain_word_reference
    rts
__F_stage_data_value_join_18:
    lda ass_image_length
    sta __L_stage_data_value_stage
    lda ass_image_length+1
    sta __L_stage_data_value_stage+1
    lda #$00
    jsr stage_byte
    sta __L_stage_data_value_status
    cmp ASSEMBLE_OK
    beq __F_stage_data_value_join_27
__F_stage_data_value_yes_25:
    lda __L_stage_data_value_status
    rts
__F_stage_data_value_join_27:
    lda __L_stage_data_value_width
    cmp #$02
    bne __F_stage_data_value_no_29
__F_stage_data_value_yes_28:
    lda #$00
    jsr stage_byte
    sta __L_stage_data_value_status
    cmp ASSEMBLE_OK
    beq __F_stage_data_value_join_33
__F_stage_data_value_yes_31:
    lda __L_stage_data_value_status
    rts
__F_stage_data_value_join_33:
    lda FIXUP_WORD
    sta __L_stage_data_value_kind
    jmp __F_stage_data_value_join_30
__F_stage_data_value_no_29:
    lda FIXUP_DATA_BYTE
    sta __L_stage_data_value_kind
__F_stage_data_value_join_30:
    sta __call_append_fixup_0
    lda __L_stage_data_value_stage
    sta __call_append_fixup_1
    lda __L_stage_data_value_stage+1
    sta __call_append_fixup_1+1
    lda captured_symbol
    sta __call_append_fixup_2
    lda captured_symbol+1
    sta __call_append_fixup_2+1
    lda captured_addend
    sta __call_append_fixup_3
    lda captured_addend+1
    sta __call_append_fixup_3+1
    lda captured_prefix
    jsr append_fixup
    rts
__F_stage_data_value_join_15:
    cmp VALUE_SYMBOL_FULL
    bne __F_stage_data_value_join_36
__F_stage_data_value_yes_34:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_stage_data_value_join_36:
    cmp VALUE_SCOPE_ERROR
    bne __F_stage_data_value_join_39
__F_stage_data_value_yes_37:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_stage_data_value_join_39:
    lda ASSEMBLE_BAD_DATA
    rts
assemble_data_list:
__F_assemble_data_list_entry:
    sta __L_assemble_data_list_width
    lda #$00
    sta __L_assemble_data_list_cursor
__F_assemble_data_list_while_1:
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_while_4
    jmp __F_assemble_data_list_after_3
__F_assemble_data_list_while_4:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_after_6
__F_assemble_data_list_body_5:
    jsr __outline_28
    cmp #$20
    bne __F_assemble_data_list_no_8
__F_assemble_data_list_yes_7:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_4
__F_assemble_data_list_no_8:
    cmp #$09
    bne __F_assemble_data_list_after_6
__F_assemble_data_list_yes_10:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_4
__F_assemble_data_list_after_6:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_join_15
__F_assemble_data_list_yes_13:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_data_list_join_15:
    lda __L_assemble_data_list_cursor
    sta __L_assemble_data_list_item_start
    tax
__F_assemble_data_list_while_16:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_after_18
__F_assemble_data_list_body_17:
    jsr __outline_28
    cmp #$2c
    beq __F_assemble_data_list_after_18
__F_assemble_data_list_join_21:
    cmp #$20
    beq __F_assemble_data_list_join_24
__F_assemble_data_list_yes_22:
    cmp #$09
    beq __F_assemble_data_list_join_24
__F_assemble_data_list_yes_25:
    lda __L_assemble_data_list_cursor
    clc
    adc #$01
    tax
__F_assemble_data_list_join_24:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_16
__F_assemble_data_list_after_18:
    txa
    cmp __L_assemble_data_list_item_start
    bne __F_assemble_data_list_join_30
__F_assemble_data_list_yes_28:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_data_list_join_30:
    lda __L_assemble_data_list_argument
    clc
    adc __L_assemble_data_list_item_start
    sta __call_stage_data_value_0
    lda __L_assemble_data_list_argument+1
    adc #$00
    sta __call_stage_data_value_0+1
    txa
    sec
    sbc __L_assemble_data_list_item_start
    sta __tmp0
    lda #$00
    sbc #$00
    lda __tmp0
    sta __call_stage_data_value_1
    lda __L_assemble_data_list_width
    jsr stage_data_value
    sta __L_assemble_data_list_status
    cmp ASSEMBLE_OK
    beq __F_assemble_data_list_join_33
__F_assemble_data_list_yes_31:
    lda __L_assemble_data_list_status
    rts
__F_assemble_data_list_join_33:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_join_36
__F_assemble_data_list_yes_34:
    lda ASSEMBLE_OK
    rts
__F_assemble_data_list_join_36:
    inc __L_assemble_data_list_cursor
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_yes_37
    jmp __F_assemble_data_list_while_1
__F_assemble_data_list_yes_37:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_data_list_after_3:
    lda ASSEMBLE_OK
    rts
assemble_string:
__F_assemble_string_entry:
    sta __L_assemble_string_length
    cmp #$02
    bcs __F_assemble_string_join_3
__F_assemble_string_yes_1:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_string_join_3:
    ldy #$00
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    sta __ap+1
    lda (__ap),y
    cmp #$22
    beq __F_assemble_string_join_6
__F_assemble_string_yes_4:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_string_join_6:
    lda __L_assemble_string_length
    jsr __outline_12
    sta __tmp1
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    jsr __outline_01
    cmp #$22
    beq __F_assemble_string_join_9
__F_assemble_string_yes_7:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_string_join_9:
    lda #$01
    sta __L_assemble_string_i
__F_assemble_string_while_10:
    lda __L_assemble_string_length
    jsr __outline_12
    eor #$80
    sta __rh
    lda #$80
    cmp __rh
    bcc __F_assemble_string_body_11
    bne __F_assemble_string_after_12
    lda __L_assemble_string_i
    cmp __tmp0
    bcs __F_assemble_string_after_12
__F_assemble_string_body_11:
    ldy __L_assemble_string_i
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    sta __ap+1
    lda (__ap),y
    jsr stage_byte
    sta __L_assemble_string_status
    cmp ASSEMBLE_OK
    beq __F_assemble_string_join_15
__F_assemble_string_yes_13:
    lda __L_assemble_string_status
    rts
__F_assemble_string_join_15:
    inc __L_assemble_string_i
    jmp __F_assemble_string_while_10
__F_assemble_string_after_12:
    lda #$00
    jsr stage_byte
    rts
open_include:
__F_open_include_entry:
    sta __L_open_include_length
    cmp #$03
    bcs __F_open_include_join_3
__F_open_include_yes_1:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_open_include_join_3:
    ldy #$00
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda (__ap),y
    cmp #$22
    beq __F_open_include_join_6
__F_open_include_yes_4:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_open_include_join_6:
    lda __L_open_include_length
    jsr __outline_12
    sta __tmp1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    jsr __outline_01
    cmp #$22
    beq __F_open_include_join_9
__F_open_include_yes_7:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_open_include_join_9:
    lda source_depth+1
    eor #$80
    cmp #$80
    bcc __F_open_include_join_12
    bne __F_open_include_yes_10
    lda source_depth
    cmp #$04
    bcc __F_open_include_join_12
__F_open_include_yes_10:
    lda ASSEMBLE_INCLUDE_DEPTH
    rts
__F_open_include_join_12:
    lda #$01
    sta __L_open_include_input_start
    lda __L_open_include_length
    sec
    sbc #$02
    sta __L_open_include_input_length
    lda #$00
    sta __L_open_include_output
    tax
    lda __L_open_include_input_length
    cmp #$03
    bcc __F_open_include_join_15
__F_open_include_yes_13:
    ldy __L_open_include_input_start
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda (__ap),y
    cmp #$2e
    bne __F_open_include_join_15
__F_open_include_yes_16:
    lda __L_open_include_input_start
    clc
    adc #$01
    jsr __outline_15
    jsr __outline_01
    cmp #$2e
    bne __F_open_include_join_15
__F_open_include_yes_19:
    lda __L_open_include_input_start
    clc
    adc #$02
    jsr __outline_15
    jsr __outline_01
    cmp #$2f
    bne __F_open_include_join_15
__F_open_include_yes_22:
    lda #$01
    tax
    lda __L_open_include_input_start
    clc
    adc #$03
    sta __L_open_include_input_start
    lda __L_open_include_input_length
    sec
    sbc #$03
    sta __L_open_include_input_length
__F_open_include_join_15:
    txa
    cmp #$00
    bne __F_open_include_join_27
__F_open_include_yes_25:
    lda #$00
    sta __L_open_include_i
__F_open_include_while_28:
    lda __L_open_include_i
    cmp source_directory_length
    bcs __F_open_include_join_27
__F_open_include_body_29:
    ldy __L_open_include_i
    lda source_directory
    sta __ap
    lda source_directory+1
    sta __ap+1
    lda (__ap),y
    sta __tmp0
    ldy __L_open_include_output
    lda __tmp0
    sta source_path,y
    inc __L_open_include_output
    inc __L_open_include_i
    jmp __F_open_include_while_28
__F_open_include_join_27:
    lda __L_open_include_output
    clc
    adc __L_open_include_input_length
    sta __tmp0
    lda #$00
    adc #$00
    eor #$80
    cmp #$80
    bcc __F_open_include_join_33
    bne __F_open_include_yes_31
    lda __tmp0
    cmp #$ff
    bcc __F_open_include_join_33
    beq __F_open_include_join_33
__F_open_include_yes_31:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_open_include_join_33:
    lda #$00
    sta __L_open_include_i
__F_open_include_while_34:
    lda __L_open_include_i
    cmp __L_open_include_input_length
    bcs __F_open_include_after_36
__F_open_include_body_35:
    lda __L_open_include_input_start
    clc
    adc __L_open_include_i
    jsr __outline_15
    jsr __outline_01
    sta __tmp2
    ldy __L_open_include_output
    lda __tmp2
    sta source_path,y
    inc __L_open_include_output
    inc __L_open_include_i
    jmp __F_open_include_while_34
__F_open_include_after_36:
    lda #<source_path
    sta __call_io_open_0
    lda #>source_path
    sta __call_io_open_0+1
    lda __L_open_include_output
    sta __call_io_open_1
    lda #$00
    sta __call_io_open_1+1
    jsr io_open
    sta __L_open_include_handle
    stx __L_open_include_handle+1
    lda __L_open_include_handle+1
    bpl __F_open_include_join_39
__F_open_include_yes_37:
    lda ASSEMBLE_IO_ERROR
    rts
__F_open_include_join_39:
    lda source_depth
    clc
    adc #$01
    sta __tmp0
    lda source_depth+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta source_depth
    lda __tmp1
    sta source_depth+1
    jsr __outline_04
    lda __L_open_include_handle
    sta (__ap),y
    lda ASSEMBLE_OK
    rts
read_source_line:
__F_read_source_line_entry:
    lda #$00
    sta source_line_length
    jsr __outline_04
    lda (__ap),y
    sta __L_read_source_line_handle
__F_read_source_line_while_1:
    lda #$01
    ora #$00
    beq __F_read_source_line_after_3
__F_read_source_line_body_2:
    lda __L_read_source_line_handle
    sta __call_io_read_0
    lda #$00
    sta __call_io_read_0+1
    jsr io_read
    sta __L_read_source_line_c
    stx __L_read_source_line_c+1
    lda __L_read_source_line_c+1
    bpl __F_read_source_line_join_6
__F_read_source_line_yes_4:
    cmp #$ff
    bne __F_read_source_line_join_9
    lda __L_read_source_line_c
    cmp #$ff
    bne __F_read_source_line_join_9
__F_read_source_line_yes_7:
    lda source_line_length
    cmp #$00
    beq __F_read_source_line_join_12
__F_read_source_line_yes_10:
    jsr __outline_19
    rts
__F_read_source_line_join_12:
    lda #$00
    ldx #$00
    rts
__F_read_source_line_join_9:
    lda #$ff
    ldx #$ff
    rts
__F_read_source_line_join_6:
    cmp #$00
    bne __F_read_source_line_join_15
    lda __L_read_source_line_c
    cmp #$0d
    bne __F_read_source_line_join_15
__F_read_source_line_yes_13:
    jsr __outline_19
    rts
__F_read_source_line_join_15:
    lda __L_read_source_line_c+1
    cmp #$00
    bne __F_read_source_line_join_18
    lda __L_read_source_line_c
    cmp #$0a
    bne __F_read_source_line_join_18
__F_read_source_line_yes_16:
    jsr __outline_19
    rts
__F_read_source_line_join_18:
    lda source_line_length
    cmp #$ff
    bcc __F_read_source_line_join_21
__F_read_source_line_yes_19:
    lda #$fe
    ldx #$ff
    rts
__F_read_source_line_join_21:
    ldy source_line_length
    lda __L_read_source_line_c
    sta source_line,y
    inc source_line_length
    jmp __F_read_source_line_while_1
__F_read_source_line_after_3:
    lda #$00
    ldx #$00
    rts
close_source_tree:
__F_close_source_tree_entry:
__F_close_source_tree_while_1:
    lda source_depth+1
    bmi __F_close_source_tree_after_3
__F_close_source_tree_body_2:
    jsr __outline_04
    lda (__ap),y
    sta __call_io_close_0
    lda #$00
    sta __call_io_close_0+1
    jsr io_close
    jsr __outline_14
    jmp __F_close_source_tree_while_1
__F_close_source_tree_after_3:
    lda ASSEMBLE_OK
    rts
scan_argument:
__F_scan_argument_entry:
    sta __L_scan_argument_start
    lda __L_scan_argument_start
    sta __L_scan_argument_i
    lda #$00
    tax
    lda __L_scan_argument_start
    sta __L_scan_argument_last
__F_scan_argument_while_1:
    lda __L_scan_argument_i
    cmp source_line_length
    bcs __F_scan_argument_after_3
__F_scan_argument_body_2:
    ldy __L_scan_argument_i
    lda source_line,y
    sta __L_scan_argument_c
    cmp #$3b
    bne __F_scan_argument_no_5
__F_scan_argument_yes_4:
    txa
    cmp #$00
    bne __F_scan_argument_no_8
__F_scan_argument_yes_7:
    lda source_line_length
    sta __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_no_8:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    inc __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_no_5:
    cmp #$27
    bne __F_scan_argument_no_11
__F_scan_argument_yes_10:
    txa
    cmp #$00
    bne __F_scan_argument_no_14
__F_scan_argument_yes_13:
    lda #$27
    tax
    jmp __F_scan_argument_join_15
__F_scan_argument_no_14:
    cmp #$27
    bne __F_scan_argument_join_15
__F_scan_argument_yes_16:
    lda #$00
    tax
__F_scan_argument_join_15:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    jmp __F_scan_argument_join_12
__F_scan_argument_no_11:
    cmp #$22
    bne __F_scan_argument_no_20
__F_scan_argument_yes_19:
    txa
    cmp #$00
    bne __F_scan_argument_no_23
__F_scan_argument_yes_22:
    lda #$22
    tax
    jmp __F_scan_argument_join_24
__F_scan_argument_no_23:
    cmp #$22
    bne __F_scan_argument_join_24
__F_scan_argument_yes_25:
    lda #$00
    tax
__F_scan_argument_join_24:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    jmp __F_scan_argument_join_12
__F_scan_argument_no_20:
    cmp #$20
    beq __F_scan_argument_join_12
__F_scan_argument_yes_28:
    cmp #$09
    beq __F_scan_argument_join_12
__F_scan_argument_yes_31:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
__F_scan_argument_join_12:
    inc __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_after_3:
    lda __L_scan_argument_last
    sec
    sbc __L_scan_argument_start
    jsr __outline_25
    ldx __tmp1
    rts
process_label:
__F_process_label_entry:
    sta __L_process_label_length
    cmp #$00
    bne __F_process_label_join_3
__F_process_label_yes_1:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_process_label_join_3:
    ldy #$00
    lda __L_process_label_name
    sta __ap
    lda __L_process_label_name+1
    sta __ap+1
    lda (__ap),y
    cmp #$2e
    bne __F_process_label_no_5
__F_process_label_yes_4:
    lda current_scope
    cmp #$00
    bne __F_process_label_join_6
__F_process_label_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_process_label_no_5:
    lda current_scope
    cmp #$ff
    bne __F_process_label_join_12
__F_process_label_yes_10:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_process_label_join_12:
    inc current_scope
__F_process_label_join_6:
    lda #$00
    sta origin_allowed
    jsr __outline_21
    sta __L_process_label_value
    lda __tmp1
    sta __L_process_label_value+1
    lda __L_process_label_name
    sta __call_define_label_0
    lda __L_process_label_name+1
    sta __call_define_label_0+1
    lda __L_process_label_length
    sta __call_define_label_1
    lda __L_process_label_value
    sta __call_define_label_2
    lda __L_process_label_value+1
    sta __call_define_label_2+1
    jsr define_label
    sta __L_process_label_status
    lda __L_process_label_status
    rts
process_symbol:
__F_process_symbol_entry:
    sta __L_process_symbol_argument_length
    lda __L_process_symbol_name_length
    cmp #$01
    bne __F_process_symbol_join_3
__F_process_symbol_yes_1:
    ldy #$00
    lda __L_process_symbol_name
    sta __ap
    lda __L_process_symbol_name+1
    sta __ap+1
    lda (__ap),y
    cmp #$2a
    bne __F_process_symbol_join_3
__F_process_symbol_yes_4:
    lda origin_allowed
    cmp #$00
    bne __F_process_symbol_join_9
__F_process_symbol_yes_7:
    lda ASSEMBLE_BAD_ORIGIN
    rts
__F_process_symbol_join_9:
    lda __L_process_symbol_argument
    sta __call_parse_value_0
    lda __L_process_symbol_argument+1
    sta __call_parse_value_0+1
    lda __L_process_symbol_argument_length
    jsr parse_value
    sta __L_process_symbol_status
    cmp VALUE_OK
    beq __F_process_symbol_join_12
__F_process_symbol_yes_10:
    lda ASSEMBLE_BAD_ORIGIN
    rts
__F_process_symbol_join_12:
    lda value_result
    sta ass_origin
    lda value_result+1
    sta ass_origin+1
    lda #$00
    sta origin_allowed
    lda ASSEMBLE_OK
    rts
__F_process_symbol_join_3:
    lda __L_process_symbol_argument
    sta __call_parse_value_0
    lda __L_process_symbol_argument+1
    sta __call_parse_value_0+1
    lda __L_process_symbol_argument_length
    jsr parse_value
    sta __L_process_symbol_status
    cmp VALUE_OK
    beq __F_process_symbol_join_15
__F_process_symbol_yes_13:
    cmp VALUE_SYMBOL_FULL
    bne __F_process_symbol_join_18
__F_process_symbol_yes_16:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_process_symbol_join_18:
    cmp VALUE_SCOPE_ERROR
    bne __F_process_symbol_join_21
__F_process_symbol_yes_19:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_process_symbol_join_21:
    lda ASSEMBLE_BAD_SYMBOL
    rts
__F_process_symbol_join_15:
    lda __L_process_symbol_name
    sta __call_define_constant_0
    lda __L_process_symbol_name+1
    sta __call_define_constant_0+1
    lda __L_process_symbol_name_length
    sta __call_define_constant_1
    lda value_result
    sta __call_define_constant_2
    lda value_result+1
    sta __call_define_constant_2+1
    jsr define_constant
    rts
process_instruction_like:
__F_process_instruction_like_entry:
    sta __L_process_instruction_like_argument_length
    jsr __outline_07
    lda #<__S_process_instruction_like___text_0
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_0
    sta __call_same_text_2+1
    lda #$07
    jsr same_text
    cmp #$00
    beq __F_process_instruction_like_join_3
__F_process_instruction_like_yes_1:
    lda __L_process_instruction_like_argument
    sta __call_open_include_0
    lda __L_process_instruction_like_argument+1
    sta __call_open_include_0+1
    lda __L_process_instruction_like_argument_length
    jsr open_include
    rts
__F_process_instruction_like_join_3:
    lda #$00
    sta origin_allowed
    jsr __outline_07
    lda #<__S_process_instruction_like___text_1
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_1
    sta __call_same_text_2+1
    lda #$04
    jsr same_text
    cmp #$00
    beq __F_process_instruction_like_join_6
__F_process_instruction_like_yes_4:
    jsr __outline_35
    lda #$01
    jsr assemble_data_list
    rts
__F_process_instruction_like_join_6:
    jsr __outline_07
    lda #<__S_process_instruction_like___text_2
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_2
    sta __call_same_text_2+1
    lda #$04
    jsr same_text
    cmp #$00
    beq __F_process_instruction_like_join_9
__F_process_instruction_like_yes_7:
    jsr __outline_35
    lda #$02
    jsr assemble_data_list
    rts
__F_process_instruction_like_join_9:
    jsr __outline_07
    lda #<__S_process_instruction_like___text_3
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_3
    sta __call_same_text_2+1
    lda #$06
    jsr same_text
    cmp #$00
    beq __F_process_instruction_like_join_12
__F_process_instruction_like_yes_10:
    lda __L_process_instruction_like_argument
    sta __call_assemble_string_0
    lda __L_process_instruction_like_argument+1
    sta __call_assemble_string_0+1
    lda __L_process_instruction_like_argument_length
    jsr assemble_string
    rts
__F_process_instruction_like_join_12:
    lda __L_process_instruction_like_name
    sta __call_assemble_instruction_0
    lda __L_process_instruction_like_name+1
    sta __call_assemble_instruction_0+1
    lda __L_process_instruction_like_name_length
    sta __call_assemble_instruction_1
    lda __L_process_instruction_like_argument
    sta __call_assemble_instruction_2
    lda __L_process_instruction_like_argument+1
    sta __call_assemble_instruction_2+1
    lda __L_process_instruction_like_argument_length
    jsr assemble_instruction
    rts
__S_process_instruction_like___text_0:
    byte 105,110,99,108,117,100,101,0
__S_process_instruction_like___text_1:
    byte 98,121,116,101,0
__S_process_instruction_like___text_2:
    byte 119,111,114,100,0
__S_process_instruction_like___text_3:
    byte 115,116,114,105,110,103,0
process_source_line:
__F_process_source_line_entry:
    lda #$00
    sta __L_process_source_line_cursor
__F_process_source_line_while_1:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_while_4
    jmp __F_process_source_line_after_3
__F_process_source_line_while_4:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_after_6
__F_process_source_line_body_5:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$20
    bne __F_process_source_line_no_8
__F_process_source_line_yes_7:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_4
__F_process_source_line_no_8:
    cmp #$09
    bne __F_process_source_line_after_6
__F_process_source_line_yes_10:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_4
__F_process_source_line_after_6:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_join_15
__F_process_source_line_yes_13:
    lda ASSEMBLE_OK
    rts
__F_process_source_line_join_15:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$3b
    bne __F_process_source_line_join_18
__F_process_source_line_yes_16:
    lda ASSEMBLE_OK
    rts
__F_process_source_line_join_18:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_name_start
__F_process_source_line_while_19:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_after_21
__F_process_source_line_body_20:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$20
    beq __F_process_source_line_after_21
__F_process_source_line_join_24:
    cmp #$09
    beq __F_process_source_line_after_21
__F_process_source_line_join_27:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_19
__F_process_source_line_after_21:
    lda __L_process_source_line_cursor
    sec
    sbc __L_process_source_line_name_start
    sta __L_process_source_line_name_length
    cmp #$00
    bne __F_process_source_line_join_30
__F_process_source_line_yes_28:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_process_source_line_join_30:
    lda __L_process_source_line_name_start
    clc
    adc __L_process_source_line_name_length
    sta __tmp0
    lda #$00
    adc #$00
    sta __tmp1
    lda __tmp0
    sec
    sbc #$01
    sta __tmp2
    lda __tmp1
    sbc #$00
    sta __tmp3
    clc
    lda __tmp2
    adc #<source_line
    sta __ap
    lda __tmp3
    adc #>source_line
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp #$3a
    bne __F_process_source_line_while_37
__F_process_source_line_yes_31:
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_label_0
    lda #>source_line
    adc #$00
    sta __call_process_label_0+1
    lda __L_process_source_line_name_length
    jsr __outline_12
    lda __tmp0
    jsr process_label
    sta __L_process_source_line_status
    cmp ASSEMBLE_OK
    bne __F_process_source_line_yes_34
    jmp __F_process_source_line_while_1
__F_process_source_line_yes_34:
    lda __L_process_source_line_status
    rts
__F_process_source_line_while_37:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_after_39
__F_process_source_line_body_38:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$20
    bne __F_process_source_line_no_41
__F_process_source_line_yes_40:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_37
__F_process_source_line_no_41:
    cmp #$09
    bne __F_process_source_line_after_39
__F_process_source_line_yes_43:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_37
__F_process_source_line_after_39:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_join_48
__F_process_source_line_yes_46:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$3d
    bne __F_process_source_line_join_48
__F_process_source_line_yes_49:
    inc __L_process_source_line_cursor
__F_process_source_line_while_52:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_after_54
__F_process_source_line_body_53:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$20
    bne __F_process_source_line_no_56
__F_process_source_line_yes_55:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_52
__F_process_source_line_no_56:
    cmp #$09
    bne __F_process_source_line_after_54
__F_process_source_line_yes_58:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_52
__F_process_source_line_after_54:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_argument_start
    jsr scan_argument
    sta __tmp0
    lda __tmp0
    tax
    cmp #$00
    bne __F_process_source_line_join_63
__F_process_source_line_yes_61:
    lda ASSEMBLE_BAD_SYMBOL
    rts
__F_process_source_line_join_63:
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_symbol_0
    lda #>source_line
    adc #$00
    sta __call_process_symbol_0+1
    lda #<source_line
    clc
    adc __L_process_source_line_argument_start
    sta __call_process_symbol_2
    lda #>source_line
    adc #$00
    sta __call_process_symbol_2+1
    lda __L_process_source_line_name_length
    sta __call_process_symbol_1
    txa
    jsr process_symbol
    rts
__F_process_source_line_join_48:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_argument_start
    jsr scan_argument
    sta __tmp0
    lda __tmp0
    tax
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_instruction_like_0
    lda #>source_line
    adc #$00
    sta __call_process_instruction_like_0+1
    lda #<source_line
    clc
    adc __L_process_source_line_argument_start
    sta __call_process_instruction_like_2
    lda #>source_line
    adc #$00
    sta __call_process_instruction_like_2+1
    lda __L_process_source_line_name_length
    sta __call_process_instruction_like_1
    txa
    jsr process_instruction_like
    rts
__F_process_source_line_after_3:
    lda ASSEMBLE_OK
    rts
reset_assembler:
__F_reset_assembler_entry:
    sta __L_reset_assembler_directory_length
    lda #$00
    sta ass_image_length
    sta ass_image_length+1
    lda __L_reset_assembler_default_origin
    sta ass_origin
    lda __L_reset_assembler_default_origin+1
    sta ass_origin+1
    lda #$ff
    sta source_depth
    sta source_depth+1
    lda __L_reset_assembler_directory
    sta source_directory
    lda __L_reset_assembler_directory+1
    sta source_directory+1
    lda __L_reset_assembler_directory_length
    sta source_directory_length
    lda #$00
    sta symbol_count
    sta symbol_count+1
    sta symbol_name_used
    sta symbol_name_used+1
    sta current_scope
    sta fixup_count
    sta fixup_count+1
    lda #$01
    sta origin_allowed
    lda ASSEMBLE_OK
    rts
all_symbols_defined:
__F_all_symbols_defined_entry:
    lda #$00
    sta __L_all_symbols_defined_i
    sta __L_all_symbols_defined_i+1
    ldy #$00
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
__F_all_symbols_defined_while_1:
    lda symbol_count+1
    eor #$80
    sta __rh
    lda __L_all_symbols_defined_i+1
    eor #$80
    cmp __rh
    bcc __F_all_symbols_defined_body_2
    bne __F_all_symbols_defined_after_3
    lda __L_all_symbols_defined_i
    cmp symbol_count
    bcs __F_all_symbols_defined_after_3
__F_all_symbols_defined_body_2:
    lda (__ap),y
    cmp SYMBOL_LABEL_UNDEFINED
    bne __F_all_symbols_defined_join_6
__F_all_symbols_defined_yes_4:
    lda #$00
    rts
__F_all_symbols_defined_join_6:
    lda __L_all_symbols_defined_i
    clc
    adc #$01
    sta __tmp0
    lda __L_all_symbols_defined_i+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta __L_all_symbols_defined_i
    lda __tmp1
    sta __L_all_symbols_defined_i+1
    inc __ap
    bne __F_all_symbols_defined___sel1
    inc __ap+1
__F_all_symbols_defined___sel1:
    jmp __F_all_symbols_defined_while_1
__F_all_symbols_defined_after_3:
    lda #$01
    rts
all_fixups_resolved:
__F_all_fixups_resolved_entry:
    lda #$00
    sta __L_all_fixups_resolved_i
    sta __L_all_fixups_resolved_i+1
    ldy #$00
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
__F_all_fixups_resolved_while_1:
    lda fixup_count+1
    eor #$80
    sta __rh
    lda __L_all_fixups_resolved_i+1
    eor #$80
    cmp __rh
    bcc __F_all_fixups_resolved_body_2
    bne __F_all_fixups_resolved_after_3
    lda __L_all_fixups_resolved_i
    cmp fixup_count
    bcs __F_all_fixups_resolved_after_3
__F_all_fixups_resolved_body_2:
    lda (__ap),y
    cmp FIXUP_NONE
    beq __F_all_fixups_resolved_join_6
__F_all_fixups_resolved_yes_4:
    lda #$00
    rts
__F_all_fixups_resolved_join_6:
    lda __L_all_fixups_resolved_i
    clc
    adc #$01
    sta __tmp0
    lda __L_all_fixups_resolved_i+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta __L_all_fixups_resolved_i
    lda __tmp1
    sta __L_all_fixups_resolved_i+1
    inc __ap
    bne __F_all_fixups_resolved___sel1
    inc __ap+1
__F_all_fixups_resolved___sel1:
    jmp __F_all_fixups_resolved_while_1
__F_all_fixups_resolved_after_3:
    lda #$01
    rts
ass_assemble:
__F_ass_assemble_entry:
    lda __L_ass_assemble_default_origin
    sta __call_reset_assembler_0
    lda __L_ass_assemble_default_origin+1
    sta __call_reset_assembler_0+1
    lda __L_ass_assemble_directory
    sta __call_reset_assembler_1
    lda __L_ass_assemble_directory+1
    sta __call_reset_assembler_1+1
    lda __L_ass_assemble_directory_length
    jsr reset_assembler
    lda __L_ass_assemble_root_name
    sta __call_io_open_0
    lda __L_ass_assemble_root_name+1
    sta __call_io_open_0+1
    lda __L_ass_assemble_root_name_length
    sta __call_io_open_1
    lda #$00
    sta __call_io_open_1+1
    jsr io_open
    sta __L_ass_assemble_handle
    stx __L_ass_assemble_handle+1
    lda __L_ass_assemble_handle+1
    bpl __F_ass_assemble_join_3
__F_ass_assemble_yes_1:
    lda ASSEMBLE_IO_ERROR
    rts
__F_ass_assemble_join_3:
    lda #$00
    sta source_depth
    sta source_depth+1
    ldy #$00
    lda __L_ass_assemble_handle
    sta source_handle,y
__F_ass_assemble_while_4:
    lda source_depth+1
    bmi __F_ass_assemble_after_6
__F_ass_assemble_body_5:
    jsr read_source_line
    sta __L_ass_assemble_line_status
    stx __L_ass_assemble_line_status+1
    lda __L_ass_assemble_line_status+1
    cmp #$00
    bne __F_ass_assemble_no_8
    lda __L_ass_assemble_line_status
    cmp #$01
    bne __F_ass_assemble_no_8
__F_ass_assemble_yes_7:
    jsr process_source_line
    sta __L_ass_assemble_status
    cmp ASSEMBLE_OK
    beq __F_ass_assemble_while_4
__F_ass_assemble_yes_10:
    jsr close_source_tree
    lda __L_ass_assemble_status
    rts
__F_ass_assemble_no_8:
    lda __L_ass_assemble_line_status
    ora __L_ass_assemble_line_status+1
    bne __F_ass_assemble_no_14
__F_ass_assemble_yes_13:
    jsr __outline_04
    lda (__ap),y
    sta __call_io_close_0
    lda #$00
    sta __call_io_close_0+1
    jsr io_close
    jsr __outline_14
    jmp __F_ass_assemble_while_4
__F_ass_assemble_no_14:
    jsr close_source_tree
    lda __L_ass_assemble_line_status+1
    cmp #$ff
    bne __F_ass_assemble_join_18
    lda __L_ass_assemble_line_status
    cmp #$fe
    bne __F_ass_assemble_join_18
__F_ass_assemble_yes_16:
    lda ASSEMBLE_LINE_TOO_LONG
    rts
__F_ass_assemble_join_18:
    lda ASSEMBLE_IO_ERROR
    rts
__F_ass_assemble_after_6:
    jsr all_symbols_defined
    cmp #$00
    bne __F_ass_assemble_join_21
__F_ass_assemble_yes_19:
    lda ASSEMBLE_UNDEFINED
    rts
__F_ass_assemble_join_21:
    jsr all_fixups_resolved
    cmp #$00
    bne __F_ass_assemble_join_24
__F_ass_assemble_yes_22:
    lda ASSEMBLE_UNDEFINED
    rts
__F_ass_assemble_join_24:
    lda ASSEMBLE_OK
    rts
__nc_io_mode   = $ce00
__nc_io_eof    = $ce06
__nc_io_handle = $ce0c
__nc_io_name   = $ce10             ; 256-byte create-name buffer
__c_io_open__v00   = $cf10         ; char *name
__c_io_open__v01   = $cf12         ; int length
__c_io_read__v00   = $cf14         ; int handle
__c_io_create__v00 = $cf16         ; char *name
__c_io_create__v01 = $cf18         ; int length
__c_io_write__v00  = $cf1a         ; int handle
__c_io_write__v01  = $cf1c         ; int value
__c_io_close__v00  = $cf1e         ; int handle
__nc_init:
	cld
	lda #<NC_BSS
	sta NC_PTR
	lda #>NC_BSS
	sta NC_PTR+1
	lda #<__nc_bss_bytes
	sta NC_TMP
	lda #>__nc_bss_bytes
	sta NC_TMP+1
	ldy #$00
__local___nc_init_clear_bss:
	lda NC_TMP
	ora NC_TMP+1
	beq __local___nc_init_clear_runtime
	lda #$00
	sta (NC_PTR),y
	inc NC_PTR
	bne __local___nc_init_pointer_ok
	inc NC_PTR+1
__local___nc_init_pointer_ok:
	lda NC_TMP
	bne __local___nc_init_dec_low
	dec NC_TMP+1
__local___nc_init_dec_low:
	dec NC_TMP
	jmp __local___nc_init_clear_bss
__local___nc_init_clear_runtime:
	lda #$00
	ldx #$05
__local___nc_init_clear_io:
	sta __nc_io_mode,x
	sta __nc_io_eof,x
	dex
	bpl __local___nc_init_clear_io
	cld
	rts
NC_IO_INPUT        = $01
NC_IO_OUTPUT       = $02
NC_IO_PREFETCH     = $03
NC_IO_PREFETCH_EOF = $04
NC_IO_HANDLE_COUNT = $06
NC_IO_LFN_BASE     = $04
NC_IO_READ_DEVICE  = $08
NC_IO_WRITE_DEVICE = $09
__nc_io_zero:
	lda #$00
	ldx #$00
	cld
	rts
__nc_io_minus1:
	lda #$ff
	ldx #$ff
	cld
	rts
__nc_io_minus2:
	lda #$fe
	ldx #$ff
	cld
	rts
__c_io_open:
	cld
	ldx #$00
__local___c_io_open_find:
	lda __nc_io_mode,x
	beq __local___c_io_open_slot
	inx
	cpx #NC_IO_HANDLE_COUNT
	bne __local___c_io_open_find
	jmp __nc_io_minus1
__local___c_io_open_slot:
	stx __nc_io_handle
	lda __c_io_open__v01+1
    bne __nc_io_minus1
__local___c_io_open_length_ok:
	jsr $ffcc      ; CLRCHN
	lda __c_io_open__v01
	ldx __c_io_open__v00
	ldy __c_io_open__v00+1
	jsr $ffbd      ; SETNAM
	lda __nc_io_handle
	clc
	adc #NC_IO_LFN_BASE
	tay
	ldx #NC_IO_READ_DEVICE
	jsr $ffba      ; SETLFS
	jsr $ffc0      ; OPEN
	bcs __local___c_io_open_fail
	lda __nc_io_handle
	clc
	adc #NC_IO_LFN_BASE
	tax
	jsr $ffc6      ; CHKIN
	bcs __local___c_io_open_fail
	jsr $ffcf      ; CHRIN
	sta NC_TMP
	jsr $ffb7      ; READST
	sta NC_TMP+1
	and #$bf
	beq __local___c_io_open_ok
__local___c_io_open_fail:
	jsr $ffcc      ; CLRCHN
	lda __nc_io_handle
	clc
	adc #NC_IO_LFN_BASE
	jsr $ffc3      ; CLOSE
	jmp __nc_io_minus1
__local___c_io_open_ok:
	jsr $ffcc      ; CLRCHN
	ldx __nc_io_handle
	lda NC_TMP
	sta __nc_io_eof,x
	lda NC_TMP+1
	and #$40
	beq __local___c_io_open_prefetch
	lda #NC_IO_PREFETCH_EOF
	bne __local___c_io_open_store_mode
__local___c_io_open_prefetch:
	lda #NC_IO_PREFETCH
__local___c_io_open_store_mode:
	sta __nc_io_mode,x
	txa
	ldx #$00
	cld
	rts
__c_io_read:
	cld
	lda __c_io_read__v00+1
	beq __local___c_io_read_handle_low
	jmp __nc_io_minus2
__local___c_io_read_handle_low:
	lda __c_io_read__v00
	cmp #NC_IO_HANDLE_COUNT
	bcc __local___c_io_read_in_range
	jmp __nc_io_minus2
__local___c_io_read_in_range:
	sta __nc_io_handle
	tax
	lda __nc_io_mode,x
	cmp #NC_IO_INPUT
	beq __local___c_io_read_open
	cmp #NC_IO_PREFETCH
	beq __local___c_io_read_prefetch
	cmp #NC_IO_PREFETCH_EOF
	beq __local___c_io_read_prefetch_eof
	jmp __nc_io_minus2
__local___c_io_read_prefetch:
	lda __nc_io_eof,x
	sta NC_TMP
	lda #$00
	sta __nc_io_eof,x
	lda #NC_IO_INPUT
	sta __nc_io_mode,x
	lda NC_TMP
	ldx #$00
	cld
	rts
__local___c_io_read_prefetch_eof:
	lda __nc_io_eof,x
	sta NC_TMP
	lda #$01
	sta __nc_io_eof,x
	lda #NC_IO_INPUT
	sta __nc_io_mode,x
	lda NC_TMP
	ldx #$00
	cld
	rts
__local___c_io_read_open:
	lda __nc_io_eof,x
	beq __local___c_io_read_byte
	jmp __nc_io_minus1
__local___c_io_read_byte:
	jsr $ffcc      ; CLRCHN
	lda __nc_io_handle
	clc
	adc #NC_IO_LFN_BASE
	tax
	jsr $ffc6      ; CHKIN
    bcs __local___c_io_read_error_clear
__local___c_io_read_selected:
	jsr $ffcf      ; CHRIN
	sta NC_TMP
	jsr $ffb7      ; READST
	sta NC_TMP+1
	jsr $ffcc      ; CLRCHN
	lda NC_TMP+1
	and #$bf
	beq __local___c_io_read_status_ok
	jmp __nc_io_minus2
__local___c_io_read_status_ok:
	lda NC_TMP+1
	and #$40
	beq __local___c_io_read_return
	ldx __nc_io_handle
	lda #$01
	sta __nc_io_eof,x
__local___c_io_read_return:
	lda NC_TMP
	ldx #$00
	cld
	rts
__local___c_io_read_error_clear:
	jsr $ffcc      ; CLRCHN
	jmp __nc_io_minus2
__c_io_close:
	cld
	lda __c_io_close__v00+1
	beq __local___c_io_close_handle_low
	jmp __nc_io_minus1
__local___c_io_close_handle_low:
	lda __c_io_close__v00
	cmp #NC_IO_HANDLE_COUNT
	bcc __local___c_io_close_in_range
	jmp __nc_io_minus1
__local___c_io_close_in_range:
	sta __nc_io_handle
	tax
	lda __nc_io_mode,x
	bne __local___c_io_close_open
	jmp __nc_io_minus1
__local___c_io_close_open:
	jsr $ffcc      ; CLRCHN
	lda __nc_io_handle
	clc
	adc #NC_IO_LFN_BASE
	jsr $ffc3      ; CLOSE
	ldx __nc_io_handle
	lda #$00
	sta __nc_io_mode,x
	sta __nc_io_eof,x
	jmp __nc_io_zero
__experiment_entry:
    lda $01
    and #$fe
    sta $01
    jsr __nc_init
    lda #<__experiment_name
    sta __call_ass_assemble_0
    lda #>__experiment_name
    sta __call_ass_assemble_0+1
    lda #$08
    sta __call_ass_assemble_1
    lda #$00
    sta __call_ass_assemble_2
    sta __call_ass_assemble_2+1
    sta __call_ass_assemble_3
    sta __call_ass_assemble_4
    sta __call_ass_assemble_4+1
    jsr ass_assemble
    sta __experiment_status
__experiment_stop:
    jmp __experiment_stop
__experiment_name:
    byte 84,69,83,84,46,65,83,77
__outline_01:
    sta __ap+1
    lda __tmp0
    sta __ix
    lda __tmp1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    rts
__outline_02:
    sta __tmp0
    lda #$00
    sbc #$00
    sta __tmp1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    rts
__outline_03:
    rol
    sta __ix+1
    clc
    lda __ix
    adc #<symbol_payload
    sta __ap
    lda __ix+1
    adc #>symbol_payload
    sta __ap+1
    ldy #$00
    rts
__outline_04:
    clc
    lda source_depth
    adc #<source_handle
    sta __ap
    lda source_depth+1
    adc #>source_handle
    sta __ap+1
    ldy #$00
    rts
__outline_05:
    lda __L_assemble_instruction_argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda __L_assemble_instruction_argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    rts
__outline_06:
    sta __call_append_fixup_0
    lda __L_stage_unresolved_instruction_stage
    sta __call_append_fixup_1
    lda __L_stage_unresolved_instruction_stage+1
    sta __call_append_fixup_1+1
    lda __L_stage_unresolved_instruction_symbol
    sta __call_append_fixup_2
    lda __L_stage_unresolved_instruction_symbol+1
    sta __call_append_fixup_2+1
    lda __L_stage_unresolved_instruction_addend
    sta __call_append_fixup_3
    lda __L_stage_unresolved_instruction_addend+1
    sta __call_append_fixup_3+1
    lda __L_stage_unresolved_instruction_prefix
    rts
__outline_07:
    lda __L_process_instruction_like_name
    sta __call_same_text_0
    lda __L_process_instruction_like_name+1
    sta __call_same_text_0+1
    lda __L_process_instruction_like_name_length
    sta __call_same_text_1
    rts
__outline_08:
    lda __L_parse_value_text
    clc
    adc __L_parse_value_position
    sta __call_parse_atom_0
    lda __L_parse_value_text+1
    adc #$00
    sta __call_parse_atom_0+1
    lda __L_parse_value_length
    sec
    sbc __L_parse_value_position
    sta __tmp0
    lda #$00
    sbc #$00
    lda __tmp0
    rts
__outline_09:
    sta __tmp0
    lda #$00
    adc #$00
    sta __tmp1
    clc
    lda __tmp0
    adc #<mnemonic_table
    sta __ap
    lda __tmp1
    adc #>mnemonic_table
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp __tmp2
    rts
__outline_10:
    sta (__ap),y
    lda __L_append_fixup_n
    asl
    sta __ix
    lda __L_append_fixup_n+1
    rol
    sta __ix+1
    clc
    lda __ix
    rts
__outline_11:
    clc
    lda __L_resolve_fixups_for_symbol_stage
    adc #<ass_image
    sta __ap
    lda __L_resolve_fixups_for_symbol_stage+1
    adc #>ass_image
    sta __ap+1
    ldy #$00
    rts
__outline_12:
    sec
    sbc #$01
    sta __tmp0
    lda #$00
    sbc #$00
    rts
__outline_13:
    sta __call_stage_unresolved_instruction_1
    lda captured_symbol
    sta __call_stage_unresolved_instruction_2
    lda captured_symbol+1
    sta __call_stage_unresolved_instruction_2+1
    lda captured_addend
    sta __call_stage_unresolved_instruction_3
    lda captured_addend+1
    sta __call_stage_unresolved_instruction_3+1
    lda captured_prefix
    rts
__outline_14:
    lda source_depth
    sec
    sbc #$01
    sta __tmp0
    lda source_depth+1
    sbc #$00
    sta __tmp1
    lda __tmp0
    sta source_depth
    lda __tmp1
    sta source_depth+1
    rts
__outline_15:
    sta __tmp0
    lda #$00
    adc #$00
    sta __tmp1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    rts
__outline_16:
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
    lda (__ap),y
    rts
__outline_17:
    lda __L_resolve_fixups_for_symbol_i
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    rol
    sta __ix+1
    clc
    lda __ix
    rts
__outline_18:
    sta __call_stage_resolved_instruction_1
    lda value_result
    sta __call_stage_resolved_instruction_2
    lda value_result+1
    sta __call_stage_resolved_instruction_2+1
    rts
__outline_19:
    ldy source_line_length
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
__outline_20:
    adc #$00
    sta __tmp1
    clc
    lda __tmp0
    adc #<ass_image
    sta __ap
    lda __tmp1
    adc #>ass_image
    sta __ap+1
    ldy #$00
    rts
__outline_21:
    lda ass_origin
    clc
    adc ass_image_length
    sta __tmp0
    lda ass_origin+1
    adc ass_image_length+1
    sta __tmp1
    lda __tmp0
    rts
__outline_22:
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    rts
__outline_23:
    rol
    sta __ix+1
    clc
    lda __ix
    adc #<symbol_name_offset
    sta __ap
    lda __ix+1
    adc #>symbol_name_offset
    sta __ap+1
    ldy #$00
    rts
__outline_24:
    asl __mw
    rol __mw+1
    clc
    lda __tmp2
    adc __mw
    sta __tmp2
    lda __tmp3
    adc __mw+1
    sta __tmp3
    rts
__outline_25:
    sta __tmp0
    lda #$00
    sbc #$00
    sta __tmp1
    lda __tmp0
    rts
__outline_26:
    lda __L_find_mnemonic_name
    sta __ap
    lda __L_find_mnemonic_name+1
    sta __ap+1
    lda (__ap),y
    rts
__outline_27:
    asl __tmp1
    rol __tmp2
    asl __tmp1
    rol __tmp2
    asl __tmp1
    rol __tmp2
    asl __tmp1
    rol __tmp2
    rts
__outline_28:
    ldy __L_assemble_data_list_cursor
    lda __L_assemble_data_list_argument
    sta __ap
    lda __L_assemble_data_list_argument+1
    sta __ap+1
    lda (__ap),y
    sta __L_assemble_data_list_c
    rts
__outline_29:
    lda fixup_count
    sec
    sbc #$01
    sta __tmp0
    lda fixup_count+1
    sbc #$00
    sta __tmp1
    rts
__outline_30:
    clc
    lda __L_resolve_fixups_for_symbol_i
    adc #<fixup_kind
    sta __ap
    lda __L_resolve_fixups_for_symbol_i+1
    adc #>fixup_kind
    sta __ap+1
    ldy #$00
    rts
__outline_31:
    clc
    lda __L_patch_word_chain_stage
    adc #<ass_image
    sta __ap
    lda __L_patch_word_chain_stage+1
    adc #>ass_image
    sta __ap+1
    ldy #$00
    rts
__outline_32:
    clc
    lda __L_define_label_symbol
    adc #<symbol_kind
    sta __ap
    lda __L_define_label_symbol+1
    adc #>symbol_kind
    sta __ap+1
    ldy #$00
    rts
__outline_33:
    sta __tmp3
    lda __tmp2
    sta __L_parse_atom_value
    lda __tmp3
    sta __L_parse_atom_value+1
    inc atom_used
    inc __L_parse_atom_i
    rts
__outline_34:
    lda __L_assemble_instruction_opcode
    sta __call_stage_resolved_instruction_0
    lda MODE_ACCUMULATOR
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    sta __call_stage_resolved_instruction_2+1
    rts
__outline_35:
    lda __L_process_instruction_like_argument
    sta __call_assemble_data_list_0
    lda __L_process_instruction_like_argument+1
    sta __call_assemble_data_list_0+1
    lda __L_process_instruction_like_argument_length
    sta __call_assemble_data_list_1
    rts
__outline_36:
    lda (__ap),y
    sta __tmp0
    iny
    lda (__ap),y
    sta __tmp1
    rts
ass_image = $4800
ass_image_length = $7400
ass_origin = $7402
source_line = $7404
source_line_length = $7504
source_path = $7505
source_handle = $7605
source_depth = $760a
source_directory = $760c
source_directory_length = $760e
symbol_name_offset = $760f
symbol_name_length = $7d0f
symbol_payload = $808f
symbol_scope = $878f
symbol_kind = $8b0f
symbol_name_bytes = $8e8f
symbol_count = $b30f
symbol_name_used = $b311
current_scope = $b313
fixup_kind = $b314
fixup_stage = $b594
fixup_symbol = $ba94
fixup_addend = $bf94
fixup_prefix = $c494
fixup_count = $c714
value_result = $c716
captured_symbol = $c718
captured_addend = $c71a
captured_prefix = $c71c
atom_value = $c71d
atom_symbol = $c71f
atom_used = $c721
atom_kind = $c722
origin_allowed = $c723
__L_upper_char_c = $c724
__L_same_text_a = $0034
__L_same_text_a_length = $0031
__L_same_text_b = $0032
__L_same_text_b_length = $0039
__L_same_text_i = $0036
__L_apply_byte_prefix_value = $0035
__L_apply_byte_prefix_prefix = $c72e
__L_hex_nibble_c = $c72f
__L_append_fixup_kind = $c730
__L_append_fixup_stage = $c731
__L_append_fixup_symbol = $0039
__L_append_fixup_addend = $c735
__L_append_fixup_prefix = $c737
__L_append_fixup_n = $0033
__L_relative_byte_target = $c73a
__L_relative_byte_base = $c73c
__L_relative_byte_difference = $0033
__L_resolve_fixups_for_symbol_symbol = $0039
__L_resolve_fixups_for_symbol_i = $0031
__L_resolve_fixups_for_symbol_kind = $c744
__L_resolve_fixups_for_symbol_value = $0033
__L_resolve_fixups_for_symbol_stage = $0035
__L_resolve_fixups_for_symbol_relative = $0033
__L_scope_for_name_name = $0039
__L_scope_for_name_length = $c74d
__L_find_symbol_name = $c74e
__L_find_symbol_length = $c750
__L_find_symbol_wanted_scope = $c751
__L_find_symbol_i = $0039
__L_find_symbol_j = $0036
__L_find_symbol_offset = $c756
__L_find_symbol_same = $c758
__L_allocate_symbol_name = $c759
__L_allocate_symbol_length = $0036
__L_allocate_symbol_kind = $c75c
__L_allocate_symbol_payload = $c75d
__L_allocate_symbol_scope = $c75f
__L_allocate_symbol_n = $0039
__L_allocate_symbol_i = $c763
__L_intern_label_name = $c764
__L_intern_label_length = $c766
__L_intern_label_symbol = $0039
__L_define_constant_name = $0032
__L_define_constant_length = $0034
__L_define_constant_value = $0037
__L_define_constant_symbol = $0030
__L_patch_word_chain_head = $0035
__L_patch_word_chain_value = $0039
__L_patch_word_chain_stage = $0033
__L_patch_word_chain_next = $c776
__L_define_label_name = $003e
__L_define_label_length = $c77a
__L_define_label_value = $0037
__L_define_label_symbol = $0031
__L_define_label_old_head = $0033
__L_define_label_status = $0033
__L_parse_atom_text = $0034
__L_parse_atom_length = $c784
__L_parse_atom_i = $0036
__L_parse_atom_digit = $c786
__L_parse_atom_value = $0039
__L_parse_atom_symbol = $0039
__L_parse_value_text = $0037
__L_parse_value_length = $c78e
__L_parse_value_position = $0033
__L_parse_value_status = $0034
__L_parse_value_first_kind = $0036
__L_parse_value_first_value = $0034
__L_parse_value_first_symbol = $0039
__L_parse_value_operation = $c796
__L_parse_value_second_kind = $c797
__L_find_mnemonic_name = $0034
__L_find_mnemonic_length = $0037
__L_find_mnemonic_candidate = $0033
__L_find_mnemonic_offset = $0036
__L_find_opcode_mnemonic = $0033
__L_find_opcode_mode = $c79e
__L_find_opcode_opcode = $c79f
__L_stage_byte_value = $c7a1
__L_stage_plain_word_reference_symbol = $0033
__L_stage_plain_word_reference_stage = $c7a4
__L_stage_plain_word_reference_old_head = $c7a6
__L_stage_plain_word_reference_status = $0039
__L_stage_resolved_instruction_opcode = $0035
__L_stage_resolved_instruction_mode = $0036
__L_stage_resolved_instruction_value = $0033
__L_stage_resolved_instruction_width = $0038
__L_stage_resolved_instruction_status = $0037
__L_stage_resolved_relative_opcode = $0038
__L_stage_resolved_relative_target = $0035
__L_stage_resolved_relative_base = $0033
__L_stage_resolved_relative_relative = $0033
__L_stage_resolved_relative_status = $0037
__L_stage_unresolved_instruction_opcode = $c7b7
__L_stage_unresolved_instruction_mode = $c7b8
__L_stage_unresolved_instruction_symbol = $0035
__L_stage_unresolved_instruction_addend = $0037
__L_stage_unresolved_instruction_prefix = $c7bd
__L_stage_unresolved_instruction_width = $0034
__L_stage_unresolved_instruction_stage = $0039
__L_stage_unresolved_instruction_status = $0033
__L_stage_unresolved_instruction_kind = $c7c2
__L_short_mode_for_index_index = $003b
__L_long_mode_for_index_index = $c7c4
__L_assemble_mode_value_mnemonic = $c7c5
__L_assemble_mode_value_mode = $003b
__L_assemble_mode_value_text = $c7c7
__L_assemble_mode_value_length = $c7c9
__L_assemble_mode_value_opcode = $c7ca
__L_assemble_mode_value_status = $0033
__L_assemble_direct_value_mnemonic = $c7cd
__L_assemble_direct_value_text = $c7ce
__L_assemble_direct_value_length = $c7d0
__L_assemble_direct_value_index = $c7d1
__L_assemble_direct_value_status = $0035
__L_assemble_direct_value_short_mode = $0036
__L_assemble_direct_value_long_mode = $0034
__L_assemble_direct_value_short_opcode = $0037
__L_assemble_direct_value_long_opcode = $0039
__L_assemble_direct_value_mode = $c7d9
__L_assemble_direct_value_opcode = $0033
__L_assemble_instruction_name = $c7dc
__L_assemble_instruction_name_length = $c7de
__L_assemble_instruction_argument = $0031
__L_assemble_instruction_argument_length = $0030
__L_assemble_instruction_mnemonic = $0035
__L_assemble_instruction_opcode = $0033
__L_assemble_instruction_index = $0034
__L_assemble_instruction_core_length = $0033
__L_stage_data_value_text = $c7e8
__L_stage_data_value_length = $c7ea
__L_stage_data_value_width = $003b
__L_stage_data_value_status = $0032
__L_stage_data_value_stage = $0033
__L_stage_data_value_kind = $0032
__L_assemble_data_list_argument = $c7f0
__L_assemble_data_list_length = $0031
__L_assemble_data_list_width = $c7f3
__L_assemble_data_list_cursor = $0030
__L_assemble_data_list_item_start = $0032
__L_assemble_data_list_item_end = $c7f6
__L_assemble_data_list_status = $0032
__L_assemble_data_list_c = $0033
__L_assemble_string_argument = $0030
__L_assemble_string_length = $0038
__L_assemble_string_i = $0032
__L_assemble_string_status = $0033
__L_open_include_argument = $0031
__L_open_include_length = $0037
__L_open_include_input_start = $0034
__L_open_include_input_length = $0035
__L_open_include_output = $0033
__L_open_include_i = $0030
__L_open_include_parent_path = $c805
__L_open_include_handle = $0033
__L_read_source_line_c = $0030
__L_read_source_line_handle = $0032
__L_scan_argument_start = $003b
__L_scan_argument_i = $0030
__L_scan_argument_quote = $c80d
__L_scan_argument_last = $0031
__L_scan_argument_c = $0035
__L_process_label_name = $003c
__L_process_label_length = $c812
__L_process_label_status = $0031
__L_process_label_value = $0031
__L_process_symbol_name = $003b
__L_process_symbol_name_length = $003f
__L_process_symbol_argument = $003d
__L_process_symbol_argument_length = $c81b
__L_process_symbol_status = $0030
__L_process_instruction_like_name = $003c
__L_process_instruction_like_name_length = $c81f
__L_process_instruction_like_argument = $003e
__L_process_instruction_like_argument_length = $c822
__L_process_source_line_cursor = $0030
__L_process_source_line_name_start = $0032
__L_process_source_line_name_length = $0033
__L_process_source_line_argument_start = $0034
__L_process_source_line_argument_length = $c827
__L_process_source_line_status = $0031
__L_reset_assembler_default_origin = $0032
__L_reset_assembler_directory = $0030
__L_reset_assembler_directory_length = $0034
__L_all_symbols_defined_i = $0030
__L_all_fixups_resolved_i = $0030
__L_ass_assemble_root_name = $0035
__L_ass_assemble_root_name_length = $0039
__L_ass_assemble_directory = $0037
__L_ass_assemble_directory_length = $003a
__L_ass_assemble_default_origin = $0030
__L_ass_assemble_handle = $0030
__L_ass_assemble_line_status = $0030
__L_ass_assemble_status = $0030
__call_upper_char_0 = $c724
__call_same_text_0 = $0034
__call_same_text_1 = $0031
__call_same_text_2 = $0032
__call_same_text_3 = $0039
__call_apply_byte_prefix_0 = $0035
__call_apply_byte_prefix_1 = $c72e
__call_hex_nibble_0 = $c72f
__call_append_fixup_0 = $c730
__call_append_fixup_1 = $c731
__call_append_fixup_2 = $0039
__call_append_fixup_3 = $c735
__call_append_fixup_4 = $c737
__call_relative_byte_0 = $c73a
__call_relative_byte_1 = $c73c
__call_resolve_fixups_for_symbol_0 = $0039
__call_scope_for_name_0 = $0039
__call_scope_for_name_1 = $c74d
__call_find_symbol_0 = $c74e
__call_find_symbol_1 = $c750
__call_allocate_symbol_0 = $c759
__call_allocate_symbol_1 = $0036
__call_allocate_symbol_2 = $c75c
__call_allocate_symbol_3 = $c75d
__call_intern_label_0 = $c764
__call_intern_label_1 = $c766
__call_define_constant_0 = $0032
__call_define_constant_1 = $0034
__call_define_constant_2 = $0037
__call_patch_word_chain_0 = $0035
__call_patch_word_chain_1 = $0039
__call_define_label_0 = $003e
__call_define_label_1 = $c77a
__call_define_label_2 = $0037
__call_parse_atom_0 = $0034
__call_parse_atom_1 = $c784
__call_parse_value_0 = $0037
__call_parse_value_1 = $c78e
__call_find_mnemonic_0 = $0034
__call_find_mnemonic_1 = $0037
__call_find_opcode_0 = $0033
__call_find_opcode_1 = $c79e
__call_stage_byte_0 = $c7a1
__call_stage_plain_word_reference_0 = $0033
__call_stage_resolved_instruction_0 = $0035
__call_stage_resolved_instruction_1 = $0036
__call_stage_resolved_instruction_2 = $0033
__call_stage_resolved_relative_0 = $0038
__call_stage_resolved_relative_1 = $0035
__call_stage_unresolved_instruction_0 = $c7b7
__call_stage_unresolved_instruction_1 = $c7b8
__call_stage_unresolved_instruction_2 = $0035
__call_stage_unresolved_instruction_3 = $0037
__call_stage_unresolved_instruction_4 = $c7bd
__call_short_mode_for_index_0 = $003b
__call_long_mode_for_index_0 = $c7c4
__call_assemble_mode_value_0 = $c7c5
__call_assemble_mode_value_1 = $003b
__call_assemble_mode_value_2 = $c7c7
__call_assemble_mode_value_3 = $c7c9
__call_assemble_direct_value_0 = $c7cd
__call_assemble_direct_value_1 = $c7ce
__call_assemble_direct_value_2 = $c7d0
__call_assemble_direct_value_3 = $c7d1
__call_assemble_instruction_0 = $c7dc
__call_assemble_instruction_1 = $c7de
__call_assemble_instruction_2 = $0031
__call_assemble_instruction_3 = $0030
__call_stage_data_value_0 = $c7e8
__call_stage_data_value_1 = $c7ea
__call_stage_data_value_2 = $003b
__call_assemble_data_list_0 = $c7f0
__call_assemble_data_list_1 = $0031
__call_assemble_data_list_2 = $c7f3
__call_assemble_string_0 = $0030
__call_assemble_string_1 = $0038
__call_open_include_0 = $0031
__call_open_include_1 = $0037
__call_scan_argument_0 = $003b
__call_process_label_0 = $003c
__call_process_label_1 = $c812
__call_process_symbol_0 = $003b
__call_process_symbol_1 = $003f
__call_process_symbol_2 = $003d
__call_process_symbol_3 = $c81b
__call_process_instruction_like_0 = $003c
__call_process_instruction_like_1 = $c81f
__call_process_instruction_like_2 = $003e
__call_process_instruction_like_3 = $c822
__call_reset_assembler_0 = $0032
__call_reset_assembler_1 = $0030
__call_reset_assembler_2 = $0034
__call_ass_assemble_0 = $0035
__call_ass_assemble_1 = $0039
__call_ass_assemble_2 = $0037
__call_ass_assemble_3 = $003a
__call_ass_assemble_4 = $0030
__call_io_open_0 = $cf10
__call_io_open_1 = $cf12
__call_io_read_0 = $cf14
__call_io_close_0 = $cf1e
__ap = $0002
__ix = $0004
__rh = $0006
__mw = $0007
__tmp0 = $0009
__tmp1 = $000a
__tmp2 = $000b
__tmp3 = $000c
__tmp4 = $000d
__tmp5 = $000e
__tmp6 = $000f
__tmp7 = $0010
NC_TMP = $00fc
NC_PTR = $00fe
__nc_io_mode = $ce00
__nc_io_eof = $ce06
__nc_io_handle = $ce0c
__nc_io_name = $ce10
__c_io_open__v00 = $cf10
__c_io_open__v01 = $cf12
__c_io_read__v00 = $cf14
__c_io_close__v00 = $cf1e
NC_BSS = $4800
__nc_bss_bytes = $8040
__experiment_status = $c83f
