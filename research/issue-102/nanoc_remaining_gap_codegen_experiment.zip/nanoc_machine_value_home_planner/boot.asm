__experiment_entry:
    lda $01
    and #$fe
    sta $01
    jsr __nc_init
    lda #<__experiment_name
    sta __call_ass_assemble_0
    lda #>__experiment_name
    sta __call_ass_assemble_0+1
    lda #$08
    sta __call_ass_assemble_1
    lda #$00
    sta __call_ass_assemble_2
    sta __call_ass_assemble_2+1
    sta __call_ass_assemble_3
    sta __call_ass_assemble_4
    sta __call_ass_assemble_4+1
    jsr ass_assemble
    sta __experiment_status
__experiment_stop:
    jmp __experiment_stop
__experiment_name:
    byte 84,69,83,84,46,65,83,77
__outline_01:
    sta __ap+1
    lda __tmp0
    sta __ix
    lda __tmp1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    rts
__outline_02:
    sta __tmp0
    lda #$00
    sbc #$00
    sta __tmp1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    rts
__outline_03:
    rol
    sta __ix+1
    clc
    lda __ix
    adc #<symbol_payload
    sta __ap
    lda __ix+1
    adc #>symbol_payload
    sta __ap+1
    ldy #$00
    rts
__outline_04:
    clc
    lda source_depth
    adc #<source_handle
    sta __ap
    lda source_depth+1
    adc #>source_handle
    sta __ap+1
    ldy #$00
    rts
__outline_05:
    lda __L_assemble_instruction_argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda __L_assemble_instruction_argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    rts
__outline_06:
    sta __call_append_fixup_0
    lda __L_stage_unresolved_instruction_stage
    sta __call_append_fixup_1
    lda __L_stage_unresolved_instruction_stage+1
    sta __call_append_fixup_1+1
    lda __L_stage_unresolved_instruction_symbol
    sta __call_append_fixup_2
    lda __L_stage_unresolved_instruction_symbol+1
    sta __call_append_fixup_2+1
    lda __L_stage_unresolved_instruction_addend
    sta __call_append_fixup_3
    lda __L_stage_unresolved_instruction_addend+1
    sta __call_append_fixup_3+1
    lda __L_stage_unresolved_instruction_prefix
    rts
__outline_07:
    lda __L_process_instruction_like_name
    sta __call_same_text_0
    lda __L_process_instruction_like_name+1
    sta __call_same_text_0+1
    lda __L_process_instruction_like_name_length
    sta __call_same_text_1
    rts
__outline_08:
    lda __L_parse_value_text
    clc
    adc __L_parse_value_position
    sta __call_parse_atom_0
    lda __L_parse_value_text+1
    adc #$00
    sta __call_parse_atom_0+1
    lda __L_parse_value_length
    sec
    sbc __L_parse_value_position
    sta __tmp0
    lda #$00
    sbc #$00
    lda __tmp0
    rts
__outline_09:
    sta __tmp0
    lda #$00
    adc #$00
    sta __tmp1
    clc
    lda __tmp0
    adc #<mnemonic_table
    sta __ap
    lda __tmp1
    adc #>mnemonic_table
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp __tmp2
    rts
__outline_10:
    sta (__ap),y
    lda __L_append_fixup_n
    asl
    sta __ix
    lda __L_append_fixup_n+1
    rol
    sta __ix+1
    clc
    lda __ix
    rts
__outline_11:
    clc
    lda __L_resolve_fixups_for_symbol_stage
    adc #<ass_image
    sta __ap
    lda __L_resolve_fixups_for_symbol_stage+1
    adc #>ass_image
    sta __ap+1
    ldy #$00
    rts
__outline_12:
    sec
    sbc #$01
    sta __tmp0
    lda #$00
    sbc #$00
    rts
__outline_13:
    sta __call_stage_unresolved_instruction_1
    lda captured_symbol
    sta __call_stage_unresolved_instruction_2
    lda captured_symbol+1
    sta __call_stage_unresolved_instruction_2+1
    lda captured_addend
    sta __call_stage_unresolved_instruction_3
    lda captured_addend+1
    sta __call_stage_unresolved_instruction_3+1
    lda captured_prefix
    rts
__outline_14:
    lda source_depth
    sec
    sbc #$01
    sta __tmp0
    lda source_depth+1
    sbc #$00
    sta __tmp1
    lda __tmp0
    sta source_depth
    lda __tmp1
    sta source_depth+1
    rts
__outline_15:
    sta __tmp0
    lda #$00
    adc #$00
    sta __tmp1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    rts
__outline_16:
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
    lda (__ap),y
    rts
__outline_17:
    lda __L_resolve_fixups_for_symbol_i
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    rol
    sta __ix+1
    clc
    lda __ix
    rts
__outline_18:
    sta __call_stage_resolved_instruction_1
    lda value_result
    sta __call_stage_resolved_instruction_2
    lda value_result+1
    sta __call_stage_resolved_instruction_2+1
    rts
__outline_19:
    ldy source_line_length
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
__outline_20:
    adc #$00
    sta __tmp1
    clc
    lda __tmp0
    adc #<ass_image
    sta __ap
    lda __tmp1
    adc #>ass_image
    sta __ap+1
    ldy #$00
    rts
__outline_21:
    lda ass_origin
    clc
    adc ass_image_length
    sta __tmp0
    lda ass_origin+1
    adc ass_image_length+1
    sta __tmp1
    lda __tmp0
    rts
__outline_22:
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    rts
__outline_23:
    rol
    sta __ix+1
    clc
    lda __ix
    adc #<symbol_name_offset
    sta __ap
    lda __ix+1
    adc #>symbol_name_offset
    sta __ap+1
    ldy #$00
    rts
__outline_24:
    asl __mw
    rol __mw+1
    clc
    lda __tmp2
    adc __mw
    sta __tmp2
    lda __tmp3
    adc __mw+1
    sta __tmp3
    rts
__outline_25:
    sta __tmp0
    lda #$00
    sbc #$00
    sta __tmp1
    lda __tmp0
    rts
__outline_26:
    lda __L_find_mnemonic_name
    sta __ap
    lda __L_find_mnemonic_name+1
    sta __ap+1
    lda (__ap),y
    rts
__outline_27:
    asl __tmp1
    rol __tmp2
    asl __tmp1
    rol __tmp2
    asl __tmp1
    rol __tmp2
    asl __tmp1
    rol __tmp2
    rts
__outline_28:
    ldy __L_assemble_data_list_cursor
    lda __L_assemble_data_list_argument
    sta __ap
    lda __L_assemble_data_list_argument+1
    sta __ap+1
    lda (__ap),y
    sta __L_assemble_data_list_c
    rts
__outline_29:
    lda fixup_count
    sec
    sbc #$01
    sta __tmp0
    lda fixup_count+1
    sbc #$00
    sta __tmp1
    rts
__outline_30:
    clc
    lda __L_resolve_fixups_for_symbol_i
    adc #<fixup_kind
    sta __ap
    lda __L_resolve_fixups_for_symbol_i+1
    adc #>fixup_kind
    sta __ap+1
    ldy #$00
    rts
__outline_31:
    clc
    lda __L_patch_word_chain_stage
    adc #<ass_image
    sta __ap
    lda __L_patch_word_chain_stage+1
    adc #>ass_image
    sta __ap+1
    ldy #$00
    rts
__outline_32:
    clc
    lda __L_define_label_symbol
    adc #<symbol_kind
    sta __ap
    lda __L_define_label_symbol+1
    adc #>symbol_kind
    sta __ap+1
    ldy #$00
    rts
__outline_33:
    sta __tmp3
    lda __tmp2
    sta __L_parse_atom_value
    lda __tmp3
    sta __L_parse_atom_value+1
    inc atom_used
    inc __L_parse_atom_i
    rts
__outline_34:
    lda __L_assemble_instruction_opcode
    sta __call_stage_resolved_instruction_0
    lda MODE_ACCUMULATOR
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    sta __call_stage_resolved_instruction_2+1
    rts
__outline_35:
    lda __L_process_instruction_like_argument
    sta __call_assemble_data_list_0
    lda __L_process_instruction_like_argument+1
    sta __call_assemble_data_list_0+1
    lda __L_process_instruction_like_argument_length
    sta __call_assemble_data_list_1
    rts
__outline_36:
    lda (__ap),y
    sta __tmp0
    iny
    lda (__ap),y
    sta __tmp1
    rts
