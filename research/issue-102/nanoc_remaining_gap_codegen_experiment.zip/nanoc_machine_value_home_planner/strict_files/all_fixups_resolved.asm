* = $0800
FIXUP_NONE = $0ae3
__L_all_fixups_resolved_i = $0030
__ap = $0002
__rh = $0006
__tmp0 = $0009
__tmp1 = $000a
fixup_count = $c714
fixup_kind = $b314
all_fixups_resolved:
__F_all_fixups_resolved_entry:
    lda #$00
    sta __L_all_fixups_resolved_i
    sta __L_all_fixups_resolved_i+1
    ldy #$00
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
__F_all_fixups_resolved_while_1:
    lda fixup_count+1
    eor #$80
    sta __rh
    lda __L_all_fixups_resolved_i+1
    eor #$80
    cmp __rh
    bcc __F_all_fixups_resolved_body_2
    bne __F_all_fixups_resolved_after_3
    lda __L_all_fixups_resolved_i
    cmp fixup_count
    bcs __F_all_fixups_resolved_after_3
__F_all_fixups_resolved_body_2:
    lda (__ap),y
    cmp FIXUP_NONE
    beq __F_all_fixups_resolved_join_6
__F_all_fixups_resolved_yes_4:
    lda #$00
    rts
__F_all_fixups_resolved_join_6:
    lda __L_all_fixups_resolved_i
    clc
    adc #$01
    sta __tmp0
    lda __L_all_fixups_resolved_i+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta __L_all_fixups_resolved_i
    lda __tmp1
    sta __L_all_fixups_resolved_i+1
    inc __ap
    bne __F_all_fixups_resolved___sel1
    inc __ap+1
__F_all_fixups_resolved___sel1:
    jmp __F_all_fixups_resolved_while_1
__F_all_fixups_resolved_after_3:
    lda #$01
    rts
