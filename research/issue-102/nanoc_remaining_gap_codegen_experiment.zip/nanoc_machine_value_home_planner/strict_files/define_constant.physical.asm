* = $1122
ASSEMBLE_BAD_SYMBOL = $0805
ASSEMBLE_OK = $0803
ASSEMBLE_SCOPE_ERROR = $0807
ASSEMBLE_SYMBOL_FULL = $0806
SYMBOL_CONSTANT = $0ad8
__L_define_constant_length = $0034
__L_define_constant_name = $0032
__L_define_constant_symbol = $0030
__L_define_constant_value = $0037
__call_allocate_symbol_0 = $c759
__call_allocate_symbol_1 = $0036
__call_allocate_symbol_2 = $c75c
__call_allocate_symbol_3 = $c75d
__call_find_symbol_0 = $c74e
allocate_symbol = $0f79
find_symbol = $0e85
define_constant:
__F_define_constant_entry:
    lda __L_define_constant_name
    sta __call_find_symbol_0
    lda __L_define_constant_name+1
    sta __call_find_symbol_0+1
    lda __L_define_constant_length
    jsr find_symbol
    sta __L_define_constant_symbol
    stx __L_define_constant_symbol+1
    lda __L_define_constant_symbol+1
    bmi __F_define_constant_join_3
__F_define_constant_yes_1:
    lda ASSEMBLE_BAD_SYMBOL
    rts
__F_define_constant_join_3:
    cmp #$ff
    bne __F_define_constant_join_6
    lda __L_define_constant_symbol
    cmp #$fe
    bne __F_define_constant_join_6
__F_define_constant_yes_4:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_define_constant_join_6:
    lda __L_define_constant_name
    sta __call_allocate_symbol_0
    lda __L_define_constant_name+1
    sta __call_allocate_symbol_0+1
    lda __L_define_constant_length
    sta __call_allocate_symbol_1
    lda SYMBOL_CONSTANT
    sta __call_allocate_symbol_2
    lda __L_define_constant_value
    sta __call_allocate_symbol_3
    lda __L_define_constant_value+1
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    sta __L_define_constant_symbol
    stx __L_define_constant_symbol+1
    lda __L_define_constant_symbol+1
    cmp #$ff
    bne __F_define_constant_join_9
    lda __L_define_constant_symbol
    cmp #$fe
    bne __F_define_constant_join_9
__F_define_constant_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_define_constant_join_9:
    lda __L_define_constant_symbol+1
    bpl __F_define_constant_join_12
__F_define_constant_yes_10:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_define_constant_join_12:
    lda ASSEMBLE_OK
    rts
