* = $0800
__L_read_source_line_c = $0030
__L_read_source_line_handle = $0032
__ap = $0002
__call_io_read_0 = $cf14
__outline_04 = $28ba
__outline_19 = $29d9
io_read = $2777
source_line = $7404
source_line_length = $7504
read_source_line:
__F_read_source_line_entry:
    lda #$00
    sta source_line_length
    jsr __outline_04
    lda (__ap),y
    sta __L_read_source_line_handle
__F_read_source_line_while_1:
    lda #$01
    ora #$00
    beq __F_read_source_line_after_3
__F_read_source_line_body_2:
    lda __L_read_source_line_handle
    sta __call_io_read_0
    lda #$00
    sta __call_io_read_0+1
    jsr io_read
    sta __L_read_source_line_c
    stx __L_read_source_line_c+1
    lda __L_read_source_line_c+1
    bpl __F_read_source_line_join_6
__F_read_source_line_yes_4:
    cmp #$ff
    bne __F_read_source_line_join_9
    lda __L_read_source_line_c
    cmp #$ff
    bne __F_read_source_line_join_9
__F_read_source_line_yes_7:
    lda source_line_length
    cmp #$00
    beq __F_read_source_line_join_12
__F_read_source_line_yes_10:
    jsr __outline_19
    rts
__F_read_source_line_join_12:
    lda #$00
    ldx #$00
    rts
__F_read_source_line_join_9:
    lda #$ff
    ldx #$ff
    rts
__F_read_source_line_join_6:
    cmp #$00
    bne __F_read_source_line_join_15
    lda __L_read_source_line_c
    cmp #$0d
    bne __F_read_source_line_join_15
__F_read_source_line_yes_13:
    jsr __outline_19
    rts
__F_read_source_line_join_15:
    lda __L_read_source_line_c+1
    cmp #$00
    bne __F_read_source_line_join_18
    lda __L_read_source_line_c
    cmp #$0a
    bne __F_read_source_line_join_18
__F_read_source_line_yes_16:
    jsr __outline_19
    rts
__F_read_source_line_join_18:
    lda source_line_length
    cmp #$ff
    bcc __F_read_source_line_join_21
__F_read_source_line_yes_19:
    lda #$fe
    ldx #$ff
    rts
__F_read_source_line_join_21:
    ldy source_line_length
    lda __L_read_source_line_c
    sta source_line,y
    inc source_line_length
    jmp __F_read_source_line_while_1
__F_read_source_line_after_3:
    lda #$00
    ldx #$00
    rts
