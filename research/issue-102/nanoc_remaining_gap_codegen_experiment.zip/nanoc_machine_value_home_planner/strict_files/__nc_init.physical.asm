* = $26a8
NC_BSS = $4800
NC_PTR = $00fe
NC_TMP = $00fc
__c_io_close__v00 = $cf1e
__c_io_open__v00 = $cf10
__c_io_open__v01 = $cf12
__c_io_read__v00 = $cf14
__nc_bss_bytes = $8040
__nc_io_eof = $ce06
__nc_io_handle = $ce0c
__nc_io_mode = $ce00
__nc_init:
	cld
	lda #<NC_BSS
	sta NC_PTR
	lda #>NC_BSS
	sta NC_PTR+1
	lda #<__nc_bss_bytes
	sta NC_TMP
	lda #>__nc_bss_bytes
	sta NC_TMP+1
	ldy #$00
__local___nc_init_clear_bss:
	lda NC_TMP
	ora NC_TMP+1
	beq __local___nc_init_clear_runtime
	lda #$00
	sta (NC_PTR),y
	inc NC_PTR
	bne __local___nc_init_pointer_ok
	inc NC_PTR+1
__local___nc_init_pointer_ok:
	lda NC_TMP
	bne __local___nc_init_dec_low
	dec NC_TMP+1
__local___nc_init_dec_low:
	dec NC_TMP
	jmp __local___nc_init_clear_bss
__local___nc_init_clear_runtime:
	lda #$00
	ldx #$05
__local___nc_init_clear_io:
	sta __nc_io_mode,x
	sta __nc_io_eof,x
	dex
	bpl __local___nc_init_clear_io
	cld
	rts
NC_IO_INPUT        = $01
NC_IO_OUTPUT       = $02
NC_IO_PREFETCH     = $03
NC_IO_PREFETCH_EOF = $04
NC_IO_HANDLE_COUNT = $06
NC_IO_LFN_BASE     = $04
NC_IO_READ_DEVICE  = $08
NC_IO_WRITE_DEVICE = $09
__nc_io_zero:
	lda #$00
	ldx #$00
	cld
	rts
__nc_io_minus1:
	lda #$ff
	ldx #$ff
	cld
	rts
__nc_io_minus2:
	lda #$fe
	ldx #$ff
	cld
	rts
__c_io_open:
	cld
	ldx #$00
__local___c_io_open_find:
	lda __nc_io_mode,x
	beq __local___c_io_open_slot
	inx
	cpx #NC_IO_HANDLE_COUNT
	bne __local___c_io_open_find
	jmp __nc_io_minus1
__local___c_io_open_slot:
	stx __nc_io_handle
	lda __c_io_open__v01+1
    bne __nc_io_minus1
__local___c_io_open_length_ok:
	jsr $ffcc      ; CLRCHN
	lda __c_io_open__v01
	ldx __c_io_open__v00
	ldy __c_io_open__v00+1
	jsr $ffbd      ; SETNAM
	lda __nc_io_handle
	clc
	adc #NC_IO_LFN_BASE
	tay
	ldx #NC_IO_READ_DEVICE
	jsr $ffba      ; SETLFS
	jsr $ffc0      ; OPEN
	bcs __local___c_io_open_fail
	lda __nc_io_handle
	clc
	adc #NC_IO_LFN_BASE
	tax
	jsr $ffc6      ; CHKIN
	bcs __local___c_io_open_fail
	jsr $ffcf      ; CHRIN
	sta NC_TMP
	jsr $ffb7      ; READST
	sta NC_TMP+1
	and #$bf
	beq __local___c_io_open_ok
__local___c_io_open_fail:
	jsr $ffcc      ; CLRCHN
	lda __nc_io_handle
	clc
	adc #NC_IO_LFN_BASE
	jsr $ffc3      ; CLOSE
	jmp __nc_io_minus1
__local___c_io_open_ok:
	jsr $ffcc      ; CLRCHN
	ldx __nc_io_handle
	lda NC_TMP
	sta __nc_io_eof,x
	lda NC_TMP+1
	and #$40
	beq __local___c_io_open_prefetch
	lda #NC_IO_PREFETCH_EOF
	bne __local___c_io_open_store_mode
__local___c_io_open_prefetch:
	lda #NC_IO_PREFETCH
__local___c_io_open_store_mode:
	sta __nc_io_mode,x
	txa
	ldx #$00
	cld
	rts
__c_io_read:
	cld
	lda __c_io_read__v00+1
	beq __local___c_io_read_handle_low
	jmp __nc_io_minus2
__local___c_io_read_handle_low:
	lda __c_io_read__v00
	cmp #NC_IO_HANDLE_COUNT
	bcc __local___c_io_read_in_range
	jmp __nc_io_minus2
__local___c_io_read_in_range:
	sta __nc_io_handle
	tax
	lda __nc_io_mode,x
	cmp #NC_IO_INPUT
	beq __local___c_io_read_open
	cmp #NC_IO_PREFETCH
	beq __local___c_io_read_prefetch
	cmp #NC_IO_PREFETCH_EOF
	beq __local___c_io_read_prefetch_eof
	jmp __nc_io_minus2
__local___c_io_read_prefetch:
	lda __nc_io_eof,x
	sta NC_TMP
	lda #$00
	sta __nc_io_eof,x
	lda #NC_IO_INPUT
	sta __nc_io_mode,x
	lda NC_TMP
	ldx #$00
	cld
	rts
__local___c_io_read_prefetch_eof:
	lda __nc_io_eof,x
	sta NC_TMP
	lda #$01
	sta __nc_io_eof,x
	lda #NC_IO_INPUT
	sta __nc_io_mode,x
	lda NC_TMP
	ldx #$00
	cld
	rts
__local___c_io_read_open:
	lda __nc_io_eof,x
	beq __local___c_io_read_byte
	jmp __nc_io_minus1
__local___c_io_read_byte:
	jsr $ffcc      ; CLRCHN
	lda __nc_io_handle
	clc
	adc #NC_IO_LFN_BASE
	tax
	jsr $ffc6      ; CHKIN
    bcs __local___c_io_read_error_clear
__local___c_io_read_selected:
	jsr $ffcf      ; CHRIN
	sta NC_TMP
	jsr $ffb7      ; READST
	sta NC_TMP+1
	jsr $ffcc      ; CLRCHN
	lda NC_TMP+1
	and #$bf
	beq __local___c_io_read_status_ok
	jmp __nc_io_minus2
__local___c_io_read_status_ok:
	lda NC_TMP+1
	and #$40
	beq __local___c_io_read_return
	ldx __nc_io_handle
	lda #$01
	sta __nc_io_eof,x
__local___c_io_read_return:
	lda NC_TMP
	ldx #$00
	cld
	rts
__local___c_io_read_error_clear:
	jsr $ffcc      ; CLRCHN
	jmp __nc_io_minus2
__c_io_close:
	cld
	lda __c_io_close__v00+1
	beq __local___c_io_close_handle_low
	jmp __nc_io_minus1
__local___c_io_close_handle_low:
	lda __c_io_close__v00
	cmp #NC_IO_HANDLE_COUNT
	bcc __local___c_io_close_in_range
	jmp __nc_io_minus1
__local___c_io_close_in_range:
	sta __nc_io_handle
	tax
	lda __nc_io_mode,x
	bne __local___c_io_close_open
	jmp __nc_io_minus1
__local___c_io_close_open:
	jsr $ffcc      ; CLRCHN
	lda __nc_io_handle
	clc
	adc #NC_IO_LFN_BASE
	jsr $ffc3      ; CLOSE
	ldx __nc_io_handle
	lda #$00
	sta __nc_io_mode,x
	sta __nc_io_eof,x
	jmp __nc_io_zero
