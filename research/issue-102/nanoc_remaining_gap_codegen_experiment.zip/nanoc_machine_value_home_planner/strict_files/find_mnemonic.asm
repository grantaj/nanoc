* = $0800
__L_find_mnemonic_candidate = $0033
__L_find_mnemonic_length = $0037
__L_find_mnemonic_offset = $0036
__mw = $0007
__outline_09 = $2929
__outline_26 = $2a4a
__tmp0 = $0009
__tmp2 = $000b
mnemonic_table = $082c
upper_char = $0ae8
find_mnemonic:
__F_find_mnemonic_entry:
    sta __L_find_mnemonic_length
    cmp #$03
    beq __F_find_mnemonic_join_3
__F_find_mnemonic_yes_1:
    lda #$ff
    ldx #$ff
    rts
__F_find_mnemonic_join_3:
    lda #$00
    sta __L_find_mnemonic_candidate
__F_find_mnemonic_while_4:
    lda __L_find_mnemonic_candidate
    cmp #$38
    bcs __F_find_mnemonic_after_6
__F_find_mnemonic_body_5:
    lda #$00
    sta __tmp0
    lda __L_find_mnemonic_candidate
    sta __mw
    clc
    lda __tmp0
    adc __mw
    sta __tmp0
    asl __mw
    clc
    lda __tmp0
    adc __mw
    sta __L_find_mnemonic_offset
    ldy #$00
    jsr __outline_26
    jsr upper_char
    sta __tmp0
    ldy __L_find_mnemonic_offset
    lda mnemonic_table,y
    cmp __tmp0
    bne __F_find_mnemonic_join_9
__F_find_mnemonic_yes_7:
    ldy #$01
    jsr __outline_26
    jsr upper_char
    sta __tmp2
    lda __L_find_mnemonic_offset
    clc
    adc #$01
    jsr __outline_09
    bne __F_find_mnemonic_join_9
__F_find_mnemonic_yes_10:
    ldy #$02
    jsr __outline_26
    jsr upper_char
    sta __tmp2
    lda __L_find_mnemonic_offset
    clc
    adc #$02
    jsr __outline_09
    bne __F_find_mnemonic_join_9
__F_find_mnemonic_yes_13:
    lda __L_find_mnemonic_candidate
    ldx #$00
    rts
__F_find_mnemonic_join_9:
    inc __L_find_mnemonic_candidate
    jmp __F_find_mnemonic_while_4
__F_find_mnemonic_after_6:
    lda #$ff
    ldx #$ff
    rts
