* = $0800
SYMBOL_LABEL_UNDEFINED = $0ad9
VALUE_BAD = $0add
VALUE_OK = $0adb
VALUE_SCOPE_ERROR = $0adf
VALUE_SYMBOL_FULL = $0ade
VALUE_UNRESOLVED = $0adc
__L_parse_atom_digit = $c786
__L_parse_atom_i = $0036
__L_parse_atom_length = $c784
__L_parse_atom_symbol = $0039
__L_parse_atom_text = $0034
__L_parse_atom_value = $0039
__ap = $0002
__call_find_symbol_0 = $c74e
__call_intern_label_0 = $c764
__ix = $0004
__mw = $0007
__outline_03 = $28a7
__outline_16 = $29b3
__outline_22 = $2a0e
__outline_24 = $2a2d
__outline_33 = $2ab7
__tmp0 = $0009
__tmp1 = $000a
__tmp2 = $000b
__tmp3 = $000c
atom_kind = $c722
atom_symbol = $c71f
atom_used = $c721
atom_value = $c71d
find_symbol = $0e85
hex_nibble = $0b49
intern_label = $10b3
symbol_kind = $8b0f
parse_atom:
__F_parse_atom_entry:
    sta __L_parse_atom_length
    lda #$00
    sta atom_used
    lda __L_parse_atom_length
    cmp #$00
    bne __F_parse_atom_join_3
__F_parse_atom_yes_1:
    lda VALUE_BAD
    rts
__F_parse_atom_join_3:
    ldy #$00
    jsr __outline_16
    cmp #$24
    beq __F_parse_atom_yes_4
    jmp __F_parse_atom_join_6
__F_parse_atom_yes_4:
    lda #$01
    sta __L_parse_atom_i
    lda #$00
    sta __L_parse_atom_value
    sta __L_parse_atom_value+1
__F_parse_atom_while_7:
    lda __L_parse_atom_i
    cmp __L_parse_atom_length
    bcs __F_parse_atom_after_9
__F_parse_atom_body_8:
    ldy __L_parse_atom_i
    jsr __outline_16
    sta __tmp0
    cmp #$2b
    beq __F_parse_atom_after_9
__F_parse_atom_no_11:
    cmp #$2d
    beq __F_parse_atom_after_9
__F_parse_atom_no_14:
    lda __tmp0
    jsr hex_nibble
    sta __L_parse_atom_digit
    stx __L_parse_atom_digit+1
    lda __L_parse_atom_digit+1
    bpl __F_parse_atom_join_18
__F_parse_atom_yes_16:
    lda VALUE_BAD
    rts
__F_parse_atom_join_18:
    lda atom_used
    cmp #$04
    bcc __F_parse_atom_join_21
__F_parse_atom_yes_19:
    lda VALUE_BAD
    rts
__F_parse_atom_join_21:
    lda __L_parse_atom_value
    sta __tmp0
    lda __L_parse_atom_value+1
    sta __tmp1
    asl __tmp0
    rol __tmp1
    asl __tmp0
    rol __tmp1
    asl __tmp0
    rol __tmp1
    asl __tmp0
    rol __tmp1
    lda __tmp0
    ora __L_parse_atom_digit
    sta __tmp2
    lda __tmp1
    ora __L_parse_atom_digit+1
    jsr __outline_33
    jmp __F_parse_atom_while_7
__F_parse_atom_after_9:
    lda atom_used
    cmp #$00
    bne __F_parse_atom_join_24
__F_parse_atom_yes_22:
    lda VALUE_BAD
    rts
__F_parse_atom_join_24:
    inc atom_used
    lda __L_parse_atom_value
    sta atom_value
    lda __L_parse_atom_value+1
    jsr __outline_22
    rts
__F_parse_atom_join_6:
    cmp #$27
    bne __F_parse_atom_join_27
__F_parse_atom_yes_25:
    lda __L_parse_atom_length
    cmp #$03
    bcs __F_parse_atom_join_30
__F_parse_atom_yes_28:
    lda VALUE_BAD
    rts
__F_parse_atom_join_30:
    ldy #$02
    jsr __outline_16
    cmp #$27
    beq __F_parse_atom_join_33
__F_parse_atom_yes_31:
    lda VALUE_BAD
    rts
__F_parse_atom_join_33:
    ldy #$01
    jsr __outline_16
    sta atom_value
    lda #$00
    sta atom_value+1
    lda #$03
    sta atom_used
    lda #$00
    sta atom_kind
    lda VALUE_OK
    rts
__F_parse_atom_join_27:
    cmp #$30
    bcc __F_parse_atom_join_36
__F_parse_atom_yes_34:
    cmp #$39
    bcc __F_parse_atom_yes_37
    bne __F_parse_atom_join_36
__F_parse_atom_yes_37:
    lda #$00
    sta __L_parse_atom_i
    sta __L_parse_atom_value
    sta __L_parse_atom_value+1
    ldy __L_parse_atom_i
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
__F_parse_atom_while_40:
    cpy __L_parse_atom_length
    bcs __F_parse_atom_after_42
__F_parse_atom_body_41:
    lda (__ap),y
    sta __tmp0
    cmp #$2b
    beq __F_parse_atom_after_42
__F_parse_atom___far_skip_0:
__F_parse_atom_no_44:
    cmp #$2d
    beq __F_parse_atom_after_42
__F_parse_atom_no_47:
    cmp #$30
    bcs __F_parse_atom_join_51
__F_parse_atom_yes_49:
    lda VALUE_BAD
    rts
__F_parse_atom_join_51:
    cmp #$39
    bcc __F_parse_atom_join_54
    beq __F_parse_atom_join_54
__F_parse_atom_yes_52:
    lda VALUE_BAD
    rts
__F_parse_atom_join_54:
    lda #$00
    sta __tmp2
    sta __tmp3
    lda __L_parse_atom_value
    sta __mw
    lda __L_parse_atom_value+1
    sta __mw+1
    jsr __outline_24
    asl __mw
    rol __mw+1
    jsr __outline_24
    lda __tmp2
    clc
    adc __tmp0
    sta __tmp0
    lda __tmp3
    adc #$00
    sta __tmp1
    lda __tmp0
    sec
    sbc #$30
    sta __tmp2
    lda __tmp1
    sbc #$00
    jsr __outline_33
    iny
    jmp __F_parse_atom_while_40
__F_parse_atom_after_42:
    lda __L_parse_atom_value
    sta atom_value
    lda __L_parse_atom_value+1
    jsr __outline_22
    rts
__F_parse_atom_join_36:
    lda #$00
    sta __L_parse_atom_i
    ldy __L_parse_atom_i
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
__F_parse_atom_while_55:
    cpy __L_parse_atom_length
    bcs __F_parse_atom_after_57
__F_parse_atom_body_56:
    lda (__ap),y
    cmp #$2b
    beq __F_parse_atom_after_57
__F_parse_atom_no_59:
    cmp #$2d
    beq __F_parse_atom_after_57
__F_parse_atom_no_62:
    inc atom_used
    inc __L_parse_atom_i
    iny
    jmp __F_parse_atom_while_55
__F_parse_atom_after_57:
    lda atom_used
    cmp #$00
    bne __F_parse_atom_join_66
__F_parse_atom_yes_64:
    lda VALUE_BAD
    rts
__F_parse_atom_join_66:
    lda __L_parse_atom_text
    sta __call_find_symbol_0
    lda __L_parse_atom_text+1
    sta __call_find_symbol_0+1
    lda atom_used
    jsr find_symbol
    sta __L_parse_atom_symbol
    stx __L_parse_atom_symbol+1
    lda __L_parse_atom_symbol+1
    cmp #$ff
    bne __F_parse_atom_join_69
    lda __L_parse_atom_symbol
    cmp #$fe
    bne __F_parse_atom_join_69
__F_parse_atom_yes_67:
    lda VALUE_SCOPE_ERROR
    rts
__F_parse_atom_join_69:
    lda __L_parse_atom_symbol+1
    bpl __F_parse_atom_join_72
__F_parse_atom_yes_70:
    lda __L_parse_atom_text
    sta __call_intern_label_0
    lda __L_parse_atom_text+1
    sta __call_intern_label_0+1
    lda atom_used
    jsr intern_label
    sta __L_parse_atom_symbol
    stx __L_parse_atom_symbol+1
    lda __L_parse_atom_symbol+1
    cmp #$ff
    bne __F_parse_atom_join_75
    lda __L_parse_atom_symbol
    cmp #$fe
    bne __F_parse_atom_join_75
__F_parse_atom_yes_73:
    lda VALUE_SCOPE_ERROR
    rts
__F_parse_atom_join_75:
    lda __L_parse_atom_symbol+1
    cmp #$ff
    bne __F_parse_atom_join_78
    lda __L_parse_atom_symbol
    cmp #$fd
    bne __F_parse_atom_join_78
__F_parse_atom_yes_76:
    lda VALUE_SYMBOL_FULL
    rts
__F_parse_atom_join_78:
    lda __L_parse_atom_symbol+1
    bpl __F_parse_atom_join_72
__F_parse_atom_yes_79:
    lda VALUE_BAD
    rts
__F_parse_atom_join_72:
    clc
    lda __L_parse_atom_symbol
    adc #<symbol_kind
    sta __ap
    lda __L_parse_atom_symbol+1
    adc #>symbol_kind
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp SYMBOL_LABEL_UNDEFINED
    bne __F_parse_atom_join_84
__F_parse_atom_yes_82:
    lda __L_parse_atom_symbol
    sta atom_symbol
    lda __L_parse_atom_symbol+1
    sta atom_symbol+1
    lda #$01
    sta atom_kind
    lda VALUE_UNRESOLVED
    rts
__F_parse_atom_join_84:
    lda __L_parse_atom_symbol
    asl
    sta __ix
    lda __L_parse_atom_symbol+1
    jsr __outline_03
    lda (__ap),y
    sta atom_value
    iny
    lda (__ap),y
    jsr __outline_22
    rts
