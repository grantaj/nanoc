* = $2546
SYMBOL_LABEL_UNDEFINED = $0ad9
__L_all_symbols_defined_i = $0030
__ap = $0002
__rh = $0006
__tmp0 = $0009
__tmp1 = $000a
symbol_count = $b30f
symbol_kind = $8b0f
all_symbols_defined:
__F_all_symbols_defined_entry:
    lda #$00
    sta __L_all_symbols_defined_i
    sta __L_all_symbols_defined_i+1
    ldy #$00
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
__F_all_symbols_defined_while_1:
    lda symbol_count+1
    eor #$80
    sta __rh
    lda __L_all_symbols_defined_i+1
    eor #$80
    cmp __rh
    bcc __F_all_symbols_defined_body_2
    bne __F_all_symbols_defined_after_3
    lda __L_all_symbols_defined_i
    cmp symbol_count
    bcs __F_all_symbols_defined_after_3
__F_all_symbols_defined_body_2:
    lda (__ap),y
    cmp SYMBOL_LABEL_UNDEFINED
    bne __F_all_symbols_defined_join_6
__F_all_symbols_defined_yes_4:
    lda #$00
    rts
__F_all_symbols_defined_join_6:
    lda __L_all_symbols_defined_i
    clc
    adc #$01
    sta __tmp0
    lda __L_all_symbols_defined_i+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta __L_all_symbols_defined_i
    lda __tmp1
    sta __L_all_symbols_defined_i+1
    inc __ap
    bne __F_all_symbols_defined___sel1
    inc __ap+1
__F_all_symbols_defined___sel1:
    jmp __F_all_symbols_defined_while_1
__F_all_symbols_defined_after_3:
    lda #$01
    rts
