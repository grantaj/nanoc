* = $2112
ASSEMBLE_OK = $0803
__ap = $0002
__call_io_close_0 = $cf1e
__outline_04 = $28ba
__outline_14 = $298a
io_close = $2811
source_depth = $760a
close_source_tree:
__F_close_source_tree_entry:
__F_close_source_tree_while_1:
    lda source_depth+1
    bmi __F_close_source_tree_after_3
__F_close_source_tree_body_2:
    jsr __outline_04
    lda (__ap),y
    sta __call_io_close_0
    lda #$00
    sta __call_io_close_0+1
    jsr io_close
    jsr __outline_14
    jmp __F_close_source_tree_while_1
__F_close_source_tree_after_3:
    lda ASSEMBLE_OK
    rts
