* = $0800
ASSEMBLE_BAD_ORIGIN = $080c
ASSEMBLE_BAD_SYMBOL = $0805
ASSEMBLE_OK = $0803
ASSEMBLE_SCOPE_ERROR = $0807
ASSEMBLE_SYMBOL_FULL = $0806
VALUE_OK = $0adb
VALUE_SCOPE_ERROR = $0adf
VALUE_SYMBOL_FULL = $0ade
__L_process_symbol_argument = $003d
__L_process_symbol_argument_length = $c81b
__L_process_symbol_name = $003b
__L_process_symbol_name_length = $003f
__L_process_symbol_status = $0030
__ap = $0002
__call_define_constant_0 = $0032
__call_define_constant_1 = $0034
__call_define_constant_2 = $0037
__call_parse_value_0 = $0037
ass_origin = $7402
define_constant = $1122
origin_allowed = $c723
parse_value = $1504
value_result = $c716
process_symbol:
__F_process_symbol_entry:
    sta __L_process_symbol_argument_length
    lda __L_process_symbol_name_length
    cmp #$01
    bne __F_process_symbol_join_3
__F_process_symbol_yes_1:
    ldy #$00
    lda __L_process_symbol_name
    sta __ap
    lda __L_process_symbol_name+1
    sta __ap+1
    lda (__ap),y
    cmp #$2a
    bne __F_process_symbol_join_3
__F_process_symbol_yes_4:
    lda origin_allowed
    cmp #$00
    bne __F_process_symbol_join_9
__F_process_symbol_yes_7:
    lda ASSEMBLE_BAD_ORIGIN
    rts
__F_process_symbol_join_9:
    lda __L_process_symbol_argument
    sta __call_parse_value_0
    lda __L_process_symbol_argument+1
    sta __call_parse_value_0+1
    lda __L_process_symbol_argument_length
    jsr parse_value
    sta __L_process_symbol_status
    cmp VALUE_OK
    beq __F_process_symbol_join_12
__F_process_symbol_yes_10:
    lda ASSEMBLE_BAD_ORIGIN
    rts
__F_process_symbol_join_12:
    lda value_result
    sta ass_origin
    lda value_result+1
    sta ass_origin+1
    lda #$00
    sta origin_allowed
    lda ASSEMBLE_OK
    rts
__F_process_symbol_join_3:
    lda __L_process_symbol_argument
    sta __call_parse_value_0
    lda __L_process_symbol_argument+1
    sta __call_parse_value_0+1
    lda __L_process_symbol_argument_length
    jsr parse_value
    sta __L_process_symbol_status
    cmp VALUE_OK
    beq __F_process_symbol_join_15
__F_process_symbol_yes_13:
    cmp VALUE_SYMBOL_FULL
    bne __F_process_symbol_join_18
__F_process_symbol_yes_16:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_process_symbol_join_18:
    cmp VALUE_SCOPE_ERROR
    bne __F_process_symbol_join_21
__F_process_symbol_yes_19:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_process_symbol_join_21:
    lda ASSEMBLE_BAD_SYMBOL
    rts
__F_process_symbol_join_15:
    lda __L_process_symbol_name
    sta __call_define_constant_0
    lda __L_process_symbol_name+1
    sta __call_define_constant_0+1
    lda __L_process_symbol_name_length
    sta __call_define_constant_1
    lda value_result
    sta __call_define_constant_2
    lda value_result+1
    sta __call_define_constant_2+1
    jsr define_constant
    rts
