* = $0f79
__L_allocate_symbol_i = $c763
__L_allocate_symbol_kind = $c75c
__L_allocate_symbol_length = $0036
__L_allocate_symbol_n = $0039
__L_allocate_symbol_name = $c759
__L_allocate_symbol_payload = $c75d
__L_allocate_symbol_scope = $c75f
__ap = $0002
__call_scope_for_name_0 = $0039
__ix = $0004
__outline_03 = $28a7
__outline_23 = $2a1a
__tmp0 = $0009
__tmp1 = $000a
__tmp2 = $000b
scope_for_name = $0e52
symbol_count = $b30f
symbol_kind = $8b0f
symbol_name_bytes = $8e8f
symbol_name_length = $7d0f
symbol_name_used = $b311
symbol_scope = $878f
allocate_symbol:
__F_allocate_symbol_entry:
    lda __L_allocate_symbol_name
    sta __call_scope_for_name_0
    lda __L_allocate_symbol_name+1
    sta __call_scope_for_name_0+1
    lda __L_allocate_symbol_length
    jsr scope_for_name
    sta __L_allocate_symbol_scope
    stx __L_allocate_symbol_scope+1
    lda __L_allocate_symbol_scope+1
    bpl __F_allocate_symbol_join_3
__F_allocate_symbol_yes_1:
    lda #$fe
    ldx #$ff
    rts
__F_allocate_symbol_join_3:
    lda symbol_count+1
    eor #$80
    cmp #$83
    bcc __F_allocate_symbol_join_6
    bne __F_allocate_symbol_yes_4
    lda symbol_count
    cmp #$80
    bcc __F_allocate_symbol_join_6
__F_allocate_symbol_yes_4:
    lda #$fd
    ldx #$ff
    rts
__F_allocate_symbol_join_6:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_length
    sta __tmp0
    lda symbol_name_used+1
    adc #$00
    eor #$80
    cmp #$a4
    bcc __F_allocate_symbol_join_9
    bne __F_allocate_symbol_yes_7
    lda __tmp0
    cmp #$80
    bcc __F_allocate_symbol_join_9
    beq __F_allocate_symbol_join_9
__F_allocate_symbol_yes_7:
    lda #$fd
    ldx #$ff
    rts
__F_allocate_symbol_join_9:
    lda symbol_count
    sta __L_allocate_symbol_n
    lda symbol_count+1
    sta __L_allocate_symbol_n+1
    lda __L_allocate_symbol_n
    asl
    sta __ix
    lda __L_allocate_symbol_n+1
    jsr __outline_23
    lda symbol_name_used
    sta (__ap),y
    iny
    lda symbol_name_used+1
    sta (__ap),y
    clc
    lda __L_allocate_symbol_n
    adc #<symbol_name_length
    sta __ap
    lda __L_allocate_symbol_n+1
    adc #>symbol_name_length
    sta __ap+1
    ldy #$00
    lda __L_allocate_symbol_length
    sta (__ap),y
    lda __L_allocate_symbol_n
    asl
    sta __ix
    lda __L_allocate_symbol_n+1
    jsr __outline_03
    lda __L_allocate_symbol_payload
    sta (__ap),y
    iny
    lda __L_allocate_symbol_payload+1
    sta (__ap),y
    clc
    lda __L_allocate_symbol_n
    adc #<symbol_scope
    sta __ap
    lda __L_allocate_symbol_n+1
    adc #>symbol_scope
    sta __ap+1
    ldy #$00
    lda __L_allocate_symbol_scope
    sta (__ap),y
    clc
    lda __L_allocate_symbol_n
    adc #<symbol_kind
    sta __ap
    lda __L_allocate_symbol_n+1
    adc #>symbol_kind
    sta __ap+1
    ldy #$00
    lda __L_allocate_symbol_kind
    sta (__ap),y
    lda #$00
    sta __L_allocate_symbol_i
__F_allocate_symbol_while_10:
    lda __L_allocate_symbol_i
    cmp __L_allocate_symbol_length
    bcs __F_allocate_symbol_after_12
__F_allocate_symbol_body_11:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_i
    sta __tmp0
    lda symbol_name_used+1
    adc #$00
    sta __tmp1
    ldy __L_allocate_symbol_i
    lda __L_allocate_symbol_name
    sta __ap
    lda __L_allocate_symbol_name+1
    sta __ap+1
    lda (__ap),y
    sta __tmp2
    clc
    lda __tmp0
    adc #<symbol_name_bytes
    sta __ap
    lda __tmp1
    adc #>symbol_name_bytes
    sta __ap+1
    ldy #$00
    lda __tmp2
    sta (__ap),y
    inc __L_allocate_symbol_i
    jmp __F_allocate_symbol_while_10
__F_allocate_symbol_after_12:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_length
    sta __tmp0
    lda symbol_name_used+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta symbol_name_used
    lda __tmp1
    sta symbol_name_used+1
    lda __L_allocate_symbol_n
    clc
    adc #$01
    sta symbol_count
    lda __L_allocate_symbol_n+1
    adc #$00
    sta symbol_count+1
    lda __L_allocate_symbol_n
    ldx __L_allocate_symbol_n+1
    rts
