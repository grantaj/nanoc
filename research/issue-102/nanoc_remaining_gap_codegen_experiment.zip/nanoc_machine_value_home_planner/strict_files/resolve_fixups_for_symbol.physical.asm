* = $0cbc
ASSEMBLE_BAD_DATA = $080b
ASSEMBLE_EMIT_ERROR = $080a
FIXUP_DATA_BYTE = $0ae7
FIXUP_NONE = $0ae3
FIXUP_RELATIVE = $0ae6
FIXUP_WORD = $0ae5
VALUE_PREFIX_NONE = $0ae0
__L_resolve_fixups_for_symbol_i = $0031
__L_resolve_fixups_for_symbol_kind = $c744
__L_resolve_fixups_for_symbol_relative = $0033
__L_resolve_fixups_for_symbol_stage = $0035
__L_resolve_fixups_for_symbol_symbol = $0039
__L_resolve_fixups_for_symbol_value = $0033
__ap = $0002
__call_apply_byte_prefix_0 = $0035
__call_relative_byte_0 = $c73a
__call_relative_byte_1 = $c73c
__ix = $0004
__outline_03 = $28a7
__outline_11 = $2955
__outline_17 = $29be
__outline_20 = $29e6
__outline_30 = $2a87
__outline_36 = $2ae7
__rh = $0006
__tmp0 = $0009
__tmp1 = $000a
__tmp2 = $000b
__tmp3 = $000c
__tmp4 = $000d
__tmp5 = $000e
apply_byte_prefix = $0b3b
ass_origin = $7402
fixup_addend = $bf94
fixup_count = $c714
fixup_prefix = $c494
fixup_stage = $b594
fixup_symbol = $ba94
relative_byte = $0c33
trim_fixups = $0c77
resolve_fixups_for_symbol:
__F_resolve_fixups_for_symbol_entry:
    lda #$00
    sta __L_resolve_fixups_for_symbol_i
    sta __L_resolve_fixups_for_symbol_i+1
__F_resolve_fixups_for_symbol_while_1:
    lda fixup_count+1
    eor #$80
    sta __rh
    lda __L_resolve_fixups_for_symbol_i+1
    eor #$80
    cmp __rh
    bcc __F_resolve_fixups_for_symbol_body_2
    beq __F_resolve_fixups_for_symbol___far_skip_0
    jmp __F_resolve_fixups_for_symbol_after_3
__F_resolve_fixups_for_symbol___far_skip_0:
    lda __L_resolve_fixups_for_symbol_i
    cmp fixup_count
    bcc __F_resolve_fixups_for_symbol_body_2
    jmp __F_resolve_fixups_for_symbol_after_3
__F_resolve_fixups_for_symbol_body_2:
    jsr __outline_30
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_NONE
    bne __F_resolve_fixups_for_symbol_yes_4
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol_yes_4:
    jsr __outline_17
    adc #<fixup_symbol
    sta __ap
    lda __ix+1
    adc #>fixup_symbol
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __tmp0
    iny
    lda (__ap),y
    cmp __L_resolve_fixups_for_symbol_symbol+1
    beq __F_resolve_fixups_for_symbol___far_skip_1
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol___far_skip_1:
    lda __tmp0
    cmp __L_resolve_fixups_for_symbol_symbol
    beq __F_resolve_fixups_for_symbol_yes_7
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol_yes_7:
    lda __L_resolve_fixups_for_symbol_symbol
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_symbol+1
    jsr __outline_03
    jsr __outline_36
    jsr __outline_17
    adc #<fixup_addend
    sta __ap
    lda __ix+1
    adc #>fixup_addend
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __tmp2
    iny
    lda (__ap),y
    sta __tmp3
    lda __tmp0
    clc
    adc __tmp2
    sta __tmp4
    lda __tmp1
    adc __tmp3
    sta __tmp5
    lda __tmp4
    sta __L_resolve_fixups_for_symbol_value
    lda __tmp5
    sta __L_resolve_fixups_for_symbol_value+1
    clc
    lda __L_resolve_fixups_for_symbol_i
    adc #<fixup_prefix
    sta __ap
    lda __L_resolve_fixups_for_symbol_i+1
    adc #>fixup_prefix
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __tmp0
    cmp VALUE_PREFIX_NONE
    beq __F_resolve_fixups_for_symbol_join_12
__F_resolve_fixups_for_symbol_yes_10:
    lda __L_resolve_fixups_for_symbol_value
    sta __call_apply_byte_prefix_0
    lda __L_resolve_fixups_for_symbol_value+1
    sta __call_apply_byte_prefix_0+1
    lda __tmp0
    jsr apply_byte_prefix
    sta __tmp0
    lda __tmp0
    sta __L_resolve_fixups_for_symbol_value
    lda #$00
    sta __L_resolve_fixups_for_symbol_value+1
__F_resolve_fixups_for_symbol_join_12:
    jsr __outline_17
    adc #<fixup_stage
    sta __ap
    lda __ix+1
    adc #>fixup_stage
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_stage
    iny
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_stage+1
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_WORD
    bne __F_resolve_fixups_for_symbol_no_14
__F_resolve_fixups_for_symbol_yes_13:
    jsr __outline_11
    lda __L_resolve_fixups_for_symbol_value
    sta (__ap),y
    lda __L_resolve_fixups_for_symbol_stage
    clc
    adc #$01
    sta __tmp0
    lda __L_resolve_fixups_for_symbol_stage+1
    jsr __outline_20
    lda __L_resolve_fixups_for_symbol_value+1
    sta (__ap),y
    jmp __F_resolve_fixups_for_symbol_join_15
__F_resolve_fixups_for_symbol_no_14:
    cmp FIXUP_RELATIVE
    bne __F_resolve_fixups_for_symbol_no_17
__F_resolve_fixups_for_symbol_yes_16:
    lda ass_origin
    clc
    adc __L_resolve_fixups_for_symbol_stage
    sta __tmp0
    lda ass_origin+1
    adc __L_resolve_fixups_for_symbol_stage+1
    sta __tmp1
    lda __tmp0
    clc
    adc #$01
    sta __tmp2
    lda __tmp1
    adc #$00
    sta __tmp3
    lda __L_resolve_fixups_for_symbol_value
    sta __call_relative_byte_0
    lda __L_resolve_fixups_for_symbol_value+1
    sta __call_relative_byte_0+1
    lda __tmp2
    sta __call_relative_byte_1
    lda __tmp3
    sta __call_relative_byte_1+1
    jsr relative_byte
    sta __L_resolve_fixups_for_symbol_relative
    stx __L_resolve_fixups_for_symbol_relative+1
    lda __L_resolve_fixups_for_symbol_relative+1
    bpl __F_resolve_fixups_for_symbol_join_21
__F_resolve_fixups_for_symbol_yes_19:
    lda ASSEMBLE_EMIT_ERROR
    rts
__F_resolve_fixups_for_symbol_join_21:
    jsr __outline_11
    lda __L_resolve_fixups_for_symbol_relative
    sta (__ap),y
    jmp __F_resolve_fixups_for_symbol_join_15
__F_resolve_fixups_for_symbol_no_17:
    lda __L_resolve_fixups_for_symbol_value+1
    cmp #$00
    bcc __F_resolve_fixups_for_symbol_join_24
    bne __F_resolve_fixups_for_symbol_yes_22
    lda __L_resolve_fixups_for_symbol_value
    cmp #$ff
    bcc __F_resolve_fixups_for_symbol_join_24
    beq __F_resolve_fixups_for_symbol_join_24
__F_resolve_fixups_for_symbol_yes_22:
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_DATA_BYTE
    bne __F_resolve_fixups_for_symbol_join_27
__F_resolve_fixups_for_symbol_yes_25:
    lda ASSEMBLE_BAD_DATA
    rts
__F_resolve_fixups_for_symbol_join_27:
    lda ASSEMBLE_EMIT_ERROR
    rts
__F_resolve_fixups_for_symbol_join_24:
    jsr __outline_11
    lda __L_resolve_fixups_for_symbol_value
    sta (__ap),y
__F_resolve_fixups_for_symbol_join_15:
    jsr __outline_30
    lda FIXUP_NONE
    sta (__ap),y
__F_resolve_fixups_for_symbol_join_6:
    lda __L_resolve_fixups_for_symbol_i
    clc
    adc #$01
    sta __tmp0
    lda __L_resolve_fixups_for_symbol_i+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta __L_resolve_fixups_for_symbol_i
    lda __tmp1
    sta __L_resolve_fixups_for_symbol_i+1
    jmp __F_resolve_fixups_for_symbol_while_1
__F_resolve_fixups_for_symbol_after_3:
    jsr trim_fixups
    rts
