* = $1847
ASSEMBLE_EMIT_ERROR = $080a
ASSEMBLE_OK = $0803
__L_stage_resolved_relative_base = $0033
__L_stage_resolved_relative_opcode = $0038
__L_stage_resolved_relative_relative = $0033
__L_stage_resolved_relative_status = $0037
__L_stage_resolved_relative_target = $0035
__call_relative_byte_0 = $c73a
__call_relative_byte_1 = $c73c
__outline_21 = $29fa
__tmp1 = $000a
__tmp2 = $000b
__tmp3 = $000c
relative_byte = $0c33
stage_byte = $173b
stage_resolved_relative:
__F_stage_resolved_relative_entry:
    jsr __outline_21
    clc
    adc #$02
    sta __tmp2
    lda __tmp1
    adc #$00
    sta __tmp3
    lda __tmp2
    sta __L_stage_resolved_relative_base
    lda __tmp3
    sta __L_stage_resolved_relative_base+1
    lda __L_stage_resolved_relative_target
    sta __call_relative_byte_0
    lda __L_stage_resolved_relative_target+1
    sta __call_relative_byte_0+1
    lda __L_stage_resolved_relative_base
    sta __call_relative_byte_1
    lda __L_stage_resolved_relative_base+1
    sta __call_relative_byte_1+1
    jsr relative_byte
    sta __L_stage_resolved_relative_relative
    stx __L_stage_resolved_relative_relative+1
    lda __L_stage_resolved_relative_relative+1
    bpl __F_stage_resolved_relative_join_3
__F_stage_resolved_relative_yes_1:
    lda ASSEMBLE_EMIT_ERROR
    rts
__F_stage_resolved_relative_join_3:
    lda __L_stage_resolved_relative_opcode
    jsr stage_byte
    sta __L_stage_resolved_relative_status
    cmp ASSEMBLE_OK
    beq __F_stage_resolved_relative_join_6
__F_stage_resolved_relative_yes_4:
    lda __L_stage_resolved_relative_status
    rts
__F_stage_resolved_relative_join_6:
    lda __L_stage_resolved_relative_relative
    jsr stage_byte
    rts
