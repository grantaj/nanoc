* = $1f35
ASSEMBLE_BAD_STATEMENT = $0804
ASSEMBLE_INCLUDE_DEPTH = $0810
ASSEMBLE_IO_ERROR = $080e
ASSEMBLE_OK = $0803
__L_open_include_argument = $0031
__L_open_include_handle = $0033
__L_open_include_i = $0030
__L_open_include_input_length = $0035
__L_open_include_input_start = $0034
__L_open_include_length = $0037
__L_open_include_output = $0033
__ap = $0002
__call_io_open_0 = $cf10
__call_io_open_1 = $cf12
__outline_01 = $287c
__outline_04 = $28ba
__outline_12 = $2965
__outline_15 = $29a4
__tmp0 = $0009
__tmp1 = $000a
__tmp2 = $000b
io_open = $26f7
source_depth = $760a
source_directory = $760c
source_directory_length = $760e
source_path = $7505
open_include:
__F_open_include_entry:
    sta __L_open_include_length
    cmp #$03
    bcs __F_open_include_join_3
__F_open_include_yes_1:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_open_include_join_3:
    ldy #$00
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda (__ap),y
    cmp #$22
    beq __F_open_include_join_6
__F_open_include_yes_4:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_open_include_join_6:
    lda __L_open_include_length
    jsr __outline_12
    sta __tmp1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    jsr __outline_01
    cmp #$22
    beq __F_open_include_join_9
__F_open_include_yes_7:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_open_include_join_9:
    lda source_depth+1
    eor #$80
    cmp #$80
    bcc __F_open_include_join_12
    bne __F_open_include_yes_10
    lda source_depth
    cmp #$04
    bcc __F_open_include_join_12
__F_open_include_yes_10:
    lda ASSEMBLE_INCLUDE_DEPTH
    rts
__F_open_include_join_12:
    lda #$01
    sta __L_open_include_input_start
    lda __L_open_include_length
    sec
    sbc #$02
    sta __L_open_include_input_length
    lda #$00
    sta __L_open_include_output
    tax
    lda __L_open_include_input_length
    cmp #$03
    bcc __F_open_include_join_15
__F_open_include_yes_13:
    ldy __L_open_include_input_start
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda (__ap),y
    cmp #$2e
    bne __F_open_include_join_15
__F_open_include_yes_16:
    lda __L_open_include_input_start
    clc
    adc #$01
    jsr __outline_15
    jsr __outline_01
    cmp #$2e
    bne __F_open_include_join_15
__F_open_include_yes_19:
    lda __L_open_include_input_start
    clc
    adc #$02
    jsr __outline_15
    jsr __outline_01
    cmp #$2f
    bne __F_open_include_join_15
__F_open_include_yes_22:
    lda #$01
    tax
    lda __L_open_include_input_start
    clc
    adc #$03
    sta __L_open_include_input_start
    lda __L_open_include_input_length
    sec
    sbc #$03
    sta __L_open_include_input_length
__F_open_include_join_15:
    txa
    cmp #$00
    bne __F_open_include_join_27
__F_open_include_yes_25:
    lda #$00
    sta __L_open_include_i
__F_open_include_while_28:
    lda __L_open_include_i
    cmp source_directory_length
    bcs __F_open_include_join_27
__F_open_include_body_29:
    ldy __L_open_include_i
    lda source_directory
    sta __ap
    lda source_directory+1
    sta __ap+1
    lda (__ap),y
    sta __tmp0
    ldy __L_open_include_output
    lda __tmp0
    sta source_path,y
    inc __L_open_include_output
    inc __L_open_include_i
    jmp __F_open_include_while_28
__F_open_include_join_27:
    lda __L_open_include_output
    clc
    adc __L_open_include_input_length
    sta __tmp0
    lda #$00
    adc #$00
    eor #$80
    cmp #$80
    bcc __F_open_include_join_33
    bne __F_open_include_yes_31
    lda __tmp0
    cmp #$ff
    bcc __F_open_include_join_33
    beq __F_open_include_join_33
__F_open_include_yes_31:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_open_include_join_33:
    lda #$00
    sta __L_open_include_i
__F_open_include_while_34:
    lda __L_open_include_i
    cmp __L_open_include_input_length
    bcs __F_open_include_after_36
__F_open_include_body_35:
    lda __L_open_include_input_start
    clc
    adc __L_open_include_i
    jsr __outline_15
    jsr __outline_01
    sta __tmp2
    ldy __L_open_include_output
    lda __tmp2
    sta source_path,y
    inc __L_open_include_output
    inc __L_open_include_i
    jmp __F_open_include_while_34
__F_open_include_after_36:
    lda #<source_path
    sta __call_io_open_0
    lda #>source_path
    sta __call_io_open_0+1
    lda __L_open_include_output
    sta __call_io_open_1
    lda #$00
    sta __call_io_open_1+1
    jsr io_open
    sta __L_open_include_handle
    stx __L_open_include_handle+1
    lda __L_open_include_handle+1
    bpl __F_open_include_join_39
__F_open_include_yes_37:
    lda ASSEMBLE_IO_ERROR
    rts
__F_open_include_join_39:
    lda source_depth
    clc
    adc #$01
    sta __tmp0
    lda source_depth+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta source_depth
    lda __tmp1
    sta source_depth+1
    jsr __outline_04
    lda __L_open_include_handle
    sta (__ap),y
    lda ASSEMBLE_OK
    rts
