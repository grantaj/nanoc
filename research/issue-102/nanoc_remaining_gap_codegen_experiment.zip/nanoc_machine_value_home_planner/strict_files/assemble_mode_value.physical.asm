* = $195e
ASSEMBLE_BAD_INSTRUCTION = $0808
ASSEMBLE_SCOPE_ERROR = $0807
ASSEMBLE_SYMBOL_FULL = $0806
MODE_RELATIVE = $081d
VALUE_OK = $0adb
VALUE_SCOPE_ERROR = $0adf
VALUE_SYMBOL_FULL = $0ade
VALUE_UNRESOLVED = $0adc
__L_assemble_mode_value_length = $c7c9
__L_assemble_mode_value_mnemonic = $c7c5
__L_assemble_mode_value_mode = $003b
__L_assemble_mode_value_opcode = $c7ca
__L_assemble_mode_value_status = $0033
__L_assemble_mode_value_text = $c7c7
__call_find_opcode_0 = $0033
__call_parse_value_0 = $0037
__call_stage_resolved_instruction_0 = $0035
__call_stage_resolved_relative_0 = $0038
__call_stage_resolved_relative_1 = $0035
__call_stage_unresolved_instruction_0 = $c7b7
__outline_13 = $296f
__outline_18 = $29cc
find_opcode = $1719
parse_value = $1504
stage_resolved_instruction = $17f0
stage_resolved_relative = $1847
stage_unresolved_instruction = $1895
value_result = $c716
assemble_mode_value:
__F_assemble_mode_value_entry:
    sta __L_assemble_mode_value_length
    lda __L_assemble_mode_value_mnemonic
    sta __call_find_opcode_0
    lda __L_assemble_mode_value_mode
    jsr find_opcode
    sta __L_assemble_mode_value_opcode
    stx __L_assemble_mode_value_opcode+1
    lda __L_assemble_mode_value_opcode+1
    bpl __F_assemble_mode_value_join_3
__F_assemble_mode_value_yes_1:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_mode_value_join_3:
    lda __L_assemble_mode_value_text
    sta __call_parse_value_0
    lda __L_assemble_mode_value_text+1
    sta __call_parse_value_0+1
    lda __L_assemble_mode_value_length
    jsr parse_value
    sta __L_assemble_mode_value_status
    cmp VALUE_OK
    bne __F_assemble_mode_value_join_6
__F_assemble_mode_value_yes_4:
    lda __L_assemble_mode_value_mode
    cmp MODE_RELATIVE
    bne __F_assemble_mode_value_join_9
__F_assemble_mode_value_yes_7:
    lda __L_assemble_mode_value_opcode
    sta __call_stage_resolved_relative_0
    lda value_result
    sta __call_stage_resolved_relative_1
    lda value_result+1
    sta __call_stage_resolved_relative_1+1
    jsr stage_resolved_relative
    rts
__F_assemble_mode_value_join_9:
    lda __L_assemble_mode_value_opcode
    sta __call_stage_resolved_instruction_0
    lda __L_assemble_mode_value_mode
    jsr __outline_18
    jsr stage_resolved_instruction
    rts
__F_assemble_mode_value_join_6:
    cmp VALUE_UNRESOLVED
    bne __F_assemble_mode_value_join_12
__F_assemble_mode_value_yes_10:
    lda __L_assemble_mode_value_opcode
    sta __call_stage_unresolved_instruction_0
    lda __L_assemble_mode_value_mode
    jsr __outline_13
    jsr stage_unresolved_instruction
    rts
__F_assemble_mode_value_join_12:
    cmp VALUE_SYMBOL_FULL
    bne __F_assemble_mode_value_join_15
__F_assemble_mode_value_yes_13:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_assemble_mode_value_join_15:
    cmp VALUE_SCOPE_ERROR
    bne __F_assemble_mode_value_join_18
__F_assemble_mode_value_yes_16:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_assemble_mode_value_join_18:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
