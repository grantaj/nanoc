* = $0800
ASSEMBLE_BAD_INSTRUCTION = $0808
ASSEMBLE_SCOPE_ERROR = $0807
ASSEMBLE_SYMBOL_FULL = $0806
MODE_RELATIVE = $081d
VALUE_OK = $0adb
VALUE_PREFIX_NONE = $0ae0
VALUE_SCOPE_ERROR = $0adf
VALUE_SYMBOL_FULL = $0ade
VALUE_UNRESOLVED = $0adc
__L_assemble_direct_value_index = $c7d1
__L_assemble_direct_value_length = $c7d0
__L_assemble_direct_value_long_mode = $0034
__L_assemble_direct_value_long_opcode = $0039
__L_assemble_direct_value_mnemonic = $c7cd
__L_assemble_direct_value_opcode = $0033
__L_assemble_direct_value_short_mode = $0036
__L_assemble_direct_value_short_opcode = $0037
__L_assemble_direct_value_status = $0035
__L_assemble_direct_value_text = $c7ce
__call_assemble_mode_value_0 = $c7c5
__call_assemble_mode_value_1 = $003b
__call_assemble_mode_value_2 = $c7c7
__call_find_opcode_0 = $0033
__call_parse_value_0 = $0037
__call_stage_resolved_instruction_0 = $0035
__call_stage_unresolved_instruction_0 = $c7b7
__outline_13 = $296f
__outline_18 = $29cc
assemble_mode_value = $195e
captured_prefix = $c71c
find_opcode = $1719
long_mode_for_index = $1947
parse_value = $1504
short_mode_for_index = $1931
stage_resolved_instruction = $17f0
stage_unresolved_instruction = $1895
value_result = $c716
assemble_direct_value:
__F_assemble_direct_value_entry:
    sta __L_assemble_direct_value_index
    cmp #$00
    bne __F_assemble_direct_value_join_3
__F_assemble_direct_value_yes_1:
    lda __L_assemble_direct_value_mnemonic
    sta __call_find_opcode_0
    lda MODE_RELATIVE
    jsr find_opcode
    stx __L_assemble_direct_value_opcode+1
    lda __L_assemble_direct_value_opcode+1
    bmi __F_assemble_direct_value_join_3
__F_assemble_direct_value_yes_4:
    lda __L_assemble_direct_value_mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_RELATIVE
    sta __call_assemble_mode_value_1
    lda __L_assemble_direct_value_text
    sta __call_assemble_mode_value_2
    lda __L_assemble_direct_value_text+1
    sta __call_assemble_mode_value_2+1
    lda __L_assemble_direct_value_length
    jsr assemble_mode_value
    rts
__F_assemble_direct_value_join_3:
    lda __L_assemble_direct_value_text
    sta __call_parse_value_0
    lda __L_assemble_direct_value_text+1
    sta __call_parse_value_0+1
    lda __L_assemble_direct_value_length
    jsr parse_value
    sta __L_assemble_direct_value_status
    cmp VALUE_OK
    beq __F_assemble_direct_value_join_9
__F_assemble_direct_value_yes_7:
    cmp VALUE_UNRESOLVED
    beq __F_assemble_direct_value_join_9
__F_assemble_direct_value_yes_10:
    cmp VALUE_SYMBOL_FULL
    bne __F_assemble_direct_value_join_15
__F_assemble_direct_value_yes_13:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_assemble_direct_value_join_15:
    cmp VALUE_SCOPE_ERROR
    bne __F_assemble_direct_value_join_18
__F_assemble_direct_value_yes_16:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_assemble_direct_value_join_18:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_direct_value_join_9:
    lda __L_assemble_direct_value_index
    jsr short_mode_for_index
    sta __L_assemble_direct_value_short_mode
    lda __L_assemble_direct_value_index
    jsr long_mode_for_index
    sta __L_assemble_direct_value_long_mode
    lda __L_assemble_direct_value_mnemonic
    sta __call_find_opcode_0
    lda __L_assemble_direct_value_short_mode
    jsr find_opcode
    sta __L_assemble_direct_value_short_opcode
    stx __L_assemble_direct_value_short_opcode+1
    lda __L_assemble_direct_value_mnemonic
    sta __call_find_opcode_0
    lda __L_assemble_direct_value_long_mode
    jsr find_opcode
    sta __L_assemble_direct_value_long_opcode
    stx __L_assemble_direct_value_long_opcode+1
    lda __L_assemble_direct_value_status
    cmp VALUE_OK
    bne __F_assemble_direct_value_join_21
__F_assemble_direct_value_yes_19:
    lda value_result+1
    cmp #$00
    bcc __F_assemble_direct_value_yes_22
    bne __F_assemble_direct_value_join_24
    lda value_result
    cmp #$ff
    bcc __F_assemble_direct_value_yes_22
    bne __F_assemble_direct_value_join_24
__F_assemble_direct_value_yes_22:
    lda __L_assemble_direct_value_short_opcode+1
    bmi __F_assemble_direct_value_join_24
__F_assemble_direct_value_yes_25:
    lda __L_assemble_direct_value_short_opcode
    sta __call_stage_resolved_instruction_0
    lda __L_assemble_direct_value_short_mode
    jsr __outline_18
    jsr stage_resolved_instruction
    rts
__F_assemble_direct_value_join_24:
    lda __L_assemble_direct_value_long_opcode+1
    bmi __F_assemble_direct_value_join_30
__F_assemble_direct_value_yes_28:
    lda __L_assemble_direct_value_long_opcode
    sta __call_stage_resolved_instruction_0
    lda __L_assemble_direct_value_long_mode
    jsr __outline_18
    jsr stage_resolved_instruction
    rts
__F_assemble_direct_value_join_30:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_direct_value_join_21:
    lda __L_assemble_direct_value_long_mode
    tax
    lda __L_assemble_direct_value_long_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_long_opcode+1
    sta __L_assemble_direct_value_opcode+1
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    beq __F_assemble_direct_value_no_32
__F_assemble_direct_value_yes_31:
    lda __L_assemble_direct_value_short_mode
    tax
    lda __L_assemble_direct_value_short_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_short_opcode+1
    sta __L_assemble_direct_value_opcode+1
    jmp __F_assemble_direct_value_join_33
__F_assemble_direct_value_no_32:
    lda __L_assemble_direct_value_long_opcode+1
    bpl __F_assemble_direct_value_join_33
__F_assemble_direct_value_yes_34:
    lda __L_assemble_direct_value_short_mode
    tax
    lda __L_assemble_direct_value_short_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_short_opcode+1
    sta __L_assemble_direct_value_opcode+1
__F_assemble_direct_value_join_33:
    lda __L_assemble_direct_value_opcode+1
    bpl __F_assemble_direct_value_join_39
__F_assemble_direct_value_yes_37:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_direct_value_join_39:
    lda __L_assemble_direct_value_opcode
    sta __call_stage_unresolved_instruction_0
    txa
    jsr __outline_13
    jsr stage_unresolved_instruction
    rts
