* = $2131
__L_scan_argument_c = $0035
__L_scan_argument_i = $0030
__L_scan_argument_last = $0031
__L_scan_argument_start = $003b
__outline_25 = $2a3f
__tmp1 = $000a
source_line = $7404
source_line_length = $7504
scan_argument:
__F_scan_argument_entry:
    sta __L_scan_argument_start
    lda __L_scan_argument_start
    sta __L_scan_argument_i
    lda #$00
    tax
    lda __L_scan_argument_start
    sta __L_scan_argument_last
__F_scan_argument_while_1:
    lda __L_scan_argument_i
    cmp source_line_length
    bcs __F_scan_argument_after_3
__F_scan_argument_body_2:
    ldy __L_scan_argument_i
    lda source_line,y
    sta __L_scan_argument_c
    cmp #$3b
    bne __F_scan_argument_no_5
__F_scan_argument_yes_4:
    txa
    cmp #$00
    bne __F_scan_argument_no_8
__F_scan_argument_yes_7:
    lda source_line_length
    sta __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_no_8:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    inc __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_no_5:
    cmp #$27
    bne __F_scan_argument_no_11
__F_scan_argument_yes_10:
    txa
    cmp #$00
    bne __F_scan_argument_no_14
__F_scan_argument_yes_13:
    lda #$27
    tax
    jmp __F_scan_argument_join_15
__F_scan_argument_no_14:
    cmp #$27
    bne __F_scan_argument_join_15
__F_scan_argument_yes_16:
    lda #$00
    tax
__F_scan_argument_join_15:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    jmp __F_scan_argument_join_12
__F_scan_argument_no_11:
    cmp #$22
    bne __F_scan_argument_no_20
__F_scan_argument_yes_19:
    txa
    cmp #$00
    bne __F_scan_argument_no_23
__F_scan_argument_yes_22:
    lda #$22
    tax
    jmp __F_scan_argument_join_24
__F_scan_argument_no_23:
    cmp #$22
    bne __F_scan_argument_join_24
__F_scan_argument_yes_25:
    lda #$00
    tax
__F_scan_argument_join_24:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    jmp __F_scan_argument_join_12
__F_scan_argument_no_20:
    cmp #$20
    beq __F_scan_argument_join_12
__F_scan_argument_yes_28:
    cmp #$09
    beq __F_scan_argument_join_12
__F_scan_argument_yes_31:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
__F_scan_argument_join_12:
    inc __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_after_3:
    lda __L_scan_argument_last
    sec
    sbc __L_scan_argument_start
    jsr __outline_25
    ldx __tmp1
    rts
