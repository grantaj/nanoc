* = $0b49
__L_hex_nibble_c = $c72f
__outline_25 = $2a3f
__tmp1 = $000a
__tmp2 = $000b
__tmp3 = $000c
upper_char = $0ae8
hex_nibble:
__F_hex_nibble_entry:
    sta __L_hex_nibble_c
    lda __L_hex_nibble_c
    jsr upper_char
    sta __L_hex_nibble_c
    cmp #$30
    bcc __F_hex_nibble_join_3
__F_hex_nibble_yes_1:
    cmp #$39
    bcc __F_hex_nibble_yes_4
    bne __F_hex_nibble_join_3
__F_hex_nibble_yes_4:
    lda __L_hex_nibble_c
    sec
    sbc #$30
    jsr __outline_25
    ldx __tmp1
    rts
__F_hex_nibble_join_3:
    cmp #$41
    bcc __F_hex_nibble_join_9
__F_hex_nibble_yes_7:
    cmp #$46
    bcc __F_hex_nibble_yes_10
    bne __F_hex_nibble_join_9
__F_hex_nibble_yes_10:
    lda __L_hex_nibble_c
    sec
    sbc #$41
    jsr __outline_25
    clc
    adc #$0a
    sta __tmp2
    lda __tmp1
    adc #$00
    sta __tmp3
    lda __tmp2
    ldx __tmp3
    rts
__F_hex_nibble_join_9:
    lda #$ff
    ldx #$ff
    rts
