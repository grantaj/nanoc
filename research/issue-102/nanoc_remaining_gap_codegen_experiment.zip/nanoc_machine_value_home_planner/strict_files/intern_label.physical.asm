* = $10b3
SYMBOL_CONSTANT = $0ad8
SYMBOL_LABEL_UNDEFINED = $0ad9
__L_intern_label_length = $c766
__L_intern_label_name = $c764
__L_intern_label_symbol = $0039
__ap = $0002
__call_allocate_symbol_0 = $c759
__call_allocate_symbol_1 = $0036
__call_allocate_symbol_2 = $c75c
__call_allocate_symbol_3 = $c75d
__call_find_symbol_0 = $c74e
allocate_symbol = $0f79
find_symbol = $0e85
symbol_kind = $8b0f
intern_label:
__F_intern_label_entry:
    sta __L_intern_label_length
    lda __L_intern_label_name
    sta __call_find_symbol_0
    lda __L_intern_label_name+1
    sta __call_find_symbol_0+1
    lda __L_intern_label_length
    jsr find_symbol
    sta __L_intern_label_symbol
    stx __L_intern_label_symbol+1
    lda __L_intern_label_symbol+1
    bmi __F_intern_label_join_3
__F_intern_label_yes_1:
    clc
    lda __L_intern_label_symbol
    adc #<symbol_kind
    sta __ap
    lda __L_intern_label_symbol+1
    adc #>symbol_kind
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp SYMBOL_CONSTANT
    bne __F_intern_label_join_6
__F_intern_label_yes_4:
    lda #$fc
    ldx #$ff
    rts
__F_intern_label_join_6:
    lda __L_intern_label_symbol
    ldx __L_intern_label_symbol+1
    rts
__F_intern_label_join_3:
    cmp #$ff
    bne __F_intern_label_join_9
    lda __L_intern_label_symbol
    cmp #$fe
    bne __F_intern_label_join_9
__F_intern_label_yes_7:
    lda #$fe
    ldx #$ff
    rts
__F_intern_label_join_9:
    lda __L_intern_label_name
    sta __call_allocate_symbol_0
    lda __L_intern_label_name+1
    sta __call_allocate_symbol_0+1
    lda __L_intern_label_length
    sta __call_allocate_symbol_1
    lda SYMBOL_LABEL_UNDEFINED
    sta __call_allocate_symbol_2
    lda #$00
    sta __call_allocate_symbol_3
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    rts
