* = $1d18
ASSEMBLE_BAD_DATA = $080b
ASSEMBLE_OK = $0803
ASSEMBLE_SCOPE_ERROR = $0807
ASSEMBLE_SYMBOL_FULL = $0806
FIXUP_DATA_BYTE = $0ae7
FIXUP_WORD = $0ae5
VALUE_OK = $0adb
VALUE_PREFIX_NONE = $0ae0
VALUE_SCOPE_ERROR = $0adf
VALUE_SYMBOL_FULL = $0ade
VALUE_UNRESOLVED = $0adc
__L_stage_data_value_kind = $0032
__L_stage_data_value_length = $c7ea
__L_stage_data_value_stage = $0033
__L_stage_data_value_status = $0032
__L_stage_data_value_text = $c7e8
__L_stage_data_value_width = $003b
__call_append_fixup_0 = $c730
__call_append_fixup_1 = $c731
__call_append_fixup_2 = $0039
__call_append_fixup_3 = $c735
__call_parse_value_0 = $0037
__call_stage_plain_word_reference_0 = $0033
append_fixup = $0b93
ass_image_length = $7400
captured_addend = $c71a
captured_prefix = $c71c
captured_symbol = $c718
parse_value = $1504
stage_byte = $173b
stage_plain_word_reference = $1787
value_result = $c716
stage_data_value:
__F_stage_data_value_entry:
    sta __L_stage_data_value_width
    lda __L_stage_data_value_text
    sta __call_parse_value_0
    lda __L_stage_data_value_text+1
    sta __call_parse_value_0+1
    lda __L_stage_data_value_length
    jsr parse_value
    sta __L_stage_data_value_status
    cmp VALUE_OK
    bne __F_stage_data_value_join_3
__F_stage_data_value_yes_1:
    lda __L_stage_data_value_width
    cmp #$01
    bne __F_stage_data_value_join_6
__F_stage_data_value_yes_4:
    lda value_result+1
    cmp #$00
    bcc __F_stage_data_value_join_9
    bne __F_stage_data_value_yes_7
    lda value_result
    cmp #$ff
    bcc __F_stage_data_value_join_9
    beq __F_stage_data_value_join_9
__F_stage_data_value_yes_7:
    lda ASSEMBLE_BAD_DATA
    rts
__F_stage_data_value_join_9:
    lda value_result
    jsr stage_byte
    rts
__F_stage_data_value_join_6:
    lda value_result
    jsr stage_byte
    sta __L_stage_data_value_status
    cmp ASSEMBLE_OK
    beq __F_stage_data_value_join_12
__F_stage_data_value_yes_10:
    lda __L_stage_data_value_status
    rts
__F_stage_data_value_join_12:
    lda value_result+1
    jsr stage_byte
    rts
__F_stage_data_value_join_3:
    cmp VALUE_UNRESOLVED
    beq __F_stage_data_value_yes_13
    jmp __F_stage_data_value_join_15
__F_stage_data_value_yes_13:
    lda __L_stage_data_value_width
    cmp #$02
    bne __F_stage_data_value_join_18
__F_stage_data_value_yes_16:
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    bne __F_stage_data_value_join_18
__F_stage_data_value_yes_19:
    lda captured_addend
    ora captured_addend+1
    bne __F_stage_data_value_join_18
__F_stage_data_value_yes_22:
    lda captured_symbol
    sta __call_stage_plain_word_reference_0
    lda captured_symbol+1
    sta __call_stage_plain_word_reference_0+1
    jsr stage_plain_word_reference
    rts
__F_stage_data_value_join_18:
    lda ass_image_length
    sta __L_stage_data_value_stage
    lda ass_image_length+1
    sta __L_stage_data_value_stage+1
    lda #$00
    jsr stage_byte
    sta __L_stage_data_value_status
    cmp ASSEMBLE_OK
    beq __F_stage_data_value_join_27
__F_stage_data_value_yes_25:
    lda __L_stage_data_value_status
    rts
__F_stage_data_value_join_27:
    lda __L_stage_data_value_width
    cmp #$02
    bne __F_stage_data_value_no_29
__F_stage_data_value_yes_28:
    lda #$00
    jsr stage_byte
    sta __L_stage_data_value_status
    cmp ASSEMBLE_OK
    beq __F_stage_data_value_join_33
__F_stage_data_value_yes_31:
    lda __L_stage_data_value_status
    rts
__F_stage_data_value_join_33:
    lda FIXUP_WORD
    sta __L_stage_data_value_kind
    jmp __F_stage_data_value_join_30
__F_stage_data_value_no_29:
    lda FIXUP_DATA_BYTE
    sta __L_stage_data_value_kind
__F_stage_data_value_join_30:
    sta __call_append_fixup_0
    lda __L_stage_data_value_stage
    sta __call_append_fixup_1
    lda __L_stage_data_value_stage+1
    sta __call_append_fixup_1+1
    lda captured_symbol
    sta __call_append_fixup_2
    lda captured_symbol+1
    sta __call_append_fixup_2+1
    lda captured_addend
    sta __call_append_fixup_3
    lda captured_addend+1
    sta __call_append_fixup_3+1
    lda captured_prefix
    jsr append_fixup
    rts
__F_stage_data_value_join_15:
    cmp VALUE_SYMBOL_FULL
    bne __F_stage_data_value_join_36
__F_stage_data_value_yes_34:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_stage_data_value_join_36:
    cmp VALUE_SCOPE_ERROR
    bne __F_stage_data_value_join_39
__F_stage_data_value_yes_37:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_stage_data_value_join_39:
    lda ASSEMBLE_BAD_DATA
    rts
