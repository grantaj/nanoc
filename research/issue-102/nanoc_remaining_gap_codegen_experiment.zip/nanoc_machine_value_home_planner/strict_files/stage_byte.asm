* = $0800
ASSEMBLE_OK = $0803
ASSEMBLE_WORK_FULL = $080d
__L_stage_byte_value = $c7a1
__ap = $0002
__tmp0 = $0009
__tmp1 = $000a
ass_image = $4800
ass_image_length = $7400
stage_byte:
__F_stage_byte_entry:
    sta __L_stage_byte_value
    lda ass_image_length+1
    eor #$80
    cmp #$ac
    bcc __F_stage_byte_join_3
    bne __F_stage_byte_yes_1
    lda ass_image_length
    cmp #$00
    bcc __F_stage_byte_join_3
__F_stage_byte_yes_1:
    lda ASSEMBLE_WORK_FULL
    rts
__F_stage_byte_join_3:
    clc
    lda ass_image_length
    adc #<ass_image
    sta __ap
    lda ass_image_length+1
    adc #>ass_image
    sta __ap+1
    ldy #$00
    lda __L_stage_byte_value
    sta (__ap),y
    lda ass_image_length
    clc
    adc #$01
    sta __tmp0
    lda ass_image_length+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta ass_image_length
    lda __tmp1
    sta ass_image_length+1
    lda ASSEMBLE_OK
    rts
