* = $0800
__L_find_symbol_i = $0039
__L_find_symbol_j = $0036
__L_find_symbol_length = $c750
__L_find_symbol_name = $c74e
__L_find_symbol_offset = $c756
__L_find_symbol_wanted_scope = $c751
__ap = $0002
__call_scope_for_name_0 = $0039
__ix = $0004
__outline_23 = $2a1a
__rh = $0006
__tmp0 = $0009
__tmp1 = $000a
scope_for_name = $0e52
symbol_count = $b30f
symbol_name_bytes = $8e8f
symbol_name_length = $7d0f
symbol_scope = $878f
find_symbol:
__F_find_symbol_entry:
    sta __L_find_symbol_length
    lda __L_find_symbol_name
    sta __call_scope_for_name_0
    lda __L_find_symbol_name+1
    sta __call_scope_for_name_0+1
    lda __L_find_symbol_length
    jsr scope_for_name
    sta __L_find_symbol_wanted_scope
    stx __L_find_symbol_wanted_scope+1
    lda __L_find_symbol_wanted_scope+1
    bpl __F_find_symbol_join_3
__F_find_symbol_yes_1:
    lda #$fe
    ldx #$ff
    rts
__F_find_symbol_join_3:
    lda #$00
    sta __L_find_symbol_i
    sta __L_find_symbol_i+1
__F_find_symbol_while_4:
    lda symbol_count+1
    eor #$80
    sta __rh
    lda __L_find_symbol_i+1
    eor #$80
    cmp __rh
    bcc __F_find_symbol_body_5
    beq __F_find_symbol___far_skip_0
    jmp __F_find_symbol_after_6
__F_find_symbol___far_skip_0:
    lda __L_find_symbol_i
    cmp symbol_count
    bcc __F_find_symbol_body_5
    jmp __F_find_symbol_after_6
__F_find_symbol_body_5:
    clc
    lda __L_find_symbol_i
    adc #<symbol_scope
    sta __ap
    lda __L_find_symbol_i+1
    adc #>symbol_scope
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __tmp0
    lda #$00
    cmp __L_find_symbol_wanted_scope+1
    bne __F_find_symbol_join_9
__F_find_symbol___far_skip_1:
    lda __tmp0
    cmp __L_find_symbol_wanted_scope
    bne __F_find_symbol_join_9
__F_find_symbol_yes_7:
    clc
    lda __L_find_symbol_i
    adc #<symbol_name_length
    sta __ap
    lda __L_find_symbol_i+1
    adc #>symbol_name_length
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp __L_find_symbol_length
    bne __F_find_symbol_join_9
__F_find_symbol_yes_10:
    lda __L_find_symbol_i
    asl
    sta __ix
    lda __L_find_symbol_i+1
    jsr __outline_23
    lda (__ap),y
    sta __L_find_symbol_offset
    iny
    lda (__ap),y
    sta __L_find_symbol_offset+1
    lda #$01
    tax
    lda #$00
    sta __L_find_symbol_j
    ldy __L_find_symbol_j
    lda __L_find_symbol_name
    sta __ap
    lda __L_find_symbol_name+1
    sta __ap+1
    clc
    lda __L_find_symbol_offset
    adc #<symbol_name_bytes
    sta __ix
    lda __L_find_symbol_offset+1
    adc #>symbol_name_bytes
    sta __ix+1
__F_find_symbol_while_13:
    cpy __L_find_symbol_length
    bcs __F_find_symbol_after_15
__F_find_symbol_body_14:
    lda (__ix),y
    sta __tmp0
    lda (__ap),y
    cmp __tmp0
    beq __F_find_symbol_join_18
__F_find_symbol_yes_16:
    lda #$00
    tax
__F_find_symbol_join_18:
    inc __L_find_symbol_j
    iny
    jmp __F_find_symbol_while_13
__F_find_symbol_after_15:
    txa
    cmp #$00
    beq __F_find_symbol_join_9
__F_find_symbol_yes_19:
    lda __L_find_symbol_i
    ldx __L_find_symbol_i+1
    rts
__F_find_symbol_join_9:
    lda __L_find_symbol_i
    clc
    adc #$01
    sta __tmp0
    lda __L_find_symbol_i+1
    adc #$00
    sta __tmp1
    lda __tmp0
    sta __L_find_symbol_i
    lda __tmp1
    sta __L_find_symbol_i+1
    jmp __F_find_symbol_while_4
__F_find_symbol_after_6:
    lda #$ff
    ldx #$ff
    rts
