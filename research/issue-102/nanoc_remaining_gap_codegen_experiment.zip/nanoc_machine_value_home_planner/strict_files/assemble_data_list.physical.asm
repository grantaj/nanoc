* = $1e12
ASSEMBLE_BAD_DATA = $080b
ASSEMBLE_OK = $0803
__L_assemble_data_list_argument = $c7f0
__L_assemble_data_list_cursor = $0030
__L_assemble_data_list_item_start = $0032
__L_assemble_data_list_length = $0031
__L_assemble_data_list_status = $0032
__L_assemble_data_list_width = $c7f3
__call_stage_data_value_0 = $c7e8
__call_stage_data_value_1 = $c7ea
__outline_28 = $2a66
__tmp0 = $0009
stage_data_value = $1d18
assemble_data_list:
__F_assemble_data_list_entry:
    sta __L_assemble_data_list_width
    lda #$00
    sta __L_assemble_data_list_cursor
__F_assemble_data_list_while_1:
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_while_4
    jmp __F_assemble_data_list_after_3
__F_assemble_data_list_while_4:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_after_6
__F_assemble_data_list_body_5:
    jsr __outline_28
    cmp #$20
    bne __F_assemble_data_list_no_8
__F_assemble_data_list_yes_7:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_4
__F_assemble_data_list_no_8:
    cmp #$09
    bne __F_assemble_data_list_after_6
__F_assemble_data_list_yes_10:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_4
__F_assemble_data_list_after_6:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_join_15
__F_assemble_data_list_yes_13:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_data_list_join_15:
    lda __L_assemble_data_list_cursor
    sta __L_assemble_data_list_item_start
    tax
__F_assemble_data_list_while_16:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_after_18
__F_assemble_data_list_body_17:
    jsr __outline_28
    cmp #$2c
    beq __F_assemble_data_list_after_18
__F_assemble_data_list_join_21:
    cmp #$20
    beq __F_assemble_data_list_join_24
__F_assemble_data_list_yes_22:
    cmp #$09
    beq __F_assemble_data_list_join_24
__F_assemble_data_list_yes_25:
    lda __L_assemble_data_list_cursor
    clc
    adc #$01
    tax
__F_assemble_data_list_join_24:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_16
__F_assemble_data_list_after_18:
    txa
    cmp __L_assemble_data_list_item_start
    bne __F_assemble_data_list_join_30
__F_assemble_data_list_yes_28:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_data_list_join_30:
    lda __L_assemble_data_list_argument
    clc
    adc __L_assemble_data_list_item_start
    sta __call_stage_data_value_0
    lda __L_assemble_data_list_argument+1
    adc #$00
    sta __call_stage_data_value_0+1
    txa
    sec
    sbc __L_assemble_data_list_item_start
    sta __tmp0
    lda #$00
    sbc #$00
    lda __tmp0
    sta __call_stage_data_value_1
    lda __L_assemble_data_list_width
    jsr stage_data_value
    sta __L_assemble_data_list_status
    cmp ASSEMBLE_OK
    beq __F_assemble_data_list_join_33
__F_assemble_data_list_yes_31:
    lda __L_assemble_data_list_status
    rts
__F_assemble_data_list_join_33:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_join_36
__F_assemble_data_list_yes_34:
    lda ASSEMBLE_OK
    rts
__F_assemble_data_list_join_36:
    inc __L_assemble_data_list_cursor
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_yes_37
    jmp __F_assemble_data_list_while_1
__F_assemble_data_list_yes_37:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_data_list_after_3:
    lda ASSEMBLE_OK
    rts
