* = $0800
__L_process_instruction_like_argument = $003e
__L_process_instruction_like_argument_length = $c822
__L_process_instruction_like_name = $003c
__L_process_instruction_like_name_length = $c81f
__call_assemble_instruction_0 = $c7dc
__call_assemble_instruction_1 = $c7de
__call_assemble_instruction_2 = $0031
__call_assemble_string_0 = $0030
__call_open_include_0 = $0031
__call_same_text_2 = $0032
__outline_07 = $28ff
__outline_35 = $2ad7
assemble_data_list = $1e12
assemble_instruction = $1afb
assemble_string = $1ec0
open_include = $1f35
origin_allowed = $c723
same_text = $0b00
process_instruction_like:
__F_process_instruction_like_entry:
    sta __L_process_instruction_like_argument_length
    jsr __outline_07
    lda #<__S_process_instruction_like___text_0
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_0
    sta __call_same_text_2+1
    lda #$07
    jsr same_text
    cmp #$00
    beq __F_process_instruction_like_join_3
__F_process_instruction_like_yes_1:
    lda __L_process_instruction_like_argument
    sta __call_open_include_0
    lda __L_process_instruction_like_argument+1
    sta __call_open_include_0+1
    lda __L_process_instruction_like_argument_length
    jsr open_include
    rts
__F_process_instruction_like_join_3:
    lda #$00
    sta origin_allowed
    jsr __outline_07
    lda #<__S_process_instruction_like___text_1
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_1
    sta __call_same_text_2+1
    lda #$04
    jsr same_text
    cmp #$00
    beq __F_process_instruction_like_join_6
__F_process_instruction_like_yes_4:
    jsr __outline_35
    lda #$01
    jsr assemble_data_list
    rts
__F_process_instruction_like_join_6:
    jsr __outline_07
    lda #<__S_process_instruction_like___text_2
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_2
    sta __call_same_text_2+1
    lda #$04
    jsr same_text
    cmp #$00
    beq __F_process_instruction_like_join_9
__F_process_instruction_like_yes_7:
    jsr __outline_35
    lda #$02
    jsr assemble_data_list
    rts
__F_process_instruction_like_join_9:
    jsr __outline_07
    lda #<__S_process_instruction_like___text_3
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_3
    sta __call_same_text_2+1
    lda #$06
    jsr same_text
    cmp #$00
    beq __F_process_instruction_like_join_12
__F_process_instruction_like_yes_10:
    lda __L_process_instruction_like_argument
    sta __call_assemble_string_0
    lda __L_process_instruction_like_argument+1
    sta __call_assemble_string_0+1
    lda __L_process_instruction_like_argument_length
    jsr assemble_string
    rts
__F_process_instruction_like_join_12:
    lda __L_process_instruction_like_name
    sta __call_assemble_instruction_0
    lda __L_process_instruction_like_name+1
    sta __call_assemble_instruction_0+1
    lda __L_process_instruction_like_name_length
    sta __call_assemble_instruction_1
    lda __L_process_instruction_like_argument
    sta __call_assemble_instruction_2
    lda __L_process_instruction_like_argument+1
    sta __call_assemble_instruction_2+1
    lda __L_process_instruction_like_argument_length
    jsr assemble_instruction
    rts
__S_process_instruction_like___text_0:
    byte 105,110,99,108,117,100,101,0
__S_process_instruction_like___text_1:
    byte 98,121,116,101,0
__S_process_instruction_like___text_2:
    byte 119,111,114,100,0
__S_process_instruction_like___text_3:
    byte 115,116,114,105,110,103,0
