* = $0800
ASSEMBLE_BAD_SYMBOL = $0805
ASSEMBLE_OK = $0803
ASSEMBLE_SCOPE_ERROR = $0807
ASSEMBLE_SYMBOL_FULL = $0806
SYMBOL_LABEL_DEFINED = $0ada
SYMBOL_LABEL_UNDEFINED = $0ad9
__L_define_label_length = $c77a
__L_define_label_name = $003e
__L_define_label_old_head = $0033
__L_define_label_status = $0033
__L_define_label_symbol = $0031
__L_define_label_value = $0037
__ap = $0002
__call_allocate_symbol_0 = $c759
__call_allocate_symbol_1 = $0036
__call_allocate_symbol_2 = $c75c
__call_allocate_symbol_3 = $c75d
__call_find_symbol_0 = $c74e
__call_patch_word_chain_0 = $0035
__call_patch_word_chain_1 = $0039
__call_resolve_fixups_for_symbol_0 = $0039
__ix = $0004
__outline_03 = $28a7
__outline_32 = $2aa7
__outline_36 = $2ae7
__tmp0 = $0009
__tmp1 = $000a
allocate_symbol = $0f79
find_symbol = $0e85
patch_word_chain = $118c
resolve_fixups_for_symbol = $0cbc
define_label:
__F_define_label_entry:
    lda __L_define_label_name
    sta __call_find_symbol_0
    lda __L_define_label_name+1
    sta __call_find_symbol_0+1
    lda __L_define_label_length
    jsr find_symbol
    sta __L_define_label_symbol
    stx __L_define_label_symbol+1
    lda __L_define_label_symbol+1
    cmp #$ff
    bne __F_define_label_join_3
    lda __L_define_label_symbol
    cmp #$fe
    bne __F_define_label_join_3
__F_define_label_yes_1:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_define_label_join_3:
    lda __L_define_label_symbol+1
    bpl __F_define_label_join_6
__F_define_label_yes_4:
    lda __L_define_label_name
    sta __call_allocate_symbol_0
    lda __L_define_label_name+1
    sta __call_allocate_symbol_0+1
    lda __L_define_label_length
    sta __call_allocate_symbol_1
    lda SYMBOL_LABEL_DEFINED
    sta __call_allocate_symbol_2
    lda __L_define_label_value
    sta __call_allocate_symbol_3
    lda __L_define_label_value+1
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    sta __L_define_label_symbol
    stx __L_define_label_symbol+1
    lda __L_define_label_symbol+1
    cmp #$ff
    bne __F_define_label_join_9
    lda __L_define_label_symbol
    cmp #$fe
    bne __F_define_label_join_9
__F_define_label_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_define_label_join_9:
    lda __L_define_label_symbol+1
    bpl __F_define_label_join_12
__F_define_label_yes_10:
    lda ASSEMBLE_SYMBOL_FULL
    rts
__F_define_label_join_12:
    lda ASSEMBLE_OK
    rts
__F_define_label_join_6:
    jsr __outline_32
    lda (__ap),y
    cmp SYMBOL_LABEL_UNDEFINED
    beq __F_define_label_join_15
__F_define_label_yes_13:
    lda ASSEMBLE_BAD_SYMBOL
    rts
__F_define_label_join_15:
    lda __L_define_label_symbol
    asl
    sta __ix
    lda __L_define_label_symbol+1
    jsr __outline_03
    jsr __outline_36
    lda __tmp0
    sta __L_define_label_old_head
    lda __tmp1
    sta __L_define_label_old_head+1
    ldy #$00
    lda __L_define_label_value
    sta (__ap),y
    iny
    lda __L_define_label_value+1
    sta (__ap),y
    jsr __outline_32
    lda SYMBOL_LABEL_DEFINED
    sta (__ap),y
    lda __L_define_label_old_head
    sta __call_patch_word_chain_0
    lda __L_define_label_old_head+1
    sta __call_patch_word_chain_0+1
    lda __L_define_label_value
    sta __call_patch_word_chain_1
    lda __L_define_label_value+1
    sta __call_patch_word_chain_1+1
    jsr patch_word_chain
    sta __L_define_label_status
    cmp ASSEMBLE_OK
    beq __F_define_label_join_18
__F_define_label_yes_16:
    lda __L_define_label_status
    rts
__F_define_label_join_18:
    lda __L_define_label_symbol
    sta __call_resolve_fixups_for_symbol_0
    lda __L_define_label_symbol+1
    sta __call_resolve_fixups_for_symbol_0+1
    jsr resolve_fixups_for_symbol
    rts
