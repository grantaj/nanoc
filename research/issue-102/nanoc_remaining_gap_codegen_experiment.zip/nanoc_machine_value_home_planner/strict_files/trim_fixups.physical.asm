* = $0c77
ASSEMBLE_OK = $0803
FIXUP_NONE = $0ae3
__ap = $0002
__outline_29 = $2a77
__tmp0 = $0009
__tmp1 = $000a
fixup_count = $c714
fixup_kind = $b314
trim_fixups:
__F_trim_fixups_entry:
__F_trim_fixups_while_1:
    lda fixup_count+1
    eor #$80
    cmp #$80
    bcc __F_trim_fixups_after_3
    bne __F_trim_fixups_body_2
    lda fixup_count
    cmp #$00
    bcc __F_trim_fixups_after_3
    beq __F_trim_fixups_after_3
__F_trim_fixups_body_2:
    jsr __outline_29
    clc
    lda __tmp0
    adc #<fixup_kind
    sta __ap
    lda __tmp1
    adc #>fixup_kind
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp FIXUP_NONE
    beq __F_trim_fixups_join_6
__F_trim_fixups_yes_4:
    lda ASSEMBLE_OK
    rts
__F_trim_fixups_join_6:
    jsr __outline_29
    lda __tmp0
    sta fixup_count
    lda __tmp1
    sta fixup_count+1
    jmp __F_trim_fixups_while_1
__F_trim_fixups_after_3:
    lda ASSEMBLE_OK
    rts
