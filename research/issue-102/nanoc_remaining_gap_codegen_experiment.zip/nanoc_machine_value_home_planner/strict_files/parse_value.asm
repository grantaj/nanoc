* = $0800
VALUE_BAD = $0add
VALUE_OK = $0adb
VALUE_PREFIX_HIGH = $0ae2
VALUE_PREFIX_LOW = $0ae1
VALUE_PREFIX_NONE = $0ae0
VALUE_UNRESOLVED = $0adc
__L_parse_value_first_kind = $0036
__L_parse_value_first_symbol = $0039
__L_parse_value_first_value = $0034
__L_parse_value_length = $c78e
__L_parse_value_operation = $c796
__L_parse_value_position = $0033
__L_parse_value_status = $0034
__L_parse_value_text = $0037
__ap = $0002
__call_apply_byte_prefix_0 = $0035
__outline_08 = $290d
__tmp0 = $0009
__tmp1 = $000a
apply_byte_prefix = $0b3b
atom_kind = $c722
atom_symbol = $c71f
atom_used = $c721
atom_value = $c71d
captured_addend = $c71a
captured_prefix = $c71c
captured_symbol = $c718
parse_atom = $12d7
value_result = $c716
parse_value:
__F_parse_value_entry:
    sta __L_parse_value_length
    lda #$ff
    sta captured_symbol
    sta captured_symbol+1
    lda #$00
    sta captured_addend
    sta captured_addend+1
    lda VALUE_PREFIX_NONE
    sta captured_prefix
    lda __L_parse_value_length
    cmp #$00
    bne __F_parse_value_join_3
__F_parse_value_yes_1:
    lda VALUE_BAD
    rts
__F_parse_value_join_3:
    lda #$00
    sta __L_parse_value_position
    ldy __L_parse_value_position
    lda __L_parse_value_text
    sta __ap
    lda __L_parse_value_text+1
    sta __ap+1
    lda (__ap),y
    cmp #$3c
    bne __F_parse_value_no_5
__F_parse_value_yes_4:
    lda VALUE_PREFIX_LOW
    sta captured_prefix
    inc __L_parse_value_position
    jmp __F_parse_value_join_6
__F_parse_value_no_5:
    cmp #$3e
    bne __F_parse_value_join_6
__F_parse_value_yes_7:
    lda VALUE_PREFIX_HIGH
    sta captured_prefix
    inc __L_parse_value_position
__F_parse_value_join_6:
    jsr __outline_08
    jsr parse_atom
    sta __L_parse_value_status
    cmp VALUE_OK
    beq __F_parse_value_join_12
__F_parse_value_yes_10:
    cmp VALUE_UNRESOLVED
    beq __F_parse_value_join_12
__F_parse_value_yes_13:
    lda __L_parse_value_status
    rts
__F_parse_value_join_12:
    lda atom_kind
    sta __L_parse_value_first_kind
    lda atom_value
    sta __L_parse_value_first_value
    lda atom_value+1
    sta __L_parse_value_first_value+1
    lda atom_symbol
    sta __L_parse_value_first_symbol
    lda atom_symbol+1
    sta __L_parse_value_first_symbol+1
    lda __L_parse_value_position
    clc
    adc atom_used
    sta __L_parse_value_position
    lda __L_parse_value_first_kind
    cmp #$00
    bne __F_parse_value_no_17
__F_parse_value_yes_16:
    lda __L_parse_value_first_value
    sta captured_addend
    lda __L_parse_value_first_value+1
    sta captured_addend+1
    jmp __F_parse_value_join_18
__F_parse_value_no_17:
    lda __L_parse_value_first_symbol
    sta captured_symbol
    lda __L_parse_value_first_symbol+1
    sta captured_symbol+1
    lda #$00
    sta captured_addend
    sta captured_addend+1
__F_parse_value_join_18:
    lda __L_parse_value_position
    cmp __L_parse_value_length
    bcc __F_parse_value_yes_19
    jmp __F_parse_value_join_21
__F_parse_value_yes_19:
    ldy __L_parse_value_position
    lda __L_parse_value_text
    sta __ap
    lda __L_parse_value_text+1
    sta __ap+1
    lda (__ap),y
    sta __L_parse_value_operation
    cmp #$2b
    beq __F_parse_value_join_24
__F_parse_value_yes_22:
    cmp #$2d
    beq __F_parse_value_join_24
__F_parse_value_yes_25:
    lda VALUE_BAD
    rts
__F_parse_value_join_24:
    inc __L_parse_value_position
    jsr __outline_08
    jsr parse_atom
    sta __L_parse_value_status
    cmp VALUE_OK
    beq __F_parse_value_join_30
__F_parse_value_yes_28:
    cmp VALUE_UNRESOLVED
    beq __F_parse_value_join_30
__F_parse_value_yes_31:
    lda __L_parse_value_status
    rts
__F_parse_value_join_30:
    lda atom_kind
    tax
    lda __L_parse_value_position
    clc
    adc atom_used
    cmp __L_parse_value_length
    beq __F_parse_value_join_36
__F_parse_value_yes_34:
    lda VALUE_BAD
    rts
__F_parse_value_join_36:
    txa
    cmp #$00
    bne __F_parse_value_no_38
__F_parse_value_yes_37:
    lda __L_parse_value_operation
    cmp #$2b
    bne __F_parse_value_no_41
__F_parse_value_yes_40:
    lda captured_addend
    clc
    adc atom_value
    sta __tmp0
    lda captured_addend+1
    adc atom_value+1
    sta __tmp1
    lda __tmp0
    sta captured_addend
    lda __tmp1
    sta captured_addend+1
    jmp __F_parse_value_join_21
__F_parse_value_no_41:
    lda captured_addend
    sec
    sbc atom_value
    sta __tmp0
    lda captured_addend+1
    sbc atom_value+1
    sta __tmp1
    lda __tmp0
    sta captured_addend
    lda __tmp1
    sta captured_addend+1
    jmp __F_parse_value_join_21
__F_parse_value_no_38:
    lda captured_symbol+1
    bmi __F_parse_value_join_45
__F_parse_value_yes_43:
    lda VALUE_BAD
    rts
__F_parse_value_join_45:
    lda __L_parse_value_operation
    cmp #$2b
    beq __F_parse_value_join_48
__F_parse_value_yes_46:
    lda VALUE_BAD
    rts
__F_parse_value_join_48:
    lda atom_symbol
    sta captured_symbol
    lda atom_symbol+1
    sta captured_symbol+1
__F_parse_value_join_21:
    lda captured_symbol+1
    bmi __F_parse_value_join_51
__F_parse_value_yes_49:
    lda VALUE_UNRESOLVED
    rts
__F_parse_value_join_51:
    lda captured_addend
    sta value_result
    lda captured_addend+1
    sta value_result+1
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    beq __F_parse_value_join_54
__F_parse_value_yes_52:
    lda captured_addend
    sta __call_apply_byte_prefix_0
    lda captured_addend+1
    sta __call_apply_byte_prefix_0+1
    lda captured_prefix
    jsr apply_byte_prefix
    sta __tmp0
    lda __tmp0
    sta value_result
    lda #$00
    sta value_result+1
__F_parse_value_join_54:
    lda VALUE_OK
    rts
