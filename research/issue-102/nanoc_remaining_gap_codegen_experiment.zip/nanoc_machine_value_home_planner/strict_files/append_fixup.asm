* = $0800
ASSEMBLE_OK = $0803
ASSEMBLE_WORK_FULL = $080d
__L_append_fixup_addend = $c735
__L_append_fixup_kind = $c730
__L_append_fixup_n = $0033
__L_append_fixup_prefix = $c737
__L_append_fixup_stage = $c731
__L_append_fixup_symbol = $0039
__ap = $0002
__ix = $0004
__outline_10 = $2945
fixup_addend = $bf94
fixup_count = $c714
fixup_kind = $b314
fixup_prefix = $c494
fixup_stage = $b594
fixup_symbol = $ba94
append_fixup:
__F_append_fixup_entry:
    sta __L_append_fixup_prefix
    lda fixup_count
    sta __L_append_fixup_n
    lda fixup_count+1
    sta __L_append_fixup_n+1
    eor #$80
    cmp #$82
    bcc __F_append_fixup_join_3
    bne __F_append_fixup_yes_1
    lda __L_append_fixup_n
    cmp #$80
    bcc __F_append_fixup_join_3
__F_append_fixup_yes_1:
    lda ASSEMBLE_WORK_FULL
    rts
__F_append_fixup_join_3:
    clc
    lda __L_append_fixup_n
    adc #<fixup_kind
    sta __ap
    lda __L_append_fixup_n+1
    adc #>fixup_kind
    sta __ap+1
    ldy #$00
    lda __L_append_fixup_kind
    jsr __outline_10
    adc #<fixup_stage
    sta __ap
    lda __ix+1
    adc #>fixup_stage
    sta __ap+1
    ldy #$00
    lda __L_append_fixup_stage
    sta (__ap),y
    iny
    lda __L_append_fixup_stage+1
    jsr __outline_10
    adc #<fixup_symbol
    sta __ap
    lda __ix+1
    adc #>fixup_symbol
    sta __ap+1
    ldy #$00
    lda __L_append_fixup_symbol
    sta (__ap),y
    iny
    lda __L_append_fixup_symbol+1
    jsr __outline_10
    adc #<fixup_addend
    sta __ap
    lda __ix+1
    adc #>fixup_addend
    sta __ap+1
    ldy #$00
    lda __L_append_fixup_addend
    sta (__ap),y
    iny
    lda __L_append_fixup_addend+1
    sta (__ap),y
    clc
    lda __L_append_fixup_n
    adc #<fixup_prefix
    sta __ap
    lda __L_append_fixup_n+1
    adc #>fixup_prefix
    sta __ap+1
    ldy #$00
    lda __L_append_fixup_prefix
    sta (__ap),y
    lda __L_append_fixup_n
    clc
    adc #$01
    sta fixup_count
    lda __L_append_fixup_n+1
    adc #$00
    sta fixup_count+1
    lda ASSEMBLE_OK
    rts
