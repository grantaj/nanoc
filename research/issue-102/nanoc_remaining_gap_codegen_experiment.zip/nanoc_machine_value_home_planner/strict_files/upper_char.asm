* = $0800
__L_upper_char_c = $c724
upper_char:
__F_upper_char_entry:
    sta __L_upper_char_c
    cmp #$61
    bcc __F_upper_char_join_3
__F_upper_char_yes_1:
    cmp #$7a
    bcc __F_upper_char_yes_4
    bne __F_upper_char_join_3
__F_upper_char_yes_4:
    lda __L_upper_char_c
    sec
    sbc #$20
    rts
__F_upper_char_join_3:
    lda __L_upper_char_c
    rts
