* = $1895
ASSEMBLE_BAD_INSTRUCTION = $0808
ASSEMBLE_OK = $0803
FIXUP_BYTE = $0ae4
FIXUP_RELATIVE = $0ae6
FIXUP_WORD = $0ae5
MODE_RELATIVE = $081d
VALUE_PREFIX_NONE = $0ae0
__L_stage_unresolved_instruction_addend = $0037
__L_stage_unresolved_instruction_mode = $c7b8
__L_stage_unresolved_instruction_opcode = $c7b7
__L_stage_unresolved_instruction_prefix = $c7bd
__L_stage_unresolved_instruction_stage = $0039
__L_stage_unresolved_instruction_status = $0033
__L_stage_unresolved_instruction_symbol = $0035
__L_stage_unresolved_instruction_width = $0034
__call_stage_plain_word_reference_0 = $0033
__outline_06 = $28dc
append_fixup = $0b93
ass_image_length = $7400
mode_width = $081e
stage_byte = $173b
stage_plain_word_reference = $1787
stage_unresolved_instruction:
__F_stage_unresolved_instruction_entry:
    sta __L_stage_unresolved_instruction_prefix
    ldy __L_stage_unresolved_instruction_mode
    lda mode_width,y
    sta __L_stage_unresolved_instruction_width
    lda __L_stage_unresolved_instruction_opcode
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_unresolved_instruction_join_3
__F_stage_unresolved_instruction_yes_1:
    lda __L_stage_unresolved_instruction_status
    rts
__F_stage_unresolved_instruction_join_3:
    lda ass_image_length
    sta __L_stage_unresolved_instruction_stage
    lda ass_image_length+1
    sta __L_stage_unresolved_instruction_stage+1
    lda __L_stage_unresolved_instruction_width
    cmp #$02
    bne __F_stage_unresolved_instruction_join_6
__F_stage_unresolved_instruction_yes_4:
    lda __L_stage_unresolved_instruction_prefix
    cmp VALUE_PREFIX_NONE
    bne __F_stage_unresolved_instruction_join_9
__F_stage_unresolved_instruction_yes_7:
    lda __L_stage_unresolved_instruction_addend
    ora __L_stage_unresolved_instruction_addend+1
    bne __F_stage_unresolved_instruction_join_9
__F_stage_unresolved_instruction_yes_10:
    lda __L_stage_unresolved_instruction_symbol
    sta __call_stage_plain_word_reference_0
    lda __L_stage_unresolved_instruction_symbol+1
    sta __call_stage_plain_word_reference_0+1
    jsr stage_plain_word_reference
    rts
__F_stage_unresolved_instruction_join_9:
    lda #$00
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_unresolved_instruction_join_15
__F_stage_unresolved_instruction_yes_13:
    lda __L_stage_unresolved_instruction_status
    rts
__F_stage_unresolved_instruction_join_15:
    lda #$00
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_unresolved_instruction_join_18
__F_stage_unresolved_instruction_yes_16:
    lda __L_stage_unresolved_instruction_status
    rts
__F_stage_unresolved_instruction_join_18:
    lda FIXUP_WORD
    jsr __outline_06
    jsr append_fixup
    rts
__F_stage_unresolved_instruction_join_6:
    cmp #$01
    beq __F_stage_unresolved_instruction_join_21
__F_stage_unresolved_instruction_yes_19:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_stage_unresolved_instruction_join_21:
    lda #$00
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_unresolved_instruction_join_24
__F_stage_unresolved_instruction_yes_22:
    lda __L_stage_unresolved_instruction_status
    rts
__F_stage_unresolved_instruction_join_24:
    lda FIXUP_BYTE
    tax
    lda __L_stage_unresolved_instruction_mode
    cmp MODE_RELATIVE
    bne __F_stage_unresolved_instruction_join_27
__F_stage_unresolved_instruction_yes_25:
    lda FIXUP_RELATIVE
    tax
__F_stage_unresolved_instruction_join_27:
    txa
    jsr __outline_06
    jsr append_fixup
    rts
