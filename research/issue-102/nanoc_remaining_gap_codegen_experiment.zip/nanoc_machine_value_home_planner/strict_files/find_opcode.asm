* = $0800
__L_find_opcode_mnemonic = $0033
__L_find_opcode_mode = $c79e
opcode_mnemonic = $08d8
opcode_mode = $09d8
find_opcode:
__F_find_opcode_entry:
    sta __L_find_opcode_mode
    lda #$00
    ldy #$00
__F_find_opcode_while_1:
__F_find_opcode_body_2:
    lda opcode_mnemonic,y
    cmp __L_find_opcode_mnemonic
    bne __F_find_opcode_join_6
__F_find_opcode_yes_4:
    lda opcode_mode,y
    cmp __L_find_opcode_mode
    bne __F_find_opcode_join_6
__F_find_opcode_yes_7:
    tya
    ldx #$00
    rts
__F_find_opcode_join_6:
    iny
    bne __F_find_opcode_while_1
__F_find_opcode_after_3:
    lda #$ff
    ldx #$ff
    rts
