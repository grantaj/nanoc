* = $0800
__L_relative_byte_base = $c73c
__L_relative_byte_difference = $0033
__L_relative_byte_target = $c73a
__tmp0 = $0009
__tmp1 = $000a
relative_byte:
__F_relative_byte_entry:
    lda __L_relative_byte_target
    sec
    sbc __L_relative_byte_base
    sta __tmp0
    lda __L_relative_byte_target+1
    sbc __L_relative_byte_base+1
    sta __tmp1
    lda __tmp0
    sta __L_relative_byte_difference
    lda __tmp1
    sta __L_relative_byte_difference+1
    cmp #$00
    bcc __F_relative_byte_yes_1
    bne __F_relative_byte_join_3
    lda __L_relative_byte_difference
    cmp #$7f
    bcc __F_relative_byte_yes_1
    bne __F_relative_byte_join_3
__F_relative_byte_yes_1:
    lda __L_relative_byte_difference
    ldx __L_relative_byte_difference+1
    rts
__F_relative_byte_join_3:
    lda __L_relative_byte_difference+1
    cmp #$ff
    bcc __F_relative_byte_join_6
    bne __F_relative_byte_yes_4
    lda __L_relative_byte_difference
    cmp #$80
    bcc __F_relative_byte_join_6
__F_relative_byte_yes_4:
    lda __L_relative_byte_difference
    ldx #$00
    rts
__F_relative_byte_join_6:
    lda #$ff
    ldx #$ff
    rts
