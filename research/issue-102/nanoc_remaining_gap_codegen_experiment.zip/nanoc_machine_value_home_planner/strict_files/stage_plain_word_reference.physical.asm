* = $1787
ASSEMBLE_OK = $0803
__L_stage_plain_word_reference_old_head = $c7a6
__L_stage_plain_word_reference_stage = $c7a4
__L_stage_plain_word_reference_status = $0039
__L_stage_plain_word_reference_symbol = $0033
__ap = $0002
__ix = $0004
__outline_03 = $28a7
__outline_36 = $2ae7
__tmp0 = $0009
__tmp1 = $000a
ass_image_length = $7400
stage_byte = $173b
stage_plain_word_reference:
__F_stage_plain_word_reference_entry:
    lda ass_image_length
    sta __L_stage_plain_word_reference_stage
    lda ass_image_length+1
    sta __L_stage_plain_word_reference_stage+1
    lda __L_stage_plain_word_reference_symbol
    asl
    sta __ix
    lda __L_stage_plain_word_reference_symbol+1
    jsr __outline_03
    jsr __outline_36
    lda __tmp0
    sta __L_stage_plain_word_reference_old_head
    lda __tmp1
    sta __L_stage_plain_word_reference_old_head+1
    lda __L_stage_plain_word_reference_old_head
    jsr stage_byte
    sta __L_stage_plain_word_reference_status
    cmp ASSEMBLE_OK
    beq __F_stage_plain_word_reference_join_3
__F_stage_plain_word_reference_yes_1:
    lda __L_stage_plain_word_reference_status
    rts
__F_stage_plain_word_reference_join_3:
    lda __L_stage_plain_word_reference_old_head+1
    jsr stage_byte
    sta __L_stage_plain_word_reference_status
    cmp ASSEMBLE_OK
    beq __F_stage_plain_word_reference_join_6
__F_stage_plain_word_reference_yes_4:
    lda __L_stage_plain_word_reference_status
    rts
__F_stage_plain_word_reference_join_6:
    lda __L_stage_plain_word_reference_stage
    clc
    adc #$01
    sta __tmp0
    lda __L_stage_plain_word_reference_stage+1
    adc #$00
    sta __tmp1
    lda __L_stage_plain_word_reference_symbol
    asl
    sta __ix
    lda __L_stage_plain_word_reference_symbol+1
    jsr __outline_03
    lda __tmp0
    sta (__ap),y
    iny
    lda __tmp1
    sta (__ap),y
    lda ASSEMBLE_OK
    rts
