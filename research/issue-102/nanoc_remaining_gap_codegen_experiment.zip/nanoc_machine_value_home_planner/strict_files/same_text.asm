* = $0800
__L_same_text_a = $0034
__L_same_text_a_length = $0031
__L_same_text_b = $0032
__L_same_text_b_length = $0039
__L_same_text_i = $0036
__ap = $0002
__ix = $0004
__tmp0 = $0009
same_text:
__F_same_text_entry:
    sta __L_same_text_b_length
    lda __L_same_text_a_length
    cmp __L_same_text_b_length
    beq __F_same_text_join_3
__F_same_text_yes_1:
    lda #$00
    rts
__F_same_text_join_3:
    lda #$00
    sta __L_same_text_i
    ldy __L_same_text_i
    lda __L_same_text_a
    sta __ap
    lda __L_same_text_a+1
    sta __ap+1
    lda __L_same_text_b
    sta __ix
    lda __L_same_text_b+1
    sta __ix+1
__F_same_text_while_4:
    cpy __L_same_text_a_length
    bcs __F_same_text_after_6
__F_same_text_body_5:
    lda (__ap),y
    sta __tmp0
    lda (__ix),y
    cmp __tmp0
    beq __F_same_text_join_9
__F_same_text_yes_7:
    lda #$00
    rts
__F_same_text_join_9:
    inc __L_same_text_i
    iny
    jmp __F_same_text_while_4
__F_same_text_after_6:
    lda #$01
    rts
