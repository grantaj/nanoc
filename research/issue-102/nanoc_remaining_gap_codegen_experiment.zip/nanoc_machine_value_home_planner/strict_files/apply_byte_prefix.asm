* = $0800
VALUE_PREFIX_LOW = $0ae1
__L_apply_byte_prefix_prefix = $c72e
__L_apply_byte_prefix_value = $0035
apply_byte_prefix:
__F_apply_byte_prefix_entry:
    sta __L_apply_byte_prefix_prefix
    cmp VALUE_PREFIX_LOW
    bne __F_apply_byte_prefix_join_3
__F_apply_byte_prefix_yes_1:
    lda __L_apply_byte_prefix_value
    rts
__F_apply_byte_prefix_join_3:
    lda __L_apply_byte_prefix_value+1
    rts
