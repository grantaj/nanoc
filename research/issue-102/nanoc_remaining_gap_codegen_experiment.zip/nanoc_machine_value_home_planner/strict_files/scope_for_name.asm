* = $0800
__L_scope_for_name_length = $c74d
__L_scope_for_name_name = $0039
__ap = $0002
current_scope = $b313
scope_for_name:
__F_scope_for_name_entry:
    sta __L_scope_for_name_length
    cmp #$00
    bne __F_scope_for_name_join_3
__F_scope_for_name_yes_1:
    lda #$ff
    ldx #$ff
    rts
__F_scope_for_name_join_3:
    ldy #$00
    lda __L_scope_for_name_name
    sta __ap
    lda __L_scope_for_name_name+1
    sta __ap+1
    lda (__ap),y
    cmp #$2e
    bne __F_scope_for_name_join_6
__F_scope_for_name_yes_4:
    lda current_scope
    cmp #$00
    bne __F_scope_for_name_join_9
__F_scope_for_name_yes_7:
    lda #$ff
    ldx #$ff
    rts
__F_scope_for_name_join_9:
    lda current_scope
    ldx #$00
    rts
__F_scope_for_name_join_6:
    lda #$00
    ldx #$00
    rts
