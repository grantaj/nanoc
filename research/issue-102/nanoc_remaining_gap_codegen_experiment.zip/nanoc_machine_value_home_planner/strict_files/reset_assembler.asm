* = $0800
ASSEMBLE_OK = $0803
__L_reset_assembler_default_origin = $0032
__L_reset_assembler_directory = $0030
__L_reset_assembler_directory_length = $0034
ass_image_length = $7400
ass_origin = $7402
current_scope = $b313
fixup_count = $c714
origin_allowed = $c723
source_depth = $760a
source_directory = $760c
source_directory_length = $760e
symbol_count = $b30f
symbol_name_used = $b311
reset_assembler:
__F_reset_assembler_entry:
    sta __L_reset_assembler_directory_length
    lda #$00
    sta ass_image_length
    sta ass_image_length+1
    lda __L_reset_assembler_default_origin
    sta ass_origin
    lda __L_reset_assembler_default_origin+1
    sta ass_origin+1
    lda #$ff
    sta source_depth
    sta source_depth+1
    lda __L_reset_assembler_directory
    sta source_directory
    lda __L_reset_assembler_directory+1
    sta source_directory+1
    lda __L_reset_assembler_directory_length
    sta source_directory_length
    lda #$00
    sta symbol_count
    sta symbol_count+1
    sta symbol_name_used
    sta symbol_name_used+1
    sta current_scope
    sta fixup_count
    sta fixup_count+1
    lda #$01
    sta origin_allowed
    lda ASSEMBLE_OK
    rts
