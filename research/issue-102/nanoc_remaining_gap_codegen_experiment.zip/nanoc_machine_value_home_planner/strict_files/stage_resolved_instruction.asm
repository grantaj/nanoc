* = $0800
ASSEMBLE_BAD_INSTRUCTION = $0808
ASSEMBLE_OK = $0803
__L_stage_resolved_instruction_mode = $0036
__L_stage_resolved_instruction_opcode = $0035
__L_stage_resolved_instruction_status = $0037
__L_stage_resolved_instruction_value = $0033
__L_stage_resolved_instruction_width = $0038
mode_width = $081e
stage_byte = $173b
stage_resolved_instruction:
__F_stage_resolved_instruction_entry:
    ldy __L_stage_resolved_instruction_mode
    lda mode_width,y
    sta __L_stage_resolved_instruction_width
    cmp #$01
    bne __F_stage_resolved_instruction_join_3
__F_stage_resolved_instruction_yes_1:
    lda __L_stage_resolved_instruction_value+1
    cmp #$00
    bcc __F_stage_resolved_instruction_join_3
    bne __F_stage_resolved_instruction_yes_4
    lda __L_stage_resolved_instruction_value
    cmp #$ff
    bcc __F_stage_resolved_instruction_join_3
    beq __F_stage_resolved_instruction_join_3
__F_stage_resolved_instruction_yes_4:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_stage_resolved_instruction_join_3:
    lda __L_stage_resolved_instruction_opcode
    jsr stage_byte
    sta __L_stage_resolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_resolved_instruction_join_9
__F_stage_resolved_instruction_yes_7:
    lda __L_stage_resolved_instruction_status
    rts
__F_stage_resolved_instruction_join_9:
    lda __L_stage_resolved_instruction_width
    cmp #$00
    bne __F_stage_resolved_instruction_join_12
__F_stage_resolved_instruction_yes_10:
    lda ASSEMBLE_OK
    rts
__F_stage_resolved_instruction_join_12:
    lda __L_stage_resolved_instruction_value
    jsr stage_byte
    sta __L_stage_resolved_instruction_status
    cmp ASSEMBLE_OK
    beq __F_stage_resolved_instruction_join_15
__F_stage_resolved_instruction_yes_13:
    lda __L_stage_resolved_instruction_status
    rts
__F_stage_resolved_instruction_join_15:
    lda __L_stage_resolved_instruction_width
    cmp #$02
    bne __F_stage_resolved_instruction_join_18
__F_stage_resolved_instruction_yes_16:
    lda __L_stage_resolved_instruction_value+1
    jsr stage_byte
    rts
__F_stage_resolved_instruction_join_18:
    lda ASSEMBLE_OK
    rts
