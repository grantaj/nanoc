* = $0800
ASSEMBLE_BAD_DATA = $080b
ASSEMBLE_OK = $0803
__L_assemble_string_argument = $0030
__L_assemble_string_i = $0032
__L_assemble_string_length = $0038
__L_assemble_string_status = $0033
__ap = $0002
__outline_01 = $287c
__outline_12 = $2965
__rh = $0006
__tmp0 = $0009
__tmp1 = $000a
stage_byte = $173b
assemble_string:
__F_assemble_string_entry:
    sta __L_assemble_string_length
    cmp #$02
    bcs __F_assemble_string_join_3
__F_assemble_string_yes_1:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_string_join_3:
    ldy #$00
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    sta __ap+1
    lda (__ap),y
    cmp #$22
    beq __F_assemble_string_join_6
__F_assemble_string_yes_4:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_string_join_6:
    lda __L_assemble_string_length
    jsr __outline_12
    sta __tmp1
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    jsr __outline_01
    cmp #$22
    beq __F_assemble_string_join_9
__F_assemble_string_yes_7:
    lda ASSEMBLE_BAD_DATA
    rts
__F_assemble_string_join_9:
    lda #$01
    sta __L_assemble_string_i
__F_assemble_string_while_10:
    lda __L_assemble_string_length
    jsr __outline_12
    eor #$80
    sta __rh
    lda #$80
    cmp __rh
    bcc __F_assemble_string_body_11
    bne __F_assemble_string_after_12
    lda __L_assemble_string_i
    cmp __tmp0
    bcs __F_assemble_string_after_12
__F_assemble_string_body_11:
    ldy __L_assemble_string_i
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    sta __ap+1
    lda (__ap),y
    jsr stage_byte
    sta __L_assemble_string_status
    cmp ASSEMBLE_OK
    beq __F_assemble_string_join_15
__F_assemble_string_yes_13:
    lda __L_assemble_string_status
    rts
__F_assemble_string_join_15:
    inc __L_assemble_string_i
    jmp __F_assemble_string_while_10
__F_assemble_string_after_12:
    lda #$00
    jsr stage_byte
    rts
