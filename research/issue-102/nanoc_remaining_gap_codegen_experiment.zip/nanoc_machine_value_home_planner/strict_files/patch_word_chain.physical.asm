* = $118c
ASSEMBLE_OK = $0803
__L_patch_word_chain_head = $0035
__L_patch_word_chain_next = $c776
__L_patch_word_chain_stage = $0033
__L_patch_word_chain_value = $0039
__ap = $0002
__outline_20 = $29e6
__outline_27 = $2a55
__outline_31 = $2a97
__tmp0 = $0009
__tmp1 = $000a
__tmp2 = $000b
__tmp3 = $000c
__tmp4 = $000d
ass_image = $4800
patch_word_chain:
__F_patch_word_chain_entry:
__F_patch_word_chain_while_1:
    lda __L_patch_word_chain_head
    ora __L_patch_word_chain_head+1
    beq __F_patch_word_chain_after_3
__F_patch_word_chain_body_2:
    lda __L_patch_word_chain_head
    sec
    sbc #$01
    sta __L_patch_word_chain_stage
    lda __L_patch_word_chain_head+1
    sbc #$00
    sta __L_patch_word_chain_stage+1
    jsr __outline_31
    lda (__ap),y
    sta __tmp0
    lda __L_patch_word_chain_stage
    clc
    adc #$01
    sta __tmp1
    lda __L_patch_word_chain_stage+1
    adc #$00
    sta __tmp2
    clc
    lda __tmp1
    adc #<ass_image
    sta __ap
    lda __tmp2
    adc #>ass_image
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __tmp1
    lda #$00
    sta __tmp2
    jsr __outline_27
    jsr __outline_27
    lda __tmp0
    ora __tmp1
    sta __tmp3
    lda #$00
    ora __tmp2
    sta __tmp4
    lda __tmp3
    sta __L_patch_word_chain_next
    lda __tmp4
    sta __L_patch_word_chain_next+1
    jsr __outline_31
    lda __L_patch_word_chain_value
    sta (__ap),y
    lda __L_patch_word_chain_stage
    clc
    adc #$01
    sta __tmp0
    lda __L_patch_word_chain_stage+1
    jsr __outline_20
    lda __L_patch_word_chain_value+1
    sta (__ap),y
    lda __L_patch_word_chain_next
    sta __L_patch_word_chain_head
    lda __L_patch_word_chain_next+1
    sta __L_patch_word_chain_head+1
    jmp __F_patch_word_chain_while_1
__F_patch_word_chain_after_3:
    lda ASSEMBLE_OK
    rts
