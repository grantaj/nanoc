* = $237f
ASSEMBLE_BAD_STATEMENT = $0804
ASSEMBLE_BAD_SYMBOL = $0805
ASSEMBLE_OK = $0803
__L_process_source_line_argument_start = $0034
__L_process_source_line_cursor = $0030
__L_process_source_line_name_length = $0033
__L_process_source_line_name_start = $0032
__L_process_source_line_status = $0031
__ap = $0002
__call_process_instruction_like_0 = $003c
__call_process_instruction_like_1 = $c81f
__call_process_instruction_like_2 = $003e
__call_process_label_0 = $003c
__call_process_symbol_0 = $003b
__call_process_symbol_1 = $003f
__call_process_symbol_2 = $003d
__outline_12 = $2965
__tmp0 = $0009
__tmp1 = $000a
__tmp2 = $000b
__tmp3 = $000c
process_instruction_like = $22bf
process_label = $21c8
process_symbol = $2228
scan_argument = $2131
source_line = $7404
source_line_length = $7504
process_source_line:
__F_process_source_line_entry:
    lda #$00
    sta __L_process_source_line_cursor
__F_process_source_line_while_1:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_while_4
    jmp __F_process_source_line_after_3
__F_process_source_line_while_4:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_after_6
__F_process_source_line_body_5:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$20
    bne __F_process_source_line_no_8
__F_process_source_line_yes_7:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_4
__F_process_source_line_no_8:
    cmp #$09
    bne __F_process_source_line_after_6
__F_process_source_line_yes_10:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_4
__F_process_source_line_after_6:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_join_15
__F_process_source_line_yes_13:
    lda ASSEMBLE_OK
    rts
__F_process_source_line_join_15:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$3b
    bne __F_process_source_line_join_18
__F_process_source_line_yes_16:
    lda ASSEMBLE_OK
    rts
__F_process_source_line_join_18:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_name_start
__F_process_source_line_while_19:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_after_21
__F_process_source_line_body_20:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$20
    beq __F_process_source_line_after_21
__F_process_source_line_join_24:
    cmp #$09
    beq __F_process_source_line_after_21
__F_process_source_line_join_27:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_19
__F_process_source_line_after_21:
    lda __L_process_source_line_cursor
    sec
    sbc __L_process_source_line_name_start
    sta __L_process_source_line_name_length
    cmp #$00
    bne __F_process_source_line_join_30
__F_process_source_line_yes_28:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_process_source_line_join_30:
    lda __L_process_source_line_name_start
    clc
    adc __L_process_source_line_name_length
    sta __tmp0
    lda #$00
    adc #$00
    sta __tmp1
    lda __tmp0
    sec
    sbc #$01
    sta __tmp2
    lda __tmp1
    sbc #$00
    sta __tmp3
    clc
    lda __tmp2
    adc #<source_line
    sta __ap
    lda __tmp3
    adc #>source_line
    sta __ap+1
    ldy #$00
    lda (__ap),y
    cmp #$3a
    bne __F_process_source_line_while_37
__F_process_source_line_yes_31:
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_label_0
    lda #>source_line
    adc #$00
    sta __call_process_label_0+1
    lda __L_process_source_line_name_length
    jsr __outline_12
    lda __tmp0
    jsr process_label
    sta __L_process_source_line_status
    cmp ASSEMBLE_OK
    bne __F_process_source_line_yes_34
    jmp __F_process_source_line_while_1
__F_process_source_line_yes_34:
    lda __L_process_source_line_status
    rts
__F_process_source_line_while_37:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_after_39
__F_process_source_line_body_38:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$20
    bne __F_process_source_line_no_41
__F_process_source_line_yes_40:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_37
__F_process_source_line_no_41:
    cmp #$09
    bne __F_process_source_line_after_39
__F_process_source_line_yes_43:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_37
__F_process_source_line_after_39:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_join_48
__F_process_source_line_yes_46:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$3d
    bne __F_process_source_line_join_48
__F_process_source_line_yes_49:
    inc __L_process_source_line_cursor
__F_process_source_line_while_52:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_after_54
__F_process_source_line_body_53:
    ldy __L_process_source_line_cursor
    lda source_line,y
    cmp #$20
    bne __F_process_source_line_no_56
__F_process_source_line_yes_55:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_52
__F_process_source_line_no_56:
    cmp #$09
    bne __F_process_source_line_after_54
__F_process_source_line_yes_58:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_52
__F_process_source_line_after_54:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_argument_start
    jsr scan_argument
    sta __tmp0
    lda __tmp0
    tax
    cmp #$00
    bne __F_process_source_line_join_63
__F_process_source_line_yes_61:
    lda ASSEMBLE_BAD_SYMBOL
    rts
__F_process_source_line_join_63:
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_symbol_0
    lda #>source_line
    adc #$00
    sta __call_process_symbol_0+1
    lda #<source_line
    clc
    adc __L_process_source_line_argument_start
    sta __call_process_symbol_2
    lda #>source_line
    adc #$00
    sta __call_process_symbol_2+1
    lda __L_process_source_line_name_length
    sta __call_process_symbol_1
    txa
    jsr process_symbol
    rts
__F_process_source_line_join_48:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_argument_start
    jsr scan_argument
    sta __tmp0
    lda __tmp0
    tax
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_instruction_like_0
    lda #>source_line
    adc #$00
    sta __call_process_instruction_like_0+1
    lda #<source_line
    clc
    adc __L_process_source_line_argument_start
    sta __call_process_instruction_like_2
    lda #>source_line
    adc #$00
    sta __call_process_instruction_like_2+1
    lda __L_process_source_line_name_length
    sta __call_process_instruction_like_1
    txa
    jsr process_instruction_like
    rts
__F_process_source_line_after_3:
    lda ASSEMBLE_OK
    rts
