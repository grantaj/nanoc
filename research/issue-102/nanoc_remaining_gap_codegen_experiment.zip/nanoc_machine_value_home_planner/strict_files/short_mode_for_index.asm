* = $0800
MODE_ZERO_PAGE = $0814
MODE_ZERO_PAGE_X = $0815
MODE_ZERO_PAGE_Y = $0816
__L_short_mode_for_index_index = $003b
short_mode_for_index:
__F_short_mode_for_index_entry:
    sta __L_short_mode_for_index_index
    cmp #$01
    bne __F_short_mode_for_index_join_3
__F_short_mode_for_index_yes_1:
    lda MODE_ZERO_PAGE_X
    rts
__F_short_mode_for_index_join_3:
    cmp #$02
    bne __F_short_mode_for_index_join_6
__F_short_mode_for_index_yes_4:
    lda MODE_ZERO_PAGE_Y
    rts
__F_short_mode_for_index_join_6:
    lda MODE_ZERO_PAGE
    rts
