* = $1947
MODE_ABSOLUTE = $0817
MODE_ABSOLUTE_X = $0818
MODE_ABSOLUTE_Y = $0819
__L_long_mode_for_index_index = $c7c4
long_mode_for_index:
__F_long_mode_for_index_entry:
    sta __L_long_mode_for_index_index
    cmp #$01
    bne __F_long_mode_for_index_join_3
__F_long_mode_for_index_yes_1:
    lda MODE_ABSOLUTE_X
    rts
__F_long_mode_for_index_join_3:
    cmp #$02
    bne __F_long_mode_for_index_join_6
__F_long_mode_for_index_yes_4:
    lda MODE_ABSOLUTE_Y
    rts
__F_long_mode_for_index_join_6:
    lda MODE_ABSOLUTE
    rts
