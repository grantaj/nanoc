* = $1afb
ASSEMBLE_BAD_INSTRUCTION = $0808
MODE_ACCUMULATOR = $0812
MODE_IMMEDIATE = $0813
MODE_IMPLIED = $0811
MODE_INDIRECT = $081a
MODE_INDIRECT_X = $081b
MODE_INDIRECT_Y = $081c
__L_assemble_instruction_argument = $0031
__L_assemble_instruction_argument_length = $0030
__L_assemble_instruction_core_length = $0033
__L_assemble_instruction_index = $0034
__L_assemble_instruction_mnemonic = $0035
__L_assemble_instruction_name = $c7dc
__L_assemble_instruction_name_length = $c7de
__L_assemble_instruction_opcode = $0033
__ap = $0002
__call_assemble_direct_value_0 = $c7cd
__call_assemble_direct_value_1 = $c7ce
__call_assemble_direct_value_2 = $c7d0
__call_assemble_mode_value_0 = $c7c5
__call_assemble_mode_value_1 = $003b
__call_find_mnemonic_0 = $0034
__call_find_opcode_0 = $0033
__call_stage_resolved_instruction_0 = $0035
__call_stage_resolved_instruction_1 = $0036
__call_stage_resolved_instruction_2 = $0033
__outline_01 = $287c
__outline_02 = $2898
__outline_05 = $28cc
__outline_12 = $2965
__outline_34 = $2ac7
__tmp0 = $0009
assemble_direct_value = $19e3
assemble_mode_value = $195e
find_mnemonic = $16a2
find_opcode = $1719
stage_resolved_instruction = $17f0
upper_char = $0ae8
assemble_instruction:
__F_assemble_instruction_entry:
    sta __L_assemble_instruction_argument_length
    lda __L_assemble_instruction_name
    sta __call_find_mnemonic_0
    lda __L_assemble_instruction_name+1
    sta __call_find_mnemonic_0+1
    lda __L_assemble_instruction_name_length
    jsr find_mnemonic
    sta __L_assemble_instruction_mnemonic
    stx __L_assemble_instruction_mnemonic+1
    lda __L_assemble_instruction_mnemonic+1
    bpl __F_assemble_instruction_join_3
__F_assemble_instruction_yes_1:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_3:
    lda __L_assemble_instruction_argument_length
    cmp #$00
    bne __F_assemble_instruction_join_6
__F_assemble_instruction_yes_4:
    lda __L_assemble_instruction_mnemonic
    sta __call_find_opcode_0
    lda MODE_IMPLIED
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda __L_assemble_instruction_opcode+1
    bmi __F_assemble_instruction_join_9
__F_assemble_instruction_yes_7:
    lda __L_assemble_instruction_opcode
    sta __call_stage_resolved_instruction_0
    lda MODE_IMPLIED
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    rts
__F_assemble_instruction_join_9:
    lda __L_assemble_instruction_mnemonic
    sta __call_find_opcode_0
    lda MODE_ACCUMULATOR
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda __L_assemble_instruction_opcode+1
    bmi __F_assemble_instruction_join_12
__F_assemble_instruction_yes_10:
    jsr __outline_34
    jsr stage_resolved_instruction
    rts
__F_assemble_instruction_join_12:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_6:
    cmp #$01
    bne __F_assemble_instruction_join_15
__F_assemble_instruction_yes_13:
    ldy #$00
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda (__ap),y
    jsr upper_char
    cmp #$41
    bne __F_assemble_instruction_join_15
__F_assemble_instruction_yes_16:
    lda __L_assemble_instruction_mnemonic
    sta __call_find_opcode_0
    lda MODE_ACCUMULATOR
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda __L_assemble_instruction_opcode+1
    bpl __F_assemble_instruction_join_21
__F_assemble_instruction_yes_19:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_21:
    jsr __outline_34
    jsr stage_resolved_instruction
    rts
__F_assemble_instruction_join_15:
    ldy #$00
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda (__ap),y
    cmp #$23
    bne __F_assemble_instruction_join_24
__F_assemble_instruction_yes_22:
    lda __L_assemble_instruction_argument_length
    cmp #$02
    bcs __F_assemble_instruction_join_27
__F_assemble_instruction_yes_25:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_27:
    jsr __outline_05
    lda __L_assemble_instruction_argument_length
    jsr __outline_12
    lda __L_assemble_instruction_mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_IMMEDIATE
    sta __call_assemble_mode_value_1
    lda __tmp0
    jsr assemble_mode_value
    rts
__F_assemble_instruction_join_24:
    cmp #$28
    beq __F_assemble_instruction_yes_28
    jmp __F_assemble_instruction_join_30
__F_assemble_instruction_yes_28:
    lda __L_assemble_instruction_argument_length
    cmp #$03
    bcs __F_assemble_instruction_join_33
__F_assemble_instruction_yes_31:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_33:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    jsr __outline_02
    jsr __outline_01
    jsr upper_char
    cmp #$59
    bne __F_assemble_instruction_join_36
__F_assemble_instruction_yes_34:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    jsr __outline_02
    jsr __outline_01
    cmp #$2c
    bne __F_assemble_instruction_join_36
__F_assemble_instruction_yes_37:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$03
    jsr __outline_02
    jsr __outline_01
    cmp #$29
    beq __F_assemble_instruction_join_42
__F_assemble_instruction_yes_40:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_42:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$04
    sta __L_assemble_instruction_core_length
    cmp #$00
    bcc __F_assemble_instruction_yes_43
    bne __F_assemble_instruction_join_45
__F_assemble_instruction_yes_43:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_45:
    jsr __outline_05
    lda __L_assemble_instruction_mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_INDIRECT_Y
    sta __call_assemble_mode_value_1
    lda __L_assemble_instruction_core_length
    jsr assemble_mode_value
    rts
__F_assemble_instruction_join_36:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    jsr __outline_02
    jsr __outline_01
    cmp #$29
    beq __F_assemble_instruction_join_48
__F_assemble_instruction_yes_46:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_48:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    jsr __outline_02
    jsr __outline_01
    jsr upper_char
    cmp #$58
    bne __F_assemble_instruction_join_51
__F_assemble_instruction_yes_49:
    lda __L_assemble_instruction_argument_length
    cmp #$05
    bcs __F_assemble_instruction_join_54
__F_assemble_instruction_yes_52:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_54:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$03
    jsr __outline_02
    jsr __outline_01
    cmp #$2c
    beq __F_assemble_instruction_join_57
__F_assemble_instruction_yes_55:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
__F_assemble_instruction_join_57:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$04
    sta __L_assemble_instruction_core_length
    jsr __outline_05
    lda __L_assemble_instruction_mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_INDIRECT_X
    sta __call_assemble_mode_value_1
    lda __L_assemble_instruction_core_length
    jsr assemble_mode_value
    rts
__F_assemble_instruction_join_51:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
    jsr __outline_05
    lda __L_assemble_instruction_mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_INDIRECT
    sta __call_assemble_mode_value_1
    lda __L_assemble_instruction_core_length
    jsr assemble_mode_value
    rts
__F_assemble_instruction_join_30:
    lda #$00
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sta __L_assemble_instruction_core_length
    cmp #$03
    bcc __F_assemble_instruction_join_60
__F_assemble_instruction_yes_58:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    jsr __outline_02
    jsr __outline_01
    cmp #$2c
    bne __F_assemble_instruction_join_60
__F_assemble_instruction_yes_61:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    jsr __outline_02
    jsr __outline_01
    jsr upper_char
    cmp #$58
    bne __F_assemble_instruction_no_65
__F_assemble_instruction_yes_64:
    lda #$01
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
    jmp __F_assemble_instruction_join_60
__F_assemble_instruction_no_65:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    jsr __outline_02
    jsr __outline_01
    jsr upper_char
    cmp #$59
    bne __F_assemble_instruction_join_60
__F_assemble_instruction_yes_67:
    lda #$02
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
__F_assemble_instruction_join_60:
    lda __L_assemble_instruction_mnemonic
    sta __call_assemble_direct_value_0
    lda __L_assemble_instruction_argument
    sta __call_assemble_direct_value_1
    lda __L_assemble_instruction_argument+1
    sta __call_assemble_direct_value_1+1
    lda __L_assemble_instruction_core_length
    sta __call_assemble_direct_value_2
    lda __L_assemble_instruction_index
    jsr assemble_direct_value
    rts
