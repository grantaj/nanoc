* = $25ec
ASSEMBLE_IO_ERROR = $080e
ASSEMBLE_LINE_TOO_LONG = $080f
ASSEMBLE_OK = $0803
ASSEMBLE_UNDEFINED = $0809
__L_ass_assemble_default_origin = $0030
__L_ass_assemble_directory = $0037
__L_ass_assemble_directory_length = $003a
__L_ass_assemble_handle = $0030
__L_ass_assemble_line_status = $0030
__L_ass_assemble_root_name = $0035
__L_ass_assemble_root_name_length = $0039
__L_ass_assemble_status = $0030
__ap = $0002
__call_io_close_0 = $cf1e
__call_io_open_0 = $cf10
__call_io_open_1 = $cf12
__call_reset_assembler_0 = $0032
__call_reset_assembler_1 = $0030
__outline_04 = $28ba
__outline_14 = $298a
all_fixups_resolved = $2599
all_symbols_defined = $2546
close_source_tree = $2112
io_close = $2811
io_open = $26f7
process_source_line = $237f
read_source_line = $208f
reset_assembler = $24fb
source_depth = $760a
source_handle = $7605
ass_assemble:
__F_ass_assemble_entry:
    lda __L_ass_assemble_default_origin
    sta __call_reset_assembler_0
    lda __L_ass_assemble_default_origin+1
    sta __call_reset_assembler_0+1
    lda __L_ass_assemble_directory
    sta __call_reset_assembler_1
    lda __L_ass_assemble_directory+1
    sta __call_reset_assembler_1+1
    lda __L_ass_assemble_directory_length
    jsr reset_assembler
    lda __L_ass_assemble_root_name
    sta __call_io_open_0
    lda __L_ass_assemble_root_name+1
    sta __call_io_open_0+1
    lda __L_ass_assemble_root_name_length
    sta __call_io_open_1
    lda #$00
    sta __call_io_open_1+1
    jsr io_open
    sta __L_ass_assemble_handle
    stx __L_ass_assemble_handle+1
    lda __L_ass_assemble_handle+1
    bpl __F_ass_assemble_join_3
__F_ass_assemble_yes_1:
    lda ASSEMBLE_IO_ERROR
    rts
__F_ass_assemble_join_3:
    lda #$00
    sta source_depth
    sta source_depth+1
    ldy #$00
    lda __L_ass_assemble_handle
    sta source_handle,y
__F_ass_assemble_while_4:
    lda source_depth+1
    bmi __F_ass_assemble_after_6
__F_ass_assemble_body_5:
    jsr read_source_line
    sta __L_ass_assemble_line_status
    stx __L_ass_assemble_line_status+1
    lda __L_ass_assemble_line_status+1
    cmp #$00
    bne __F_ass_assemble_no_8
    lda __L_ass_assemble_line_status
    cmp #$01
    bne __F_ass_assemble_no_8
__F_ass_assemble_yes_7:
    jsr process_source_line
    sta __L_ass_assemble_status
    cmp ASSEMBLE_OK
    beq __F_ass_assemble_while_4
__F_ass_assemble_yes_10:
    jsr close_source_tree
    lda __L_ass_assemble_status
    rts
__F_ass_assemble_no_8:
    lda __L_ass_assemble_line_status
    ora __L_ass_assemble_line_status+1
    bne __F_ass_assemble_no_14
__F_ass_assemble_yes_13:
    jsr __outline_04
    lda (__ap),y
    sta __call_io_close_0
    lda #$00
    sta __call_io_close_0+1
    jsr io_close
    jsr __outline_14
    jmp __F_ass_assemble_while_4
__F_ass_assemble_no_14:
    jsr close_source_tree
    lda __L_ass_assemble_line_status+1
    cmp #$ff
    bne __F_ass_assemble_join_18
    lda __L_ass_assemble_line_status
    cmp #$fe
    bne __F_ass_assemble_join_18
__F_ass_assemble_yes_16:
    lda ASSEMBLE_LINE_TOO_LONG
    rts
__F_ass_assemble_join_18:
    lda ASSEMBLE_IO_ERROR
    rts
__F_ass_assemble_after_6:
    jsr all_symbols_defined
    cmp #$00
    bne __F_ass_assemble_join_21
__F_ass_assemble_yes_19:
    lda ASSEMBLE_UNDEFINED
    rts
__F_ass_assemble_join_21:
    jsr all_fixups_resolved
    cmp #$00
    bne __F_ass_assemble_join_24
__F_ass_assemble_yes_22:
    lda ASSEMBLE_UNDEFINED
    rts
__F_ass_assemble_join_24:
    lda ASSEMBLE_OK
    rts
__nc_io_mode   = $ce00
__nc_io_eof    = $ce06
__nc_io_handle = $ce0c
__nc_io_name   = $ce10             ; 256-byte create-name buffer
__c_io_open__v00   = $cf10         ; char *name
__c_io_open__v01   = $cf12         ; int length
__c_io_read__v00   = $cf14         ; int handle
__c_io_create__v00 = $cf16         ; char *name
__c_io_create__v01 = $cf18         ; int length
__c_io_write__v00  = $cf1a         ; int handle
__c_io_write__v01  = $cf1c         ; int value
__c_io_close__v00  = $cf1e         ; int handle
