* = $21c8
ASSEMBLE_BAD_STATEMENT = $0804
ASSEMBLE_SCOPE_ERROR = $0807
__L_process_label_length = $c812
__L_process_label_name = $003c
__L_process_label_status = $0031
__L_process_label_value = $0031
__ap = $0002
__call_define_label_0 = $003e
__call_define_label_1 = $c77a
__call_define_label_2 = $0037
__outline_21 = $29fa
__tmp1 = $000a
current_scope = $b313
define_label = $120e
origin_allowed = $c723
process_label:
__F_process_label_entry:
    sta __L_process_label_length
    cmp #$00
    bne __F_process_label_join_3
__F_process_label_yes_1:
    lda ASSEMBLE_BAD_STATEMENT
    rts
__F_process_label_join_3:
    ldy #$00
    lda __L_process_label_name
    sta __ap
    lda __L_process_label_name+1
    sta __ap+1
    lda (__ap),y
    cmp #$2e
    bne __F_process_label_no_5
__F_process_label_yes_4:
    lda current_scope
    cmp #$00
    bne __F_process_label_join_6
__F_process_label_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_process_label_no_5:
    lda current_scope
    cmp #$ff
    bne __F_process_label_join_12
__F_process_label_yes_10:
    lda ASSEMBLE_SCOPE_ERROR
    rts
__F_process_label_join_12:
    inc current_scope
__F_process_label_join_6:
    lda #$00
    sta origin_allowed
    jsr __outline_21
    sta __L_process_label_value
    lda __tmp1
    sta __L_process_label_value+1
    lda __L_process_label_name
    sta __call_define_label_0
    lda __L_process_label_name+1
    sta __call_define_label_0+1
    lda __L_process_label_length
    sta __call_define_label_1
    lda __L_process_label_value
    sta __call_define_label_2
    lda __L_process_label_value+1
    sta __call_define_label_2+1
    jsr define_label
    sta __L_process_label_status
    lda __L_process_label_status
    rts
