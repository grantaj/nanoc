	include "../nanoc1/target/header.asm"
__g05:
	byte $00
__g06:
	byte $01
__g07:
	byte $02
__g08:
	byte $03
__g09:
	byte $04
__g0a:
	byte $05
__g0b:
	byte $06
__g0c:
	byte $07
__g0d:
	byte $09
__g0e:
	byte $0a
__g0f:
	byte $0b
__g10:
	byte $0c
__g11:
	byte $0d
__g12:
	byte $0e
__g13:
	byte $00
__g14:
	byte $01
__g15:
	byte $02
__g16:
	byte $03
__g17:
	byte $04
__g18:
	byte $05
__g19:
	byte $06
__g1a:
	byte $07
__g1b:
	byte $08
__g1c:
	byte $09
__g1d:
	byte $0a
__g1e:
	byte $0b
__g1f:
	byte $0c
__g20:
	byte $00
	byte $00
	byte $01
	byte $01
	byte $01
	byte $01
	byte $02
	byte $02
	byte $02
	byte $02
	byte $01
	byte $01
	byte $01
	byte $00
__g21:
	byte $41
	byte $44
	byte $43
	byte $41
	byte $4e
	byte $44
	byte $41
	byte $53
	byte $4c
	byte $42
	byte $43
	byte $43
	byte $42
	byte $43
	byte $53
	byte $42
	byte $45
	byte $51
	byte $42
	byte $49
	byte $54
	byte $42
	byte $4d
	byte $49
	byte $42
	byte $4e
	byte $45
	byte $42
	byte $50
	byte $4c
	byte $42
	byte $52
	byte $4b
	byte $42
	byte $56
	byte $43
	byte $42
	byte $56
	byte $53
	byte $43
	byte $4c
	byte $43
	byte $43
	byte $4c
	byte $44
	byte $43
	byte $4c
	byte $49
	byte $43
	byte $4c
	byte $56
	byte $43
	byte $4d
	byte $50
	byte $43
	byte $50
	byte $58
	byte $43
	byte $50
	byte $59
	byte $44
	byte $45
	byte $43
	byte $44
	byte $45
	byte $58
	byte $44
	byte $45
	byte $59
	byte $45
	byte $4f
	byte $52
	byte $49
	byte $4e
	byte $43
	byte $49
	byte $4e
	byte $58
	byte $49
	byte $4e
	byte $59
	byte $4a
	byte $4d
	byte $50
	byte $4a
	byte $53
	byte $52
	byte $4c
	byte $44
	byte $41
	byte $4c
	byte $44
	byte $58
	byte $4c
	byte $44
	byte $59
	byte $4c
	byte $53
	byte $52
	byte $4e
	byte $4f
	byte $50
	byte $4f
	byte $52
	byte $41
	byte $50
	byte $48
	byte $41
	byte $50
	byte $48
	byte $50
	byte $50
	byte $4c
	byte $41
	byte $50
	byte $4c
	byte $50
	byte $52
	byte $4f
	byte $4c
	byte $52
	byte $4f
	byte $52
	byte $52
	byte $54
	byte $49
	byte $52
	byte $54
	byte $53
	byte $53
	byte $42
	byte $43
	byte $53
	byte $45
	byte $43
	byte $53
	byte $45
	byte $44
	byte $53
	byte $45
	byte $49
	byte $53
	byte $54
	byte $41
	byte $53
	byte $54
	byte $58
	byte $53
	byte $54
	byte $59
	byte $54
	byte $41
	byte $58
	byte $54
	byte $41
	byte $59
	byte $54
	byte $53
	byte $58
	byte $54
	byte $58
	byte $41
	byte $54
	byte $58
	byte $53
	byte $54
	byte $59
	byte $41
	byte $3f
	byte $3f
	byte $3f
	byte $00
__g22:
	byte $0a
	byte $22
	byte $38
	byte $38
	byte $38
	byte $22
	byte $02
	byte $38
	byte $24
	byte $22
	byte $02
	byte $38
	byte $38
	byte $22
	byte $02
	byte $38
	byte $09
	byte $22
	byte $38
	byte $38
	byte $38
	byte $22
	byte $02
	byte $38
	byte $0d
	byte $22
	byte $38
	byte $38
	byte $38
	byte $22
	byte $02
	byte $38
	byte $1c
	byte $01
	byte $38
	byte $38
	byte $06
	byte $01
	byte $27
	byte $38
	byte $26
	byte $01
	byte $27
	byte $38
	byte $06
	byte $01
	byte $27
	byte $38
	byte $07
	byte $01
	byte $38
	byte $38
	byte $38
	byte $01
	byte $27
	byte $38
	byte $2c
	byte $01
	byte $38
	byte $38
	byte $38
	byte $01
	byte $27
	byte $38
	byte $29
	byte $17
	byte $38
	byte $38
	byte $38
	byte $17
	byte $20
	byte $38
	byte $23
	byte $17
	byte $20
	byte $38
	byte $1b
	byte $17
	byte $20
	byte $38
	byte $0b
	byte $17
	byte $38
	byte $38
	byte $38
	byte $17
	byte $20
	byte $38
	byte $0f
	byte $17
	byte $38
	byte $38
	byte $38
	byte $17
	byte $20
	byte $38
	byte $2a
	byte $00
	byte $38
	byte $38
	byte $38
	byte $00
	byte $28
	byte $38
	byte $25
	byte $00
	byte $28
	byte $38
	byte $1b
	byte $00
	byte $28
	byte $38
	byte $0c
	byte $00
	byte $38
	byte $38
	byte $38
	byte $00
	byte $28
	byte $38
	byte $2e
	byte $00
	byte $38
	byte $38
	byte $38
	byte $00
	byte $28
	byte $38
	byte $38
	byte $2f
	byte $38
	byte $38
	byte $31
	byte $2f
	byte $30
	byte $38
	byte $16
	byte $38
	byte $35
	byte $38
	byte $31
	byte $2f
	byte $30
	byte $38
	byte $03
	byte $2f
	byte $38
	byte $38
	byte $31
	byte $2f
	byte $30
	byte $38
	byte $37
	byte $2f
	byte $36
	byte $38
	byte $38
	byte $2f
	byte $38
	byte $38
	byte $1f
	byte $1d
	byte $1e
	byte $38
	byte $1f
	byte $1d
	byte $1e
	byte $38
	byte $33
	byte $1d
	byte $32
	byte $38
	byte $1f
	byte $1d
	byte $1e
	byte $38
	byte $04
	byte $1d
	byte $38
	byte $38
	byte $1f
	byte $1d
	byte $1e
	byte $38
	byte $10
	byte $1d
	byte $34
	byte $38
	byte $1f
	byte $1d
	byte $1e
	byte $38
	byte $13
	byte $11
	byte $38
	byte $38
	byte $13
	byte $11
	byte $14
	byte $38
	byte $1a
	byte $11
	byte $15
	byte $38
	byte $13
	byte $11
	byte $14
	byte $38
	byte $08
	byte $11
	byte $38
	byte $38
	byte $38
	byte $11
	byte $14
	byte $38
	byte $0e
	byte $11
	byte $38
	byte $38
	byte $38
	byte $11
	byte $14
	byte $38
	byte $12
	byte $2b
	byte $38
	byte $38
	byte $12
	byte $2b
	byte $18
	byte $38
	byte $19
	byte $2b
	byte $21
	byte $38
	byte $12
	byte $2b
	byte $18
	byte $38
	byte $05
	byte $2b
	byte $38
	byte $38
	byte $38
	byte $2b
	byte $18
	byte $38
	byte $2d
	byte $2b
	byte $38
	byte $38
	byte $38
	byte $2b
	byte $18
	byte $38
__g23:
	byte $00
	byte $0a
	byte $0d
	byte $0d
	byte $0d
	byte $03
	byte $03
	byte $0d
	byte $00
	byte $02
	byte $01
	byte $0d
	byte $0d
	byte $06
	byte $06
	byte $0d
	byte $0c
	byte $0b
	byte $0d
	byte $0d
	byte $0d
	byte $04
	byte $04
	byte $0d
	byte $00
	byte $08
	byte $0d
	byte $0d
	byte $0d
	byte $07
	byte $07
	byte $0d
	byte $06
	byte $0a
	byte $0d
	byte $0d
	byte $03
	byte $03
	byte $03
	byte $0d
	byte $00
	byte $02
	byte $01
	byte $0d
	byte $06
	byte $06
	byte $06
	byte $0d
	byte $0c
	byte $0b
	byte $0d
	byte $0d
	byte $0d
	byte $04
	byte $04
	byte $0d
	byte $00
	byte $08
	byte $0d
	byte $0d
	byte $0d
	byte $07
	byte $07
	byte $0d
	byte $00
	byte $0a
	byte $0d
	byte $0d
	byte $0d
	byte $03
	byte $03
	byte $0d
	byte $00
	byte $02
	byte $01
	byte $0d
	byte $06
	byte $06
	byte $06
	byte $0d
	byte $0c
	byte $0b
	byte $0d
	byte $0d
	byte $0d
	byte $04
	byte $04
	byte $0d
	byte $00
	byte $08
	byte $0d
	byte $0d
	byte $0d
	byte $07
	byte $07
	byte $0d
	byte $00
	byte $0a
	byte $0d
	byte $0d
	byte $0d
	byte $03
	byte $03
	byte $0d
	byte $00
	byte $02
	byte $01
	byte $0d
	byte $09
	byte $06
	byte $06
	byte $0d
	byte $0c
	byte $0b
	byte $0d
	byte $0d
	byte $0d
	byte $04
	byte $04
	byte $0d
	byte $00
	byte $08
	byte $0d
	byte $0d
	byte $0d
	byte $07
	byte $07
	byte $0d
	byte $0d
	byte $0a
	byte $0d
	byte $0d
	byte $03
	byte $03
	byte $03
	byte $0d
	byte $00
	byte $0d
	byte $00
	byte $0d
	byte $06
	byte $06
	byte $06
	byte $0d
	byte $0c
	byte $0b
	byte $0d
	byte $0d
	byte $04
	byte $04
	byte $05
	byte $0d
	byte $00
	byte $08
	byte $00
	byte $0d
	byte $0d
	byte $07
	byte $0d
	byte $0d
	byte $02
	byte $0a
	byte $02
	byte $0d
	byte $03
	byte $03
	byte $03
	byte $0d
	byte $00
	byte $02
	byte $00
	byte $0d
	byte $06
	byte $06
	byte $06
	byte $0d
	byte $0c
	byte $0b
	byte $0d
	byte $0d
	byte $04
	byte $04
	byte $05
	byte $0d
	byte $00
	byte $08
	byte $00
	byte $0d
	byte $07
	byte $07
	byte $08
	byte $0d
	byte $02
	byte $0a
	byte $0d
	byte $0d
	byte $03
	byte $03
	byte $03
	byte $0d
	byte $00
	byte $02
	byte $00
	byte $0d
	byte $06
	byte $06
	byte $06
	byte $0d
	byte $0c
	byte $0b
	byte $0d
	byte $0d
	byte $0d
	byte $04
	byte $04
	byte $0d
	byte $00
	byte $08
	byte $0d
	byte $0d
	byte $0d
	byte $07
	byte $07
	byte $0d
	byte $02
	byte $0a
	byte $0d
	byte $0d
	byte $03
	byte $03
	byte $03
	byte $0d
	byte $00
	byte $02
	byte $00
	byte $0d
	byte $06
	byte $06
	byte $06
	byte $0d
	byte $0c
	byte $0b
	byte $0d
	byte $0d
	byte $0d
	byte $04
	byte $04
	byte $0d
	byte $00
	byte $08
	byte $0d
	byte $0d
	byte $0d
	byte $07
	byte $07
	byte $0d
__g24 = NC_BSS+$0000
__g25 = NC_BSS+$2c00
__g26 = NC_BSS+$2c02
__g27 = NC_BSS+$2c04
__g28 = NC_BSS+$2d04
__g29 = NC_BSS+$2d05
__g2a = NC_BSS+$2e05
__g2b = NC_BSS+$2e0a
__g2c = NC_BSS+$2e0c
__g2d = NC_BSS+$2e0e
__g2e = NC_BSS+$2e0f
__g2f = NC_BSS+$350f
__g30 = NC_BSS+$388f
__g31 = NC_BSS+$3f8f
__g32 = NC_BSS+$430f
__g33 = NC_BSS+$468f
__g34 = NC_BSS+$6b0f
__g35 = NC_BSS+$6b11
__g36 = NC_BSS+$6b13
__g37 = NC_BSS+$6b14
__g38 = NC_BSS+$6d94
__g39 = NC_BSS+$7294
__g3a = NC_BSS+$7794
__g3b = NC_BSS+$7c94
__g3c = NC_BSS+$7f14
__g3d:
	byte $00
__g3e:
	byte $01
__g3f:
	byte $02
__g40:
	byte $00
__g41:
	byte $01
__g42:
	byte $02
__g43:
	byte $03
__g44:
	byte $04
__g45:
	byte $00
__g46:
	byte $01
__g47:
	byte $02
__g48 = NC_BSS+$7f16
__g49 = NC_BSS+$7f18
__g4a = NC_BSS+$7f1a
__g4b = NC_BSS+$7f1c
__g4c = NC_BSS+$7f1d
__g4d = NC_BSS+$7f1f
__g4e = NC_BSS+$7f21
__g4f = NC_BSS+$7f22
__g50:
	byte $00
__g51:
	byte $01
__g52:
	byte $02
__g53:
	byte $03
__g54:
	byte $04
__g55 = NC_BSS+$7f23
__v56_00 = NC_BSS+$7f24
__f56:
	lda __v56_00
	ldx #$00
	pha
	txa
	pha
	lda #$61
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0002
	jmp __L0001
__L0002:
	lda __v56_00
	ldx #$00
	pha
	txa
	pha
	lda #$7a
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sle16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0004
	jmp __L0003
__L0004:
	lda __v56_00
	ldx #$00
	pha
	txa
	pha
	lda #$20
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	rts
__L0003:
__L0001:
	lda __v56_00
	ldx #$00
	rts
__v57_00 = NC_BSS+$7f25
__v57_01 = NC_BSS+$7f27
__v57_02 = NC_BSS+$7f28
__v57_03 = NC_BSS+$7f2a
__f57:
__v57_04 = NC_BSS+$7f2b
	lda __v57_01
	ldx #$00
	pha
	txa
	pha
	lda __v57_03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0006
	jmp __L0005
__L0006:
	lda #$00
	ldx #$00
	rts
__L0005:
	lda #$00
	ldx #$00
	sta __v57_04
	lda __v57_00
	sta NC_TMP
	lda __v57_00+1
	sta NC_TMP+1
	lda __v57_02
	sta NC_PTR
	lda __v57_02+1
	sta NC_PTR+1
__L0007:
	ldy __v57_04
	cpy __v57_01
	bcs __L0008
	lda (NC_TMP),y
	cmp (NC_PTR),y
	beq __L0009
	lda #$00
	ldx #$00
	rts
__L0009:
	inc __v57_04
	jmp __L0007
__L0008:
	lda #$01
	ldx #$00
	rts
__v58_00 = NC_BSS+$7f2c
__v58_01 = NC_BSS+$7f2e
__f58:
	lda __v58_00
	ldx __v58_00+1
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	sta __v58_00
	stx __v58_00+1
	lda __v58_01
	ldx #$00
	pha
	txa
	pha
	lda __g46
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L000b
	jmp __L000a
__L000b:
	lda __v58_00
	ldx __v58_00+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	rts
__L000a:
	lda __v58_00
	ldx __v58_00+1
	pha
	txa
	pha
	lda #$08
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	ldy NC_TMP
	beq __L000d
__L000c:
	sta NC_TMP+1
	txa
	lsr
	tax
	lda NC_TMP+1
	ror
	dey
	bne __L000c
__L000d:
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	rts
__v59_00 = NC_BSS+$7f2f
__f59:
	lda __v59_00
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v56_00
	jsr __f56
	ldx #$00
	sta __v59_00
	lda __v59_00
	ldx #$00
	pha
	txa
	pha
	lda #$30
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L000f
	jmp __L000e
__L000f:
	lda __v59_00
	ldx #$00
	pha
	txa
	pha
	lda #$39
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sle16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0011
	jmp __L0010
__L0011:
	lda __v59_00
	ldx #$00
	pha
	txa
	pha
	lda #$30
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	rts
__L0010:
__L000e:
	lda __v59_00
	ldx #$00
	pha
	txa
	pha
	lda #$41
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0013
	jmp __L0012
__L0013:
	lda __v59_00
	ldx #$00
	pha
	txa
	pha
	lda #$46
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sle16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0015
	jmp __L0014
__L0015:
	lda __v59_00
	ldx #$00
	pha
	txa
	pha
	lda #$41
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$0a
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	rts
__L0014:
__L0012:
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__v5a_00 = NC_BSS+$7f30
__v5a_01 = NC_BSS+$7f31
__v5a_02 = NC_BSS+$7f33
__v5a_03 = NC_BSS+$7f35
__v5a_04 = NC_BSS+$7f37
__f5a:
__v5a_05 = NC_BSS+$7f38
	lda __g3c
	ldx __g3c+1
	sta __v5a_05
	stx __v5a_05+1
	lda __v5a_05
	ldx __v5a_05+1
	pha
	txa
	pha
	lda #$80
	ldx #$02
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0017
	jmp __L0016
__L0017:
	lda __g0f
	ldx #$00
	rts
__L0016:
	lda __v5a_05
	ldx __v5a_05+1
	clc
	adc #<__g37
	sta NC_PTR
	txa
	adc #>__g37
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v5a_00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v5a_05
	ldx __v5a_05+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g38
	sta NC_PTR
	txa
	adc #>__g38
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v5a_01
	ldx __v5a_01+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	iny
	lda NC_TMP+1
	sta (NC_PTR),y
	lda __v5a_05
	ldx __v5a_05+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g39
	sta NC_PTR
	txa
	adc #>__g39
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v5a_02
	ldx __v5a_02+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	iny
	lda NC_TMP+1
	sta (NC_PTR),y
	lda __v5a_05
	ldx __v5a_05+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g3a
	sta NC_PTR
	txa
	adc #>__g3a
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v5a_03
	ldx __v5a_03+1
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	iny
	lda NC_TMP+1
	sta (NC_PTR),y
	lda __v5a_05
	ldx __v5a_05+1
	clc
	adc #<__g3b
	sta NC_PTR
	txa
	adc #>__g3b
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v5a_04
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v5a_05
	ldx __v5a_05+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g3c
	stx __g3c+1
	lda __g05
	ldx #$00
	rts
__v5b_00 = NC_BSS+$7f3a
__v5b_01 = NC_BSS+$7f3c
__f5b:
__v5b_02 = NC_BSS+$7f3e
	lda __v5b_00
	ldx __v5b_00+1
	pha
	txa
	pha
	lda __v5b_01
	ldx __v5b_01+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	sta __v5b_02
	stx __v5b_02+1
	lda __v5b_02
	ldx __v5b_02+1
	pha
	txa
	pha
	lda #$7f
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ule16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0019
	jmp __L0018
__L0019:
	lda __v5b_02
	ldx __v5b_02+1
	rts
__L0018:
	lda __v5b_02
	ldx __v5b_02+1
	pha
	txa
	pha
	lda #$80
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_uge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L001b
	jmp __L001a
__L001b:
	lda __v5b_02
	ldx __v5b_02+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	rts
__L001a:
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__f5c:
__L001c:
	lda __g3c
	ldx __g3c+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sgt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L001e
	jmp __L001d
__L001e:
	lda __g3c
	ldx __g3c+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc #<__g37
	sta NC_PTR
	txa
	adc #>__g37
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __g50
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0020
	jmp __L001f
__L0020:
	lda __g05
	ldx #$00
	rts
__L001f:
	lda __g3c
	ldx __g3c+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __g3c
	stx __g3c+1
	jmp __L001c
__L001d:
	lda __g05
	ldx #$00
	rts
__v5d_00 = NC_BSS+$7f40
__f5d:
__v5d_01 = NC_BSS+$7f42
__v5d_02 = NC_BSS+$7f44
__v5d_03 = NC_BSS+$7f45
__v5d_04 = NC_BSS+$7f47
__v5d_05 = NC_BSS+$7f49
	lda #$00
	ldx #$00
	sta __v5d_01
	stx __v5d_01+1
__L0021:
	lda __v5d_01
	ldx __v5d_01+1
	pha
	txa
	pha
	lda __g3c
	ldx __g3c+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0023
	jmp __L0022
__L0023:
	lda __v5d_01
	ldx __v5d_01+1
	clc
	adc #<__g37
	sta NC_PTR
	txa
	adc #>__g37
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	sta __v5d_02
	lda __v5d_02
	ldx #$00
	pha
	txa
	pha
	lda __g50
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0025
	jmp __L0024
__L0025:
	lda __v5d_01
	ldx __v5d_01+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g39
	sta NC_PTR
	txa
	adc #>__g39
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	sta NC_TMP
	iny
	lda (NC_PTR),y
	tax
	lda NC_TMP
	pha
	txa
	pha
	lda __v5d_00
	ldx __v5d_00+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0027
	jmp __L0026
__L0027:
	lda __v5d_00
	ldx __v5d_00+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g30
	sta NC_PTR
	txa
	adc #>__g30
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	sta NC_TMP
	iny
	lda (NC_PTR),y
	tax
	lda NC_TMP
	pha
	txa
	pha
	lda __v5d_01
	ldx __v5d_01+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g3a
	sta NC_PTR
	txa
	adc #>__g3a
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	sta NC_TMP
	iny
	lda (NC_PTR),y
	tax
	lda NC_TMP
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	sta __v5d_03
	stx __v5d_03+1
	lda __v5d_01
	ldx __v5d_01+1
	clc
	adc #<__g3b
	sta NC_PTR
	txa
	adc #>__g3b
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __g45
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0029
	jmp __L0028
__L0029:
	lda __v5d_03
	ldx __v5d_03+1
	pha
	txa
	pha
	lda __v5d_01
	ldx __v5d_01+1
	clc
	adc #<__g3b
	sta NC_PTR
	txa
	adc #>__g3b
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v58_01
	pla
	sta __v58_00+1
	pla
	sta __v58_00
	jsr __f58
	ldx #$00
	sta __v5d_03
	stx __v5d_03+1
__L0028:
	lda __v5d_01
	ldx __v5d_01+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g38
	sta NC_PTR
	txa
	adc #>__g38
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	sta NC_TMP
	iny
	lda (NC_PTR),y
	tax
	lda NC_TMP
	pha
	txa
	pha
	pla
	tax
	pla
	sta __v5d_04
	stx __v5d_04+1
	lda __v5d_02
	ldx #$00
	pha
	txa
	pha
	lda __g52
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L002b
	jmp __L002a
__L002b:
	lda __v5d_04
	ldx __v5d_04+1
	clc
	adc #<__g24
	sta NC_PTR
	txa
	adc #>__g24
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v5d_03
	ldx __v5d_03+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v5d_04
	ldx __v5d_04+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	clc
	adc #<__g24
	sta NC_PTR
	txa
	adc #>__g24
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v5d_03
	ldx __v5d_03+1
	pha
	txa
	pha
	lda #$08
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	ldy NC_TMP
	beq __L002d
__L002c:
	sta NC_TMP+1
	txa
	lsr
	tax
	lda NC_TMP+1
	ror
	dey
	bne __L002c
__L002d:
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	jmp __L002e
__L002a:
	lda __v5d_02
	ldx #$00
	pha
	txa
	pha
	lda __g53
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0030
	jmp __L002f
__L0030:
	lda __v5d_03
	ldx __v5d_03+1
	pha
	txa
	pha
	lda __g26
	ldx __g26+1
	pha
	txa
	pha
	lda __v5d_04
	ldx __v5d_04+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta __v5b_01+1
	pla
	sta __v5b_01
	pla
	sta __v5b_00+1
	pla
	sta __v5b_00
	jsr __f5b
	sta __v5d_05
	stx __v5d_05+1
	lda __v5d_05
	ldx __v5d_05+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0032
	jmp __L0031
__L0032:
	lda __g0c
	ldx #$00
	rts
__L0031:
	lda __v5d_04
	ldx __v5d_04+1
	clc
	adc #<__g24
	sta NC_PTR
	txa
	adc #>__g24
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v5d_05
	ldx __v5d_05+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	jmp __L0033
__L002f:
	lda __v5d_03
	ldx __v5d_03+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ugt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0035
	jmp __L0034
__L0035:
	lda __v5d_02
	ldx #$00
	pha
	txa
	pha
	lda __g54
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0037
	jmp __L0036
__L0037:
	lda __g0d
	ldx #$00
	rts
__L0036:
	lda __g0c
	ldx #$00
	rts
__L0034:
	lda __v5d_04
	ldx __v5d_04+1
	clc
	adc #<__g24
	sta NC_PTR
	txa
	adc #>__g24
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v5d_03
	ldx __v5d_03+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
__L0033:
__L002e:
	lda __v5d_01
	ldx __v5d_01+1
	clc
	adc #<__g37
	sta NC_PTR
	txa
	adc #>__g37
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __g50
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
__L0026:
__L0024:
	lda __v5d_01
	ldx __v5d_01+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v5d_01
	stx __v5d_01+1
	jmp __L0021
__L0022:
	jsr __f5c
	ldx #$00
	rts
__v5e_00 = NC_BSS+$7f4b
__v5e_01 = NC_BSS+$7f4d
__f5e:
	lda __v5e_01
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0039
	jmp __L0038
__L0039:
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L0038:
	lda #$00
	ldx #$00
	clc
	adc __v5e_00
	sta NC_PTR
	txa
	adc __v5e_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2e
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L003b
	jmp __L003a
__L003b:
	lda __g36
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L003d
	jmp __L003c
__L003d:
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L003c:
	lda __g36
	ldx #$00
	rts
__L003a:
	lda #$00
	ldx #$00
	rts
__v5f_00 = NC_BSS+$7f4e
__v5f_01 = NC_BSS+$7f50
__f5f:
__v5f_02 = NC_BSS+$7f51
__v5f_03 = NC_BSS+$7f53
__v5f_04 = NC_BSS+$7f55
__v5f_05 = NC_BSS+$7f56
__v5f_06 = NC_BSS+$7f58
	lda __v5f_00
	ldx __v5f_00+1
	pha
	txa
	pha
	lda __v5f_01
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v5e_01
	pla
	sta __v5e_00+1
	pla
	sta __v5e_00
	jsr __f5e
	sta __v5f_02
	stx __v5f_02+1
	lda __v5f_02
	ldx __v5f_02+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L003f
	jmp __L003e
__L003f:
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L003e:
	lda #$00
	ldx #$00
	sta __v5f_03
	stx __v5f_03+1
__L0040:
	lda __v5f_03
	ldx __v5f_03+1
	pha
	txa
	pha
	lda __g34
	ldx __g34+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0042
	jmp __L0041
__L0042:
	lda __v5f_03
	ldx __v5f_03+1
	clc
	adc #<__g31
	sta NC_PTR
	txa
	adc #>__g31
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __v5f_02
	ldx __v5f_02+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0044
	jmp __L0043
__L0044:
	lda __v5f_03
	ldx __v5f_03+1
	clc
	adc #<__g2f
	sta NC_PTR
	txa
	adc #>__g2f
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __v5f_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0046
	jmp __L0045
__L0046:
	lda __v5f_03
	ldx __v5f_03+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g2e
	sta NC_PTR
	txa
	adc #>__g2e
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	sta NC_TMP
	iny
	lda (NC_PTR),y
	tax
	lda NC_TMP
	pha
	txa
	pha
	pla
	tax
	pla
	sta __v5f_05
	stx __v5f_05+1
	lda #$01
	ldx #$00
	sta __v5f_06
	lda #$00
	ldx #$00
	sta __v5f_04
__L0047:
	lda __v5f_04
	ldx #$00
	pha
	txa
	pha
	lda __v5f_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0049
	jmp __L0048
__L0049:
	lda __v5f_05
	ldx __v5f_05+1
	pha
	txa
	pha
	lda __v5f_04
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	clc
	adc #<__g33
	sta NC_PTR
	txa
	adc #>__g33
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __v5f_04
	ldx #$00
	tay
	lda __v5f_00
	sta NC_PTR
	lda __v5f_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L004b
	jmp __L004a
__L004b:
	lda #$00
	ldx #$00
	sta __v5f_06
__L004a:
	lda __v5f_04
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v5f_04
	jmp __L0047
__L0048:
	lda __v5f_06
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L004d
	jmp __L004c
__L004d:
	lda __v5f_03
	ldx __v5f_03+1
	rts
__L004c:
__L0045:
__L0043:
	lda __v5f_03
	ldx __v5f_03+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v5f_03
	stx __v5f_03+1
	jmp __L0040
__L0041:
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__v60_00 = NC_BSS+$7f59
__v60_01 = NC_BSS+$7f5b
__v60_02 = NC_BSS+$7f5c
__v60_03 = NC_BSS+$7f5d
__f60:
__v60_04 = NC_BSS+$7f5f
__v60_05 = NC_BSS+$7f61
__v60_06 = NC_BSS+$7f63
	lda __v60_00
	ldx __v60_00+1
	pha
	txa
	pha
	lda __v60_01
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v5e_01
	pla
	sta __v5e_00+1
	pla
	sta __v5e_00
	jsr __f5e
	sta __v60_04
	stx __v60_04+1
	lda __v60_04
	ldx __v60_04+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L004f
	jmp __L004e
__L004f:
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L004e:
	lda __g34
	ldx __g34+1
	pha
	txa
	pha
	lda #$80
	ldx #$03
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0051
	jmp __L0050
__L0051:
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L0050:
	lda __g35
	ldx __g35+1
	pha
	txa
	pha
	lda __v60_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$80
	ldx #$24
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sgt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0053
	jmp __L0052
__L0053:
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L0052:
	lda __g34
	ldx __g34+1
	sta __v60_05
	stx __v60_05+1
	lda __v60_05
	ldx __v60_05+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g2e
	sta NC_PTR
	txa
	adc #>__g2e
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __g35
	ldx __g35+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	iny
	lda NC_TMP+1
	sta (NC_PTR),y
	lda __v60_05
	ldx __v60_05+1
	clc
	adc #<__g2f
	sta NC_PTR
	txa
	adc #>__g2f
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v60_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v60_05
	ldx __v60_05+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g30
	sta NC_PTR
	txa
	adc #>__g30
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v60_03
	ldx __v60_03+1
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	iny
	lda NC_TMP+1
	sta (NC_PTR),y
	lda __v60_05
	ldx __v60_05+1
	clc
	adc #<__g31
	sta NC_PTR
	txa
	adc #>__g31
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v60_04
	ldx __v60_04+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v60_05
	ldx __v60_05+1
	clc
	adc #<__g32
	sta NC_PTR
	txa
	adc #>__g32
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v60_02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda #$00
	ldx #$00
	sta __v60_06
__L0054:
	ldy __v60_06
	cpy __v60_01
	bcc __L0056
	jmp __L0055
__L0056:
	lda __g35
	ldx __g35+1
	pha
	txa
	pha
	lda __v60_06
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	clc
	adc #<__g33
	sta NC_PTR
	txa
	adc #>__g33
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v60_06
	ldx #$00
	tay
	lda __v60_00
	sta NC_PTR
	lda __v60_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v60_06
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v60_06
	jmp __L0054
__L0055:
	lda __g35
	ldx __g35+1
	pha
	txa
	pha
	lda __v60_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g35
	stx __g35+1
	lda __v60_05
	ldx __v60_05+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g34
	stx __g34+1
	lda __v60_05
	ldx __v60_05+1
	rts
__v61_00 = NC_BSS+$7f64
__v61_01 = NC_BSS+$7f66
__f61:
__v61_02 = NC_BSS+$7f67
	lda __v61_00
	ldx __v61_00+1
	pha
	txa
	pha
	lda __v61_01
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v5f_01
	pla
	sta __v5f_00+1
	pla
	sta __v5f_00
	jsr __f5f
	sta __v61_02
	stx __v61_02+1
	lda __v61_02
	ldx __v61_02+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0058
	jmp __L0057
__L0058:
	lda __v61_02
	ldx __v61_02+1
	clc
	adc #<__g32
	sta NC_PTR
	txa
	adc #>__g32
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __g3d
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L005a
	jmp __L0059
__L005a:
	lda #$04
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L0059:
	lda __v61_02
	ldx __v61_02+1
	rts
__L0057:
	lda __v61_02
	ldx __v61_02+1
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L005c
	jmp __L005b
__L005c:
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L005b:
	lda __v61_00
	ldx __v61_00+1
	pha
	txa
	pha
	lda __v61_01
	ldx #$00
	pha
	txa
	pha
	lda __g3e
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta __v60_03+1
	pla
	sta __v60_03
	pla
	pla
	sta __v60_02
	pla
	pla
	sta __v60_01
	pla
	sta __v60_00+1
	pla
	sta __v60_00
	jsr __f60
	rts
__v62_00 = NC_BSS+$7f69
__v62_01 = NC_BSS+$7f6b
__v62_02 = NC_BSS+$7f6c
__f62:
__v62_03 = NC_BSS+$7f6e
	lda __v62_00
	ldx __v62_00+1
	pha
	txa
	pha
	lda __v62_01
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v5f_01
	pla
	sta __v5f_00+1
	pla
	sta __v5f_00
	jsr __f5f
	sta __v62_03
	stx __v62_03+1
	lda __v62_03
	ldx __v62_03+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L005e
	jmp __L005d
__L005e:
	lda __g07
	ldx #$00
	rts
__L005d:
	lda __v62_03
	ldx __v62_03+1
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0060
	jmp __L005f
__L0060:
	lda __g09
	ldx #$00
	rts
__L005f:
	lda __v62_00
	ldx __v62_00+1
	pha
	txa
	pha
	lda __v62_01
	ldx #$00
	pha
	txa
	pha
	lda __g3d
	ldx #$00
	pha
	txa
	pha
	lda __v62_02
	ldx __v62_02+1
	pha
	txa
	pha
	pla
	sta __v60_03+1
	pla
	sta __v60_03
	pla
	pla
	sta __v60_02
	pla
	pla
	sta __v60_01
	pla
	sta __v60_00+1
	pla
	sta __v60_00
	jsr __f60
	sta __v62_03
	stx __v62_03+1
	lda __v62_03
	ldx __v62_03+1
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0062
	jmp __L0061
__L0062:
	lda __g09
	ldx #$00
	rts
__L0061:
	lda __v62_03
	ldx __v62_03+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0064
	jmp __L0063
__L0064:
	lda __g08
	ldx #$00
	rts
__L0063:
	lda __g05
	ldx #$00
	rts
__v63_00 = NC_BSS+$7f70
__v63_01 = NC_BSS+$7f72
__f63:
__v63_02 = NC_BSS+$7f74
__v63_03 = NC_BSS+$7f76
__L0065:
	lda __v63_00
	ldx __v63_00+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0067
	jmp __L0066
__L0067:
	lda __v63_00
	ldx __v63_00+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __v63_02
	stx __v63_02+1
	lda __v63_02
	ldx __v63_02+1
	clc
	adc #<__g24
	sta NC_PTR
	txa
	adc #>__g24
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __v63_02
	ldx __v63_02+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	clc
	adc #<__g24
	sta NC_PTR
	txa
	adc #>__g24
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$08
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	ldy NC_TMP
	beq __L0069
__L0068:
	asl
	sta NC_TMP+1
	txa
	rol
	tax
	lda NC_TMP+1
	dey
	bne __L0068
__L0069:
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	ora NC_TMP
	tay
	txa
	ora NC_TMP+1
	tax
	tya
	sta __v63_03
	stx __v63_03+1
	lda __v63_02
	ldx __v63_02+1
	clc
	adc #<__g24
	sta NC_PTR
	txa
	adc #>__g24
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v63_01
	ldx __v63_01+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v63_02
	ldx __v63_02+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	clc
	adc #<__g24
	sta NC_PTR
	txa
	adc #>__g24
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v63_01
	ldx __v63_01+1
	pha
	txa
	pha
	lda #$08
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	ldy NC_TMP
	beq __L006b
__L006a:
	sta NC_TMP+1
	txa
	lsr
	tax
	lda NC_TMP+1
	ror
	dey
	bne __L006a
__L006b:
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v63_03
	ldx __v63_03+1
	sta __v63_00
	stx __v63_00+1
	jmp __L0065
__L0066:
	lda __g05
	ldx #$00
	rts
__v64_00 = NC_BSS+$7f78
__v64_01 = NC_BSS+$7f7a
__v64_02 = NC_BSS+$7f7b
__f64:
__v64_03 = NC_BSS+$7f7d
__v64_04 = NC_BSS+$7f7f
__v64_05 = NC_BSS+$7f81
	lda __v64_00
	ldx __v64_00+1
	pha
	txa
	pha
	lda __v64_01
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v5f_01
	pla
	sta __v5f_00+1
	pla
	sta __v5f_00
	jsr __f5f
	sta __v64_03
	stx __v64_03+1
	lda __v64_03
	ldx __v64_03+1
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L006d
	jmp __L006c
__L006d:
	lda __g09
	ldx #$00
	rts
__L006c:
	lda __v64_03
	ldx __v64_03+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L006f
	jmp __L006e
__L006f:
	lda __v64_00
	ldx __v64_00+1
	pha
	txa
	pha
	lda __v64_01
	ldx #$00
	pha
	txa
	pha
	lda __g3f
	ldx #$00
	pha
	txa
	pha
	lda __v64_02
	ldx __v64_02+1
	pha
	txa
	pha
	pla
	sta __v60_03+1
	pla
	sta __v60_03
	pla
	pla
	sta __v60_02
	pla
	pla
	sta __v60_01
	pla
	sta __v60_00+1
	pla
	sta __v60_00
	jsr __f60
	sta __v64_03
	stx __v64_03+1
	lda __v64_03
	ldx __v64_03+1
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0071
	jmp __L0070
__L0071:
	lda __g09
	ldx #$00
	rts
__L0070:
	lda __v64_03
	ldx __v64_03+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0073
	jmp __L0072
__L0073:
	lda __g08
	ldx #$00
	rts
__L0072:
	lda __g05
	ldx #$00
	rts
__L006e:
	lda __v64_03
	ldx __v64_03+1
	clc
	adc #<__g32
	sta NC_PTR
	txa
	adc #>__g32
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __g3e
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0075
	jmp __L0074
__L0075:
	lda __g07
	ldx #$00
	rts
__L0074:
	lda __v64_03
	ldx __v64_03+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g30
	sta NC_PTR
	txa
	adc #>__g30
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	sta NC_TMP
	iny
	lda (NC_PTR),y
	tax
	lda NC_TMP
	pha
	txa
	pha
	pla
	tax
	pla
	sta __v64_04
	stx __v64_04+1
	lda __v64_03
	ldx __v64_03+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g30
	sta NC_PTR
	txa
	adc #>__g30
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v64_02
	ldx __v64_02+1
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	iny
	lda NC_TMP+1
	sta (NC_PTR),y
	lda __v64_03
	ldx __v64_03+1
	clc
	adc #<__g32
	sta NC_PTR
	txa
	adc #>__g32
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __g3f
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v64_04
	ldx __v64_04+1
	pha
	txa
	pha
	lda __v64_02
	ldx __v64_02+1
	pha
	txa
	pha
	pla
	sta __v63_01+1
	pla
	sta __v63_01
	pla
	sta __v63_00+1
	pla
	sta __v63_00
	jsr __f63
	ldx #$00
	sta __v64_05
	lda __v64_05
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0077
	jmp __L0076
__L0077:
	lda __v64_05
	ldx #$00
	rts
__L0076:
	lda __v64_03
	ldx __v64_03+1
	pha
	txa
	pha
	pla
	sta __v5d_00+1
	pla
	sta __v5d_00
	jsr __f5d
	ldx #$00
	rts
__v65_00 = NC_BSS+$7f82
__v65_01 = NC_BSS+$7f84
__f65:
__v65_02 = NC_BSS+$7f85
__v65_03 = NC_BSS+$7f86
__v65_04 = NC_BSS+$7f88
__v65_05 = NC_BSS+$7f8a
	lda #$00
	ldx #$00
	sta __g4e
	lda __v65_01
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0079
	jmp __L0078
__L0079:
	lda __g42
	ldx #$00
	rts
__L0078:
	lda #$00
	ldx #$00
	clc
	adc __v65_00
	sta NC_PTR
	txa
	adc __v65_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$24
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L007b
	jmp __L007a
__L007b:
	lda #$01
	ldx #$00
	sta __v65_02
	lda #$00
	ldx #$00
	sta __v65_04
	stx __v65_04+1
__L007c:
	ldy __v65_02
	cpy __v65_01
	bcc __L007e
	jmp __L007d
__L007e:
	lda __v65_02
	ldx #$00
	tay
	lda __v65_00
	sta NC_PTR
	lda __v65_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2b
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0080
	jmp __L007f
__L0080:
	jmp __L007d
	jmp __L0081
__L007f:
	lda __v65_02
	ldx #$00
	tay
	lda __v65_00
	sta NC_PTR
	lda __v65_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2d
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0083
	jmp __L0082
__L0083:
	jmp __L007d
	jmp __L0084
__L0082:
	lda __v65_02
	ldx #$00
	tay
	lda __v65_00
	sta NC_PTR
	lda __v65_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v59_00
	jsr __f59
	sta __v65_03
	stx __v65_03+1
	lda __v65_03
	ldx __v65_03+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0086
	jmp __L0085
__L0086:
	lda __g42
	ldx #$00
	rts
__L0085:
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	lda #$04
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0088
	jmp __L0087
__L0088:
	lda __g42
	ldx #$00
	rts
__L0087:
	lda __v65_04
	ldx __v65_04+1
	pha
	txa
	pha
	lda #$04
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	ldy NC_TMP
	beq __L008a
__L0089:
	asl
	sta NC_TMP+1
	txa
	rol
	tax
	lda NC_TMP+1
	dey
	bne __L0089
__L008a:
	pha
	txa
	pha
	lda __v65_03
	ldx __v65_03+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	ora NC_TMP
	tay
	txa
	ora NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	sta __v65_04
	stx __v65_04+1
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g4e
	lda __v65_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v65_02
__L0084:
__L0081:
	jmp __L007c
__L007d:
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L008c
	jmp __L008b
__L008c:
	lda __g42
	ldx #$00
	rts
__L008b:
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g4e
	lda __v65_04
	ldx __v65_04+1
	sta __g4c
	stx __g4c+1
	lda #$00
	ldx #$00
	sta __g4f
	lda __g40
	ldx #$00
	rts
__L007a:
	lda #$00
	ldx #$00
	clc
	adc __v65_00
	sta NC_PTR
	txa
	adc __v65_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$27
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L008e
	jmp __L008d
__L008e:
	lda __v65_01
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0090
	jmp __L008f
__L0090:
	lda __g42
	ldx #$00
	rts
__L008f:
	lda #$02
	ldx #$00
	clc
	adc __v65_00
	sta NC_PTR
	txa
	adc __v65_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$27
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0092
	jmp __L0091
__L0092:
	lda __g42
	ldx #$00
	rts
__L0091:
	lda #$01
	ldx #$00
	clc
	adc __v65_00
	sta NC_PTR
	txa
	adc __v65_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	sta __g4c
	stx __g4c+1
	lda #$03
	ldx #$00
	sta __g4e
	lda #$00
	ldx #$00
	sta __g4f
	lda __g40
	ldx #$00
	rts
__L008d:
	lda #$00
	ldx #$00
	clc
	adc __v65_00
	sta NC_PTR
	txa
	adc __v65_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$30
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0094
	jmp __L0093
__L0094:
	lda #$00
	ldx #$00
	clc
	adc __v65_00
	sta NC_PTR
	txa
	adc __v65_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$39
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sle16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0096
	jmp __L0095
__L0096:
	lda #$00
	ldx #$00
	sta __v65_02
	lda #$00
	ldx #$00
	sta __v65_04
	stx __v65_04+1
__L0097:
	ldy __v65_02
	cpy __v65_01
	bcc __L0099
	jmp __L0098
__L0099:
	lda __v65_02
	ldx #$00
	tay
	lda __v65_00
	sta NC_PTR
	lda __v65_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2b
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L009b
	jmp __L009a
__L009b:
	jmp __L0098
	jmp __L009c
__L009a:
	lda __v65_02
	ldx #$00
	tay
	lda __v65_00
	sta NC_PTR
	lda __v65_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2d
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L009e
	jmp __L009d
__L009e:
	jmp __L0098
	jmp __L009f
__L009d:
	lda __v65_02
	ldx #$00
	tay
	lda __v65_00
	sta NC_PTR
	lda __v65_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$30
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00a1
	jmp __L00a0
__L00a1:
	lda __g42
	ldx #$00
	rts
__L00a0:
	lda __v65_02
	ldx #$00
	tay
	lda __v65_00
	sta NC_PTR
	lda __v65_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$39
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sgt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00a3
	jmp __L00a2
__L00a3:
	lda __g42
	ldx #$00
	rts
__L00a2:
	lda __v65_04
	ldx __v65_04+1
	pha
	txa
	pha
	lda #$0a
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_mul16
	pha
	txa
	pha
	lda __v65_02
	ldx #$00
	tay
	lda __v65_00
	sta NC_PTR
	lda __v65_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$30
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	sta __v65_04
	stx __v65_04+1
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g4e
	lda __v65_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v65_02
__L009f:
__L009c:
	jmp __L0097
__L0098:
	lda __v65_04
	ldx __v65_04+1
	sta __g4c
	stx __g4c+1
	lda #$00
	ldx #$00
	sta __g4f
	lda __g40
	ldx #$00
	rts
__L0095:
__L0093:
	lda #$00
	ldx #$00
	sta __v65_02
__L00a4:
	ldy __v65_02
	cpy __v65_01
	bcc __L00a6
	jmp __L00a5
__L00a6:
	lda __v65_02
	ldx #$00
	tay
	lda __v65_00
	sta NC_PTR
	lda __v65_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2b
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00a8
	jmp __L00a7
__L00a8:
	jmp __L00a5
	jmp __L00a9
__L00a7:
	lda __v65_02
	ldx #$00
	tay
	lda __v65_00
	sta NC_PTR
	lda __v65_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2d
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00ab
	jmp __L00aa
__L00ab:
	jmp __L00a5
	jmp __L00ac
__L00aa:
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g4e
	lda __v65_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v65_02
__L00ac:
__L00a9:
	jmp __L00a4
__L00a5:
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00ae
	jmp __L00ad
__L00ae:
	lda __g42
	ldx #$00
	rts
__L00ad:
	lda __v65_00
	ldx __v65_00+1
	pha
	txa
	pha
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v5f_01
	pla
	sta __v5f_00+1
	pla
	sta __v5f_00
	jsr __f5f
	sta __v65_05
	stx __v65_05+1
	lda __v65_05
	ldx __v65_05+1
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00b0
	jmp __L00af
__L00b0:
	lda __g44
	ldx #$00
	rts
__L00af:
	lda __v65_05
	ldx __v65_05+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00b2
	jmp __L00b1
__L00b2:
	lda __v65_00
	ldx __v65_00+1
	pha
	txa
	pha
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v61_01
	pla
	sta __v61_00+1
	pla
	sta __v61_00
	jsr __f61
	sta __v65_05
	stx __v65_05+1
	lda __v65_05
	ldx __v65_05+1
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00b4
	jmp __L00b3
__L00b4:
	lda __g44
	ldx #$00
	rts
__L00b3:
	lda __v65_05
	ldx __v65_05+1
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00b6
	jmp __L00b5
__L00b6:
	lda __g43
	ldx #$00
	rts
__L00b5:
	lda __v65_05
	ldx __v65_05+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00b8
	jmp __L00b7
__L00b8:
	lda __g42
	ldx #$00
	rts
__L00b7:
__L00b1:
	lda __v65_05
	ldx __v65_05+1
	clc
	adc #<__g32
	sta NC_PTR
	txa
	adc #>__g32
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __g3e
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00ba
	jmp __L00b9
__L00ba:
	lda __v65_05
	ldx __v65_05+1
	sta __g4d
	stx __g4d+1
	lda #$01
	ldx #$00
	sta __g4f
	lda __g41
	ldx #$00
	rts
__L00b9:
	lda __v65_05
	ldx __v65_05+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g30
	sta NC_PTR
	txa
	adc #>__g30
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	sta NC_TMP
	iny
	lda (NC_PTR),y
	tax
	lda NC_TMP
	pha
	txa
	pha
	pla
	tax
	pla
	sta __g4c
	stx __g4c+1
	lda #$00
	ldx #$00
	sta __g4f
	lda __g40
	ldx #$00
	rts
__v66_00 = NC_BSS+$7f8c
__v66_01 = NC_BSS+$7f8e
__f66:
__v66_02 = NC_BSS+$7f8f
__v66_03 = NC_BSS+$7f90
__v66_04 = NC_BSS+$7f91
__v66_05 = NC_BSS+$7f92
__v66_06 = NC_BSS+$7f94
__v66_07 = NC_BSS+$7f96
__v66_08 = NC_BSS+$7f97
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	sta __g49
	stx __g49+1
	lda #$00
	ldx #$00
	sta __g4a
	stx __g4a+1
	lda __g45
	ldx #$00
	sta __g4b
	lda __v66_01
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00bc
	jmp __L00bb
__L00bc:
	lda __g42
	ldx #$00
	rts
__L00bb:
	lda #$00
	ldx #$00
	sta __v66_02
	lda __v66_02
	ldx #$00
	tay
	lda __v66_00
	sta NC_PTR
	lda __v66_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$3c
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00be
	jmp __L00bd
__L00be:
	lda __g46
	ldx #$00
	sta __g4b
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v66_02
	jmp __L00bf
__L00bd:
	lda __v66_02
	ldx #$00
	tay
	lda __v66_00
	sta NC_PTR
	lda __v66_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$3e
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00c1
	jmp __L00c0
__L00c1:
	lda __g47
	ldx #$00
	sta __g4b
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v66_02
__L00c0:
__L00bf:
	lda __v66_00
	ldx __v66_00+1
	pha
	txa
	pha
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v66_01
	ldx #$00
	pha
	txa
	pha
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	pla
	sta __v65_01
	pla
	sta __v65_00+1
	pla
	sta __v65_00
	jsr __f65
	ldx #$00
	sta __v66_03
	lda __v66_03
	ldx #$00
	pha
	txa
	pha
	lda __g40
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00c3
	jmp __L00c2
__L00c3:
	lda __v66_03
	ldx #$00
	pha
	txa
	pha
	lda __g41
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00c5
	jmp __L00c4
__L00c5:
	lda __v66_03
	ldx #$00
	rts
__L00c4:
__L00c2:
	lda __g4f
	ldx #$00
	sta __v66_04
	lda __g4c
	ldx __g4c+1
	sta __v66_05
	stx __v66_05+1
	lda __g4d
	ldx __g4d+1
	sta __v66_06
	stx __v66_06+1
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v66_02
	lda __v66_04
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00c7
	jmp __L00c6
__L00c7:
	lda __v66_05
	ldx __v66_05+1
	sta __g4a
	stx __g4a+1
	jmp __L00c8
__L00c6:
	lda __v66_06
	ldx __v66_06+1
	sta __g49
	stx __g49+1
	lda #$00
	ldx #$00
	sta __g4a
	stx __g4a+1
__L00c8:
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	lda __v66_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00ca
	jmp __L00c9
__L00ca:
	lda __v66_02
	ldx #$00
	tay
	lda __v66_00
	sta NC_PTR
	lda __v66_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	sta __v66_07
	lda __v66_07
	ldx #$00
	pha
	txa
	pha
	lda #$2b
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00cc
	jmp __L00cb
__L00cc:
	lda __v66_07
	ldx #$00
	pha
	txa
	pha
	lda #$2d
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00ce
	jmp __L00cd
__L00ce:
	lda __g42
	ldx #$00
	rts
__L00cd:
__L00cb:
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v66_02
	lda __v66_00
	ldx __v66_00+1
	pha
	txa
	pha
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v66_01
	ldx #$00
	pha
	txa
	pha
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	pla
	sta __v65_01
	pla
	sta __v65_00+1
	pla
	sta __v65_00
	jsr __f65
	ldx #$00
	sta __v66_03
	lda __v66_03
	ldx #$00
	pha
	txa
	pha
	lda __g40
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00d0
	jmp __L00cf
__L00d0:
	lda __v66_03
	ldx #$00
	pha
	txa
	pha
	lda __g41
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00d2
	jmp __L00d1
__L00d2:
	lda __v66_03
	ldx #$00
	rts
__L00d1:
__L00cf:
	lda __g4f
	ldx #$00
	sta __v66_08
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	lda __g4e
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v66_02
	lda __v66_02
	ldx #$00
	pha
	txa
	pha
	lda __v66_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00d4
	jmp __L00d3
__L00d4:
	lda __g42
	ldx #$00
	rts
__L00d3:
	lda __v66_08
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00d6
	jmp __L00d5
__L00d6:
	lda __v66_07
	ldx #$00
	pha
	txa
	pha
	lda #$2b
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00d8
	jmp __L00d7
__L00d8:
	lda __g4a
	ldx __g4a+1
	pha
	txa
	pha
	lda __g4c
	ldx __g4c+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	sta __g4a
	stx __g4a+1
	jmp __L00d9
__L00d7:
	lda __g4a
	ldx __g4a+1
	pha
	txa
	pha
	lda __g4c
	ldx __g4c+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	sta __g4a
	stx __g4a+1
__L00d9:
	jmp __L00da
__L00d5:
	lda __g49
	ldx __g49+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00dc
	jmp __L00db
__L00dc:
	lda __g42
	ldx #$00
	rts
__L00db:
	lda __v66_07
	ldx #$00
	pha
	txa
	pha
	lda #$2b
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00de
	jmp __L00dd
__L00de:
	lda __g42
	ldx #$00
	rts
__L00dd:
	lda __g4d
	ldx __g4d+1
	sta __g49
	stx __g49+1
__L00da:
__L00c9:
	lda __g49
	ldx __g49+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00e0
	jmp __L00df
__L00e0:
	lda __g41
	ldx #$00
	rts
__L00df:
	lda __g4a
	ldx __g4a+1
	sta __g48
	stx __g48+1
	lda __g4b
	ldx #$00
	pha
	txa
	pha
	lda __g45
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00e2
	jmp __L00e1
__L00e2:
	lda __g4a
	ldx __g4a+1
	pha
	txa
	pha
	lda __g4b
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v58_01
	pla
	sta __v58_00+1
	pla
	sta __v58_00
	jsr __f58
	ldx #$00
	sta __g48
	stx __g48+1
__L00e1:
	lda __g40
	ldx #$00
	rts
__v67_00 = NC_BSS+$7f98
__v67_01 = NC_BSS+$7f9a
__f67:
__v67_02 = NC_BSS+$7f9b
__v67_03 = NC_BSS+$7f9c
	lda __v67_01
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00e4
	jmp __L00e3
__L00e4:
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L00e3:
	lda #$00
	ldx #$00
	sta __v67_02
__L00e5:
	lda __v67_02
	ldx #$00
	pha
	txa
	pha
	lda #$38
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00e7
	jmp __L00e6
__L00e7:
	lda __v67_02
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_mul16
	sta __v67_03
	lda #$00
	ldx #$00
	clc
	adc __v67_00
	sta NC_PTR
	txa
	adc __v67_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v56_00
	jsr __f56
	ldx #$00
	pha
	txa
	pha
	lda __v67_03
	ldx #$00
	tay
	lda __g21,y
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00e9
	jmp __L00e8
__L00e9:
	lda #$01
	ldx #$00
	clc
	adc __v67_00
	sta NC_PTR
	txa
	adc __v67_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v56_00
	jsr __f56
	ldx #$00
	pha
	txa
	pha
	lda __v67_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	clc
	adc #<__g21
	sta NC_PTR
	txa
	adc #>__g21
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00eb
	jmp __L00ea
__L00eb:
	lda #$02
	ldx #$00
	clc
	adc __v67_00
	sta NC_PTR
	txa
	adc __v67_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v56_00
	jsr __f56
	ldx #$00
	pha
	txa
	pha
	lda __v67_03
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	clc
	adc #<__g21
	sta NC_PTR
	txa
	adc #>__g21
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00ed
	jmp __L00ec
__L00ed:
	lda __v67_02
	ldx #$00
	rts
__L00ec:
__L00ea:
__L00e8:
	lda __v67_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v67_02
	jmp __L00e5
__L00e6:
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__v68_00 = NC_BSS+$7f9d
__v68_01 = NC_BSS+$7f9e
__f68:
__v68_02 = NC_BSS+$7f9f
	lda #$00
	ldx #$00
	sta __v68_02
	stx __v68_02+1
__L00ee:
	lda __v68_02
	ldx __v68_02+1
	pha
	txa
	pha
	lda #$00
	ldx #$01
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00f0
	jmp __L00ef
__L00f0:
	lda __v68_02
	ldx __v68_02+1
	clc
	adc #<__g22
	sta NC_PTR
	txa
	adc #>__g22
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __v68_00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00f2
	jmp __L00f1
__L00f2:
	lda __v68_02
	ldx __v68_02+1
	clc
	adc #<__g23
	sta NC_PTR
	txa
	adc #>__g23
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __v68_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00f4
	jmp __L00f3
__L00f4:
	lda __v68_02
	ldx __v68_02+1
	rts
__L00f3:
__L00f1:
	lda __v68_02
	ldx __v68_02+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v68_02
	stx __v68_02+1
	jmp __L00ee
__L00ef:
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__v69_00 = NC_BSS+$7fa1
__f69:
	lda __g25
	ldx __g25+1
	pha
	txa
	pha
	lda #$00
	ldx #$2c
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00f6
	jmp __L00f5
__L00f6:
	lda __g0f
	ldx #$00
	rts
__L00f5:
	lda __g25
	ldx __g25+1
	clc
	adc #<__g24
	sta NC_PTR
	txa
	adc #>__g24
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v69_00
	ldx #$00
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __g25
	ldx __g25+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g25
	stx __g25+1
	lda __g05
	ldx #$00
	rts
__v6a_00 = NC_BSS+$7fa2
__f6a:
__v6a_01 = NC_BSS+$7fa4
__v6a_02 = NC_BSS+$7fa6
__v6a_03 = NC_BSS+$7fa8
	lda __g25
	ldx __g25+1
	sta __v6a_01
	stx __v6a_01+1
	lda __v6a_00
	ldx __v6a_00+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g30
	sta NC_PTR
	txa
	adc #>__g30
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	sta NC_TMP
	iny
	lda (NC_PTR),y
	tax
	lda NC_TMP
	pha
	txa
	pha
	pla
	tax
	pla
	sta __v6a_02
	stx __v6a_02+1
	lda __v6a_02
	ldx __v6a_02+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v6a_03
	lda __v6a_03
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00f8
	jmp __L00f7
__L00f8:
	lda __v6a_03
	ldx #$00
	rts
__L00f7:
	lda __v6a_02
	ldx __v6a_02+1
	pha
	txa
	pha
	lda #$08
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	ldy NC_TMP
	beq __L00fa
__L00f9:
	sta NC_TMP+1
	txa
	lsr
	tax
	lda NC_TMP+1
	ror
	dey
	bne __L00f9
__L00fa:
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v6a_03
	lda __v6a_03
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00fc
	jmp __L00fb
__L00fc:
	lda __v6a_03
	ldx #$00
	rts
__L00fb:
	lda __v6a_00
	ldx __v6a_00+1
	asl
	sta NC_TMP
	txa
	rol
	tax
	lda NC_TMP
	clc
	adc #<__g30
	sta NC_PTR
	txa
	adc #>__g30
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v6a_01
	ldx __v6a_01+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	iny
	lda NC_TMP+1
	sta (NC_PTR),y
	lda __g05
	ldx #$00
	rts
__v6b_00 = NC_BSS+$7fa9
__v6b_01 = NC_BSS+$7faa
__v6b_02 = NC_BSS+$7fab
__f6b:
__v6b_03 = NC_BSS+$7fad
__v6b_04 = NC_BSS+$7fae
	lda __v6b_01
	ldx #$00
	tay
	lda __g20,y
	ldx #$00
	sta __v6b_03
	lda __v6b_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L00fe
	jmp __L00fd
__L00fe:
	lda __v6b_02
	ldx __v6b_02+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ugt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0100
	jmp __L00ff
__L0100:
	lda __g0a
	ldx #$00
	rts
__L00ff:
__L00fd:
	lda __v6b_00
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v6b_04
	lda __v6b_04
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0102
	jmp __L0101
__L0102:
	lda __v6b_04
	ldx #$00
	rts
__L0101:
	lda __v6b_03
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0104
	jmp __L0103
__L0104:
	lda __g05
	ldx #$00
	rts
__L0103:
	lda __v6b_02
	ldx __v6b_02+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v6b_04
	lda __v6b_04
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0106
	jmp __L0105
__L0106:
	lda __v6b_04
	ldx #$00
	rts
__L0105:
	lda __v6b_03
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0108
	jmp __L0107
__L0108:
	lda __v6b_02
	ldx __v6b_02+1
	pha
	txa
	pha
	lda #$08
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	ldy NC_TMP
	beq __L010a
__L0109:
	sta NC_TMP+1
	txa
	lsr
	tax
	lda NC_TMP+1
	ror
	dey
	bne __L0109
__L010a:
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	rts
__L0107:
	lda __g05
	ldx #$00
	rts
__v6c_00 = NC_BSS+$7faf
__v6c_01 = NC_BSS+$7fb0
__f6c:
__v6c_02 = NC_BSS+$7fb2
__v6c_03 = NC_BSS+$7fb4
__v6c_04 = NC_BSS+$7fb6
	lda __g26
	ldx __g26+1
	pha
	txa
	pha
	lda __g25
	ldx __g25+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	sta __v6c_02
	stx __v6c_02+1
	lda __v6c_01
	ldx __v6c_01+1
	pha
	txa
	pha
	lda __v6c_02
	ldx __v6c_02+1
	pha
	txa
	pha
	pla
	sta __v5b_01+1
	pla
	sta __v5b_01
	pla
	sta __v5b_00+1
	pla
	sta __v5b_00
	jsr __f5b
	sta __v6c_03
	stx __v6c_03+1
	lda __v6c_03
	ldx __v6c_03+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L010c
	jmp __L010b
__L010c:
	lda __g0c
	ldx #$00
	rts
__L010b:
	lda __v6c_00
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v6c_04
	lda __v6c_04
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L010e
	jmp __L010d
__L010e:
	lda __v6c_04
	ldx #$00
	rts
__L010d:
	lda __v6c_03
	ldx __v6c_03+1
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	rts
__v6d_00 = NC_BSS+$7fb7
__v6d_01 = NC_BSS+$7fb8
__v6d_02 = NC_BSS+$7fb9
__v6d_03 = NC_BSS+$7fbb
__v6d_04 = NC_BSS+$7fbd
__f6d:
__v6d_05 = NC_BSS+$7fbe
__v6d_06 = NC_BSS+$7fbf
__v6d_07 = NC_BSS+$7fc1
__v6d_08 = NC_BSS+$7fc2
	lda __v6d_01
	ldx #$00
	tay
	lda __g20,y
	ldx #$00
	sta __v6d_05
	lda __v6d_00
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v6d_07
	lda __v6d_07
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0110
	jmp __L010f
__L0110:
	lda __v6d_07
	ldx #$00
	rts
__L010f:
	lda __g25
	ldx __g25+1
	sta __v6d_06
	stx __v6d_06+1
	lda __v6d_05
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0112
	jmp __L0111
__L0112:
	lda __v6d_04
	ldx #$00
	pha
	txa
	pha
	lda __g45
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0114
	jmp __L0113
__L0114:
	lda __v6d_03
	ldx __v6d_03+1
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0116
	jmp __L0115
__L0116:
	lda __v6d_02
	ldx __v6d_02+1
	pha
	txa
	pha
	pla
	sta __v6a_00+1
	pla
	sta __v6a_00
	jsr __f6a
	ldx #$00
	rts
__L0115:
__L0113:
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v6d_07
	lda __v6d_07
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0118
	jmp __L0117
__L0118:
	lda __v6d_07
	ldx #$00
	rts
__L0117:
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v6d_07
	lda __v6d_07
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L011a
	jmp __L0119
__L011a:
	lda __v6d_07
	ldx #$00
	rts
__L0119:
	lda __g52
	ldx #$00
	pha
	txa
	pha
	lda __v6d_06
	ldx __v6d_06+1
	pha
	txa
	pha
	lda __v6d_02
	ldx __v6d_02+1
	pha
	txa
	pha
	lda __v6d_03
	ldx __v6d_03+1
	pha
	txa
	pha
	lda __v6d_04
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v5a_04
	pla
	sta __v5a_03+1
	pla
	sta __v5a_03
	pla
	sta __v5a_02+1
	pla
	sta __v5a_02
	pla
	sta __v5a_01+1
	pla
	sta __v5a_01
	pla
	pla
	sta __v5a_00
	jsr __f5a
	ldx #$00
	rts
__L0111:
	lda __v6d_05
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L011c
	jmp __L011b
__L011c:
	lda __g0a
	ldx #$00
	rts
__L011b:
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v6d_07
	lda __v6d_07
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L011e
	jmp __L011d
__L011e:
	lda __v6d_07
	ldx #$00
	rts
__L011d:
	lda __g51
	ldx #$00
	sta __v6d_08
	lda __v6d_01
	ldx #$00
	pha
	txa
	pha
	lda __g1f
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0120
	jmp __L011f
__L0120:
	lda __g53
	ldx #$00
	sta __v6d_08
__L011f:
	lda __v6d_08
	ldx #$00
	pha
	txa
	pha
	lda __v6d_06
	ldx __v6d_06+1
	pha
	txa
	pha
	lda __v6d_02
	ldx __v6d_02+1
	pha
	txa
	pha
	lda __v6d_03
	ldx __v6d_03+1
	pha
	txa
	pha
	lda __v6d_04
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v5a_04
	pla
	sta __v5a_03+1
	pla
	sta __v5a_03
	pla
	sta __v5a_02+1
	pla
	sta __v5a_02
	pla
	sta __v5a_01+1
	pla
	sta __v5a_01
	pla
	pla
	sta __v5a_00
	jsr __f5a
	ldx #$00
	rts
__v6e_00 = NC_BSS+$7fc3
__f6e:
	lda __v6e_00
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0122
	jmp __L0121
__L0122:
	lda __g17
	ldx #$00
	rts
__L0121:
	lda __v6e_00
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0124
	jmp __L0123
__L0124:
	lda __g18
	ldx #$00
	rts
__L0123:
	lda __g16
	ldx #$00
	rts
__v6f_00 = NC_BSS+$7fc4
__f6f:
	lda __v6f_00
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0126
	jmp __L0125
__L0126:
	lda __g1a
	ldx #$00
	rts
__L0125:
	lda __v6f_00
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0128
	jmp __L0127
__L0128:
	lda __g1b
	ldx #$00
	rts
__L0127:
	lda __g19
	ldx #$00
	rts
__v70_00 = NC_BSS+$7fc5
__v70_01 = NC_BSS+$7fc6
__v70_02 = NC_BSS+$7fc7
__v70_03 = NC_BSS+$7fc9
__f70:
__v70_04 = NC_BSS+$7fca
__v70_05 = NC_BSS+$7fcc
	lda __v70_00
	ldx #$00
	pha
	txa
	pha
	lda __v70_01
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v68_01
	pla
	pla
	sta __v68_00
	jsr __f68
	sta __v70_04
	stx __v70_04+1
	lda __v70_04
	ldx __v70_04+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L012a
	jmp __L0129
__L012a:
	lda __g0a
	ldx #$00
	rts
__L0129:
	lda __v70_02
	ldx __v70_02+1
	pha
	txa
	pha
	lda __v70_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v66_01
	pla
	sta __v66_00+1
	pla
	sta __v66_00
	jsr __f66
	ldx #$00
	sta __v70_05
	lda __v70_05
	ldx #$00
	pha
	txa
	pha
	lda __g40
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L012c
	jmp __L012b
__L012c:
	lda __v70_01
	ldx #$00
	pha
	txa
	pha
	lda __g1f
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L012e
	jmp __L012d
__L012e:
	lda __v70_04
	ldx __v70_04+1
	pha
	txa
	pha
	lda __g48
	ldx __g48+1
	pha
	txa
	pha
	pla
	sta __v6c_01+1
	pla
	sta __v6c_01
	pla
	pla
	sta __v6c_00
	jsr __f6c
	ldx #$00
	rts
__L012d:
	lda __v70_04
	ldx __v70_04+1
	pha
	txa
	pha
	lda __v70_01
	ldx #$00
	pha
	txa
	pha
	lda __g48
	ldx __g48+1
	pha
	txa
	pha
	pla
	sta __v6b_02+1
	pla
	sta __v6b_02
	pla
	pla
	sta __v6b_01
	pla
	pla
	sta __v6b_00
	jsr __f6b
	ldx #$00
	rts
__L012b:
	lda __v70_05
	ldx #$00
	pha
	txa
	pha
	lda __g41
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0130
	jmp __L012f
__L0130:
	lda __v70_04
	ldx __v70_04+1
	pha
	txa
	pha
	lda __v70_01
	ldx #$00
	pha
	txa
	pha
	lda __g49
	ldx __g49+1
	pha
	txa
	pha
	lda __g4a
	ldx __g4a+1
	pha
	txa
	pha
	lda __g4b
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v6d_04
	pla
	sta __v6d_03+1
	pla
	sta __v6d_03
	pla
	sta __v6d_02+1
	pla
	sta __v6d_02
	pla
	pla
	sta __v6d_01
	pla
	pla
	sta __v6d_00
	jsr __f6d
	ldx #$00
	rts
__L012f:
	lda __v70_05
	ldx #$00
	pha
	txa
	pha
	lda __g43
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0132
	jmp __L0131
__L0132:
	lda __g08
	ldx #$00
	rts
__L0131:
	lda __v70_05
	ldx #$00
	pha
	txa
	pha
	lda __g44
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0134
	jmp __L0133
__L0134:
	lda __g09
	ldx #$00
	rts
__L0133:
	lda __g0a
	ldx #$00
	rts
__v71_00 = NC_BSS+$7fcd
__v71_01 = NC_BSS+$7fce
__v71_02 = NC_BSS+$7fd0
__v71_03 = NC_BSS+$7fd1
__f71:
__v71_04 = NC_BSS+$7fd2
__v71_05 = NC_BSS+$7fd3
__v71_06 = NC_BSS+$7fd4
__v71_07 = NC_BSS+$7fd5
__v71_08 = NC_BSS+$7fd7
__v71_09 = NC_BSS+$7fd9
__v71_0a = NC_BSS+$7fda
	lda __v71_03
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0136
	jmp __L0135
__L0136:
	lda __v71_00
	ldx #$00
	pha
	txa
	pha
	lda __g1f
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v68_01
	pla
	pla
	sta __v68_00
	jsr __f68
	sta __v71_0a
	stx __v71_0a+1
	lda __v71_0a
	ldx __v71_0a+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0138
	jmp __L0137
__L0138:
	lda __v71_00
	ldx #$00
	pha
	txa
	pha
	lda __g1f
	ldx #$00
	pha
	txa
	pha
	lda __v71_01
	ldx __v71_01+1
	pha
	txa
	pha
	lda __v71_02
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v70_03
	pla
	sta __v70_02+1
	pla
	sta __v70_02
	pla
	pla
	sta __v70_01
	pla
	pla
	sta __v70_00
	jsr __f70
	ldx #$00
	rts
__L0137:
__L0135:
	lda __v71_01
	ldx __v71_01+1
	pha
	txa
	pha
	lda __v71_02
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v66_01
	pla
	sta __v66_00+1
	pla
	sta __v66_00
	jsr __f66
	ldx #$00
	sta __v71_04
	lda __v71_04
	ldx #$00
	pha
	txa
	pha
	lda __g40
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L013a
	jmp __L0139
__L013a:
	lda __v71_04
	ldx #$00
	pha
	txa
	pha
	lda __g41
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L013c
	jmp __L013b
__L013c:
	lda __v71_04
	ldx #$00
	pha
	txa
	pha
	lda __g43
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L013e
	jmp __L013d
__L013e:
	lda __g08
	ldx #$00
	rts
__L013d:
	lda __v71_04
	ldx #$00
	pha
	txa
	pha
	lda __g44
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0140
	jmp __L013f
__L0140:
	lda __g09
	ldx #$00
	rts
__L013f:
	lda __g0a
	ldx #$00
	rts
__L013b:
__L0139:
	lda __v71_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v6e_00
	jsr __f6e
	ldx #$00
	sta __v71_05
	lda __v71_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v6f_00
	jsr __f6f
	ldx #$00
	sta __v71_06
	lda __v71_00
	ldx #$00
	pha
	txa
	pha
	lda __v71_05
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v68_01
	pla
	pla
	sta __v68_00
	jsr __f68
	sta __v71_07
	stx __v71_07+1
	lda __v71_00
	ldx #$00
	pha
	txa
	pha
	lda __v71_06
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v68_01
	pla
	pla
	sta __v68_00
	jsr __f68
	sta __v71_08
	stx __v71_08+1
	lda __v71_04
	ldx #$00
	pha
	txa
	pha
	lda __g40
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0142
	jmp __L0141
__L0142:
	lda __g48
	ldx __g48+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ule16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0144
	jmp __L0143
__L0144:
	lda __v71_07
	ldx __v71_07+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0146
	jmp __L0145
__L0146:
	lda __v71_07
	ldx __v71_07+1
	pha
	txa
	pha
	lda __v71_05
	ldx #$00
	pha
	txa
	pha
	lda __g48
	ldx __g48+1
	pha
	txa
	pha
	pla
	sta __v6b_02+1
	pla
	sta __v6b_02
	pla
	pla
	sta __v6b_01
	pla
	pla
	sta __v6b_00
	jsr __f6b
	ldx #$00
	rts
__L0145:
__L0143:
	lda __v71_08
	ldx __v71_08+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0148
	jmp __L0147
__L0148:
	lda __v71_08
	ldx __v71_08+1
	pha
	txa
	pha
	lda __v71_06
	ldx #$00
	pha
	txa
	pha
	lda __g48
	ldx __g48+1
	pha
	txa
	pha
	pla
	sta __v6b_02+1
	pla
	sta __v6b_02
	pla
	pla
	sta __v6b_01
	pla
	pla
	sta __v6b_00
	jsr __f6b
	ldx #$00
	rts
__L0147:
	lda __g0a
	ldx #$00
	rts
__L0141:
	lda __v71_06
	ldx #$00
	sta __v71_09
	lda __v71_08
	ldx __v71_08+1
	sta __v71_0a
	stx __v71_0a+1
	lda __g4b
	ldx #$00
	pha
	txa
	pha
	lda __g45
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L014a
	jmp __L0149
__L014a:
	lda __v71_05
	ldx #$00
	sta __v71_09
	lda __v71_07
	ldx __v71_07+1
	sta __v71_0a
	stx __v71_0a+1
	jmp __L014b
__L0149:
	lda __v71_08
	ldx __v71_08+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L014d
	jmp __L014c
__L014d:
	lda __v71_05
	ldx #$00
	sta __v71_09
	lda __v71_07
	ldx __v71_07+1
	sta __v71_0a
	stx __v71_0a+1
__L014c:
__L014b:
	lda __v71_0a
	ldx __v71_0a+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L014f
	jmp __L014e
__L014f:
	lda __g0a
	ldx #$00
	rts
__L014e:
	lda __v71_0a
	ldx __v71_0a+1
	pha
	txa
	pha
	lda __v71_09
	ldx #$00
	pha
	txa
	pha
	lda __g49
	ldx __g49+1
	pha
	txa
	pha
	lda __g4a
	ldx __g4a+1
	pha
	txa
	pha
	lda __g4b
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v6d_04
	pla
	sta __v6d_03+1
	pla
	sta __v6d_03
	pla
	sta __v6d_02+1
	pla
	sta __v6d_02
	pla
	pla
	sta __v6d_01
	pla
	pla
	sta __v6d_00
	jsr __f6d
	ldx #$00
	rts
__v72_00 = NC_BSS+$7fdc
__v72_01 = NC_BSS+$7fde
__v72_02 = NC_BSS+$7fdf
__v72_03 = NC_BSS+$7fe1
__f72:
__v72_04 = NC_BSS+$7fe2
__v72_05 = NC_BSS+$7fe4
__v72_06 = NC_BSS+$7fe6
__v72_07 = NC_BSS+$7fe7
	lda __v72_00
	ldx __v72_00+1
	pha
	txa
	pha
	lda __v72_01
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v67_01
	pla
	sta __v67_00+1
	pla
	sta __v67_00
	jsr __f67
	sta __v72_04
	stx __v72_04+1
	lda __v72_04
	ldx __v72_04+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0151
	jmp __L0150
__L0151:
	lda __g0a
	ldx #$00
	rts
__L0150:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0153
	jmp __L0152
__L0153:
	lda __v72_04
	ldx __v72_04+1
	pha
	txa
	pha
	lda __g13
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v68_01
	pla
	pla
	sta __v68_00
	jsr __f68
	sta __v72_05
	stx __v72_05+1
	lda __v72_05
	ldx __v72_05+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0155
	jmp __L0154
__L0155:
	lda __v72_05
	ldx __v72_05+1
	pha
	txa
	pha
	lda __g13
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta __v6b_02+1
	pla
	sta __v6b_02
	pla
	pla
	sta __v6b_01
	pla
	pla
	sta __v6b_00
	jsr __f6b
	ldx #$00
	rts
__L0154:
	lda __v72_04
	ldx __v72_04+1
	pha
	txa
	pha
	lda __g14
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v68_01
	pla
	pla
	sta __v68_00
	jsr __f68
	sta __v72_05
	stx __v72_05+1
	lda __v72_05
	ldx __v72_05+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0157
	jmp __L0156
__L0157:
	lda __v72_05
	ldx __v72_05+1
	pha
	txa
	pha
	lda __g14
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta __v6b_02+1
	pla
	sta __v6b_02
	pla
	pla
	sta __v6b_01
	pla
	pla
	sta __v6b_00
	jsr __f6b
	ldx #$00
	rts
__L0156:
	lda __g0a
	ldx #$00
	rts
__L0152:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0159
	jmp __L0158
__L0159:
	lda #$00
	ldx #$00
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v56_00
	jsr __f56
	ldx #$00
	pha
	txa
	pha
	lda #$41
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L015b
	jmp __L015a
__L015b:
	lda __v72_04
	ldx __v72_04+1
	pha
	txa
	pha
	lda __g14
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v68_01
	pla
	pla
	sta __v68_00
	jsr __f68
	sta __v72_05
	stx __v72_05+1
	lda __v72_05
	ldx __v72_05+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L015d
	jmp __L015c
__L015d:
	lda __g0a
	ldx #$00
	rts
__L015c:
	lda __v72_05
	ldx __v72_05+1
	pha
	txa
	pha
	lda __g14
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta __v6b_02+1
	pla
	sta __v6b_02
	pla
	pla
	sta __v6b_01
	pla
	pla
	sta __v6b_00
	jsr __f6b
	ldx #$00
	rts
__L015a:
__L0158:
	lda #$00
	ldx #$00
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$23
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L015f
	jmp __L015e
__L015f:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0161
	jmp __L0160
__L0161:
	lda __g0a
	ldx #$00
	rts
__L0160:
	lda __v72_04
	ldx __v72_04+1
	pha
	txa
	pha
	lda __g15
	ldx #$00
	pha
	txa
	pha
	lda __v72_02
	ldx __v72_02+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	pla
	sta __v70_03
	pla
	sta __v70_02+1
	pla
	sta __v70_02
	pla
	pla
	sta __v70_01
	pla
	pla
	sta __v70_00
	jsr __f70
	ldx #$00
	rts
__L015e:
	lda #$00
	ldx #$00
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$28
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0163
	jmp __L0162
__L0163:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0165
	jmp __L0164
__L0165:
	lda __g0a
	ldx #$00
	rts
__L0164:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v56_00
	jsr __f56
	ldx #$00
	pha
	txa
	pha
	lda #$59
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0167
	jmp __L0166
__L0167:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2c
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0169
	jmp __L0168
__L0169:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$29
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L016b
	jmp __L016a
__L016b:
	lda __g0a
	ldx #$00
	rts
__L016a:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$04
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __v72_07
	lda __v72_07
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sle16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L016d
	jmp __L016c
__L016d:
	lda __g0a
	ldx #$00
	rts
__L016c:
	lda __v72_04
	ldx __v72_04+1
	pha
	txa
	pha
	lda __g1e
	ldx #$00
	pha
	txa
	pha
	lda __v72_02
	ldx __v72_02+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v72_07
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v70_03
	pla
	sta __v70_02+1
	pla
	sta __v70_02
	pla
	pla
	sta __v70_01
	pla
	pla
	sta __v70_00
	jsr __f70
	ldx #$00
	rts
__L0168:
__L0166:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$29
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L016f
	jmp __L016e
__L016f:
	lda __g0a
	ldx #$00
	rts
__L016e:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v56_00
	jsr __f56
	ldx #$00
	pha
	txa
	pha
	lda #$58
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0171
	jmp __L0170
__L0171:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0173
	jmp __L0172
__L0173:
	lda __g0a
	ldx #$00
	rts
__L0172:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2c
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0175
	jmp __L0174
__L0175:
	lda __g0a
	ldx #$00
	rts
__L0174:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$04
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __v72_07
	lda __v72_04
	ldx __v72_04+1
	pha
	txa
	pha
	lda __g1d
	ldx #$00
	pha
	txa
	pha
	lda __v72_02
	ldx __v72_02+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v72_07
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v70_03
	pla
	sta __v70_02+1
	pla
	sta __v70_02
	pla
	pla
	sta __v70_01
	pla
	pla
	sta __v70_00
	jsr __f70
	ldx #$00
	rts
__L0170:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __v72_07
	lda __v72_04
	ldx __v72_04+1
	pha
	txa
	pha
	lda __g1c
	ldx #$00
	pha
	txa
	pha
	lda __v72_02
	ldx __v72_02+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v72_07
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v70_03
	pla
	sta __v70_02+1
	pla
	sta __v70_02
	pla
	pla
	sta __v70_01
	pla
	pla
	sta __v70_00
	jsr __f70
	ldx #$00
	rts
__L0162:
	lda #$00
	ldx #$00
	sta __v72_06
	lda __v72_03
	ldx #$00
	sta __v72_07
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0177
	jmp __L0176
__L0177:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2c
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0179
	jmp __L0178
__L0179:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v56_00
	jsr __f56
	ldx #$00
	pha
	txa
	pha
	lda #$58
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L017b
	jmp __L017a
__L017b:
	lda #$01
	ldx #$00
	sta __v72_06
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __v72_07
	jmp __L017c
__L017a:
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v72_02
	sta NC_PTR
	txa
	adc __v72_02+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v56_00
	jsr __f56
	ldx #$00
	pha
	txa
	pha
	lda #$59
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L017e
	jmp __L017d
__L017e:
	lda #$02
	ldx #$00
	sta __v72_06
	lda __v72_03
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __v72_07
__L017d:
__L017c:
__L0178:
__L0176:
	lda __v72_04
	ldx __v72_04+1
	pha
	txa
	pha
	lda __v72_02
	ldx __v72_02+1
	pha
	txa
	pha
	lda __v72_07
	ldx #$00
	pha
	txa
	pha
	lda __v72_06
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v71_03
	pla
	pla
	sta __v71_02
	pla
	sta __v71_01+1
	pla
	sta __v71_01
	pla
	pla
	sta __v71_00
	jsr __f71
	ldx #$00
	rts
__v73_00 = NC_BSS+$7fe8
__v73_01 = NC_BSS+$7fea
__v73_02 = NC_BSS+$7feb
__f73:
__v73_03 = NC_BSS+$7fec
__v73_04 = NC_BSS+$7fed
__v73_05 = NC_BSS+$7fef
	lda __v73_00
	ldx __v73_00+1
	pha
	txa
	pha
	lda __v73_01
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v66_01
	pla
	sta __v66_00+1
	pla
	sta __v66_00
	jsr __f66
	ldx #$00
	sta __v73_03
	lda __v73_03
	ldx #$00
	pha
	txa
	pha
	lda __g40
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0180
	jmp __L017f
__L0180:
	lda __v73_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0182
	jmp __L0181
__L0182:
	lda __g48
	ldx __g48+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ugt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0184
	jmp __L0183
__L0184:
	lda __g0d
	ldx #$00
	rts
__L0183:
	lda __g48
	ldx __g48+1
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	rts
__L0181:
	lda __g48
	ldx __g48+1
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v73_03
	lda __v73_03
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0186
	jmp __L0185
__L0186:
	lda __v73_03
	ldx #$00
	rts
__L0185:
	lda __g48
	ldx __g48+1
	pha
	txa
	pha
	lda #$08
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	ldy NC_TMP
	beq __L0188
__L0187:
	sta NC_TMP+1
	txa
	lsr
	tax
	lda NC_TMP+1
	ror
	dey
	bne __L0187
__L0188:
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	rts
__L017f:
	lda __v73_03
	ldx #$00
	pha
	txa
	pha
	lda __g41
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L018a
	jmp __L0189
__L018a:
	lda __v73_02
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L018c
	jmp __L018b
__L018c:
	lda __g4b
	ldx #$00
	pha
	txa
	pha
	lda __g45
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L018e
	jmp __L018d
__L018e:
	lda __g4a
	ldx __g4a+1
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0190
	jmp __L018f
__L0190:
	lda __g49
	ldx __g49+1
	pha
	txa
	pha
	pla
	sta __v6a_00+1
	pla
	sta __v6a_00
	jsr __f6a
	ldx #$00
	rts
__L018f:
__L018d:
__L018b:
	lda __g25
	ldx __g25+1
	sta __v73_04
	stx __v73_04+1
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v73_03
	lda __v73_03
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0192
	jmp __L0191
__L0192:
	lda __v73_03
	ldx #$00
	rts
__L0191:
	lda __v73_02
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0194
	jmp __L0193
__L0194:
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v73_03
	lda __v73_03
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0196
	jmp __L0195
__L0196:
	lda __v73_03
	ldx #$00
	rts
__L0195:
	lda __g52
	ldx #$00
	sta __v73_05
	jmp __L0197
__L0193:
	lda __g54
	ldx #$00
	sta __v73_05
__L0197:
	lda __v73_05
	ldx #$00
	pha
	txa
	pha
	lda __v73_04
	ldx __v73_04+1
	pha
	txa
	pha
	lda __g49
	ldx __g49+1
	pha
	txa
	pha
	lda __g4a
	ldx __g4a+1
	pha
	txa
	pha
	lda __g4b
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v5a_04
	pla
	sta __v5a_03+1
	pla
	sta __v5a_03
	pla
	sta __v5a_02+1
	pla
	sta __v5a_02
	pla
	sta __v5a_01+1
	pla
	sta __v5a_01
	pla
	pla
	sta __v5a_00
	jsr __f5a
	ldx #$00
	rts
__L0189:
	lda __v73_03
	ldx #$00
	pha
	txa
	pha
	lda __g43
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0199
	jmp __L0198
__L0199:
	lda __g08
	ldx #$00
	rts
__L0198:
	lda __v73_03
	ldx #$00
	pha
	txa
	pha
	lda __g44
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L019b
	jmp __L019a
__L019b:
	lda __g09
	ldx #$00
	rts
__L019a:
	lda __g0d
	ldx #$00
	rts
__v74_00 = NC_BSS+$7ff0
__v74_01 = NC_BSS+$7ff2
__v74_02 = NC_BSS+$7ff3
__f74:
__v74_03 = NC_BSS+$7ff4
__v74_04 = NC_BSS+$7ff5
__v74_05 = NC_BSS+$7ff6
__v74_06 = NC_BSS+$7ff7
__v74_07 = NC_BSS+$7ff8
	lda #$00
	ldx #$00
	sta __v74_03
__L019c:
	ldy __v74_03
	cpy __v74_01
	bcc __L019e
	jmp __L019d
__L019e:
__L019f:
	lda __v74_03
	ldx #$00
	pha
	txa
	pha
	lda __v74_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01a1
	jmp __L01a0
__L01a1:
	lda __v74_03
	ldx #$00
	tay
	lda __v74_00
	sta NC_PTR
	lda __v74_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	sta __v74_07
	lda __v74_07
	ldx #$00
	pha
	txa
	pha
	lda #$20
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01a3
	jmp __L01a2
__L01a3:
	lda __v74_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v74_03
	jmp __L01a4
__L01a2:
	lda __v74_07
	ldx #$00
	pha
	txa
	pha
	lda #$09
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01a6
	jmp __L01a5
__L01a6:
	lda __v74_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v74_03
	jmp __L01a7
__L01a5:
	jmp __L01a0
__L01a7:
__L01a4:
	jmp __L019f
__L01a0:
	lda __v74_03
	ldx #$00
	pha
	txa
	pha
	lda __v74_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01a9
	jmp __L01a8
__L01a9:
	lda __g0d
	ldx #$00
	rts
__L01a8:
	lda __v74_03
	ldx #$00
	sta __v74_04
	lda __v74_03
	ldx #$00
	sta __v74_05
__L01aa:
	ldy __v74_03
	cpy __v74_01
	bcc __L01ac
	jmp __L01ab
__L01ac:
	lda __v74_03
	ldx #$00
	tay
	lda __v74_00
	sta NC_PTR
	lda __v74_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	sta __v74_07
	lda __v74_07
	ldx #$00
	pha
	txa
	pha
	lda #$2c
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01ae
	jmp __L01ad
__L01ae:
	jmp __L01ab
__L01ad:
	lda __v74_07
	ldx #$00
	pha
	txa
	pha
	lda #$20
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01b0
	jmp __L01af
__L01b0:
	lda __v74_07
	ldx #$00
	pha
	txa
	pha
	lda #$09
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01b2
	jmp __L01b1
__L01b2:
	lda __v74_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v74_05
__L01b1:
__L01af:
	lda __v74_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v74_03
	jmp __L01aa
__L01ab:
	lda __v74_05
	ldx #$00
	pha
	txa
	pha
	lda __v74_04
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01b4
	jmp __L01b3
__L01b4:
	lda __g0d
	ldx #$00
	rts
__L01b3:
	lda __v74_00
	ldx __v74_00+1
	pha
	txa
	pha
	lda __v74_04
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v74_05
	ldx #$00
	pha
	txa
	pha
	lda __v74_04
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v74_02
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v73_02
	pla
	pla
	sta __v73_01
	pla
	sta __v73_00+1
	pla
	sta __v73_00
	jsr __f73
	ldx #$00
	sta __v74_06
	lda __v74_06
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01b6
	jmp __L01b5
__L01b6:
	lda __v74_06
	ldx #$00
	rts
__L01b5:
	lda __v74_03
	ldx #$00
	pha
	txa
	pha
	lda __v74_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01b8
	jmp __L01b7
__L01b8:
	lda __g05
	ldx #$00
	rts
__L01b7:
	lda __v74_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v74_03
	lda __v74_03
	ldx #$00
	pha
	txa
	pha
	lda __v74_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01ba
	jmp __L01b9
__L01ba:
	lda __g0d
	ldx #$00
	rts
__L01b9:
	jmp __L019c
__L019d:
	lda __g05
	ldx #$00
	rts
__v75_00 = NC_BSS+$7ff9
__v75_01 = NC_BSS+$7ffb
__f75:
__v75_02 = NC_BSS+$7ffc
__v75_03 = NC_BSS+$7ffd
	lda __v75_01
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01bc
	jmp __L01bb
__L01bc:
	lda __g0d
	ldx #$00
	rts
__L01bb:
	lda #$00
	ldx #$00
	clc
	adc __v75_00
	sta NC_PTR
	txa
	adc __v75_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$22
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01be
	jmp __L01bd
__L01be:
	lda __g0d
	ldx #$00
	rts
__L01bd:
	lda __v75_01
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v75_00
	sta NC_PTR
	txa
	adc __v75_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$22
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01c0
	jmp __L01bf
__L01c0:
	lda __g0d
	ldx #$00
	rts
__L01bf:
	lda #$01
	ldx #$00
	sta __v75_02
__L01c1:
	lda __v75_02
	ldx #$00
	pha
	txa
	pha
	lda __v75_01
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01c3
	jmp __L01c2
__L01c3:
	lda __v75_02
	ldx #$00
	tay
	lda __v75_00
	sta NC_PTR
	lda __v75_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	sta __v75_03
	lda __v75_03
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01c5
	jmp __L01c4
__L01c5:
	lda __v75_03
	ldx #$00
	rts
__L01c4:
	lda __v75_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v75_02
	jmp __L01c1
__L01c2:
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v69_00
	jsr __f69
	ldx #$00
	rts
__v76_00 = NC_BSS+$7ffe
__v76_01 = NC_BSS+$8000
__f76:
__v76_02 = NC_BSS+$8001
__v76_03 = NC_BSS+$8002
__v76_04 = NC_BSS+$8003
__v76_05 = NC_BSS+$8004
__v76_06 = NC_BSS+$8005
__v76_07 = NC_BSS+$8006
	lda __v76_01
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01c7
	jmp __L01c6
__L01c7:
	lda __g06
	ldx #$00
	rts
__L01c6:
	lda #$00
	ldx #$00
	clc
	adc __v76_00
	sta NC_PTR
	txa
	adc __v76_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$22
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01c9
	jmp __L01c8
__L01c9:
	lda __g06
	ldx #$00
	rts
__L01c8:
	lda __v76_01
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc __v76_00
	sta NC_PTR
	txa
	adc __v76_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$22
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01cb
	jmp __L01ca
__L01cb:
	lda __g06
	ldx #$00
	rts
__L01ca:
	lda __g2b
	ldx __g2b+1
	pha
	txa
	pha
	lda #$04
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01cd
	jmp __L01cc
__L01cd:
	lda __g12
	ldx #$00
	rts
__L01cc:
	lda #$01
	ldx #$00
	sta __v76_02
	lda __v76_01
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __v76_03
	lda #$00
	ldx #$00
	sta __v76_04
	lda #$00
	ldx #$00
	sta __v76_06
	lda __v76_03
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01cf
	jmp __L01ce
__L01cf:
	lda __v76_02
	ldx #$00
	tay
	lda __v76_00
	sta NC_PTR
	lda __v76_00+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2e
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01d1
	jmp __L01d0
__L01d1:
	lda __v76_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	clc
	adc __v76_00
	sta NC_PTR
	txa
	adc __v76_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2e
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01d3
	jmp __L01d2
__L01d3:
	lda __v76_02
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	clc
	adc __v76_00
	sta NC_PTR
	txa
	adc __v76_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2f
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01d5
	jmp __L01d4
__L01d5:
	lda #$01
	ldx #$00
	sta __v76_06
	lda __v76_02
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v76_02
	lda __v76_03
	ldx #$00
	pha
	txa
	pha
	lda #$03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __v76_03
__L01d4:
__L01d2:
__L01d0:
__L01ce:
	lda __v76_06
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01d7
	jmp __L01d6
__L01d7:
	lda #$00
	ldx #$00
	sta __v76_05
__L01d8:
	ldy __v76_05
	cpy __g2d
	bcc __L01da
	jmp __L01d9
__L01da:
	lda __v76_04
	ldx #$00
	clc
	adc #<__g29
	sta NC_PTR
	txa
	adc #>__g29
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v76_05
	ldx #$00
	tay
	lda __g2c
	sta NC_PTR
	lda __g2c+1
	sta NC_PTR+1
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v76_04
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v76_04
	lda __v76_05
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v76_05
	jmp __L01d8
__L01d9:
__L01d6:
	lda __v76_04
	ldx #$00
	pha
	txa
	pha
	lda __v76_03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sgt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01dc
	jmp __L01db
__L01dc:
	lda __g06
	ldx #$00
	rts
__L01db:
	lda #$00
	ldx #$00
	sta __v76_05
__L01dd:
	ldy __v76_05
	cpy __v76_03
	bcc __L01df
	jmp __L01de
__L01df:
	lda __v76_04
	ldx #$00
	clc
	adc #<__g29
	sta NC_PTR
	txa
	adc #>__g29
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v76_02
	ldx #$00
	pha
	txa
	pha
	lda __v76_05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	clc
	adc __v76_00
	sta NC_PTR
	txa
	adc __v76_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __v76_04
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v76_04
	lda __v76_05
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v76_05
	jmp __L01dd
__L01de:
	lda #<__g29
	ldx #>__g29
	pha
	txa
	pha
	lda __v76_04
	ldx #$00
	pha
	txa
	pha
	pla
	sta __c_io_open__v01+1
	pla
	sta __c_io_open__v01
	pla
	sta __c_io_open__v00+1
	pla
	sta __c_io_open__v00
	jsr __c_io_open
	sta __v76_07
	stx __v76_07+1
	lda __v76_07
	ldx __v76_07+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01e1
	jmp __L01e0
__L01e1:
	lda __g10
	ldx #$00
	rts
__L01e0:
	lda __g2b
	ldx __g2b+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g2b
	stx __g2b+1
	lda __g2b
	ldx __g2b+1
	clc
	adc #<__g2a
	sta NC_PTR
	txa
	adc #>__g2a
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v76_07
	ldx __v76_07+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __g05
	ldx #$00
	rts
__f77:
__v77_00 = NC_BSS+$8008
__v77_01 = NC_BSS+$800a
	lda #$00
	ldx #$00
	sta __g28
	lda __g2b
	ldx __g2b+1
	clc
	adc #<__g2a
	sta NC_PTR
	txa
	adc #>__g2a
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	sta __v77_01
__L01e2:
	lda #$01
	ldx #$00
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01e4
	jmp __L01e3
__L01e4:
	lda __v77_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta __c_io_read__v00+1
	pla
	sta __c_io_read__v00
	jsr __c_io_read
	sta __v77_00
	stx __v77_00+1
	lda __v77_00
	ldx __v77_00+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01e6
	jmp __L01e5
__L01e6:
	lda __v77_00
	ldx __v77_00+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01e8
	jmp __L01e7
__L01e8:
	lda __g28
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01ea
	jmp __L01e9
__L01ea:
	lda __g28
	ldx #$00
	clc
	adc #<__g27
	sta NC_PTR
	txa
	adc #>__g27
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda #$01
	ldx #$00
	rts
__L01e9:
	lda #$00
	ldx #$00
	rts
__L01e7:
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L01e5:
	lda __v77_00
	ldx __v77_00+1
	pha
	txa
	pha
	lda #$0d
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01ec
	jmp __L01eb
__L01ec:
	lda __g28
	ldx #$00
	clc
	adc #<__g27
	sta NC_PTR
	txa
	adc #>__g27
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda #$01
	ldx #$00
	rts
__L01eb:
	lda __v77_00
	ldx __v77_00+1
	pha
	txa
	pha
	lda #$0a
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01ee
	jmp __L01ed
__L01ee:
	lda __g28
	ldx #$00
	clc
	adc #<__g27
	sta NC_PTR
	txa
	adc #>__g27
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda #$01
	ldx #$00
	rts
__L01ed:
	lda __g28
	ldx #$00
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01f0
	jmp __L01ef
__L01f0:
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	rts
__L01ef:
	lda __g28
	ldx #$00
	clc
	adc #<__g27
	sta NC_PTR
	txa
	adc #>__g27
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v77_00
	ldx __v77_00+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
	lda __g28
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g28
	jmp __L01e2
__L01e3:
__f78:
__L01f1:
	lda __g2b
	ldx __g2b+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01f3
	jmp __L01f2
__L01f3:
	lda __g2b
	ldx __g2b+1
	clc
	adc #<__g2a
	sta NC_PTR
	txa
	adc #>__g2a
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	sta __c_io_close__v00+1
	pla
	sta __c_io_close__v00
	jsr __c_io_close
	lda __g2b
	ldx __g2b+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __g2b
	stx __g2b+1
	jmp __L01f1
__L01f2:
	lda __g05
	ldx #$00
	rts
__v79_00 = NC_BSS+$800b
__f79:
__v79_01 = NC_BSS+$800c
__v79_02 = NC_BSS+$800d
__v79_03 = NC_BSS+$800e
__v79_04 = NC_BSS+$800f
	lda __v79_00
	ldx #$00
	sta __v79_01
	lda #$00
	ldx #$00
	sta __v79_02
	lda __v79_00
	ldx #$00
	sta __v79_03
__L01f4:
	ldy __v79_01
	cpy __g28
	bcc __L01f6
	jmp __L01f5
__L01f6:
	lda __v79_01
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	sta __v79_04
	lda __v79_04
	ldx #$00
	pha
	txa
	pha
	lda #$3b
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01f8
	jmp __L01f7
__L01f8:
	lda __v79_02
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01fa
	jmp __L01f9
__L01fa:
	lda __g28
	ldx #$00
	sta __v79_01
	jmp __L01fb
__L01f9:
	lda __v79_01
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v79_03
	lda __v79_01
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v79_01
__L01fb:
	jmp __L01fc
__L01f7:
	lda __v79_04
	ldx #$00
	pha
	txa
	pha
	lda #$27
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L01fe
	jmp __L01fd
__L01fe:
	lda __v79_02
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0200
	jmp __L01ff
__L0200:
	lda #$27
	ldx #$00
	sta __v79_02
	jmp __L0201
__L01ff:
	lda __v79_02
	ldx #$00
	pha
	txa
	pha
	lda #$27
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0203
	jmp __L0202
__L0203:
	lda #$00
	ldx #$00
	sta __v79_02
__L0202:
__L0201:
	lda __v79_01
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v79_03
	jmp __L0204
__L01fd:
	lda __v79_04
	ldx #$00
	pha
	txa
	pha
	lda #$22
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0206
	jmp __L0205
__L0206:
	lda __v79_02
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0208
	jmp __L0207
__L0208:
	lda #$22
	ldx #$00
	sta __v79_02
	jmp __L0209
__L0207:
	lda __v79_02
	ldx #$00
	pha
	txa
	pha
	lda #$22
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L020b
	jmp __L020a
__L020b:
	lda #$00
	ldx #$00
	sta __v79_02
__L020a:
__L0209:
	lda __v79_01
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v79_03
	jmp __L020c
__L0205:
	lda __v79_04
	ldx #$00
	pha
	txa
	pha
	lda #$20
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L020e
	jmp __L020d
__L020e:
	lda __v79_04
	ldx #$00
	pha
	txa
	pha
	lda #$09
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0210
	jmp __L020f
__L0210:
	lda __v79_01
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v79_03
__L020f:
__L020d:
__L020c:
__L0204:
	lda __v79_01
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v79_01
__L01fc:
	jmp __L01f4
__L01f5:
	lda __v79_03
	ldx #$00
	pha
	txa
	pha
	lda __v79_00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	rts
__v7a_00 = NC_BSS+$8010
__v7a_01 = NC_BSS+$8012
__f7a:
__v7a_02 = NC_BSS+$8013
__v7a_03 = NC_BSS+$8014
	lda __v7a_01
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0212
	jmp __L0211
__L0212:
	lda __g06
	ldx #$00
	rts
__L0211:
	lda #$00
	ldx #$00
	clc
	adc __v7a_00
	sta NC_PTR
	txa
	adc __v7a_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2e
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0214
	jmp __L0213
__L0214:
	lda __g36
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0216
	jmp __L0215
__L0216:
	lda __g09
	ldx #$00
	rts
__L0215:
	jmp __L0217
__L0213:
	lda __g36
	ldx #$00
	pha
	txa
	pha
	lda #$ff
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0219
	jmp __L0218
__L0219:
	lda __g09
	ldx #$00
	rts
__L0218:
	lda __g36
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __g36
__L0217:
	lda #$00
	ldx #$00
	sta __g55
	lda __g26
	ldx __g26+1
	pha
	txa
	pha
	lda __g25
	ldx __g25+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	sta __v7a_03
	stx __v7a_03+1
	lda __v7a_00
	ldx __v7a_00+1
	pha
	txa
	pha
	lda __v7a_01
	ldx #$00
	pha
	txa
	pha
	lda __v7a_03
	ldx __v7a_03+1
	pha
	txa
	pha
	pla
	sta __v64_02+1
	pla
	sta __v64_02
	pla
	pla
	sta __v64_01
	pla
	sta __v64_00+1
	pla
	sta __v64_00
	jsr __f64
	ldx #$00
	sta __v7a_02
	lda __v7a_02
	ldx #$00
	rts
__v7b_00 = NC_BSS+$8016
__v7b_01 = NC_BSS+$8018
__v7b_02 = NC_BSS+$8019
__v7b_03 = NC_BSS+$801b
__f7b:
__v7b_04 = NC_BSS+$801c
	lda __v7b_01
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L021b
	jmp __L021a
__L021b:
	lda #$00
	ldx #$00
	clc
	adc __v7b_00
	sta NC_PTR
	txa
	adc __v7b_00+1
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$2a
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L021d
	jmp __L021c
__L021d:
	lda __g55
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L021f
	jmp __L021e
__L021f:
	lda __g0e
	ldx #$00
	rts
__L021e:
	lda __v7b_02
	ldx __v7b_02+1
	pha
	txa
	pha
	lda __v7b_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v66_01
	pla
	sta __v66_00+1
	pla
	sta __v66_00
	jsr __f66
	ldx #$00
	sta __v7b_04
	lda __v7b_04
	ldx #$00
	pha
	txa
	pha
	lda __g40
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0221
	jmp __L0220
__L0221:
	lda __g0e
	ldx #$00
	rts
__L0220:
	lda __g48
	ldx __g48+1
	sta __g26
	stx __g26+1
	lda #$00
	ldx #$00
	sta __g55
	lda __g05
	ldx #$00
	rts
__L021c:
__L021a:
	lda __v7b_02
	ldx __v7b_02+1
	pha
	txa
	pha
	lda __v7b_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v66_01
	pla
	sta __v66_00+1
	pla
	sta __v66_00
	jsr __f66
	ldx #$00
	sta __v7b_04
	lda __v7b_04
	ldx #$00
	pha
	txa
	pha
	lda __g40
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0223
	jmp __L0222
__L0223:
	lda __v7b_04
	ldx #$00
	pha
	txa
	pha
	lda __g43
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0225
	jmp __L0224
__L0225:
	lda __g08
	ldx #$00
	rts
__L0224:
	lda __v7b_04
	ldx #$00
	pha
	txa
	pha
	lda __g44
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0227
	jmp __L0226
__L0227:
	lda __g09
	ldx #$00
	rts
__L0226:
	lda __g07
	ldx #$00
	rts
__L0222:
	lda __v7b_00
	ldx __v7b_00+1
	pha
	txa
	pha
	lda __v7b_01
	ldx #$00
	pha
	txa
	pha
	lda __g48
	ldx __g48+1
	pha
	txa
	pha
	pla
	sta __v62_02+1
	pla
	sta __v62_02
	pla
	pla
	sta __v62_01
	pla
	sta __v62_00+1
	pla
	sta __v62_00
	jsr __f62
	ldx #$00
	rts
__v7c_00 = NC_BSS+$801d
__v7c_01 = NC_BSS+$801f
__v7c_02 = NC_BSS+$8020
__v7c_03 = NC_BSS+$8022
__f7c:
	lda __v7c_00
	ldx __v7c_00+1
	pha
	txa
	pha
	lda __v7c_01
	ldx #$00
	pha
	txa
	pha
	jmp __L022a
__L0229:
	byte $69
	byte $6e
	byte $63
	byte $6c
	byte $75
	byte $64
	byte $65
	byte $00
__L022a:
	lda #<__L0229
	ldx #>__L0229
	pha
	txa
	pha
	lda #$07
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v57_03
	pla
	sta __v57_02+1
	pla
	sta __v57_02
	pla
	pla
	sta __v57_01
	pla
	sta __v57_00+1
	pla
	sta __v57_00
	jsr __f57
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L022b
	jmp __L0228
__L022b:
	lda __v7c_02
	ldx __v7c_02+1
	pha
	txa
	pha
	lda __v7c_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v76_01
	pla
	sta __v76_00+1
	pla
	sta __v76_00
	jsr __f76
	ldx #$00
	rts
__L0228:
	lda #$00
	ldx #$00
	sta __g55
	lda __v7c_00
	ldx __v7c_00+1
	pha
	txa
	pha
	lda __v7c_01
	ldx #$00
	pha
	txa
	pha
	jmp __L022e
__L022d:
	byte $62
	byte $79
	byte $74
	byte $65
	byte $00
__L022e:
	lda #<__L022d
	ldx #>__L022d
	pha
	txa
	pha
	lda #$04
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v57_03
	pla
	sta __v57_02+1
	pla
	sta __v57_02
	pla
	pla
	sta __v57_01
	pla
	sta __v57_00+1
	pla
	sta __v57_00
	jsr __f57
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L022f
	jmp __L022c
__L022f:
	lda __v7c_02
	ldx __v7c_02+1
	pha
	txa
	pha
	lda __v7c_03
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v74_02
	pla
	pla
	sta __v74_01
	pla
	sta __v74_00+1
	pla
	sta __v74_00
	jsr __f74
	ldx #$00
	rts
__L022c:
	lda __v7c_00
	ldx __v7c_00+1
	pha
	txa
	pha
	lda __v7c_01
	ldx #$00
	pha
	txa
	pha
	jmp __L0232
__L0231:
	byte $77
	byte $6f
	byte $72
	byte $64
	byte $00
__L0232:
	lda #<__L0231
	ldx #>__L0231
	pha
	txa
	pha
	lda #$04
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v57_03
	pla
	sta __v57_02+1
	pla
	sta __v57_02
	pla
	pla
	sta __v57_01
	pla
	sta __v57_00+1
	pla
	sta __v57_00
	jsr __f57
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0233
	jmp __L0230
__L0233:
	lda __v7c_02
	ldx __v7c_02+1
	pha
	txa
	pha
	lda __v7c_03
	ldx #$00
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v74_02
	pla
	pla
	sta __v74_01
	pla
	sta __v74_00+1
	pla
	sta __v74_00
	jsr __f74
	ldx #$00
	rts
__L0230:
	lda __v7c_00
	ldx __v7c_00+1
	pha
	txa
	pha
	lda __v7c_01
	ldx #$00
	pha
	txa
	pha
	jmp __L0236
__L0235:
	byte $73
	byte $74
	byte $72
	byte $69
	byte $6e
	byte $67
	byte $00
__L0236:
	lda #<__L0235
	ldx #>__L0235
	pha
	txa
	pha
	lda #$06
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v57_03
	pla
	sta __v57_02+1
	pla
	sta __v57_02
	pla
	pla
	sta __v57_01
	pla
	sta __v57_00+1
	pla
	sta __v57_00
	jsr __f57
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0237
	jmp __L0234
__L0237:
	lda __v7c_02
	ldx __v7c_02+1
	pha
	txa
	pha
	lda __v7c_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v75_01
	pla
	sta __v75_00+1
	pla
	sta __v75_00
	jsr __f75
	ldx #$00
	rts
__L0234:
	lda __v7c_00
	ldx __v7c_00+1
	pha
	txa
	pha
	lda __v7c_01
	ldx #$00
	pha
	txa
	pha
	lda __v7c_02
	ldx __v7c_02+1
	pha
	txa
	pha
	lda __v7c_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v72_03
	pla
	sta __v72_02+1
	pla
	sta __v72_02
	pla
	pla
	sta __v72_01
	pla
	sta __v72_00+1
	pla
	sta __v72_00
	jsr __f72
	ldx #$00
	rts
__f7d:
__v7d_00 = NC_BSS+$8023
__v7d_01 = NC_BSS+$8024
__v7d_02 = NC_BSS+$8025
__v7d_03 = NC_BSS+$8026
__v7d_04 = NC_BSS+$8027
__v7d_05 = NC_BSS+$8028
	lda #$00
	ldx #$00
	sta __v7d_00
__L0238:
	ldy __v7d_00
	cpy __g28
	bcc __L023a
	jmp __L0239
__L023a:
__L023b:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda __g28
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L023d
	jmp __L023c
__L023d:
	lda __v7d_00
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	pha
	txa
	pha
	lda #$20
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L023f
	jmp __L023e
__L023f:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v7d_00
	jmp __L0240
__L023e:
	lda __v7d_00
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	pha
	txa
	pha
	lda #$09
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0242
	jmp __L0241
__L0242:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v7d_00
	jmp __L0243
__L0241:
	jmp __L023c
__L0243:
__L0240:
	jmp __L023b
__L023c:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda __g28
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0245
	jmp __L0244
__L0245:
	lda __g05
	ldx #$00
	rts
__L0244:
	lda __v7d_00
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	pha
	txa
	pha
	lda #$3b
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0247
	jmp __L0246
__L0247:
	lda __g05
	ldx #$00
	rts
__L0246:
	lda __v7d_00
	ldx #$00
	sta __v7d_01
__L0248:
	ldy __v7d_00
	cpy __g28
	bcc __L024a
	jmp __L0249
__L024a:
	lda __v7d_00
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	pha
	txa
	pha
	lda #$20
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L024c
	jmp __L024b
__L024c:
	jmp __L0249
__L024b:
	lda __v7d_00
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	pha
	txa
	pha
	lda #$09
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L024e
	jmp __L024d
__L024e:
	jmp __L0249
__L024d:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v7d_00
	jmp __L0248
__L0249:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda __v7d_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __v7d_02
	lda __v7d_02
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0250
	jmp __L024f
__L0250:
	lda __g06
	ldx #$00
	rts
__L024f:
	lda __v7d_01
	ldx #$00
	pha
	txa
	pha
	lda __v7d_02
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	clc
	adc #<__g27
	sta NC_PTR
	txa
	adc #>__g27
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda #$3a
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0252
	jmp __L0251
__L0252:
	lda #<__g27
	ldx #>__g27
	pha
	txa
	pha
	lda __v7d_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v7d_02
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	pla
	pla
	sta __v7a_01
	pla
	sta __v7a_00+1
	pla
	sta __v7a_00
	jsr __f7a
	ldx #$00
	sta __v7d_05
	lda __v7d_05
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0254
	jmp __L0253
__L0254:
	lda __v7d_05
	ldx #$00
	rts
__L0253:
	jmp __L0255
__L0251:
__L0256:
	ldy __v7d_00
	cpy __g28
	bcc __L0258
	jmp __L0257
__L0258:
	lda __v7d_00
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	pha
	txa
	pha
	lda #$20
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L025a
	jmp __L0259
__L025a:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v7d_00
	jmp __L025b
__L0259:
	lda __v7d_00
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	pha
	txa
	pha
	lda #$09
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L025d
	jmp __L025c
__L025d:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v7d_00
	jmp __L025e
__L025c:
	jmp __L0257
__L025e:
__L025b:
	jmp __L0256
__L0257:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda __g28
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0260
	jmp __L025f
__L0260:
	lda __v7d_00
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	pha
	txa
	pha
	lda #$3d
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0262
	jmp __L0261
__L0262:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v7d_00
__L0263:
	ldy __v7d_00
	cpy __g28
	bcc __L0265
	jmp __L0264
__L0265:
	lda __v7d_00
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	pha
	txa
	pha
	lda #$20
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0267
	jmp __L0266
__L0267:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v7d_00
	jmp __L0268
__L0266:
	lda __v7d_00
	ldx #$00
	tay
	lda __g27,y
	ldx #$00
	pha
	txa
	pha
	lda #$09
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L026a
	jmp __L0269
__L026a:
	lda __v7d_00
	ldx #$00
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v7d_00
	jmp __L026b
__L0269:
	jmp __L0264
__L026b:
__L0268:
	jmp __L0263
__L0264:
	lda __v7d_00
	ldx #$00
	sta __v7d_03
	lda __v7d_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v79_00
	jsr __f79
	sta __v7d_04
	lda __v7d_04
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L026d
	jmp __L026c
__L026d:
	lda __g07
	ldx #$00
	rts
__L026c:
	lda #<__g27
	ldx #>__g27
	pha
	txa
	pha
	lda __v7d_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v7d_02
	ldx #$00
	pha
	txa
	pha
	lda #<__g27
	ldx #>__g27
	pha
	txa
	pha
	lda __v7d_03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v7d_04
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v7b_03
	pla
	sta __v7b_02+1
	pla
	sta __v7b_02
	pla
	pla
	sta __v7b_01
	pla
	sta __v7b_00+1
	pla
	sta __v7b_00
	jsr __f7b
	ldx #$00
	rts
__L0261:
__L025f:
	lda __v7d_00
	ldx #$00
	sta __v7d_03
	lda __v7d_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v79_00
	jsr __f79
	sta __v7d_04
	lda #<__g27
	ldx #>__g27
	pha
	txa
	pha
	lda __v7d_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v7d_02
	ldx #$00
	pha
	txa
	pha
	lda #<__g27
	ldx #>__g27
	pha
	txa
	pha
	lda __v7d_03
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	pha
	txa
	pha
	lda __v7d_04
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v7c_03
	pla
	sta __v7c_02+1
	pla
	sta __v7c_02
	pla
	pla
	sta __v7c_01
	pla
	sta __v7c_00+1
	pla
	sta __v7c_00
	jsr __f7c
	ldx #$00
	rts
__L0255:
	jmp __L0238
__L0239:
	lda __g05
	ldx #$00
	rts
__v7e_00 = NC_BSS+$8029
__v7e_01 = NC_BSS+$802b
__v7e_02 = NC_BSS+$802d
__f7e:
	lda #$00
	ldx #$00
	sta __g25
	stx __g25+1
	lda __v7e_00
	ldx __v7e_00+1
	pha
	txa
	pha
	lda #$ff
	ldx #$ff
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	and NC_TMP
	tay
	txa
	and NC_TMP+1
	tax
	tya
	sta __g26
	stx __g26+1
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	tax
	pla
	sta __g2b
	stx __g2b+1
	lda __v7e_01
	ldx __v7e_01+1
	sta __g2c
	stx __g2c+1
	lda __v7e_02
	ldx #$00
	sta __g2d
	lda #$00
	ldx #$00
	sta __g34
	stx __g34+1
	lda #$00
	ldx #$00
	sta __g35
	stx __g35+1
	lda #$00
	ldx #$00
	sta __g36
	lda #$00
	ldx #$00
	sta __g3c
	stx __g3c+1
	lda #$01
	ldx #$00
	sta __g55
	lda __g05
	ldx #$00
	rts
__f7f:
__v7f_00 = NC_BSS+$802e
	lda #$00
	ldx #$00
	sta __v7f_00
	stx __v7f_00+1
__L026e:
	lda __v7f_00
	ldx __v7f_00+1
	pha
	txa
	pha
	lda __g34
	ldx __g34+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0270
	jmp __L026f
__L0270:
	lda __v7f_00
	ldx __v7f_00+1
	clc
	adc #<__g32
	sta NC_PTR
	txa
	adc #>__g32
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __g3e
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0272
	jmp __L0271
__L0272:
	lda #$00
	ldx #$00
	rts
__L0271:
	lda __v7f_00
	ldx __v7f_00+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v7f_00
	stx __v7f_00+1
	jmp __L026e
__L026f:
	lda #$01
	ldx #$00
	rts
__f80:
__v80_00 = NC_BSS+$8030
	lda #$00
	ldx #$00
	sta __v80_00
	stx __v80_00+1
__L0273:
	lda __v80_00
	ldx __v80_00+1
	pha
	txa
	pha
	lda __g3c
	ldx __g3c+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0275
	jmp __L0274
__L0275:
	lda __v80_00
	ldx __v80_00+1
	clc
	adc #<__g37
	sta NC_PTR
	txa
	adc #>__g37
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	lda __g50
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0277
	jmp __L0276
__L0277:
	lda #$00
	ldx #$00
	rts
__L0276:
	lda __v80_00
	ldx __v80_00+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	clc
	adc NC_TMP
	tay
	txa
	adc NC_TMP+1
	tax
	tya
	sta __v80_00
	stx __v80_00+1
	jmp __L0273
__L0274:
	lda #$01
	ldx #$00
	rts
__v81_00 = NC_BSS+$8032
__v81_01 = NC_BSS+$8034
__v81_02 = NC_BSS+$8035
__v81_03 = NC_BSS+$8037
__v81_04 = NC_BSS+$8038
__f81:
__v81_05 = NC_BSS+$803a
__v81_06 = NC_BSS+$803c
__v81_07 = NC_BSS+$803e
	lda __v81_04
	ldx __v81_04+1
	pha
	txa
	pha
	lda __v81_02
	ldx __v81_02+1
	pha
	txa
	pha
	lda __v81_03
	ldx #$00
	pha
	txa
	pha
	pla
	pla
	sta __v7e_02
	pla
	sta __v7e_01+1
	pla
	sta __v7e_01
	pla
	sta __v7e_00+1
	pla
	sta __v7e_00
	jsr __f7e
	ldx #$00
	lda __v81_00
	ldx __v81_00+1
	pha
	txa
	pha
	lda __v81_01
	ldx #$00
	pha
	txa
	pha
	pla
	sta __c_io_open__v01+1
	pla
	sta __c_io_open__v01
	pla
	sta __c_io_open__v00+1
	pla
	sta __c_io_open__v00
	jsr __c_io_open
	sta __v81_05
	stx __v81_05+1
	lda __v81_05
	ldx __v81_05+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_slt16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0279
	jmp __L0278
__L0279:
	lda __g10
	ldx #$00
	rts
__L0278:
	lda #$00
	ldx #$00
	sta __g2b
	stx __g2b+1
	lda #$00
	ldx #$00
	clc
	adc #<__g2a
	sta NC_PTR
	txa
	adc #>__g2a
	sta NC_PTR+1
	lda NC_PTR
	ldx NC_PTR+1
	pha
	txa
	pha
	lda __v81_05
	ldx __v81_05+1
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	sta NC_PTR+1
	pla
	sta NC_PTR
	ldy #$00
	lda NC_TMP
	sta (NC_PTR),y
__L027a:
	lda __g2b
	ldx __g2b+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_sge16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L027c
	jmp __L027b
__L027c:
	jsr __f77
	sta __v81_06
	stx __v81_06+1
	lda __v81_06
	ldx __v81_06+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L027e
	jmp __L027d
__L027e:
	jsr __f7d
	ldx #$00
	sta __v81_07
	lda __v81_07
	ldx #$00
	pha
	txa
	pha
	lda __g05
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_ne16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0280
	jmp __L027f
__L0280:
	jsr __f78
	ldx #$00
	lda __v81_07
	ldx #$00
	rts
__L027f:
	jmp __L0281
__L027d:
	lda __v81_06
	ldx __v81_06+1
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0283
	jmp __L0282
__L0283:
	lda __g2b
	ldx __g2b+1
	clc
	adc #<__g2a
	sta NC_PTR
	txa
	adc #>__g2a
	sta NC_PTR+1
	ldy #$00
	lda (NC_PTR),y
	ldx #$00
	pha
	txa
	pha
	pla
	sta __c_io_close__v00+1
	pla
	sta __c_io_close__v00
	jsr __c_io_close
	lda __g2b
	ldx __g2b+1
	pha
	txa
	pha
	lda #$01
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	sec
	sbc NC_TMP
	tay
	txa
	sbc NC_TMP+1
	tax
	tya
	sta __g2b
	stx __g2b+1
	jmp __L0284
__L0282:
	jsr __f78
	ldx #$00
	lda __v81_06
	ldx __v81_06+1
	pha
	txa
	pha
	lda #$02
	ldx #$00
	pha
	txa
	pha
	pla
	tax
	pla
	eor #$ff
	clc
	adc #$01
	tay
	txa
	eor #$ff
	adc #$00
	tax
	tya
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0286
	jmp __L0285
__L0286:
	lda __g11
	ldx #$00
	rts
__L0285:
	lda __g10
	ldx #$00
	rts
__L0284:
__L0281:
	jmp __L027a
__L027b:
	jsr __f7f
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L0288
	jmp __L0287
__L0288:
	lda __g0b
	ldx #$00
	rts
__L0287:
	jsr __f80
	ldx #$00
	pha
	txa
	pha
	lda #$00
	ldx #$00
	pha
	txa
	pha
	pla
	sta NC_TMP+1
	pla
	sta NC_TMP
	pla
	tax
	pla
	jsr __nc_eq16
	sta NC_TMP
	txa
	ora NC_TMP
	bne __L028a
	jmp __L0289
__L028a:
	lda __g0b
	ldx #$00
	rts
__L0289:
	lda __g05
	ldx #$00
	rts
__nc_bss_bytes = $803f
	include "../nanoc1/target/runtime.asm"
__nc_entry:
	jsr __nc_init
	lda #$00
	ldx #$00
	rts
