* = $0800
MODE_ZERO_PAGE = $4000
MODE_ZERO_PAGE_X = $4002
MODE_ZERO_PAGE_Y = $4004
__L_short_mode_for_index_index = $4006
short_mode_for_index:
__F_short_mode_for_index_entry:
    lda __L_short_mode_for_index_index
    cmp #$01
    beq __F_short_mode_for_index_yes_1
    jmp __F_short_mode_for_index_join_3
__F_short_mode_for_index_yes_1:
    lda MODE_ZERO_PAGE_X
    ldx #$00
    rts
__F_short_mode_for_index_join_3:
    lda __L_short_mode_for_index_index
    cmp #$02
    beq __F_short_mode_for_index_yes_4
    jmp __F_short_mode_for_index_join_6
__F_short_mode_for_index_yes_4:
    lda MODE_ZERO_PAGE_Y
    ldx #$00
    rts
__F_short_mode_for_index_join_6:
    lda MODE_ZERO_PAGE
    ldx #$00
    rts
