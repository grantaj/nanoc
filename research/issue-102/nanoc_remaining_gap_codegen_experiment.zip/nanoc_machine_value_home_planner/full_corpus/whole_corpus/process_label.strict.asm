* = $0800
__ap = $0010
ASSEMBLE_BAD_STATEMENT = $4000
ASSEMBLE_SCOPE_ERROR = $4002
__L_process_label_length = $4004
__L_process_label_name = $4006
__L_process_label_status = $4008
__L_process_label_value = $400a
__T_process_label___v23 = $400c
__T_process_label___v25 = $400e
__T_process_label___v26 = $4010
__T_process_label___v27 = $4012
__T_process_label___v28 = $4014
__T_process_label___v6 = $4016
__call_define_label_0 = $4018
__call_define_label_1 = $401a
__call_define_label_2 = $401c
ass_image_length = $401e
ass_origin = $4020
current_scope = $4022
define_label = $4024
origin_allowed = $4026
process_label:
__F_process_label_entry:
    lda __L_process_label_length
    cmp #$00
    beq __F_process_label_yes_1
    jmp __F_process_label_join_3
__F_process_label_yes_1:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_process_label_join_3:
    ldy #$00
    lda __L_process_label_name
    sta __ap
    lda __L_process_label_name+1
    sta __ap+1
    lda (__ap),y
    sta __T_process_label___v6
    cmp #$2e
    beq __F_process_label_yes_4
    jmp __F_process_label_no_5
__F_process_label_yes_4:
    lda current_scope
    cmp #$00
    beq __F_process_label_yes_7
    jmp __F_process_label_join_6
__F_process_label_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_process_label_no_5:
    lda current_scope
    cmp #$ff
    beq __F_process_label_yes_10
    jmp __F_process_label_join_12
__F_process_label_yes_10:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_process_label_join_12:
    inc current_scope
__F_process_label_join_6:
    lda #$00
    sta origin_allowed
    lda ass_origin
    clc
    adc ass_image_length
    sta __T_process_label___v23
    lda ass_origin+1
    adc ass_image_length+1
    sta __T_process_label___v23+1
    lda __T_process_label___v23
    sta __T_process_label___v25
    lda __T_process_label___v23+1
    sta __T_process_label___v25+1
    lda __T_process_label___v25
    sta __L_process_label_value
    lda __T_process_label___v25+1
    sta __L_process_label_value+1
    lda __L_process_label_name
    sta __T_process_label___v26
    lda __L_process_label_name+1
    sta __T_process_label___v26+1
    lda __L_process_label_length
    sta __T_process_label___v27
    lda __L_process_label_value
    sta __T_process_label___v28
    lda __L_process_label_value+1
    sta __T_process_label___v28+1
    lda __T_process_label___v26
    sta __call_define_label_0
    lda __T_process_label___v26+1
    sta __call_define_label_0+1
    lda __T_process_label___v27
    sta __call_define_label_1
    lda __T_process_label___v28
    sta __call_define_label_2
    lda __T_process_label___v28+1
    sta __call_define_label_2+1
    jsr define_label
    sta __L_process_label_status
    lda __L_process_label_status
    ldx #$00
    rts
