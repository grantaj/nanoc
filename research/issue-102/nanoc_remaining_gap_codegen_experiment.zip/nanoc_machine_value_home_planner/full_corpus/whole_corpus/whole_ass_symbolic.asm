__call_ass_assemble_4 = __L_ass_assemble_default_origin
__call_ass_assemble_3 = __L_ass_assemble_directory_length
__call_ass_assemble_2 = __L_ass_assemble_directory
__call_ass_assemble_1 = __L_ass_assemble_root_name_length
__call_ass_assemble_0 = __L_ass_assemble_root_name
__call_reset_assembler_2 = __L_reset_assembler_directory_length
__call_reset_assembler_1 = __L_reset_assembler_directory
__call_reset_assembler_0 = __L_reset_assembler_default_origin
__call_process_instruction_like_3 = __L_process_instruction_like_argument_length
__call_process_instruction_like_2 = __L_process_instruction_like_argument
__call_process_instruction_like_1 = __L_process_instruction_like_name_length
__call_process_instruction_like_0 = __L_process_instruction_like_name
__call_process_symbol_3 = __L_process_symbol_argument_length
__call_process_symbol_2 = __L_process_symbol_argument
__call_process_symbol_1 = __L_process_symbol_name_length
__call_process_symbol_0 = __L_process_symbol_name
__call_process_label_1 = __L_process_label_length
__call_process_label_0 = __L_process_label_name
__call_scan_argument_0 = __L_scan_argument_start
__call_open_include_1 = __L_open_include_length
__call_open_include_0 = __L_open_include_argument
__call_assemble_string_1 = __L_assemble_string_length
__call_assemble_string_0 = __L_assemble_string_argument
__call_assemble_data_list_2 = __L_assemble_data_list_width
__call_assemble_data_list_1 = __L_assemble_data_list_length
__call_assemble_data_list_0 = __L_assemble_data_list_argument
__call_stage_data_value_2 = __L_stage_data_value_width
__call_stage_data_value_1 = __L_stage_data_value_length
__call_stage_data_value_0 = __L_stage_data_value_text
__call_assemble_instruction_3 = __L_assemble_instruction_argument_length
__call_assemble_instruction_2 = __L_assemble_instruction_argument
__call_assemble_instruction_1 = __L_assemble_instruction_name_length
__call_assemble_instruction_0 = __L_assemble_instruction_name
__call_assemble_direct_value_3 = __L_assemble_direct_value_index
__call_assemble_direct_value_2 = __L_assemble_direct_value_length
__call_assemble_direct_value_1 = __L_assemble_direct_value_text
__call_assemble_direct_value_0 = __L_assemble_direct_value_mnemonic
__call_assemble_mode_value_3 = __L_assemble_mode_value_length
__call_assemble_mode_value_2 = __L_assemble_mode_value_text
__call_assemble_mode_value_1 = __L_assemble_mode_value_mode
__call_assemble_mode_value_0 = __L_assemble_mode_value_mnemonic
__call_long_mode_for_index_0 = __L_long_mode_for_index_index
__call_short_mode_for_index_0 = __L_short_mode_for_index_index
__call_stage_unresolved_instruction_4 = __L_stage_unresolved_instruction_prefix
__call_stage_unresolved_instruction_3 = __L_stage_unresolved_instruction_addend
__call_stage_unresolved_instruction_2 = __L_stage_unresolved_instruction_symbol
__call_stage_unresolved_instruction_1 = __L_stage_unresolved_instruction_mode
__call_stage_unresolved_instruction_0 = __L_stage_unresolved_instruction_opcode
__call_stage_resolved_relative_1 = __L_stage_resolved_relative_target
__call_stage_resolved_relative_0 = __L_stage_resolved_relative_opcode
__call_stage_resolved_instruction_2 = __L_stage_resolved_instruction_value
__call_stage_resolved_instruction_1 = __L_stage_resolved_instruction_mode
__call_stage_resolved_instruction_0 = __L_stage_resolved_instruction_opcode
__call_stage_plain_word_reference_0 = __L_stage_plain_word_reference_symbol
__call_stage_byte_0 = __L_stage_byte_value
__call_find_opcode_1 = __L_find_opcode_mode
__call_find_opcode_0 = __L_find_opcode_mnemonic
__call_find_mnemonic_1 = __L_find_mnemonic_length
__call_find_mnemonic_0 = __L_find_mnemonic_name
__call_parse_value_1 = __L_parse_value_length
__call_parse_value_0 = __L_parse_value_text
__call_parse_atom_1 = __L_parse_atom_length
__call_parse_atom_0 = __L_parse_atom_text
__call_define_label_2 = __L_define_label_value
__call_define_label_1 = __L_define_label_length
__call_define_label_0 = __L_define_label_name
__call_patch_word_chain_1 = __L_patch_word_chain_value
__call_patch_word_chain_0 = __L_patch_word_chain_head
__call_define_constant_2 = __L_define_constant_value
__call_define_constant_1 = __L_define_constant_length
__call_define_constant_0 = __L_define_constant_name
__call_intern_label_1 = __L_intern_label_length
__call_intern_label_0 = __L_intern_label_name
__call_allocate_symbol_3 = __L_allocate_symbol_payload
__call_allocate_symbol_2 = __L_allocate_symbol_kind
__call_allocate_symbol_1 = __L_allocate_symbol_length
__call_allocate_symbol_0 = __L_allocate_symbol_name
__call_find_symbol_1 = __L_find_symbol_length
__call_find_symbol_0 = __L_find_symbol_name
__call_scope_for_name_1 = __L_scope_for_name_length
__call_scope_for_name_0 = __L_scope_for_name_name
__call_resolve_fixups_for_symbol_0 = __L_resolve_fixups_for_symbol_symbol
__call_relative_byte_1 = __L_relative_byte_base
__call_relative_byte_0 = __L_relative_byte_target
__call_append_fixup_4 = __L_append_fixup_prefix
__call_append_fixup_3 = __L_append_fixup_addend
__call_append_fixup_2 = __L_append_fixup_symbol
__call_append_fixup_1 = __L_append_fixup_stage
__call_append_fixup_0 = __L_append_fixup_kind
__call_hex_nibble_0 = __L_hex_nibble_c
__call_apply_byte_prefix_1 = __L_apply_byte_prefix_prefix
__call_apply_byte_prefix_0 = __L_apply_byte_prefix_value
__call_same_text_3 = __L_same_text_b_length
__call_same_text_2 = __L_same_text_b
__call_same_text_1 = __L_same_text_a_length
__call_same_text_0 = __L_same_text_a
__call_upper_char_0 = __L_upper_char_c
upper_char:
__F_upper_char_entry:
    lda __L_upper_char_c
    cmp #$61
    bcs __F_upper_char_yes_1
    jmp __F_upper_char_join_3
__F_upper_char_yes_1:
    lda __L_upper_char_c
    cmp #$7a
    bcc __F_upper_char_yes_4
    beq __F_upper_char_yes_4
    jmp __F_upper_char_join_3
__F_upper_char_yes_4:
    lda __L_upper_char_c
    sec
    sbc #$20
    sta __T_upper_char___v8
    lda #$00
    sbc #$00
    sta __T_upper_char___v8+1
    lda __T_upper_char___v8
    ldx #$00
    rts
__F_upper_char_join_3:
    lda __L_upper_char_c
    ldx #$00
    rts
same_text:
__F_same_text_entry:
    lda __L_same_text_a_length
    cmp __L_same_text_b_length
    bne __F_same_text_yes_1
    jmp __F_same_text_join_3
__F_same_text_yes_1:
    lda #$00
    ldx #$00
    rts
__F_same_text_join_3:
    lda #$00
    sta __L_same_text_i
__F_same_text_while_4:
    lda __L_same_text_i
    cmp __L_same_text_a_length
    bcc __F_same_text_body_5
    jmp __F_same_text_after_6
__F_same_text_body_5:
    ldy __L_same_text_i
    lda __L_same_text_a
    sta __ap
    lda __L_same_text_a+1
    sta __ap+1
    lda (__ap),y
    sta __T_same_text___v10
    ldy __L_same_text_i
    lda __L_same_text_b
    sta __ap
    lda __L_same_text_b+1
    sta __ap+1
    lda (__ap),y
    sta __T_same_text___v13
    lda __T_same_text___v10
    cmp __T_same_text___v13
    bne __F_same_text_yes_7
    jmp __F_same_text_join_9
__F_same_text_yes_7:
    lda #$00
    ldx #$00
    rts
__F_same_text_join_9:
    inc __L_same_text_i
    jmp __F_same_text_while_4
__F_same_text_after_6:
    lda #$01
    ldx #$00
    rts
apply_byte_prefix:
__F_apply_byte_prefix_entry:
    lda __L_apply_byte_prefix_value
    sta __T_apply_byte_prefix___v2
    lda __L_apply_byte_prefix_value+1
    sta __T_apply_byte_prefix___v2+1
    lda __T_apply_byte_prefix___v2
    sta __L_apply_byte_prefix_value
    lda __T_apply_byte_prefix___v2+1
    sta __L_apply_byte_prefix_value+1
    lda __L_apply_byte_prefix_prefix
    cmp VALUE_PREFIX_LOW
    beq __F_apply_byte_prefix_yes_1
    jmp __F_apply_byte_prefix_join_3
__F_apply_byte_prefix_yes_1:
    lda __L_apply_byte_prefix_value
    and #$ff
    sta __T_apply_byte_prefix___v8
    lda __L_apply_byte_prefix_value+1
    and #$00
    sta __T_apply_byte_prefix___v8+1
    lda __T_apply_byte_prefix___v8
    ldx #$00
    rts
__F_apply_byte_prefix_join_3:
    lda __L_apply_byte_prefix_value
    sta __T_apply_byte_prefix___v11
    lda __L_apply_byte_prefix_value+1
    sta __T_apply_byte_prefix___v11+1
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lda __T_apply_byte_prefix___v11
    and #$ff
    sta __T_apply_byte_prefix___v13
    lda __T_apply_byte_prefix___v11+1
    and #$00
    sta __T_apply_byte_prefix___v13+1
    lda __T_apply_byte_prefix___v13
    ldx #$00
    rts
hex_nibble:
__F_hex_nibble_entry:
    lda __L_hex_nibble_c
    sta __T_hex_nibble___v0
    lda __T_hex_nibble___v0
    sta __call_upper_char_0
    jsr upper_char
    sta __L_hex_nibble_c
    lda __L_hex_nibble_c
    cmp #$30
    bcs __F_hex_nibble_yes_1
    jmp __F_hex_nibble_join_3
__F_hex_nibble_yes_1:
    lda __L_hex_nibble_c
    cmp #$39
    bcc __F_hex_nibble_yes_4
    beq __F_hex_nibble_yes_4
    jmp __F_hex_nibble_join_3
__F_hex_nibble_yes_4:
    lda __L_hex_nibble_c
    sec
    sbc #$30
    sta __T_hex_nibble___v10
    lda #$00
    sbc #$00
    sta __T_hex_nibble___v10+1
    lda __T_hex_nibble___v10
    ldx __T_hex_nibble___v10+1
    rts
__F_hex_nibble_join_3:
    lda __L_hex_nibble_c
    cmp #$41
    bcs __F_hex_nibble_yes_7
    jmp __F_hex_nibble_join_9
__F_hex_nibble_yes_7:
    lda __L_hex_nibble_c
    cmp #$46
    bcc __F_hex_nibble_yes_10
    beq __F_hex_nibble_yes_10
    jmp __F_hex_nibble_join_9
__F_hex_nibble_yes_10:
    lda __L_hex_nibble_c
    sec
    sbc #$41
    sta __T_hex_nibble___v19
    lda #$00
    sbc #$00
    sta __T_hex_nibble___v19+1
    lda __T_hex_nibble___v19
    clc
    adc #$0a
    sta __T_hex_nibble___v21
    lda __T_hex_nibble___v19+1
    adc #$00
    sta __T_hex_nibble___v21+1
    lda __T_hex_nibble___v21
    ldx __T_hex_nibble___v21+1
    rts
__F_hex_nibble_join_9:
    sec
    lda #$00
    sbc #$01
    sta __T_hex_nibble___v23
    lda #$00
    sbc #$00
    sta __T_hex_nibble___v23+1
    lda __T_hex_nibble___v23
    ldx __T_hex_nibble___v23+1
    rts
append_fixup:
__F_append_fixup_entry:
    lda fixup_count
    sta __L_append_fixup_n
    lda fixup_count+1
    sta __L_append_fixup_n+1
    lda #$02
    eor #$80
    sta __rh
    lda __L_append_fixup_n+1
    eor #$80
    cmp __rh
    bcc __F_append_fixup___sel1
    bne __F_append_fixup___sel2
    lda __L_append_fixup_n
    cmp #$80
    bcc __F_append_fixup___sel1
    bne __F_append_fixup___sel2
    jmp __F_append_fixup___sel3
__F_append_fixup___sel1:
    jmp __F_append_fixup_join_3
__F_append_fixup___sel2:
    jmp __F_append_fixup_yes_1
__F_append_fixup___sel3:
    jmp __F_append_fixup_yes_1
__F_append_fixup_yes_1:
    lda ASSEMBLE_WORK_FULL
    ldx #$00
    rts
__F_append_fixup_join_3:
    lda __L_append_fixup_n
    sta __T_append_fixup___v6
    lda __L_append_fixup_n+1
    sta __T_append_fixup___v6+1
    lda __L_append_fixup_kind
    sta __T_append_fixup___v7
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda __T_append_fixup___v6
    sta __ix
    lda __T_append_fixup___v6+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_append_fixup___v7
    sta (__ap),y
    lda __L_append_fixup_n
    sta __T_append_fixup___v9
    lda __L_append_fixup_n+1
    sta __T_append_fixup___v9+1
    lda __L_append_fixup_stage
    sta __T_append_fixup___v10
    lda __L_append_fixup_stage+1
    sta __T_append_fixup___v10+1
    lda #<fixup_stage
    sta __ap
    lda #>fixup_stage
    sta __ap+1
    lda __T_append_fixup___v9
    asl
    sta __ix
    lda __T_append_fixup___v9+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_append_fixup___v10
    sta (__ap),y
    iny
    lda __T_append_fixup___v10+1
    sta (__ap),y
    lda __L_append_fixup_n
    sta __T_append_fixup___v12
    lda __L_append_fixup_n+1
    sta __T_append_fixup___v12+1
    lda __L_append_fixup_symbol
    sta __T_append_fixup___v13
    lda __L_append_fixup_symbol+1
    sta __T_append_fixup___v13+1
    lda #<fixup_symbol
    sta __ap
    lda #>fixup_symbol
    sta __ap+1
    lda __T_append_fixup___v12
    asl
    sta __ix
    lda __T_append_fixup___v12+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_append_fixup___v13
    sta (__ap),y
    iny
    lda __T_append_fixup___v13+1
    sta (__ap),y
    lda __L_append_fixup_n
    sta __T_append_fixup___v15
    lda __L_append_fixup_n+1
    sta __T_append_fixup___v15+1
    lda __L_append_fixup_addend
    sta __T_append_fixup___v18
    lda __L_append_fixup_addend+1
    sta __T_append_fixup___v18+1
    lda #<fixup_addend
    sta __ap
    lda #>fixup_addend
    sta __ap+1
    lda __T_append_fixup___v15
    asl
    sta __ix
    lda __T_append_fixup___v15+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_append_fixup___v18
    sta (__ap),y
    iny
    lda __T_append_fixup___v18+1
    sta (__ap),y
    lda __L_append_fixup_n
    sta __T_append_fixup___v20
    lda __L_append_fixup_n+1
    sta __T_append_fixup___v20+1
    lda __L_append_fixup_prefix
    sta __T_append_fixup___v21
    lda #<fixup_prefix
    sta __ap
    lda #>fixup_prefix
    sta __ap+1
    lda __T_append_fixup___v20
    sta __ix
    lda __T_append_fixup___v20+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_append_fixup___v21
    sta (__ap),y
    lda __L_append_fixup_n
    clc
    adc #$01
    sta fixup_count
    lda __L_append_fixup_n+1
    adc #$00
    sta fixup_count+1
    lda ASSEMBLE_OK
    ldx #$00
    rts
relative_byte:
__F_relative_byte_entry:
    lda __L_relative_byte_target
    sec
    sbc __L_relative_byte_base
    sta __T_relative_byte___v2
    lda __L_relative_byte_target+1
    sbc __L_relative_byte_base+1
    sta __T_relative_byte___v2+1
    lda __T_relative_byte___v2
    sta __T_relative_byte___v4
    lda __T_relative_byte___v2+1
    sta __T_relative_byte___v4+1
    lda __T_relative_byte___v4
    sta __L_relative_byte_difference
    lda __T_relative_byte___v4+1
    sta __L_relative_byte_difference+1
    lda __L_relative_byte_difference+1
    cmp #$00
    bcc __F_relative_byte___sel1
    bne __F_relative_byte___sel2
    lda __L_relative_byte_difference
    cmp #$7f
    bcc __F_relative_byte___sel1
    bne __F_relative_byte___sel2
    jmp __F_relative_byte___sel3
__F_relative_byte___sel1:
    jmp __F_relative_byte_yes_1
__F_relative_byte___sel2:
    jmp __F_relative_byte_join_3
__F_relative_byte___sel3:
    jmp __F_relative_byte_yes_1
__F_relative_byte_yes_1:
    lda __L_relative_byte_difference
    ldx __L_relative_byte_difference+1
    rts
__F_relative_byte_join_3:
    lda __L_relative_byte_difference+1
    cmp #$ff
    bcc __F_relative_byte___sel4
    bne __F_relative_byte___sel5
    lda __L_relative_byte_difference
    cmp #$80
    bcc __F_relative_byte___sel4
    bne __F_relative_byte___sel5
    jmp __F_relative_byte___sel6
__F_relative_byte___sel4:
    jmp __F_relative_byte_join_6
__F_relative_byte___sel5:
    jmp __F_relative_byte_yes_4
__F_relative_byte___sel6:
    jmp __F_relative_byte_yes_4
__F_relative_byte_yes_4:
    lda __L_relative_byte_difference
    and #$ff
    sta __T_relative_byte___v14
    lda __L_relative_byte_difference+1
    and #$00
    sta __T_relative_byte___v14+1
    lda __T_relative_byte___v14
    ldx __T_relative_byte___v14+1
    rts
__F_relative_byte_join_6:
    sec
    lda #$00
    sbc #$01
    sta __T_relative_byte___v16
    lda #$00
    sbc #$00
    sta __T_relative_byte___v16+1
    lda __T_relative_byte___v16
    ldx __T_relative_byte___v16+1
    rts
trim_fixups:
__F_trim_fixups_entry:
__F_trim_fixups_while_1:
    lda #$00
    eor #$80
    sta __rh
    lda fixup_count+1
    eor #$80
    cmp __rh
    bcc __F_trim_fixups___sel1
    bne __F_trim_fixups___sel2
    lda fixup_count
    cmp #$00
    bcc __F_trim_fixups___sel1
    bne __F_trim_fixups___sel2
    jmp __F_trim_fixups___sel3
__F_trim_fixups___sel1:
    jmp __F_trim_fixups_after_3
__F_trim_fixups___sel2:
    jmp __F_trim_fixups_body_2
__F_trim_fixups___sel3:
    jmp __F_trim_fixups_after_3
__F_trim_fixups_body_2:
    lda fixup_count
    sec
    sbc #$01
    sta __T_trim_fixups___v6
    lda fixup_count+1
    sbc #$00
    sta __T_trim_fixups___v6+1
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda __T_trim_fixups___v6
    sta __ix
    lda __T_trim_fixups___v6+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_trim_fixups___v7
    cmp FIXUP_NONE
    bne __F_trim_fixups_yes_4
    jmp __F_trim_fixups_join_6
__F_trim_fixups_yes_4:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_trim_fixups_join_6:
    lda fixup_count
    sec
    sbc #$01
    sta __T_trim_fixups___v13
    lda fixup_count+1
    sbc #$00
    sta __T_trim_fixups___v13+1
    lda __T_trim_fixups___v13
    sta fixup_count
    lda __T_trim_fixups___v13+1
    sta fixup_count+1
    jmp __F_trim_fixups_while_1
__F_trim_fixups_after_3:
    lda ASSEMBLE_OK
    ldx #$00
    rts
resolve_fixups_for_symbol:
__F_resolve_fixups_for_symbol_entry:
    lda #$00
    sta __L_resolve_fixups_for_symbol_i
    lda #$00
    sta __L_resolve_fixups_for_symbol_i+1
__F_resolve_fixups_for_symbol_while_1:
    lda fixup_count+1
    eor #$80
    sta __rh
    lda __L_resolve_fixups_for_symbol_i+1
    eor #$80
    cmp __rh
    bcc __F_resolve_fixups_for_symbol___sel1
    bne __F_resolve_fixups_for_symbol___sel2
    lda __L_resolve_fixups_for_symbol_i
    cmp fixup_count
    bcc __F_resolve_fixups_for_symbol___sel1
    bne __F_resolve_fixups_for_symbol___sel2
    jmp __F_resolve_fixups_for_symbol___sel3
__F_resolve_fixups_for_symbol___sel1:
    jmp __F_resolve_fixups_for_symbol_body_2
__F_resolve_fixups_for_symbol___sel2:
    jmp __F_resolve_fixups_for_symbol_after_3
__F_resolve_fixups_for_symbol___sel3:
    jmp __F_resolve_fixups_for_symbol_after_3
__F_resolve_fixups_for_symbol_body_2:
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_i
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_kind
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_NONE
    bne __F_resolve_fixups_for_symbol_yes_4
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol_yes_4:
    lda #<fixup_symbol
    sta __ap
    lda #>fixup_symbol
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_i
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v12
    iny
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v12+1
    lda __T_resolve_fixups_for_symbol___v12+1
    cmp __L_resolve_fixups_for_symbol_symbol+1
    beq __F_resolve_fixups_for_symbol___far_skip_0
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol___far_skip_0:
    lda __T_resolve_fixups_for_symbol___v12
    cmp __L_resolve_fixups_for_symbol_symbol
    beq __F_resolve_fixups_for_symbol_yes_7
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol_yes_7:
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_symbol
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v17
    iny
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v17+1
    lda #<fixup_addend
    sta __ap
    lda #>fixup_addend
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_i
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v20
    iny
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v20+1
    lda __T_resolve_fixups_for_symbol___v17
    clc
    adc __T_resolve_fixups_for_symbol___v20
    sta __T_resolve_fixups_for_symbol___v21
    lda __T_resolve_fixups_for_symbol___v17+1
    adc __T_resolve_fixups_for_symbol___v20+1
    sta __T_resolve_fixups_for_symbol___v21+1
    lda __T_resolve_fixups_for_symbol___v21
    sta __T_resolve_fixups_for_symbol___v23
    lda __T_resolve_fixups_for_symbol___v21+1
    sta __T_resolve_fixups_for_symbol___v23+1
    lda __T_resolve_fixups_for_symbol___v23
    sta __L_resolve_fixups_for_symbol_value
    lda __T_resolve_fixups_for_symbol___v23+1
    sta __L_resolve_fixups_for_symbol_value+1
    lda #<fixup_prefix
    sta __ap
    lda #>fixup_prefix
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_i
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v26
    cmp VALUE_PREFIX_NONE
    bne __F_resolve_fixups_for_symbol_yes_10
    jmp __F_resolve_fixups_for_symbol_join_12
__F_resolve_fixups_for_symbol_yes_10:
    lda __L_resolve_fixups_for_symbol_value
    sta __T_resolve_fixups_for_symbol___v29
    lda __L_resolve_fixups_for_symbol_value+1
    sta __T_resolve_fixups_for_symbol___v29+1
    lda __T_resolve_fixups_for_symbol___v29
    sta __call_apply_byte_prefix_0
    lda __T_resolve_fixups_for_symbol___v29+1
    sta __call_apply_byte_prefix_0+1
    lda __T_resolve_fixups_for_symbol___v26
    sta __call_apply_byte_prefix_1
    jsr apply_byte_prefix
    sta __T_resolve_fixups_for_symbol___v33
    lda __T_resolve_fixups_for_symbol___v33
    sta __L_resolve_fixups_for_symbol_value
    lda #$00
    sta __L_resolve_fixups_for_symbol_value+1
__F_resolve_fixups_for_symbol_join_12:
    lda #<fixup_stage
    sta __ap
    lda #>fixup_stage
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_i
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_stage
    iny
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_stage+1
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_WORD
    beq __F_resolve_fixups_for_symbol_yes_13
    jmp __F_resolve_fixups_for_symbol_no_14
__F_resolve_fixups_for_symbol_yes_13:
    lda __L_resolve_fixups_for_symbol_stage
    sta __T_resolve_fixups_for_symbol___v41
    lda __L_resolve_fixups_for_symbol_stage+1
    sta __T_resolve_fixups_for_symbol___v41+1
    lda __L_resolve_fixups_for_symbol_value
    and #$ff
    sta __T_resolve_fixups_for_symbol___v44
    lda __L_resolve_fixups_for_symbol_value+1
    and #$00
    sta __T_resolve_fixups_for_symbol___v44+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_resolve_fixups_for_symbol___v41
    sta __ix
    lda __T_resolve_fixups_for_symbol___v41+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_resolve_fixups_for_symbol___v44
    sta (__ap),y
    lda __L_resolve_fixups_for_symbol_stage
    clc
    adc #$01
    sta __T_resolve_fixups_for_symbol___v48
    lda __L_resolve_fixups_for_symbol_stage+1
    adc #$00
    sta __T_resolve_fixups_for_symbol___v48+1
    lda __L_resolve_fixups_for_symbol_value
    sta __T_resolve_fixups_for_symbol___v51
    lda __L_resolve_fixups_for_symbol_value+1
    sta __T_resolve_fixups_for_symbol___v51+1
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lda __T_resolve_fixups_for_symbol___v51
    and #$ff
    sta __T_resolve_fixups_for_symbol___v53
    lda __T_resolve_fixups_for_symbol___v51+1
    and #$00
    sta __T_resolve_fixups_for_symbol___v53+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_resolve_fixups_for_symbol___v48
    sta __ix
    lda __T_resolve_fixups_for_symbol___v48+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_resolve_fixups_for_symbol___v53
    sta (__ap),y
    jmp __F_resolve_fixups_for_symbol_join_15
__F_resolve_fixups_for_symbol_no_14:
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_RELATIVE
    beq __F_resolve_fixups_for_symbol_yes_16
    jmp __F_resolve_fixups_for_symbol_no_17
__F_resolve_fixups_for_symbol_yes_16:
    lda __L_resolve_fixups_for_symbol_value
    sta __T_resolve_fixups_for_symbol___v57
    lda __L_resolve_fixups_for_symbol_value+1
    sta __T_resolve_fixups_for_symbol___v57+1
    lda ass_origin
    clc
    adc __L_resolve_fixups_for_symbol_stage
    sta __T_resolve_fixups_for_symbol___v60
    lda ass_origin+1
    adc __L_resolve_fixups_for_symbol_stage+1
    sta __T_resolve_fixups_for_symbol___v60+1
    lda __T_resolve_fixups_for_symbol___v60
    clc
    adc #$01
    sta __T_resolve_fixups_for_symbol___v62
    lda __T_resolve_fixups_for_symbol___v60+1
    adc #$00
    sta __T_resolve_fixups_for_symbol___v62+1
    lda __T_resolve_fixups_for_symbol___v62
    sta __T_resolve_fixups_for_symbol___v64
    lda __T_resolve_fixups_for_symbol___v62+1
    sta __T_resolve_fixups_for_symbol___v64+1
    lda __T_resolve_fixups_for_symbol___v57
    sta __call_relative_byte_0
    lda __T_resolve_fixups_for_symbol___v57+1
    sta __call_relative_byte_0+1
    lda __T_resolve_fixups_for_symbol___v64
    sta __call_relative_byte_1
    lda __T_resolve_fixups_for_symbol___v64+1
    sta __call_relative_byte_1+1
    jsr relative_byte
    sta __L_resolve_fixups_for_symbol_relative
    stx __L_resolve_fixups_for_symbol_relative+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_resolve_fixups_for_symbol_relative+1
    eor #$80
    cmp __rh
    bcc __F_resolve_fixups_for_symbol___sel4
    bne __F_resolve_fixups_for_symbol___sel5
    lda __L_resolve_fixups_for_symbol_relative
    cmp #$00
    bcc __F_resolve_fixups_for_symbol___sel4
    bne __F_resolve_fixups_for_symbol___sel5
    jmp __F_resolve_fixups_for_symbol___sel6
__F_resolve_fixups_for_symbol___sel4:
    jmp __F_resolve_fixups_for_symbol_yes_19
__F_resolve_fixups_for_symbol___sel5:
    jmp __F_resolve_fixups_for_symbol_join_21
__F_resolve_fixups_for_symbol___sel6:
    jmp __F_resolve_fixups_for_symbol_join_21
__F_resolve_fixups_for_symbol_yes_19:
    lda ASSEMBLE_EMIT_ERROR
    ldx #$00
    rts
__F_resolve_fixups_for_symbol_join_21:
    lda __L_resolve_fixups_for_symbol_stage
    sta __T_resolve_fixups_for_symbol___v71
    lda __L_resolve_fixups_for_symbol_stage+1
    sta __T_resolve_fixups_for_symbol___v71+1
    lda __L_resolve_fixups_for_symbol_relative
    sta __T_resolve_fixups_for_symbol___v72
    lda __L_resolve_fixups_for_symbol_relative+1
    sta __T_resolve_fixups_for_symbol___v72+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_resolve_fixups_for_symbol___v71
    sta __ix
    lda __T_resolve_fixups_for_symbol___v71+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_resolve_fixups_for_symbol___v72
    sta (__ap),y
    jmp __F_resolve_fixups_for_symbol_join_15
__F_resolve_fixups_for_symbol_no_17:
    lda __L_resolve_fixups_for_symbol_value+1
    cmp #$00
    bcc __F_resolve_fixups_for_symbol___sel7
    bne __F_resolve_fixups_for_symbol___sel8
    lda __L_resolve_fixups_for_symbol_value
    cmp #$ff
    bcc __F_resolve_fixups_for_symbol___sel7
    bne __F_resolve_fixups_for_symbol___sel8
    jmp __F_resolve_fixups_for_symbol___sel9
__F_resolve_fixups_for_symbol___sel7:
    jmp __F_resolve_fixups_for_symbol_join_24
__F_resolve_fixups_for_symbol___sel8:
    jmp __F_resolve_fixups_for_symbol_yes_22
__F_resolve_fixups_for_symbol___sel9:
    jmp __F_resolve_fixups_for_symbol_join_24
__F_resolve_fixups_for_symbol_yes_22:
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_DATA_BYTE
    beq __F_resolve_fixups_for_symbol_yes_25
    jmp __F_resolve_fixups_for_symbol_join_27
__F_resolve_fixups_for_symbol_yes_25:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_resolve_fixups_for_symbol_join_27:
    lda ASSEMBLE_EMIT_ERROR
    ldx #$00
    rts
__F_resolve_fixups_for_symbol_join_24:
    lda __L_resolve_fixups_for_symbol_stage
    sta __T_resolve_fixups_for_symbol___v82
    lda __L_resolve_fixups_for_symbol_stage+1
    sta __T_resolve_fixups_for_symbol___v82+1
    lda __L_resolve_fixups_for_symbol_value
    sta __T_resolve_fixups_for_symbol___v83
    lda __L_resolve_fixups_for_symbol_value+1
    sta __T_resolve_fixups_for_symbol___v83+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_resolve_fixups_for_symbol___v82
    sta __ix
    lda __T_resolve_fixups_for_symbol___v82+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_resolve_fixups_for_symbol___v83
    sta (__ap),y
__F_resolve_fixups_for_symbol_join_15:
    lda __L_resolve_fixups_for_symbol_i
    sta __T_resolve_fixups_for_symbol___v85
    lda __L_resolve_fixups_for_symbol_i+1
    sta __T_resolve_fixups_for_symbol___v85+1
    lda FIXUP_NONE
    sta __T_resolve_fixups_for_symbol___v86
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda __T_resolve_fixups_for_symbol___v85
    sta __ix
    lda __T_resolve_fixups_for_symbol___v85+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_resolve_fixups_for_symbol___v86
    sta (__ap),y
__F_resolve_fixups_for_symbol_join_6:
    lda __L_resolve_fixups_for_symbol_i
    clc
    adc #$01
    sta __T_resolve_fixups_for_symbol___v89
    lda __L_resolve_fixups_for_symbol_i+1
    adc #$00
    sta __T_resolve_fixups_for_symbol___v89+1
    lda __T_resolve_fixups_for_symbol___v89
    sta __L_resolve_fixups_for_symbol_i
    lda __T_resolve_fixups_for_symbol___v89+1
    sta __L_resolve_fixups_for_symbol_i+1
    jmp __F_resolve_fixups_for_symbol_while_1
__F_resolve_fixups_for_symbol_after_3:
    jsr trim_fixups
    ldx #$00
    rts
scope_for_name:
__F_scope_for_name_entry:
    lda __L_scope_for_name_length
    cmp #$00
    beq __F_scope_for_name_yes_1
    jmp __F_scope_for_name_join_3
__F_scope_for_name_yes_1:
    sec
    lda #$00
    sbc #$01
    sta __T_scope_for_name___v4
    lda #$00
    sbc #$00
    sta __T_scope_for_name___v4+1
    lda __T_scope_for_name___v4
    ldx __T_scope_for_name___v4+1
    rts
__F_scope_for_name_join_3:
    ldy #$00
    lda __L_scope_for_name_name
    sta __ap
    lda __L_scope_for_name_name+1
    sta __ap+1
    lda (__ap),y
    sta __T_scope_for_name___v7
    cmp #$2e
    beq __F_scope_for_name_yes_4
    jmp __F_scope_for_name_join_6
__F_scope_for_name_yes_4:
    lda current_scope
    cmp #$00
    beq __F_scope_for_name_yes_7
    jmp __F_scope_for_name_join_9
__F_scope_for_name_yes_7:
    sec
    lda #$00
    sbc #$01
    sta __T_scope_for_name___v14
    lda #$00
    sbc #$00
    sta __T_scope_for_name___v14+1
    lda __T_scope_for_name___v14
    ldx __T_scope_for_name___v14+1
    rts
__F_scope_for_name_join_9:
    lda current_scope
    ldx #$00
    rts
__F_scope_for_name_join_6:
    lda #$00
    ldx #$00
    rts
find_symbol:
__F_find_symbol_entry:
    lda __L_find_symbol_name
    sta __T_find_symbol___v0
    lda __L_find_symbol_name+1
    sta __T_find_symbol___v0+1
    lda __L_find_symbol_length
    sta __T_find_symbol___v1
    lda __T_find_symbol___v0
    sta __call_scope_for_name_0
    lda __T_find_symbol___v0+1
    sta __call_scope_for_name_0+1
    lda __T_find_symbol___v1
    sta __call_scope_for_name_1
    jsr scope_for_name
    sta __L_find_symbol_wanted_scope
    stx __L_find_symbol_wanted_scope+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_find_symbol_wanted_scope+1
    eor #$80
    cmp __rh
    bcc __F_find_symbol___sel1
    bne __F_find_symbol___sel2
    lda __L_find_symbol_wanted_scope
    cmp #$00
    bcc __F_find_symbol___sel1
    bne __F_find_symbol___sel2
    jmp __F_find_symbol___sel3
__F_find_symbol___sel1:
    jmp __F_find_symbol_yes_1
__F_find_symbol___sel2:
    jmp __F_find_symbol_join_3
__F_find_symbol___sel3:
    jmp __F_find_symbol_join_3
__F_find_symbol_yes_1:
    sec
    lda #$00
    sbc #$02
    sta __T_find_symbol___v7
    lda #$00
    sbc #$00
    sta __T_find_symbol___v7+1
    lda __T_find_symbol___v7
    ldx __T_find_symbol___v7+1
    rts
__F_find_symbol_join_3:
    lda #$00
    sta __L_find_symbol_i
    lda #$00
    sta __L_find_symbol_i+1
__F_find_symbol_while_4:
    lda symbol_count+1
    eor #$80
    sta __rh
    lda __L_find_symbol_i+1
    eor #$80
    cmp __rh
    bcc __F_find_symbol___sel4
    bne __F_find_symbol___sel5
    lda __L_find_symbol_i
    cmp symbol_count
    bcc __F_find_symbol___sel4
    bne __F_find_symbol___sel5
    jmp __F_find_symbol___sel6
__F_find_symbol___sel4:
    jmp __F_find_symbol_body_5
__F_find_symbol___sel5:
    jmp __F_find_symbol_after_6
__F_find_symbol___sel6:
    jmp __F_find_symbol_after_6
__F_find_symbol_body_5:
    lda #<symbol_scope
    sta __ap
    lda #>symbol_scope
    sta __ap+1
    lda __L_find_symbol_i
    sta __ix
    lda __L_find_symbol_i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_symbol___v14
    lda #$00
    cmp __L_find_symbol_wanted_scope+1
    beq __F_find_symbol___far_skip_0
    jmp __F_find_symbol_join_9
__F_find_symbol___far_skip_0:
    lda __T_find_symbol___v14
    cmp __L_find_symbol_wanted_scope
    beq __F_find_symbol_yes_7
    jmp __F_find_symbol_join_9
__F_find_symbol_yes_7:
    lda #<symbol_name_length
    sta __ap
    lda #>symbol_name_length
    sta __ap+1
    lda __L_find_symbol_i
    sta __ix
    lda __L_find_symbol_i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_symbol___v19
    cmp __L_find_symbol_length
    beq __F_find_symbol_yes_10
    jmp __F_find_symbol_join_9
__F_find_symbol_yes_10:
    lda #<symbol_name_offset
    sta __ap
    lda #>symbol_name_offset
    sta __ap+1
    lda __L_find_symbol_i
    asl
    sta __ix
    lda __L_find_symbol_i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __L_find_symbol_offset
    iny
    lda (__ap),y
    sta __L_find_symbol_offset+1
    lda #$01
    sta __L_find_symbol_same
    lda #$00
    sta __L_find_symbol_j
__F_find_symbol_while_13:
    lda __L_find_symbol_j
    cmp __L_find_symbol_length
    bcc __F_find_symbol_body_14
    jmp __F_find_symbol_after_15
__F_find_symbol_body_14:
    lda __L_find_symbol_offset
    clc
    adc __L_find_symbol_j
    sta __T_find_symbol___v33
    lda __L_find_symbol_offset+1
    adc #$00
    sta __T_find_symbol___v33+1
    lda #<symbol_name_bytes
    sta __ap
    lda #>symbol_name_bytes
    sta __ap+1
    lda __T_find_symbol___v33
    sta __ix
    lda __T_find_symbol___v33+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_symbol___v34
    ldy __L_find_symbol_j
    lda __L_find_symbol_name
    sta __ap
    lda __L_find_symbol_name+1
    sta __ap+1
    lda (__ap),y
    sta __T_find_symbol___v37
    lda __T_find_symbol___v34
    cmp __T_find_symbol___v37
    bne __F_find_symbol_yes_16
    jmp __F_find_symbol_join_18
__F_find_symbol_yes_16:
    lda #$00
    sta __L_find_symbol_same
__F_find_symbol_join_18:
    inc __L_find_symbol_j
    jmp __F_find_symbol_while_13
__F_find_symbol_after_15:
    lda __L_find_symbol_same
    cmp #$00
    bne __F_find_symbol_yes_19
    jmp __F_find_symbol_join_9
__F_find_symbol_yes_19:
    lda __L_find_symbol_i
    ldx __L_find_symbol_i+1
    rts
__F_find_symbol_join_9:
    lda __L_find_symbol_i
    clc
    adc #$01
    sta __T_find_symbol___v49
    lda __L_find_symbol_i+1
    adc #$00
    sta __T_find_symbol___v49+1
    lda __T_find_symbol___v49
    sta __L_find_symbol_i
    lda __T_find_symbol___v49+1
    sta __L_find_symbol_i+1
    jmp __F_find_symbol_while_4
__F_find_symbol_after_6:
    sec
    lda #$00
    sbc #$01
    sta __T_find_symbol___v51
    lda #$00
    sbc #$00
    sta __T_find_symbol___v51+1
    lda __T_find_symbol___v51
    ldx __T_find_symbol___v51+1
    rts
allocate_symbol:
__F_allocate_symbol_entry:
    lda __L_allocate_symbol_name
    sta __T_allocate_symbol___v0
    lda __L_allocate_symbol_name+1
    sta __T_allocate_symbol___v0+1
    lda __L_allocate_symbol_length
    sta __T_allocate_symbol___v1
    lda __T_allocate_symbol___v0
    sta __call_scope_for_name_0
    lda __T_allocate_symbol___v0+1
    sta __call_scope_for_name_0+1
    lda __T_allocate_symbol___v1
    sta __call_scope_for_name_1
    jsr scope_for_name
    sta __L_allocate_symbol_scope
    stx __L_allocate_symbol_scope+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_allocate_symbol_scope+1
    eor #$80
    cmp __rh
    bcc __F_allocate_symbol___sel1
    bne __F_allocate_symbol___sel2
    lda __L_allocate_symbol_scope
    cmp #$00
    bcc __F_allocate_symbol___sel1
    bne __F_allocate_symbol___sel2
    jmp __F_allocate_symbol___sel3
__F_allocate_symbol___sel1:
    jmp __F_allocate_symbol_yes_1
__F_allocate_symbol___sel2:
    jmp __F_allocate_symbol_join_3
__F_allocate_symbol___sel3:
    jmp __F_allocate_symbol_join_3
__F_allocate_symbol_yes_1:
    sec
    lda #$00
    sbc #$02
    sta __T_allocate_symbol___v7
    lda #$00
    sbc #$00
    sta __T_allocate_symbol___v7+1
    lda __T_allocate_symbol___v7
    ldx __T_allocate_symbol___v7+1
    rts
__F_allocate_symbol_join_3:
    lda #$03
    eor #$80
    sta __rh
    lda symbol_count+1
    eor #$80
    cmp __rh
    bcc __F_allocate_symbol___sel4
    bne __F_allocate_symbol___sel5
    lda symbol_count
    cmp #$80
    bcc __F_allocate_symbol___sel4
    bne __F_allocate_symbol___sel5
    jmp __F_allocate_symbol___sel6
__F_allocate_symbol___sel4:
    jmp __F_allocate_symbol_join_6
__F_allocate_symbol___sel5:
    jmp __F_allocate_symbol_yes_4
__F_allocate_symbol___sel6:
    jmp __F_allocate_symbol_yes_4
__F_allocate_symbol_yes_4:
    sec
    lda #$00
    sbc #$03
    sta __T_allocate_symbol___v12
    lda #$00
    sbc #$00
    sta __T_allocate_symbol___v12+1
    lda __T_allocate_symbol___v12
    ldx __T_allocate_symbol___v12+1
    rts
__F_allocate_symbol_join_6:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_length
    sta __T_allocate_symbol___v15
    lda symbol_name_used+1
    adc #$00
    sta __T_allocate_symbol___v15+1
    lda #$24
    eor #$80
    sta __rh
    lda __T_allocate_symbol___v15+1
    eor #$80
    cmp __rh
    bcc __F_allocate_symbol___sel7
    bne __F_allocate_symbol___sel8
    lda __T_allocate_symbol___v15
    cmp #$80
    bcc __F_allocate_symbol___sel7
    bne __F_allocate_symbol___sel8
    jmp __F_allocate_symbol___sel9
__F_allocate_symbol___sel7:
    jmp __F_allocate_symbol_join_9
__F_allocate_symbol___sel8:
    jmp __F_allocate_symbol_yes_7
__F_allocate_symbol___sel9:
    jmp __F_allocate_symbol_join_9
__F_allocate_symbol_yes_7:
    sec
    lda #$00
    sbc #$03
    sta __T_allocate_symbol___v19
    lda #$00
    sbc #$00
    sta __T_allocate_symbol___v19+1
    lda __T_allocate_symbol___v19
    ldx __T_allocate_symbol___v19+1
    rts
__F_allocate_symbol_join_9:
    lda symbol_count
    sta __L_allocate_symbol_n
    lda symbol_count+1
    sta __L_allocate_symbol_n+1
    lda __L_allocate_symbol_n
    sta __T_allocate_symbol___v22
    lda __L_allocate_symbol_n+1
    sta __T_allocate_symbol___v22+1
    lda symbol_name_used
    sta __T_allocate_symbol___v23
    lda symbol_name_used+1
    sta __T_allocate_symbol___v23+1
    lda #<symbol_name_offset
    sta __ap
    lda #>symbol_name_offset
    sta __ap+1
    lda __T_allocate_symbol___v22
    asl
    sta __ix
    lda __T_allocate_symbol___v22+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v23
    sta (__ap),y
    iny
    lda __T_allocate_symbol___v23+1
    sta (__ap),y
    lda __L_allocate_symbol_n
    sta __T_allocate_symbol___v25
    lda __L_allocate_symbol_n+1
    sta __T_allocate_symbol___v25+1
    lda __L_allocate_symbol_length
    sta __T_allocate_symbol___v26
    lda #<symbol_name_length
    sta __ap
    lda #>symbol_name_length
    sta __ap+1
    lda __T_allocate_symbol___v25
    sta __ix
    lda __T_allocate_symbol___v25+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v26
    sta (__ap),y
    lda __L_allocate_symbol_n
    sta __T_allocate_symbol___v28
    lda __L_allocate_symbol_n+1
    sta __T_allocate_symbol___v28+1
    lda __L_allocate_symbol_payload
    sta __T_allocate_symbol___v31
    lda __L_allocate_symbol_payload+1
    sta __T_allocate_symbol___v31+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __T_allocate_symbol___v28
    asl
    sta __ix
    lda __T_allocate_symbol___v28+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v31
    sta (__ap),y
    iny
    lda __T_allocate_symbol___v31+1
    sta (__ap),y
    lda __L_allocate_symbol_n
    sta __T_allocate_symbol___v33
    lda __L_allocate_symbol_n+1
    sta __T_allocate_symbol___v33+1
    lda __L_allocate_symbol_scope
    sta __T_allocate_symbol___v34
    lda __L_allocate_symbol_scope+1
    sta __T_allocate_symbol___v34+1
    lda #<symbol_scope
    sta __ap
    lda #>symbol_scope
    sta __ap+1
    lda __T_allocate_symbol___v33
    sta __ix
    lda __T_allocate_symbol___v33+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v34
    sta (__ap),y
    lda __L_allocate_symbol_n
    sta __T_allocate_symbol___v36
    lda __L_allocate_symbol_n+1
    sta __T_allocate_symbol___v36+1
    lda __L_allocate_symbol_kind
    sta __T_allocate_symbol___v37
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda __T_allocate_symbol___v36
    sta __ix
    lda __T_allocate_symbol___v36+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v37
    sta (__ap),y
    lda #$00
    sta __L_allocate_symbol_i
__F_allocate_symbol_while_10:
    lda __L_allocate_symbol_i
    cmp __L_allocate_symbol_length
    bcc __F_allocate_symbol_body_11
    jmp __F_allocate_symbol_after_12
__F_allocate_symbol_body_11:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_i
    sta __T_allocate_symbol___v45
    lda symbol_name_used+1
    adc #$00
    sta __T_allocate_symbol___v45+1
    ldy __L_allocate_symbol_i
    lda __L_allocate_symbol_name
    sta __ap
    lda __L_allocate_symbol_name+1
    sta __ap+1
    lda (__ap),y
    sta __T_allocate_symbol___v48
    lda #<symbol_name_bytes
    sta __ap
    lda #>symbol_name_bytes
    sta __ap+1
    lda __T_allocate_symbol___v45
    sta __ix
    lda __T_allocate_symbol___v45+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v48
    sta (__ap),y
    inc __L_allocate_symbol_i
    jmp __F_allocate_symbol_while_10
__F_allocate_symbol_after_12:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_length
    sta __T_allocate_symbol___v54
    lda symbol_name_used+1
    adc #$00
    sta __T_allocate_symbol___v54+1
    lda __T_allocate_symbol___v54
    sta symbol_name_used
    lda __T_allocate_symbol___v54+1
    sta symbol_name_used+1
    lda __L_allocate_symbol_n
    clc
    adc #$01
    sta symbol_count
    lda __L_allocate_symbol_n+1
    adc #$00
    sta symbol_count+1
    lda __L_allocate_symbol_n
    ldx __L_allocate_symbol_n+1
    rts
intern_label:
__F_intern_label_entry:
    lda __L_intern_label_name
    sta __T_intern_label___v0
    lda __L_intern_label_name+1
    sta __T_intern_label___v0+1
    lda __L_intern_label_length
    sta __T_intern_label___v1
    lda __T_intern_label___v0
    sta __call_find_symbol_0
    lda __T_intern_label___v0+1
    sta __call_find_symbol_0+1
    lda __T_intern_label___v1
    sta __call_find_symbol_1
    jsr find_symbol
    sta __L_intern_label_symbol
    stx __L_intern_label_symbol+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_intern_label_symbol+1
    eor #$80
    cmp __rh
    bcc __F_intern_label___sel1
    bne __F_intern_label___sel2
    lda __L_intern_label_symbol
    cmp #$00
    bcc __F_intern_label___sel1
    bne __F_intern_label___sel2
    jmp __F_intern_label___sel3
__F_intern_label___sel1:
    jmp __F_intern_label_join_3
__F_intern_label___sel2:
    jmp __F_intern_label_yes_1
__F_intern_label___sel3:
    jmp __F_intern_label_yes_1
__F_intern_label_yes_1:
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda __L_intern_label_symbol
    sta __ix
    lda __L_intern_label_symbol+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_intern_label___v8
    cmp SYMBOL_CONSTANT
    beq __F_intern_label_yes_4
    jmp __F_intern_label_join_6
__F_intern_label_yes_4:
    sec
    lda #$00
    sbc #$04
    sta __T_intern_label___v12
    lda #$00
    sbc #$00
    sta __T_intern_label___v12+1
    lda __T_intern_label___v12
    ldx __T_intern_label___v12+1
    rts
__F_intern_label_join_6:
    lda __L_intern_label_symbol
    ldx __L_intern_label_symbol+1
    rts
__F_intern_label_join_3:
    sec
    lda #$00
    sbc #$02
    sta __T_intern_label___v16
    lda #$00
    sbc #$00
    sta __T_intern_label___v16+1
    lda __L_intern_label_symbol+1
    cmp __T_intern_label___v16+1
    bne __F_intern_label_join_9
    lda __L_intern_label_symbol
    cmp __T_intern_label___v16
    beq __F_intern_label_yes_7
    jmp __F_intern_label_join_9
__F_intern_label_yes_7:
    sec
    lda #$00
    sbc #$02
    sta __T_intern_label___v19
    lda #$00
    sbc #$00
    sta __T_intern_label___v19+1
    lda __T_intern_label___v19
    ldx __T_intern_label___v19+1
    rts
__F_intern_label_join_9:
    lda __L_intern_label_name
    sta __T_intern_label___v20
    lda __L_intern_label_name+1
    sta __T_intern_label___v20+1
    lda __L_intern_label_length
    sta __T_intern_label___v21
    lda SYMBOL_LABEL_UNDEFINED
    sta __T_intern_label___v22
    lda __T_intern_label___v20
    sta __call_allocate_symbol_0
    lda __T_intern_label___v20+1
    sta __call_allocate_symbol_0+1
    lda __T_intern_label___v21
    sta __call_allocate_symbol_1
    lda __T_intern_label___v22
    sta __call_allocate_symbol_2
    lda #$00
    sta __call_allocate_symbol_3
    lda #$00
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    rts
define_constant:
__F_define_constant_entry:
    lda __L_define_constant_name
    sta __T_define_constant___v0
    lda __L_define_constant_name+1
    sta __T_define_constant___v0+1
    lda __L_define_constant_length
    sta __T_define_constant___v1
    lda __T_define_constant___v0
    sta __call_find_symbol_0
    lda __T_define_constant___v0+1
    sta __call_find_symbol_0+1
    lda __T_define_constant___v1
    sta __call_find_symbol_1
    jsr find_symbol
    sta __L_define_constant_symbol
    stx __L_define_constant_symbol+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_define_constant_symbol+1
    eor #$80
    cmp __rh
    bcc __F_define_constant___sel1
    bne __F_define_constant___sel2
    lda __L_define_constant_symbol
    cmp #$00
    bcc __F_define_constant___sel1
    bne __F_define_constant___sel2
    jmp __F_define_constant___sel3
__F_define_constant___sel1:
    jmp __F_define_constant_join_3
__F_define_constant___sel2:
    jmp __F_define_constant_yes_1
__F_define_constant___sel3:
    jmp __F_define_constant_yes_1
__F_define_constant_yes_1:
    lda ASSEMBLE_BAD_SYMBOL
    ldx #$00
    rts
__F_define_constant_join_3:
    sec
    lda #$00
    sbc #$02
    sta __T_define_constant___v9
    lda #$00
    sbc #$00
    sta __T_define_constant___v9+1
    lda __L_define_constant_symbol+1
    cmp __T_define_constant___v9+1
    bne __F_define_constant_join_6
    lda __L_define_constant_symbol
    cmp __T_define_constant___v9
    beq __F_define_constant_yes_4
    jmp __F_define_constant_join_6
__F_define_constant_yes_4:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_define_constant_join_6:
    lda __L_define_constant_name
    sta __T_define_constant___v12
    lda __L_define_constant_name+1
    sta __T_define_constant___v12+1
    lda __L_define_constant_length
    sta __T_define_constant___v13
    lda SYMBOL_CONSTANT
    sta __T_define_constant___v14
    lda __L_define_constant_value
    sta __T_define_constant___v15
    lda __L_define_constant_value+1
    sta __T_define_constant___v15+1
    lda __T_define_constant___v12
    sta __call_allocate_symbol_0
    lda __T_define_constant___v12+1
    sta __call_allocate_symbol_0+1
    lda __T_define_constant___v13
    sta __call_allocate_symbol_1
    lda __T_define_constant___v14
    sta __call_allocate_symbol_2
    lda __T_define_constant___v15
    sta __call_allocate_symbol_3
    lda __T_define_constant___v15+1
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    sta __L_define_constant_symbol
    stx __L_define_constant_symbol+1
    sec
    lda #$00
    sbc #$02
    sta __T_define_constant___v19
    lda #$00
    sbc #$00
    sta __T_define_constant___v19+1
    lda __L_define_constant_symbol+1
    cmp __T_define_constant___v19+1
    bne __F_define_constant_join_9
    lda __L_define_constant_symbol
    cmp __T_define_constant___v19
    beq __F_define_constant_yes_7
    jmp __F_define_constant_join_9
__F_define_constant_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_define_constant_join_9:
    lda #$00
    eor #$80
    sta __rh
    lda __L_define_constant_symbol+1
    eor #$80
    cmp __rh
    bcc __F_define_constant___sel4
    bne __F_define_constant___sel5
    lda __L_define_constant_symbol
    cmp #$00
    bcc __F_define_constant___sel4
    bne __F_define_constant___sel5
    jmp __F_define_constant___sel6
__F_define_constant___sel4:
    jmp __F_define_constant_yes_10
__F_define_constant___sel5:
    jmp __F_define_constant_join_12
__F_define_constant___sel6:
    jmp __F_define_constant_join_12
__F_define_constant_yes_10:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_define_constant_join_12:
    lda ASSEMBLE_OK
    ldx #$00
    rts
patch_word_chain:
__F_patch_word_chain_entry:
__F_patch_word_chain_while_1:
    lda __L_patch_word_chain_head+1
    cmp #$00
    bne __F_patch_word_chain_body_2
    lda __L_patch_word_chain_head
    cmp #$00
    bne __F_patch_word_chain___far_skip_0
    jmp __F_patch_word_chain_after_3
__F_patch_word_chain___far_skip_0:
    jmp __F_patch_word_chain_body_2
__F_patch_word_chain_body_2:
    lda __L_patch_word_chain_head
    sec
    sbc #$01
    sta __L_patch_word_chain_stage
    lda __L_patch_word_chain_head+1
    sbc #$00
    sta __L_patch_word_chain_stage+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __L_patch_word_chain_stage
    sta __ix
    lda __L_patch_word_chain_stage+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_patch_word_chain___v8
    lda __L_patch_word_chain_stage
    clc
    adc #$01
    sta __T_patch_word_chain___v12
    lda __L_patch_word_chain_stage+1
    adc #$00
    sta __T_patch_word_chain___v12+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_patch_word_chain___v12
    sta __ix
    lda __T_patch_word_chain___v12+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_patch_word_chain___v13
    lda __T_patch_word_chain___v13
    sta __T_patch_word_chain___v15
    lda #$00
    sta __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    lda __T_patch_word_chain___v8
    ora __T_patch_word_chain___v15
    sta __T_patch_word_chain___v16
    lda #$00
    ora __T_patch_word_chain___v15+1
    sta __T_patch_word_chain___v16+1
    lda __T_patch_word_chain___v16
    sta __L_patch_word_chain_next
    lda __T_patch_word_chain___v16+1
    sta __L_patch_word_chain_next+1
    lda __L_patch_word_chain_stage
    sta __T_patch_word_chain___v18
    lda __L_patch_word_chain_stage+1
    sta __T_patch_word_chain___v18+1
    lda __L_patch_word_chain_value
    and #$ff
    sta __T_patch_word_chain___v21
    lda __L_patch_word_chain_value+1
    and #$00
    sta __T_patch_word_chain___v21+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_patch_word_chain___v18
    sta __ix
    lda __T_patch_word_chain___v18+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_patch_word_chain___v21
    sta (__ap),y
    lda __L_patch_word_chain_stage
    clc
    adc #$01
    sta __T_patch_word_chain___v25
    lda __L_patch_word_chain_stage+1
    adc #$00
    sta __T_patch_word_chain___v25+1
    lda __L_patch_word_chain_value
    sta __T_patch_word_chain___v28
    lda __L_patch_word_chain_value+1
    sta __T_patch_word_chain___v28+1
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lda __T_patch_word_chain___v28
    and #$ff
    sta __T_patch_word_chain___v30
    lda __T_patch_word_chain___v28+1
    and #$00
    sta __T_patch_word_chain___v30+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_patch_word_chain___v25
    sta __ix
    lda __T_patch_word_chain___v25+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_patch_word_chain___v30
    sta (__ap),y
    lda __L_patch_word_chain_next
    sta __L_patch_word_chain_head
    lda __L_patch_word_chain_next+1
    sta __L_patch_word_chain_head+1
    jmp __F_patch_word_chain_while_1
__F_patch_word_chain_after_3:
    lda ASSEMBLE_OK
    ldx #$00
    rts
define_label:
__F_define_label_entry:
    lda __L_define_label_name
    sta __T_define_label___v0
    lda __L_define_label_name+1
    sta __T_define_label___v0+1
    lda __L_define_label_length
    sta __T_define_label___v1
    lda __T_define_label___v0
    sta __call_find_symbol_0
    lda __T_define_label___v0+1
    sta __call_find_symbol_0+1
    lda __T_define_label___v1
    sta __call_find_symbol_1
    jsr find_symbol
    sta __L_define_label_symbol
    stx __L_define_label_symbol+1
    sec
    lda #$00
    sbc #$02
    sta __T_define_label___v5
    lda #$00
    sbc #$00
    sta __T_define_label___v5+1
    lda __L_define_label_symbol+1
    cmp __T_define_label___v5+1
    bne __F_define_label_join_3
    lda __L_define_label_symbol
    cmp __T_define_label___v5
    beq __F_define_label_yes_1
    jmp __F_define_label_join_3
__F_define_label_yes_1:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_define_label_join_3:
    lda #$00
    eor #$80
    sta __rh
    lda __L_define_label_symbol+1
    eor #$80
    cmp __rh
    bcc __F_define_label___sel1
    bne __F_define_label___sel2
    lda __L_define_label_symbol
    cmp #$00
    bcc __F_define_label___sel1
    bne __F_define_label___sel2
    jmp __F_define_label___sel3
__F_define_label___sel1:
    jmp __F_define_label_yes_4
__F_define_label___sel2:
    jmp __F_define_label_join_6
__F_define_label___sel3:
    jmp __F_define_label_join_6
__F_define_label_yes_4:
    lda __L_define_label_name
    sta __T_define_label___v11
    lda __L_define_label_name+1
    sta __T_define_label___v11+1
    lda __L_define_label_length
    sta __T_define_label___v12
    lda SYMBOL_LABEL_DEFINED
    sta __T_define_label___v13
    lda __L_define_label_value
    sta __T_define_label___v14
    lda __L_define_label_value+1
    sta __T_define_label___v14+1
    lda __T_define_label___v11
    sta __call_allocate_symbol_0
    lda __T_define_label___v11+1
    sta __call_allocate_symbol_0+1
    lda __T_define_label___v12
    sta __call_allocate_symbol_1
    lda __T_define_label___v13
    sta __call_allocate_symbol_2
    lda __T_define_label___v14
    sta __call_allocate_symbol_3
    lda __T_define_label___v14+1
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    sta __L_define_label_symbol
    stx __L_define_label_symbol+1
    sec
    lda #$00
    sbc #$02
    sta __T_define_label___v18
    lda #$00
    sbc #$00
    sta __T_define_label___v18+1
    lda __L_define_label_symbol+1
    cmp __T_define_label___v18+1
    bne __F_define_label_join_9
    lda __L_define_label_symbol
    cmp __T_define_label___v18
    beq __F_define_label_yes_7
    jmp __F_define_label_join_9
__F_define_label_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_define_label_join_9:
    lda #$00
    eor #$80
    sta __rh
    lda __L_define_label_symbol+1
    eor #$80
    cmp __rh
    bcc __F_define_label___sel4
    bne __F_define_label___sel5
    lda __L_define_label_symbol
    cmp #$00
    bcc __F_define_label___sel4
    bne __F_define_label___sel5
    jmp __F_define_label___sel6
__F_define_label___sel4:
    jmp __F_define_label_yes_10
__F_define_label___sel5:
    jmp __F_define_label_join_12
__F_define_label___sel6:
    jmp __F_define_label_join_12
__F_define_label_yes_10:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_define_label_join_12:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_define_label_join_6:
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda __L_define_label_symbol
    sta __ix
    lda __L_define_label_symbol+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_define_label___v28
    cmp SYMBOL_LABEL_UNDEFINED
    bne __F_define_label_yes_13
    jmp __F_define_label_join_15
__F_define_label_yes_13:
    lda ASSEMBLE_BAD_SYMBOL
    ldx #$00
    rts
__F_define_label_join_15:
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __L_define_label_symbol
    asl
    sta __ix
    lda __L_define_label_symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_define_label___v34
    iny
    lda (__ap),y
    sta __T_define_label___v34+1
    lda __T_define_label___v34
    sta __L_define_label_old_head
    lda __T_define_label___v34+1
    sta __L_define_label_old_head+1
    lda __L_define_label_symbol
    sta __T_define_label___v36
    lda __L_define_label_symbol+1
    sta __T_define_label___v36+1
    lda __L_define_label_value
    sta __T_define_label___v39
    lda __L_define_label_value+1
    sta __T_define_label___v39+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __T_define_label___v36
    asl
    sta __ix
    lda __T_define_label___v36+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_define_label___v39
    sta (__ap),y
    iny
    lda __T_define_label___v39+1
    sta (__ap),y
    lda __L_define_label_symbol
    sta __T_define_label___v41
    lda __L_define_label_symbol+1
    sta __T_define_label___v41+1
    lda SYMBOL_LABEL_DEFINED
    sta __T_define_label___v42
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda __T_define_label___v41
    sta __ix
    lda __T_define_label___v41+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_define_label___v42
    sta (__ap),y
    lda __L_define_label_old_head
    sta __T_define_label___v43
    lda __L_define_label_old_head+1
    sta __T_define_label___v43+1
    lda __L_define_label_value
    sta __T_define_label___v44
    lda __L_define_label_value+1
    sta __T_define_label___v44+1
    lda __T_define_label___v43
    sta __call_patch_word_chain_0
    lda __T_define_label___v43+1
    sta __call_patch_word_chain_0+1
    lda __T_define_label___v44
    sta __call_patch_word_chain_1
    lda __T_define_label___v44+1
    sta __call_patch_word_chain_1+1
    jsr patch_word_chain
    sta __L_define_label_status
    lda __L_define_label_status
    cmp ASSEMBLE_OK
    bne __F_define_label_yes_16
    jmp __F_define_label_join_18
__F_define_label_yes_16:
    lda __L_define_label_status
    ldx #$00
    rts
__F_define_label_join_18:
    lda __L_define_label_symbol
    sta __T_define_label___v50
    lda __L_define_label_symbol+1
    sta __T_define_label___v50+1
    lda __T_define_label___v50
    sta __call_resolve_fixups_for_symbol_0
    lda __T_define_label___v50+1
    sta __call_resolve_fixups_for_symbol_0+1
    jsr resolve_fixups_for_symbol
    ldx #$00
    rts
parse_atom:
__F_parse_atom_entry:
    lda #$00
    sta atom_used
    lda __L_parse_atom_length
    cmp #$00
    beq __F_parse_atom_yes_1
    jmp __F_parse_atom_join_3
__F_parse_atom_yes_1:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_3:
    ldy #$00
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
    lda (__ap),y
    sta __T_parse_atom___v7
    cmp #$24
    beq __F_parse_atom_yes_4
    jmp __F_parse_atom_join_6
__F_parse_atom_yes_4:
    lda #$01
    sta __L_parse_atom_i
    lda #$00
    sta __L_parse_atom_value
    lda #$00
    sta __L_parse_atom_value+1
__F_parse_atom_while_7:
    lda __L_parse_atom_i
    cmp __L_parse_atom_length
    bcc __F_parse_atom_body_8
    jmp __F_parse_atom_after_9
__F_parse_atom_body_8:
    ldy __L_parse_atom_i
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
    lda (__ap),y
    sta __T_parse_atom___v17
    cmp #$2b
    bne __F_parse_atom___far_skip_0
    jmp __F_parse_atom_after_9
__F_parse_atom___far_skip_0:
    jmp __F_parse_atom_no_11
__F_parse_atom_no_11:
    cmp #$2d
    bne __F_parse_atom___far_skip_1
    jmp __F_parse_atom_after_9
__F_parse_atom___far_skip_1:
    jmp __F_parse_atom_no_14
__F_parse_atom_no_14:
    lda __T_parse_atom___v17
    sta __call_hex_nibble_0
    jsr hex_nibble
    sta __L_parse_atom_digit
    stx __L_parse_atom_digit+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_parse_atom_digit+1
    eor #$80
    cmp __rh
    bcc __F_parse_atom___sel1
    bne __F_parse_atom___sel2
    lda __L_parse_atom_digit
    cmp #$00
    bcc __F_parse_atom___sel1
    bne __F_parse_atom___sel2
    jmp __F_parse_atom___sel3
__F_parse_atom___sel1:
    jmp __F_parse_atom_yes_16
__F_parse_atom___sel2:
    jmp __F_parse_atom_join_18
__F_parse_atom___sel3:
    jmp __F_parse_atom_join_18
__F_parse_atom_yes_16:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_18:
    lda atom_used
    cmp #$04
    bcs __F_parse_atom_yes_19
    jmp __F_parse_atom_join_21
__F_parse_atom_yes_19:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_21:
    lda __L_parse_atom_value
    sta __T_parse_atom___v39
    lda __L_parse_atom_value+1
    sta __T_parse_atom___v39+1
    asl __T_parse_atom___v39
    rol __T_parse_atom___v39+1
    asl __T_parse_atom___v39
    rol __T_parse_atom___v39+1
    asl __T_parse_atom___v39
    rol __T_parse_atom___v39+1
    asl __T_parse_atom___v39
    rol __T_parse_atom___v39+1
    lda __T_parse_atom___v39
    ora __L_parse_atom_digit
    sta __T_parse_atom___v41
    lda __T_parse_atom___v39+1
    ora __L_parse_atom_digit+1
    sta __T_parse_atom___v41+1
    lda __T_parse_atom___v41
    sta __T_parse_atom___v43
    lda __T_parse_atom___v41+1
    sta __T_parse_atom___v43+1
    lda __T_parse_atom___v43
    sta __L_parse_atom_value
    lda __T_parse_atom___v43+1
    sta __L_parse_atom_value+1
    inc atom_used
    inc __L_parse_atom_i
    jmp __F_parse_atom_while_7
__F_parse_atom_after_9:
    lda atom_used
    cmp #$00
    beq __F_parse_atom_yes_22
    jmp __F_parse_atom_join_24
__F_parse_atom_yes_22:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_24:
    inc atom_used
    lda __L_parse_atom_value
    sta atom_value
    lda __L_parse_atom_value+1
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    ldx #$00
    rts
__F_parse_atom_join_6:
    cmp #$27
    beq __F_parse_atom_yes_25
    jmp __F_parse_atom_join_27
__F_parse_atom_yes_25:
    lda __L_parse_atom_length
    cmp #$03
    bcc __F_parse_atom_yes_28
    jmp __F_parse_atom_join_30
__F_parse_atom_yes_28:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_30:
    ldy #$02
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
    lda (__ap),y
    sta __T_parse_atom___v71
    cmp #$27
    bne __F_parse_atom_yes_31
    jmp __F_parse_atom_join_33
__F_parse_atom_yes_31:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_33:
    ldy #$01
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
    lda (__ap),y
    sta __T_parse_atom___v77
    lda __T_parse_atom___v77
    sta atom_value
    lda #$00
    sta atom_value+1
    lda #$03
    sta atom_used
    lda #$00
    sta atom_kind
    lda VALUE_OK
    ldx #$00
    rts
__F_parse_atom_join_27:
    cmp #$30
    bcs __F_parse_atom_yes_34
    jmp __F_parse_atom_join_36
__F_parse_atom_yes_34:
    cmp #$39
    bcc __F_parse_atom_yes_37
    beq __F_parse_atom_yes_37
    jmp __F_parse_atom_join_36
__F_parse_atom_yes_37:
    lda #$00
    sta __L_parse_atom_i
    lda #$00
    sta __L_parse_atom_value
    lda #$00
    sta __L_parse_atom_value+1
    ldy __L_parse_atom_i
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
__F_parse_atom_while_40:
    cpy __L_parse_atom_length
    bcc __F_parse_atom_body_41
    jmp __F_parse_atom_after_42
__F_parse_atom_body_41:
    lda (__ap),y
    sta __T_parse_atom___v98
    cmp #$2b
    bne __F_parse_atom___far_skip_2
    jmp __F_parse_atom_after_42
__F_parse_atom___far_skip_2:
    jmp __F_parse_atom_no_44
__F_parse_atom_no_44:
    cmp #$2d
    bne __F_parse_atom___far_skip_3
    jmp __F_parse_atom_after_42
__F_parse_atom___far_skip_3:
    jmp __F_parse_atom_no_47
__F_parse_atom_no_47:
    cmp #$30
    bcc __F_parse_atom_yes_49
    jmp __F_parse_atom_join_51
__F_parse_atom_yes_49:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_51:
    cmp #$39
    bcc __F_parse_atom_join_54
    beq __F_parse_atom_join_54
    jmp __F_parse_atom_yes_52
__F_parse_atom_yes_52:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_54:
    lda #$00
    sta __T_parse_atom___v120
    sta __T_parse_atom___v120+1
    lda __L_parse_atom_value
    sta __mw
    lda __L_parse_atom_value+1
    sta __mw+1
    asl __mw
    rol __mw+1
    clc
    lda __T_parse_atom___v120
    adc __mw
    sta __T_parse_atom___v120
    lda __T_parse_atom___v120+1
    adc __mw+1
    sta __T_parse_atom___v120+1
    asl __mw
    rol __mw+1
    asl __mw
    rol __mw+1
    clc
    lda __T_parse_atom___v120
    adc __mw
    sta __T_parse_atom___v120
    lda __T_parse_atom___v120+1
    adc __mw+1
    sta __T_parse_atom___v120+1
    lda __T_parse_atom___v120
    clc
    adc __T_parse_atom___v98
    sta __T_parse_atom___v124
    lda __T_parse_atom___v120+1
    adc #$00
    sta __T_parse_atom___v124+1
    lda __T_parse_atom___v124
    sec
    sbc #$30
    sta __T_parse_atom___v126
    lda __T_parse_atom___v124+1
    sbc #$00
    sta __T_parse_atom___v126+1
    lda __T_parse_atom___v126
    sta __T_parse_atom___v128
    lda __T_parse_atom___v126+1
    sta __T_parse_atom___v128+1
    lda __T_parse_atom___v128
    sta __L_parse_atom_value
    lda __T_parse_atom___v128+1
    sta __L_parse_atom_value+1
    inc atom_used
    inc __L_parse_atom_i
    iny
    jmp __F_parse_atom_while_40
__F_parse_atom_after_42:
    lda __L_parse_atom_value
    sta atom_value
    lda __L_parse_atom_value+1
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    ldx #$00
    rts
__F_parse_atom_join_36:
    lda #$00
    sta __L_parse_atom_i
    ldy __L_parse_atom_i
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
__F_parse_atom_while_55:
    cpy __L_parse_atom_length
    bcc __F_parse_atom_body_56
    jmp __F_parse_atom_after_57
__F_parse_atom_body_56:
    lda (__ap),y
    sta __T_parse_atom___v144
    cmp #$2b
    beq __F_parse_atom_after_57
    jmp __F_parse_atom_no_59
__F_parse_atom_no_59:
    cmp #$2d
    beq __F_parse_atom_after_57
    jmp __F_parse_atom_no_62
__F_parse_atom_no_62:
    inc atom_used
    inc __L_parse_atom_i
    iny
    jmp __F_parse_atom_while_55
__F_parse_atom_after_57:
    lda atom_used
    cmp #$00
    beq __F_parse_atom_yes_64
    jmp __F_parse_atom_join_66
__F_parse_atom_yes_64:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_66:
    lda __L_parse_atom_text
    sta __T_parse_atom___v162
    lda __L_parse_atom_text+1
    sta __T_parse_atom___v162+1
    lda atom_used
    sta __T_parse_atom___v163
    lda __T_parse_atom___v162
    sta __call_find_symbol_0
    lda __T_parse_atom___v162+1
    sta __call_find_symbol_0+1
    lda __T_parse_atom___v163
    sta __call_find_symbol_1
    jsr find_symbol
    sta __L_parse_atom_symbol
    stx __L_parse_atom_symbol+1
    sec
    lda #$00
    sbc #$02
    sta __T_parse_atom___v167
    lda #$00
    sbc #$00
    sta __T_parse_atom___v167+1
    lda __L_parse_atom_symbol+1
    cmp __T_parse_atom___v167+1
    bne __F_parse_atom_join_69
    lda __L_parse_atom_symbol
    cmp __T_parse_atom___v167
    beq __F_parse_atom_yes_67
    jmp __F_parse_atom_join_69
__F_parse_atom_yes_67:
    lda VALUE_SCOPE_ERROR
    ldx #$00
    rts
__F_parse_atom_join_69:
    lda #$00
    eor #$80
    sta __rh
    lda __L_parse_atom_symbol+1
    eor #$80
    cmp __rh
    bcc __F_parse_atom___sel4
    bne __F_parse_atom___sel5
    lda __L_parse_atom_symbol
    cmp #$00
    bcc __F_parse_atom___sel4
    bne __F_parse_atom___sel5
    jmp __F_parse_atom___sel6
__F_parse_atom___sel4:
    jmp __F_parse_atom_yes_70
__F_parse_atom___sel5:
    jmp __F_parse_atom_join_72
__F_parse_atom___sel6:
    jmp __F_parse_atom_join_72
__F_parse_atom_yes_70:
    lda __L_parse_atom_text
    sta __T_parse_atom___v173
    lda __L_parse_atom_text+1
    sta __T_parse_atom___v173+1
    lda atom_used
    sta __T_parse_atom___v174
    lda __T_parse_atom___v173
    sta __call_intern_label_0
    lda __T_parse_atom___v173+1
    sta __call_intern_label_0+1
    lda __T_parse_atom___v174
    sta __call_intern_label_1
    jsr intern_label
    sta __L_parse_atom_symbol
    stx __L_parse_atom_symbol+1
    sec
    lda #$00
    sbc #$02
    sta __T_parse_atom___v178
    lda #$00
    sbc #$00
    sta __T_parse_atom___v178+1
    lda __L_parse_atom_symbol+1
    cmp __T_parse_atom___v178+1
    bne __F_parse_atom_join_75
    lda __L_parse_atom_symbol
    cmp __T_parse_atom___v178
    beq __F_parse_atom_yes_73
    jmp __F_parse_atom_join_75
__F_parse_atom_yes_73:
    lda VALUE_SCOPE_ERROR
    ldx #$00
    rts
__F_parse_atom_join_75:
    sec
    lda #$00
    sbc #$03
    sta __T_parse_atom___v183
    lda #$00
    sbc #$00
    sta __T_parse_atom___v183+1
    lda __L_parse_atom_symbol+1
    cmp __T_parse_atom___v183+1
    bne __F_parse_atom_join_78
    lda __L_parse_atom_symbol
    cmp __T_parse_atom___v183
    beq __F_parse_atom_yes_76
    jmp __F_parse_atom_join_78
__F_parse_atom_yes_76:
    lda VALUE_SYMBOL_FULL
    ldx #$00
    rts
__F_parse_atom_join_78:
    lda #$00
    eor #$80
    sta __rh
    lda __L_parse_atom_symbol+1
    eor #$80
    cmp __rh
    bcc __F_parse_atom___sel7
    bne __F_parse_atom___sel8
    lda __L_parse_atom_symbol
    cmp #$00
    bcc __F_parse_atom___sel7
    bne __F_parse_atom___sel8
    jmp __F_parse_atom___sel9
__F_parse_atom___sel7:
    jmp __F_parse_atom_yes_79
__F_parse_atom___sel8:
    jmp __F_parse_atom_join_72
__F_parse_atom___sel9:
    jmp __F_parse_atom_join_72
__F_parse_atom_yes_79:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_72:
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda __L_parse_atom_symbol
    sta __ix
    lda __L_parse_atom_symbol+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_parse_atom___v192
    cmp SYMBOL_LABEL_UNDEFINED
    beq __F_parse_atom_yes_82
    jmp __F_parse_atom_join_84
__F_parse_atom_yes_82:
    lda __L_parse_atom_symbol
    sta atom_symbol
    lda __L_parse_atom_symbol+1
    sta atom_symbol+1
    lda #$01
    sta atom_kind
    lda VALUE_UNRESOLVED
    ldx #$00
    rts
__F_parse_atom_join_84:
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __L_parse_atom_symbol
    asl
    sta __ix
    lda __L_parse_atom_symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta atom_value
    iny
    lda (__ap),y
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    ldx #$00
    rts
parse_value:
__F_parse_value_entry:
    sec
    lda #$00
    sbc #$01
    sta captured_symbol
    lda #$00
    sbc #$00
    sta captured_symbol+1
    lda #$00
    sta captured_addend
    lda #$00
    sta captured_addend+1
    lda VALUE_PREFIX_NONE
    sta captured_prefix
    lda __L_parse_value_length
    cmp #$00
    beq __F_parse_value_yes_1
    jmp __F_parse_value_join_3
__F_parse_value_yes_1:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_value_join_3:
    lda #$00
    sta __L_parse_value_position
    ldy __L_parse_value_position
    lda __L_parse_value_text
    sta __ap
    lda __L_parse_value_text+1
    sta __ap+1
    lda (__ap),y
    sta __T_parse_value___v11
    cmp #$3c
    beq __F_parse_value_yes_4
    jmp __F_parse_value_no_5
__F_parse_value_yes_4:
    lda VALUE_PREFIX_LOW
    sta captured_prefix
    inc __L_parse_value_position
    jmp __F_parse_value_join_6
__F_parse_value_no_5:
    cmp #$3e
    beq __F_parse_value_yes_7
    jmp __F_parse_value_join_6
__F_parse_value_yes_7:
    lda VALUE_PREFIX_HIGH
    sta captured_prefix
    inc __L_parse_value_position
__F_parse_value_join_6:
    lda __L_parse_value_text
    clc
    adc __L_parse_value_position
    sta __call_parse_atom_0
    lda __L_parse_value_text+1
    adc #$00
    sta __call_parse_atom_0+1
    lda __L_parse_value_length
    sec
    sbc __L_parse_value_position
    sta __call_parse_atom_1
    lda #$00
    sbc #$00
    sta __call_parse_atom_1+1
    jsr parse_atom
    sta __L_parse_value_status
    lda __L_parse_value_status
    cmp VALUE_OK
    bne __F_parse_value_yes_10
    jmp __F_parse_value_join_12
__F_parse_value_yes_10:
    lda __L_parse_value_status
    cmp VALUE_UNRESOLVED
    bne __F_parse_value_yes_13
    jmp __F_parse_value_join_12
__F_parse_value_yes_13:
    lda __L_parse_value_status
    ldx #$00
    rts
__F_parse_value_join_12:
    lda atom_kind
    sta __L_parse_value_first_kind
    lda atom_value
    sta __L_parse_value_first_value
    lda atom_value+1
    sta __L_parse_value_first_value+1
    lda atom_symbol
    sta __L_parse_value_first_symbol
    lda atom_symbol+1
    sta __L_parse_value_first_symbol+1
    lda __L_parse_value_position
    clc
    adc atom_used
    sta __L_parse_value_position
    lda __L_parse_value_first_kind
    cmp #$00
    beq __F_parse_value_yes_16
    jmp __F_parse_value_no_17
__F_parse_value_yes_16:
    lda __L_parse_value_first_value
    sta captured_addend
    lda __L_parse_value_first_value+1
    sta captured_addend+1
    jmp __F_parse_value_join_18
__F_parse_value_no_17:
    lda __L_parse_value_first_symbol
    sta captured_symbol
    lda __L_parse_value_first_symbol+1
    sta captured_symbol+1
    lda #$00
    sta captured_addend
    lda #$00
    sta captured_addend+1
__F_parse_value_join_18:
    lda __L_parse_value_position
    cmp __L_parse_value_length
    bcc __F_parse_value_yes_19
    jmp __F_parse_value_join_21
__F_parse_value_yes_19:
    ldy __L_parse_value_position
    lda __L_parse_value_text
    sta __ap
    lda __L_parse_value_text+1
    sta __ap+1
    lda (__ap),y
    sta __L_parse_value_operation
    lda __L_parse_value_operation
    cmp #$2b
    bne __F_parse_value_yes_22
    jmp __F_parse_value_join_24
__F_parse_value_yes_22:
    lda __L_parse_value_operation
    cmp #$2d
    bne __F_parse_value_yes_25
    jmp __F_parse_value_join_24
__F_parse_value_yes_25:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_value_join_24:
    inc __L_parse_value_position
    lda __L_parse_value_text
    clc
    adc __L_parse_value_position
    sta __call_parse_atom_0
    lda __L_parse_value_text+1
    adc #$00
    sta __call_parse_atom_0+1
    lda __L_parse_value_length
    sec
    sbc __L_parse_value_position
    sta __call_parse_atom_1
    lda #$00
    sbc #$00
    sta __call_parse_atom_1+1
    jsr parse_atom
    sta __L_parse_value_status
    lda __L_parse_value_status
    cmp VALUE_OK
    bne __F_parse_value_yes_28
    jmp __F_parse_value_join_30
__F_parse_value_yes_28:
    lda __L_parse_value_status
    cmp VALUE_UNRESOLVED
    bne __F_parse_value_yes_31
    jmp __F_parse_value_join_30
__F_parse_value_yes_31:
    lda __L_parse_value_status
    ldx #$00
    rts
__F_parse_value_join_30:
    lda atom_kind
    sta __L_parse_value_second_kind
    lda __L_parse_value_position
    clc
    adc atom_used
    sta __L_parse_value_position
    lda __L_parse_value_position
    cmp __L_parse_value_length
    bne __F_parse_value_yes_34
    jmp __F_parse_value_join_36
__F_parse_value_yes_34:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_value_join_36:
    lda __L_parse_value_second_kind
    cmp #$00
    beq __F_parse_value_yes_37
    jmp __F_parse_value_no_38
__F_parse_value_yes_37:
    lda __L_parse_value_operation
    cmp #$2b
    beq __F_parse_value_yes_40
    jmp __F_parse_value_no_41
__F_parse_value_yes_40:
    lda captured_addend
    clc
    adc atom_value
    sta __T_parse_value___v99
    lda captured_addend+1
    adc atom_value+1
    sta __T_parse_value___v99+1
    lda __T_parse_value___v99
    sta __T_parse_value___v101
    lda __T_parse_value___v99+1
    sta __T_parse_value___v101+1
    lda __T_parse_value___v101
    sta captured_addend
    lda __T_parse_value___v101+1
    sta captured_addend+1
    jmp __F_parse_value_join_21
__F_parse_value_no_41:
    lda captured_addend
    sec
    sbc atom_value
    sta __T_parse_value___v104
    lda captured_addend+1
    sbc atom_value+1
    sta __T_parse_value___v104+1
    lda __T_parse_value___v104
    sta __T_parse_value___v106
    lda __T_parse_value___v104+1
    sta __T_parse_value___v106+1
    lda __T_parse_value___v106
    sta captured_addend
    lda __T_parse_value___v106+1
    sta captured_addend+1
    jmp __F_parse_value_join_21
__F_parse_value_no_38:
    lda #$00
    eor #$80
    sta __rh
    lda captured_symbol+1
    eor #$80
    cmp __rh
    bcc __F_parse_value___sel1
    bne __F_parse_value___sel2
    lda captured_symbol
    cmp #$00
    bcc __F_parse_value___sel1
    bne __F_parse_value___sel2
    jmp __F_parse_value___sel3
__F_parse_value___sel1:
    jmp __F_parse_value_join_45
__F_parse_value___sel2:
    jmp __F_parse_value_yes_43
__F_parse_value___sel3:
    jmp __F_parse_value_yes_43
__F_parse_value_yes_43:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_value_join_45:
    lda __L_parse_value_operation
    cmp #$2b
    bne __F_parse_value_yes_46
    jmp __F_parse_value_join_48
__F_parse_value_yes_46:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_value_join_48:
    lda atom_symbol
    sta captured_symbol
    lda atom_symbol+1
    sta captured_symbol+1
__F_parse_value_join_21:
    lda #$00
    eor #$80
    sta __rh
    lda captured_symbol+1
    eor #$80
    cmp __rh
    bcc __F_parse_value___sel4
    bne __F_parse_value___sel5
    lda captured_symbol
    cmp #$00
    bcc __F_parse_value___sel4
    bne __F_parse_value___sel5
    jmp __F_parse_value___sel6
__F_parse_value___sel4:
    jmp __F_parse_value_join_51
__F_parse_value___sel5:
    jmp __F_parse_value_yes_49
__F_parse_value___sel6:
    jmp __F_parse_value_yes_49
__F_parse_value_yes_49:
    lda VALUE_UNRESOLVED
    ldx #$00
    rts
__F_parse_value_join_51:
    lda captured_addend
    sta value_result
    lda captured_addend+1
    sta value_result+1
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    bne __F_parse_value_yes_52
    jmp __F_parse_value_join_54
__F_parse_value_yes_52:
    lda captured_addend
    sta __T_parse_value___v124
    lda captured_addend+1
    sta __T_parse_value___v124+1
    lda captured_prefix
    sta __T_parse_value___v125
    lda __T_parse_value___v124
    sta __call_apply_byte_prefix_0
    lda __T_parse_value___v124+1
    sta __call_apply_byte_prefix_0+1
    lda __T_parse_value___v125
    sta __call_apply_byte_prefix_1
    jsr apply_byte_prefix
    sta __T_parse_value___v126
    lda __T_parse_value___v126
    sta value_result
    lda #$00
    sta value_result+1
__F_parse_value_join_54:
    lda VALUE_OK
    ldx #$00
    rts
find_mnemonic:
__F_find_mnemonic_entry:
    lda __L_find_mnemonic_length
    cmp #$03
    bne __F_find_mnemonic_yes_1
    jmp __F_find_mnemonic_join_3
__F_find_mnemonic_yes_1:
    sec
    lda #$00
    sbc #$01
    sta __T_find_mnemonic___v4
    lda #$00
    sbc #$00
    sta __T_find_mnemonic___v4+1
    lda __T_find_mnemonic___v4
    ldx __T_find_mnemonic___v4+1
    rts
__F_find_mnemonic_join_3:
    lda #$00
    sta __L_find_mnemonic_candidate
__F_find_mnemonic_while_4:
    lda __L_find_mnemonic_candidate
    cmp #$38
    bcc __F_find_mnemonic_body_5
    jmp __F_find_mnemonic_after_6
__F_find_mnemonic_body_5:
    lda #$00
    sta __T_find_mnemonic___v11
    sta __T_find_mnemonic___v11+1
    lda __L_find_mnemonic_candidate
    sta __mw
    lda #$00
    sta __mw+1
    clc
    lda __T_find_mnemonic___v11
    adc __mw
    sta __T_find_mnemonic___v11
    lda __T_find_mnemonic___v11+1
    adc __mw+1
    sta __T_find_mnemonic___v11+1
    asl __mw
    rol __mw+1
    clc
    lda __T_find_mnemonic___v11
    adc __mw
    sta __T_find_mnemonic___v11
    lda __T_find_mnemonic___v11+1
    adc __mw+1
    sta __T_find_mnemonic___v11+1
    lda __T_find_mnemonic___v11
    sta __L_find_mnemonic_offset
    ldy #$00
    lda __L_find_mnemonic_name
    sta __ap
    lda __L_find_mnemonic_name+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_find_mnemonic___v15
    ldy __L_find_mnemonic_offset
    lda mnemonic_table,y
    sta __T_find_mnemonic___v18
    lda __T_find_mnemonic___v15
    cmp __T_find_mnemonic___v18
    beq __F_find_mnemonic_yes_7
    jmp __F_find_mnemonic_join_9
__F_find_mnemonic_yes_7:
    ldy #$01
    lda __L_find_mnemonic_name
    sta __ap
    lda __L_find_mnemonic_name+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_find_mnemonic___v23
    lda __L_find_mnemonic_offset
    clc
    adc #$01
    sta __T_find_mnemonic___v27
    lda #$00
    adc #$00
    sta __T_find_mnemonic___v27+1
    lda #<mnemonic_table
    sta __ap
    lda #>mnemonic_table
    sta __ap+1
    lda __T_find_mnemonic___v27
    sta __ix
    lda __T_find_mnemonic___v27+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_mnemonic___v28
    lda __T_find_mnemonic___v23
    cmp __T_find_mnemonic___v28
    beq __F_find_mnemonic_yes_10
    jmp __F_find_mnemonic_join_9
__F_find_mnemonic_yes_10:
    ldy #$02
    lda __L_find_mnemonic_name
    sta __ap
    lda __L_find_mnemonic_name+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_find_mnemonic___v33
    lda __L_find_mnemonic_offset
    clc
    adc #$02
    sta __T_find_mnemonic___v37
    lda #$00
    adc #$00
    sta __T_find_mnemonic___v37+1
    lda #<mnemonic_table
    sta __ap
    lda #>mnemonic_table
    sta __ap+1
    lda __T_find_mnemonic___v37
    sta __ix
    lda __T_find_mnemonic___v37+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_mnemonic___v38
    lda __T_find_mnemonic___v33
    cmp __T_find_mnemonic___v38
    beq __F_find_mnemonic_yes_13
    jmp __F_find_mnemonic_join_9
__F_find_mnemonic_yes_13:
    lda __L_find_mnemonic_candidate
    ldx #$00
    rts
__F_find_mnemonic_join_9:
    inc __L_find_mnemonic_candidate
    jmp __F_find_mnemonic_while_4
__F_find_mnemonic_after_6:
    sec
    lda #$00
    sbc #$01
    sta __T_find_mnemonic___v45
    lda #$00
    sbc #$00
    sta __T_find_mnemonic___v45+1
    lda __T_find_mnemonic___v45
    ldx __T_find_mnemonic___v45+1
    rts
find_opcode:
__F_find_opcode_entry:
    lda #$00
    sta __L_find_opcode_opcode
    lda #$00
    sta __L_find_opcode_opcode+1
__F_find_opcode_while_1:
    lda #$01
    eor #$80
    sta __rh
    lda __L_find_opcode_opcode+1
    eor #$80
    cmp __rh
    bcc __F_find_opcode___sel1
    bne __F_find_opcode___sel2
    lda __L_find_opcode_opcode
    cmp #$00
    bcc __F_find_opcode___sel1
    bne __F_find_opcode___sel2
    jmp __F_find_opcode___sel3
__F_find_opcode___sel1:
    jmp __F_find_opcode_body_2
__F_find_opcode___sel2:
    jmp __F_find_opcode_after_3
__F_find_opcode___sel3:
    jmp __F_find_opcode_after_3
__F_find_opcode_body_2:
    lda #<opcode_mnemonic
    sta __ap
    lda #>opcode_mnemonic
    sta __ap+1
    lda __L_find_opcode_opcode
    sta __ix
    lda __L_find_opcode_opcode+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_opcode___v6
    cmp __L_find_opcode_mnemonic
    beq __F_find_opcode_yes_4
    jmp __F_find_opcode_join_6
__F_find_opcode_yes_4:
    lda #<opcode_mode
    sta __ap
    lda #>opcode_mode
    sta __ap+1
    lda __L_find_opcode_opcode
    sta __ix
    lda __L_find_opcode_opcode+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_opcode___v11
    cmp __L_find_opcode_mode
    beq __F_find_opcode_yes_7
    jmp __F_find_opcode_join_6
__F_find_opcode_yes_7:
    lda __L_find_opcode_opcode
    ldx __L_find_opcode_opcode+1
    rts
__F_find_opcode_join_6:
    lda __L_find_opcode_opcode
    clc
    adc #$01
    sta __T_find_opcode___v17
    lda __L_find_opcode_opcode+1
    adc #$00
    sta __T_find_opcode___v17+1
    lda __T_find_opcode___v17
    sta __L_find_opcode_opcode
    lda __T_find_opcode___v17+1
    sta __L_find_opcode_opcode+1
    jmp __F_find_opcode_while_1
__F_find_opcode_after_3:
    sec
    lda #$00
    sbc #$01
    sta __T_find_opcode___v19
    lda #$00
    sbc #$00
    sta __T_find_opcode___v19+1
    lda __T_find_opcode___v19
    ldx __T_find_opcode___v19+1
    rts
stage_byte:
__F_stage_byte_entry:
    lda #$2c
    eor #$80
    sta __rh
    lda ass_image_length+1
    eor #$80
    cmp __rh
    bcc __F_stage_byte___sel1
    bne __F_stage_byte___sel2
    lda ass_image_length
    cmp #$00
    bcc __F_stage_byte___sel1
    bne __F_stage_byte___sel2
    jmp __F_stage_byte___sel3
__F_stage_byte___sel1:
    jmp __F_stage_byte_join_3
__F_stage_byte___sel2:
    jmp __F_stage_byte_yes_1
__F_stage_byte___sel3:
    jmp __F_stage_byte_yes_1
__F_stage_byte_yes_1:
    lda ASSEMBLE_WORK_FULL
    ldx #$00
    rts
__F_stage_byte_join_3:
    lda ass_image_length
    sta __T_stage_byte___v5
    lda ass_image_length+1
    sta __T_stage_byte___v5+1
    lda __L_stage_byte_value
    and #$ff
    sta __T_stage_byte___v8
    lda #$00
    and #$00
    sta __T_stage_byte___v8+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_stage_byte___v5
    sta __ix
    lda __T_stage_byte___v5+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_stage_byte___v8
    sta (__ap),y
    lda ass_image_length
    clc
    adc #$01
    sta __T_stage_byte___v11
    lda ass_image_length+1
    adc #$00
    sta __T_stage_byte___v11+1
    lda __T_stage_byte___v11
    sta ass_image_length
    lda __T_stage_byte___v11+1
    sta ass_image_length+1
    lda ASSEMBLE_OK
    ldx #$00
    rts
stage_plain_word_reference:
__F_stage_plain_word_reference_entry:
    lda ass_image_length
    sta __L_stage_plain_word_reference_stage
    lda ass_image_length+1
    sta __L_stage_plain_word_reference_stage+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __L_stage_plain_word_reference_symbol
    asl
    sta __ix
    lda __L_stage_plain_word_reference_symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_stage_plain_word_reference___v3
    iny
    lda (__ap),y
    sta __T_stage_plain_word_reference___v3+1
    lda __T_stage_plain_word_reference___v3
    sta __L_stage_plain_word_reference_old_head
    lda __T_stage_plain_word_reference___v3+1
    sta __L_stage_plain_word_reference_old_head+1
    lda __L_stage_plain_word_reference_old_head
    and #$ff
    sta __T_stage_plain_word_reference___v6
    lda __L_stage_plain_word_reference_old_head+1
    and #$00
    sta __T_stage_plain_word_reference___v6+1
    lda __T_stage_plain_word_reference___v6
    sta __call_stage_byte_0
    lda __T_stage_plain_word_reference___v6+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_plain_word_reference_status
    lda __L_stage_plain_word_reference_status
    cmp ASSEMBLE_OK
    bne __F_stage_plain_word_reference_yes_1
    jmp __F_stage_plain_word_reference_join_3
__F_stage_plain_word_reference_yes_1:
    lda __L_stage_plain_word_reference_status
    ldx #$00
    rts
__F_stage_plain_word_reference_join_3:
    lda __L_stage_plain_word_reference_old_head
    sta __T_stage_plain_word_reference___v14
    lda __L_stage_plain_word_reference_old_head+1
    sta __T_stage_plain_word_reference___v14+1
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14
    and #$ff
    sta __T_stage_plain_word_reference___v16
    lda __T_stage_plain_word_reference___v14+1
    and #$00
    sta __T_stage_plain_word_reference___v16+1
    lda __T_stage_plain_word_reference___v16
    sta __call_stage_byte_0
    lda __T_stage_plain_word_reference___v16+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_plain_word_reference_status
    lda __L_stage_plain_word_reference_status
    cmp ASSEMBLE_OK
    bne __F_stage_plain_word_reference_yes_4
    jmp __F_stage_plain_word_reference_join_6
__F_stage_plain_word_reference_yes_4:
    lda __L_stage_plain_word_reference_status
    ldx #$00
    rts
__F_stage_plain_word_reference_join_6:
    lda __L_stage_plain_word_reference_symbol
    sta __T_stage_plain_word_reference___v23
    lda __L_stage_plain_word_reference_symbol+1
    sta __T_stage_plain_word_reference___v23+1
    lda __L_stage_plain_word_reference_stage
    clc
    adc #$01
    sta __T_stage_plain_word_reference___v26
    lda __L_stage_plain_word_reference_stage+1
    adc #$00
    sta __T_stage_plain_word_reference___v26+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __T_stage_plain_word_reference___v23
    asl
    sta __ix
    lda __T_stage_plain_word_reference___v23+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_stage_plain_word_reference___v26
    sta (__ap),y
    iny
    lda __T_stage_plain_word_reference___v26+1
    sta (__ap),y
    lda ASSEMBLE_OK
    ldx #$00
    rts
stage_resolved_instruction:
__F_stage_resolved_instruction_entry:
    ldy __L_stage_resolved_instruction_mode
    lda mode_width,y
    sta __L_stage_resolved_instruction_width
    lda __L_stage_resolved_instruction_width
    cmp #$01
    beq __F_stage_resolved_instruction_yes_1
    jmp __F_stage_resolved_instruction_join_3
__F_stage_resolved_instruction_yes_1:
    lda __L_stage_resolved_instruction_value+1
    cmp #$00
    bcc __F_stage_resolved_instruction___sel1
    bne __F_stage_resolved_instruction___sel2
    lda __L_stage_resolved_instruction_value
    cmp #$ff
    bcc __F_stage_resolved_instruction___sel1
    bne __F_stage_resolved_instruction___sel2
    jmp __F_stage_resolved_instruction___sel3
__F_stage_resolved_instruction___sel1:
    jmp __F_stage_resolved_instruction_join_3
__F_stage_resolved_instruction___sel2:
    jmp __F_stage_resolved_instruction_yes_4
__F_stage_resolved_instruction___sel3:
    jmp __F_stage_resolved_instruction_join_3
__F_stage_resolved_instruction_yes_4:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_stage_resolved_instruction_join_3:
    lda __L_stage_resolved_instruction_opcode
    sta __T_stage_resolved_instruction___v10
    lda __T_stage_resolved_instruction___v10
    sta __call_stage_byte_0
    jsr stage_byte
    sta __L_stage_resolved_instruction_status
    lda __L_stage_resolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_resolved_instruction_yes_7
    jmp __F_stage_resolved_instruction_join_9
__F_stage_resolved_instruction_yes_7:
    lda __L_stage_resolved_instruction_status
    ldx #$00
    rts
__F_stage_resolved_instruction_join_9:
    lda __L_stage_resolved_instruction_width
    cmp #$00
    beq __F_stage_resolved_instruction_yes_10
    jmp __F_stage_resolved_instruction_join_12
__F_stage_resolved_instruction_yes_10:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_stage_resolved_instruction_join_12:
    lda __L_stage_resolved_instruction_value
    and #$ff
    sta __T_stage_resolved_instruction___v22
    lda __L_stage_resolved_instruction_value+1
    and #$00
    sta __T_stage_resolved_instruction___v22+1
    lda __T_stage_resolved_instruction___v22
    sta __call_stage_byte_0
    lda __T_stage_resolved_instruction___v22+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_resolved_instruction_status
    lda __L_stage_resolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_resolved_instruction_yes_13
    jmp __F_stage_resolved_instruction_join_15
__F_stage_resolved_instruction_yes_13:
    lda __L_stage_resolved_instruction_status
    ldx #$00
    rts
__F_stage_resolved_instruction_join_15:
    lda __L_stage_resolved_instruction_width
    cmp #$02
    beq __F_stage_resolved_instruction_yes_16
    jmp __F_stage_resolved_instruction_join_18
__F_stage_resolved_instruction_yes_16:
    lda __L_stage_resolved_instruction_value
    sta __T_stage_resolved_instruction___v33
    lda __L_stage_resolved_instruction_value+1
    sta __T_stage_resolved_instruction___v33+1
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lda __T_stage_resolved_instruction___v33
    and #$ff
    sta __T_stage_resolved_instruction___v35
    lda __T_stage_resolved_instruction___v33+1
    and #$00
    sta __T_stage_resolved_instruction___v35+1
    lda __T_stage_resolved_instruction___v35
    sta __call_stage_byte_0
    lda __T_stage_resolved_instruction___v35+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    ldx #$00
    rts
__F_stage_resolved_instruction_join_18:
    lda ASSEMBLE_OK
    ldx #$00
    rts
stage_resolved_relative:
__F_stage_resolved_relative_entry:
    lda ass_origin
    clc
    adc ass_image_length
    sta __T_stage_resolved_relative___v2
    lda ass_origin+1
    adc ass_image_length+1
    sta __T_stage_resolved_relative___v2+1
    lda __T_stage_resolved_relative___v2
    clc
    adc #$02
    sta __T_stage_resolved_relative___v4
    lda __T_stage_resolved_relative___v2+1
    adc #$00
    sta __T_stage_resolved_relative___v4+1
    lda __T_stage_resolved_relative___v4
    sta __T_stage_resolved_relative___v6
    lda __T_stage_resolved_relative___v4+1
    sta __T_stage_resolved_relative___v6+1
    lda __T_stage_resolved_relative___v6
    sta __L_stage_resolved_relative_base
    lda __T_stage_resolved_relative___v6+1
    sta __L_stage_resolved_relative_base+1
    lda __L_stage_resolved_relative_target
    sta __T_stage_resolved_relative___v7
    lda __L_stage_resolved_relative_target+1
    sta __T_stage_resolved_relative___v7+1
    lda __L_stage_resolved_relative_base
    sta __T_stage_resolved_relative___v8
    lda __L_stage_resolved_relative_base+1
    sta __T_stage_resolved_relative___v8+1
    lda __T_stage_resolved_relative___v7
    sta __call_relative_byte_0
    lda __T_stage_resolved_relative___v7+1
    sta __call_relative_byte_0+1
    lda __T_stage_resolved_relative___v8
    sta __call_relative_byte_1
    lda __T_stage_resolved_relative___v8+1
    sta __call_relative_byte_1+1
    jsr relative_byte
    sta __L_stage_resolved_relative_relative
    stx __L_stage_resolved_relative_relative+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_stage_resolved_relative_relative+1
    eor #$80
    cmp __rh
    bcc __F_stage_resolved_relative___sel1
    bne __F_stage_resolved_relative___sel2
    lda __L_stage_resolved_relative_relative
    cmp #$00
    bcc __F_stage_resolved_relative___sel1
    bne __F_stage_resolved_relative___sel2
    jmp __F_stage_resolved_relative___sel3
__F_stage_resolved_relative___sel1:
    jmp __F_stage_resolved_relative_yes_1
__F_stage_resolved_relative___sel2:
    jmp __F_stage_resolved_relative_join_3
__F_stage_resolved_relative___sel3:
    jmp __F_stage_resolved_relative_join_3
__F_stage_resolved_relative_yes_1:
    lda ASSEMBLE_EMIT_ERROR
    ldx #$00
    rts
__F_stage_resolved_relative_join_3:
    lda __L_stage_resolved_relative_opcode
    sta __T_stage_resolved_relative___v14
    lda __T_stage_resolved_relative___v14
    sta __call_stage_byte_0
    jsr stage_byte
    sta __L_stage_resolved_relative_status
    lda __L_stage_resolved_relative_status
    cmp ASSEMBLE_OK
    bne __F_stage_resolved_relative_yes_4
    jmp __F_stage_resolved_relative_join_6
__F_stage_resolved_relative_yes_4:
    lda __L_stage_resolved_relative_status
    ldx #$00
    rts
__F_stage_resolved_relative_join_6:
    lda __L_stage_resolved_relative_relative
    sta __T_stage_resolved_relative___v20
    lda __L_stage_resolved_relative_relative+1
    sta __T_stage_resolved_relative___v20+1
    lda __T_stage_resolved_relative___v20
    sta __call_stage_byte_0
    lda __T_stage_resolved_relative___v20+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    ldx #$00
    rts
stage_unresolved_instruction:
__F_stage_unresolved_instruction_entry:
    ldy __L_stage_unresolved_instruction_mode
    lda mode_width,y
    sta __L_stage_unresolved_instruction_width
    lda __L_stage_unresolved_instruction_opcode
    sta __T_stage_unresolved_instruction___v3
    lda __T_stage_unresolved_instruction___v3
    sta __call_stage_byte_0
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    lda __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_unresolved_instruction_yes_1
    jmp __F_stage_unresolved_instruction_join_3
__F_stage_unresolved_instruction_yes_1:
    lda __L_stage_unresolved_instruction_status
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_3:
    lda ass_image_length
    sta __L_stage_unresolved_instruction_stage
    lda ass_image_length+1
    sta __L_stage_unresolved_instruction_stage+1
    lda __L_stage_unresolved_instruction_width
    cmp #$02
    beq __F_stage_unresolved_instruction_yes_4
    jmp __F_stage_unresolved_instruction_join_6
__F_stage_unresolved_instruction_yes_4:
    lda __L_stage_unresolved_instruction_prefix
    cmp VALUE_PREFIX_NONE
    beq __F_stage_unresolved_instruction_yes_7
    jmp __F_stage_unresolved_instruction_join_9
__F_stage_unresolved_instruction_yes_7:
    lda __L_stage_unresolved_instruction_addend
    sta __T_stage_unresolved_instruction___v18
    lda __L_stage_unresolved_instruction_addend+1
    sta __T_stage_unresolved_instruction___v18+1
    lda __T_stage_unresolved_instruction___v18+1
    cmp #$00
    bne __F_stage_unresolved_instruction_join_9
    lda __T_stage_unresolved_instruction___v18
    cmp #$00
    beq __F_stage_unresolved_instruction_yes_10
    jmp __F_stage_unresolved_instruction_join_9
__F_stage_unresolved_instruction_yes_10:
    lda __L_stage_unresolved_instruction_symbol
    sta __T_stage_unresolved_instruction___v21
    lda __L_stage_unresolved_instruction_symbol+1
    sta __T_stage_unresolved_instruction___v21+1
    lda __T_stage_unresolved_instruction___v21
    sta __call_stage_plain_word_reference_0
    lda __T_stage_unresolved_instruction___v21+1
    sta __call_stage_plain_word_reference_0+1
    jsr stage_plain_word_reference
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_9:
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    lda __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_unresolved_instruction_yes_13
    jmp __F_stage_unresolved_instruction_join_15
__F_stage_unresolved_instruction_yes_13:
    lda __L_stage_unresolved_instruction_status
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_15:
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    lda __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_unresolved_instruction_yes_16
    jmp __F_stage_unresolved_instruction_join_18
__F_stage_unresolved_instruction_yes_16:
    lda __L_stage_unresolved_instruction_status
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_18:
    lda FIXUP_WORD
    sta __T_stage_unresolved_instruction___v35
    lda __L_stage_unresolved_instruction_stage
    sta __T_stage_unresolved_instruction___v36
    lda __L_stage_unresolved_instruction_stage+1
    sta __T_stage_unresolved_instruction___v36+1
    lda __L_stage_unresolved_instruction_symbol
    sta __T_stage_unresolved_instruction___v37
    lda __L_stage_unresolved_instruction_symbol+1
    sta __T_stage_unresolved_instruction___v37+1
    lda __L_stage_unresolved_instruction_addend
    sta __T_stage_unresolved_instruction___v38
    lda __L_stage_unresolved_instruction_addend+1
    sta __T_stage_unresolved_instruction___v38+1
    lda __L_stage_unresolved_instruction_prefix
    sta __T_stage_unresolved_instruction___v39
    lda __T_stage_unresolved_instruction___v35
    sta __call_append_fixup_0
    lda __T_stage_unresolved_instruction___v36
    sta __call_append_fixup_1
    lda __T_stage_unresolved_instruction___v36+1
    sta __call_append_fixup_1+1
    lda __T_stage_unresolved_instruction___v37
    sta __call_append_fixup_2
    lda __T_stage_unresolved_instruction___v37+1
    sta __call_append_fixup_2+1
    lda __T_stage_unresolved_instruction___v38
    sta __call_append_fixup_3
    lda __T_stage_unresolved_instruction___v38+1
    sta __call_append_fixup_3+1
    lda __T_stage_unresolved_instruction___v39
    sta __call_append_fixup_4
    jsr append_fixup
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_6:
    lda __L_stage_unresolved_instruction_width
    cmp #$01
    bne __F_stage_unresolved_instruction_yes_19
    jmp __F_stage_unresolved_instruction_join_21
__F_stage_unresolved_instruction_yes_19:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_21:
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    lda __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_unresolved_instruction_yes_22
    jmp __F_stage_unresolved_instruction_join_24
__F_stage_unresolved_instruction_yes_22:
    lda __L_stage_unresolved_instruction_status
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_24:
    lda FIXUP_BYTE
    sta __L_stage_unresolved_instruction_kind
    lda __L_stage_unresolved_instruction_mode
    cmp MODE_RELATIVE
    beq __F_stage_unresolved_instruction_yes_25
    jmp __F_stage_unresolved_instruction_join_27
__F_stage_unresolved_instruction_yes_25:
    lda FIXUP_RELATIVE
    sta __L_stage_unresolved_instruction_kind
__F_stage_unresolved_instruction_join_27:
    lda __L_stage_unresolved_instruction_kind
    sta __T_stage_unresolved_instruction___v56
    lda __L_stage_unresolved_instruction_stage
    sta __T_stage_unresolved_instruction___v57
    lda __L_stage_unresolved_instruction_stage+1
    sta __T_stage_unresolved_instruction___v57+1
    lda __L_stage_unresolved_instruction_symbol
    sta __T_stage_unresolved_instruction___v58
    lda __L_stage_unresolved_instruction_symbol+1
    sta __T_stage_unresolved_instruction___v58+1
    lda __L_stage_unresolved_instruction_addend
    sta __T_stage_unresolved_instruction___v59
    lda __L_stage_unresolved_instruction_addend+1
    sta __T_stage_unresolved_instruction___v59+1
    lda __L_stage_unresolved_instruction_prefix
    sta __T_stage_unresolved_instruction___v60
    lda __T_stage_unresolved_instruction___v56
    sta __call_append_fixup_0
    lda __T_stage_unresolved_instruction___v57
    sta __call_append_fixup_1
    lda __T_stage_unresolved_instruction___v57+1
    sta __call_append_fixup_1+1
    lda __T_stage_unresolved_instruction___v58
    sta __call_append_fixup_2
    lda __T_stage_unresolved_instruction___v58+1
    sta __call_append_fixup_2+1
    lda __T_stage_unresolved_instruction___v59
    sta __call_append_fixup_3
    lda __T_stage_unresolved_instruction___v59+1
    sta __call_append_fixup_3+1
    lda __T_stage_unresolved_instruction___v60
    sta __call_append_fixup_4
    jsr append_fixup
    ldx #$00
    rts
short_mode_for_index:
__F_short_mode_for_index_entry:
    lda __L_short_mode_for_index_index
    cmp #$01
    beq __F_short_mode_for_index_yes_1
    jmp __F_short_mode_for_index_join_3
__F_short_mode_for_index_yes_1:
    lda MODE_ZERO_PAGE_X
    ldx #$00
    rts
__F_short_mode_for_index_join_3:
    lda __L_short_mode_for_index_index
    cmp #$02
    beq __F_short_mode_for_index_yes_4
    jmp __F_short_mode_for_index_join_6
__F_short_mode_for_index_yes_4:
    lda MODE_ZERO_PAGE_Y
    ldx #$00
    rts
__F_short_mode_for_index_join_6:
    lda MODE_ZERO_PAGE
    ldx #$00
    rts
long_mode_for_index:
__F_long_mode_for_index_entry:
    lda __L_long_mode_for_index_index
    cmp #$01
    beq __F_long_mode_for_index_yes_1
    jmp __F_long_mode_for_index_join_3
__F_long_mode_for_index_yes_1:
    lda MODE_ABSOLUTE_X
    ldx #$00
    rts
__F_long_mode_for_index_join_3:
    lda __L_long_mode_for_index_index
    cmp #$02
    beq __F_long_mode_for_index_yes_4
    jmp __F_long_mode_for_index_join_6
__F_long_mode_for_index_yes_4:
    lda MODE_ABSOLUTE_Y
    ldx #$00
    rts
__F_long_mode_for_index_join_6:
    lda MODE_ABSOLUTE
    ldx #$00
    rts
assemble_mode_value:
__F_assemble_mode_value_entry:
    lda __L_assemble_mode_value_mnemonic
    sta __T_assemble_mode_value___v0
    lda __L_assemble_mode_value_mode
    sta __T_assemble_mode_value___v1
    lda __T_assemble_mode_value___v0
    sta __call_find_opcode_0
    lda __T_assemble_mode_value___v1
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_mode_value_opcode
    stx __L_assemble_mode_value_opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_mode_value_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_mode_value___sel1
    bne __F_assemble_mode_value___sel2
    lda __L_assemble_mode_value_opcode
    cmp #$00
    bcc __F_assemble_mode_value___sel1
    bne __F_assemble_mode_value___sel2
    jmp __F_assemble_mode_value___sel3
__F_assemble_mode_value___sel1:
    jmp __F_assemble_mode_value_yes_1
__F_assemble_mode_value___sel2:
    jmp __F_assemble_mode_value_join_3
__F_assemble_mode_value___sel3:
    jmp __F_assemble_mode_value_join_3
__F_assemble_mode_value_yes_1:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_mode_value_join_3:
    lda __L_assemble_mode_value_text
    sta __T_assemble_mode_value___v7
    lda __L_assemble_mode_value_text+1
    sta __T_assemble_mode_value___v7+1
    lda __L_assemble_mode_value_length
    sta __T_assemble_mode_value___v8
    lda __T_assemble_mode_value___v7
    sta __call_parse_value_0
    lda __T_assemble_mode_value___v7+1
    sta __call_parse_value_0+1
    lda __T_assemble_mode_value___v8
    sta __call_parse_value_1
    jsr parse_value
    sta __L_assemble_mode_value_status
    lda __L_assemble_mode_value_status
    cmp VALUE_OK
    beq __F_assemble_mode_value_yes_4
    jmp __F_assemble_mode_value_join_6
__F_assemble_mode_value_yes_4:
    lda __L_assemble_mode_value_mode
    cmp MODE_RELATIVE
    beq __F_assemble_mode_value_yes_7
    jmp __F_assemble_mode_value_join_9
__F_assemble_mode_value_yes_7:
    lda __L_assemble_mode_value_opcode
    sta __T_assemble_mode_value___v16
    lda __L_assemble_mode_value_opcode+1
    sta __T_assemble_mode_value___v16+1
    lda value_result
    sta __T_assemble_mode_value___v17
    lda value_result+1
    sta __T_assemble_mode_value___v17+1
    lda __T_assemble_mode_value___v16
    sta __call_stage_resolved_relative_0
    lda __T_assemble_mode_value___v16+1
    sta __call_stage_resolved_relative_0+1
    lda __T_assemble_mode_value___v17
    sta __call_stage_resolved_relative_1
    lda __T_assemble_mode_value___v17+1
    sta __call_stage_resolved_relative_1+1
    jsr stage_resolved_relative
    ldx #$00
    rts
__F_assemble_mode_value_join_9:
    lda __L_assemble_mode_value_opcode
    sta __T_assemble_mode_value___v19
    lda __L_assemble_mode_value_opcode+1
    sta __T_assemble_mode_value___v19+1
    lda __L_assemble_mode_value_mode
    sta __T_assemble_mode_value___v20
    lda value_result
    sta __T_assemble_mode_value___v21
    lda value_result+1
    sta __T_assemble_mode_value___v21+1
    lda __T_assemble_mode_value___v19
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_mode_value___v19+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_mode_value___v20
    sta __call_stage_resolved_instruction_1
    lda __T_assemble_mode_value___v21
    sta __call_stage_resolved_instruction_2
    lda __T_assemble_mode_value___v21+1
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_mode_value_join_6:
    lda __L_assemble_mode_value_status
    cmp VALUE_UNRESOLVED
    beq __F_assemble_mode_value_yes_10
    jmp __F_assemble_mode_value_join_12
__F_assemble_mode_value_yes_10:
    lda __L_assemble_mode_value_opcode
    sta __T_assemble_mode_value___v26
    lda __L_assemble_mode_value_opcode+1
    sta __T_assemble_mode_value___v26+1
    lda __L_assemble_mode_value_mode
    sta __T_assemble_mode_value___v27
    lda captured_symbol
    sta __T_assemble_mode_value___v28
    lda captured_symbol+1
    sta __T_assemble_mode_value___v28+1
    lda captured_addend
    sta __T_assemble_mode_value___v29
    lda captured_addend+1
    sta __T_assemble_mode_value___v29+1
    lda captured_prefix
    sta __T_assemble_mode_value___v30
    lda __T_assemble_mode_value___v26
    sta __call_stage_unresolved_instruction_0
    lda __T_assemble_mode_value___v26+1
    sta __call_stage_unresolved_instruction_0+1
    lda __T_assemble_mode_value___v27
    sta __call_stage_unresolved_instruction_1
    lda __T_assemble_mode_value___v28
    sta __call_stage_unresolved_instruction_2
    lda __T_assemble_mode_value___v28+1
    sta __call_stage_unresolved_instruction_2+1
    lda __T_assemble_mode_value___v29
    sta __call_stage_unresolved_instruction_3
    lda __T_assemble_mode_value___v29+1
    sta __call_stage_unresolved_instruction_3+1
    lda __T_assemble_mode_value___v30
    sta __call_stage_unresolved_instruction_4
    jsr stage_unresolved_instruction
    ldx #$00
    rts
__F_assemble_mode_value_join_12:
    lda __L_assemble_mode_value_status
    cmp VALUE_SYMBOL_FULL
    beq __F_assemble_mode_value_yes_13
    jmp __F_assemble_mode_value_join_15
__F_assemble_mode_value_yes_13:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_assemble_mode_value_join_15:
    lda __L_assemble_mode_value_status
    cmp VALUE_SCOPE_ERROR
    beq __F_assemble_mode_value_yes_16
    jmp __F_assemble_mode_value_join_18
__F_assemble_mode_value_yes_16:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_assemble_mode_value_join_18:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
assemble_direct_value:
__F_assemble_direct_value_entry:
    lda __L_assemble_direct_value_index
    cmp #$00
    beq __F_assemble_direct_value_yes_1
    jmp __F_assemble_direct_value_join_3
__F_assemble_direct_value_yes_1:
    lda __L_assemble_direct_value_mnemonic
    sta __T_assemble_direct_value___v3
    lda MODE_RELATIVE
    sta __T_assemble_direct_value___v4
    lda __T_assemble_direct_value___v3
    sta __call_find_opcode_0
    lda __T_assemble_direct_value___v4
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_direct_value_opcode
    stx __L_assemble_direct_value_opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_direct_value_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_direct_value___sel1
    bne __F_assemble_direct_value___sel2
    lda __L_assemble_direct_value_opcode
    cmp #$00
    bcc __F_assemble_direct_value___sel1
    bne __F_assemble_direct_value___sel2
    jmp __F_assemble_direct_value___sel3
__F_assemble_direct_value___sel1:
    jmp __F_assemble_direct_value_join_3
__F_assemble_direct_value___sel2:
    jmp __F_assemble_direct_value_yes_4
__F_assemble_direct_value___sel3:
    jmp __F_assemble_direct_value_yes_4
__F_assemble_direct_value_yes_4:
    lda __L_assemble_direct_value_mnemonic
    sta __T_assemble_direct_value___v9
    lda MODE_RELATIVE
    sta __T_assemble_direct_value___v10
    lda __L_assemble_direct_value_text
    sta __T_assemble_direct_value___v11
    lda __L_assemble_direct_value_text+1
    sta __T_assemble_direct_value___v11+1
    lda __L_assemble_direct_value_length
    sta __T_assemble_direct_value___v12
    lda __T_assemble_direct_value___v9
    sta __call_assemble_mode_value_0
    lda __T_assemble_direct_value___v10
    sta __call_assemble_mode_value_1
    lda __T_assemble_direct_value___v11
    sta __call_assemble_mode_value_2
    lda __T_assemble_direct_value___v11+1
    sta __call_assemble_mode_value_2+1
    lda __T_assemble_direct_value___v12
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    ldx #$00
    rts
__F_assemble_direct_value_join_3:
    lda __L_assemble_direct_value_text
    sta __T_assemble_direct_value___v14
    lda __L_assemble_direct_value_text+1
    sta __T_assemble_direct_value___v14+1
    lda __L_assemble_direct_value_length
    sta __T_assemble_direct_value___v15
    lda __T_assemble_direct_value___v14
    sta __call_parse_value_0
    lda __T_assemble_direct_value___v14+1
    sta __call_parse_value_0+1
    lda __T_assemble_direct_value___v15
    sta __call_parse_value_1
    jsr parse_value
    sta __L_assemble_direct_value_status
    lda __L_assemble_direct_value_status
    cmp VALUE_OK
    bne __F_assemble_direct_value_yes_7
    jmp __F_assemble_direct_value_join_9
__F_assemble_direct_value_yes_7:
    lda __L_assemble_direct_value_status
    cmp VALUE_UNRESOLVED
    bne __F_assemble_direct_value_yes_10
    jmp __F_assemble_direct_value_join_9
__F_assemble_direct_value_yes_10:
    lda __L_assemble_direct_value_status
    cmp VALUE_SYMBOL_FULL
    beq __F_assemble_direct_value_yes_13
    jmp __F_assemble_direct_value_join_15
__F_assemble_direct_value_yes_13:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_assemble_direct_value_join_15:
    lda __L_assemble_direct_value_status
    cmp VALUE_SCOPE_ERROR
    beq __F_assemble_direct_value_yes_16
    jmp __F_assemble_direct_value_join_18
__F_assemble_direct_value_yes_16:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_assemble_direct_value_join_18:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_direct_value_join_9:
    lda __L_assemble_direct_value_index
    sta __T_assemble_direct_value___v32
    lda __T_assemble_direct_value___v32
    sta __call_short_mode_for_index_0
    jsr short_mode_for_index
    sta __L_assemble_direct_value_short_mode
    lda __L_assemble_direct_value_index
    sta __T_assemble_direct_value___v34
    lda __T_assemble_direct_value___v34
    sta __call_long_mode_for_index_0
    jsr long_mode_for_index
    sta __L_assemble_direct_value_long_mode
    lda __L_assemble_direct_value_mnemonic
    sta __T_assemble_direct_value___v36
    lda __L_assemble_direct_value_short_mode
    sta __T_assemble_direct_value___v37
    lda __T_assemble_direct_value___v36
    sta __call_find_opcode_0
    lda __T_assemble_direct_value___v37
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_direct_value_short_opcode
    stx __L_assemble_direct_value_short_opcode+1
    lda __L_assemble_direct_value_mnemonic
    sta __T_assemble_direct_value___v39
    lda __L_assemble_direct_value_long_mode
    sta __T_assemble_direct_value___v40
    lda __T_assemble_direct_value___v39
    sta __call_find_opcode_0
    lda __T_assemble_direct_value___v40
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_direct_value_long_opcode
    stx __L_assemble_direct_value_long_opcode+1
    lda __L_assemble_direct_value_status
    cmp VALUE_OK
    beq __F_assemble_direct_value_yes_19
    jmp __F_assemble_direct_value_join_21
__F_assemble_direct_value_yes_19:
    lda value_result+1
    cmp #$00
    bcc __F_assemble_direct_value___sel4
    bne __F_assemble_direct_value___sel5
    lda value_result
    cmp #$ff
    bcc __F_assemble_direct_value___sel4
    bne __F_assemble_direct_value___sel5
    jmp __F_assemble_direct_value___sel6
__F_assemble_direct_value___sel4:
    jmp __F_assemble_direct_value_yes_22
__F_assemble_direct_value___sel5:
    jmp __F_assemble_direct_value_join_24
__F_assemble_direct_value___sel6:
    jmp __F_assemble_direct_value_yes_22
__F_assemble_direct_value_yes_22:
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_direct_value_short_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_direct_value___sel7
    bne __F_assemble_direct_value___sel8
    lda __L_assemble_direct_value_short_opcode
    cmp #$00
    bcc __F_assemble_direct_value___sel7
    bne __F_assemble_direct_value___sel8
    jmp __F_assemble_direct_value___sel9
__F_assemble_direct_value___sel7:
    jmp __F_assemble_direct_value_join_24
__F_assemble_direct_value___sel8:
    jmp __F_assemble_direct_value_yes_25
__F_assemble_direct_value___sel9:
    jmp __F_assemble_direct_value_yes_25
__F_assemble_direct_value_yes_25:
    lda __L_assemble_direct_value_short_opcode
    sta __T_assemble_direct_value___v51
    lda __L_assemble_direct_value_short_opcode+1
    sta __T_assemble_direct_value___v51+1
    lda __L_assemble_direct_value_short_mode
    sta __T_assemble_direct_value___v52
    lda value_result
    sta __T_assemble_direct_value___v53
    lda value_result+1
    sta __T_assemble_direct_value___v53+1
    lda __T_assemble_direct_value___v51
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_direct_value___v51+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_direct_value___v52
    sta __call_stage_resolved_instruction_1
    lda __T_assemble_direct_value___v53
    sta __call_stage_resolved_instruction_2
    lda __T_assemble_direct_value___v53+1
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_direct_value_join_24:
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_direct_value_long_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_direct_value___sel10
    bne __F_assemble_direct_value___sel11
    lda __L_assemble_direct_value_long_opcode
    cmp #$00
    bcc __F_assemble_direct_value___sel10
    bne __F_assemble_direct_value___sel11
    jmp __F_assemble_direct_value___sel12
__F_assemble_direct_value___sel10:
    jmp __F_assemble_direct_value_join_30
__F_assemble_direct_value___sel11:
    jmp __F_assemble_direct_value_yes_28
__F_assemble_direct_value___sel12:
    jmp __F_assemble_direct_value_yes_28
__F_assemble_direct_value_yes_28:
    lda __L_assemble_direct_value_long_opcode
    sta __T_assemble_direct_value___v58
    lda __L_assemble_direct_value_long_opcode+1
    sta __T_assemble_direct_value___v58+1
    lda __L_assemble_direct_value_long_mode
    sta __T_assemble_direct_value___v59
    lda value_result
    sta __T_assemble_direct_value___v60
    lda value_result+1
    sta __T_assemble_direct_value___v60+1
    lda __T_assemble_direct_value___v58
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_direct_value___v58+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_direct_value___v59
    sta __call_stage_resolved_instruction_1
    lda __T_assemble_direct_value___v60
    sta __call_stage_resolved_instruction_2
    lda __T_assemble_direct_value___v60+1
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_direct_value_join_30:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_direct_value_join_21:
    lda __L_assemble_direct_value_long_mode
    sta __L_assemble_direct_value_mode
    lda __L_assemble_direct_value_long_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_long_opcode+1
    sta __L_assemble_direct_value_opcode+1
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    bne __F_assemble_direct_value_yes_31
    jmp __F_assemble_direct_value_no_32
__F_assemble_direct_value_yes_31:
    lda __L_assemble_direct_value_short_mode
    sta __L_assemble_direct_value_mode
    lda __L_assemble_direct_value_short_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_short_opcode+1
    sta __L_assemble_direct_value_opcode+1
    jmp __F_assemble_direct_value_join_33
__F_assemble_direct_value_no_32:
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_direct_value_long_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_direct_value___sel13
    bne __F_assemble_direct_value___sel14
    lda __L_assemble_direct_value_long_opcode
    cmp #$00
    bcc __F_assemble_direct_value___sel13
    bne __F_assemble_direct_value___sel14
    jmp __F_assemble_direct_value___sel15
__F_assemble_direct_value___sel13:
    jmp __F_assemble_direct_value_yes_34
__F_assemble_direct_value___sel14:
    jmp __F_assemble_direct_value_join_33
__F_assemble_direct_value___sel15:
    jmp __F_assemble_direct_value_join_33
__F_assemble_direct_value_yes_34:
    lda __L_assemble_direct_value_short_mode
    sta __L_assemble_direct_value_mode
    lda __L_assemble_direct_value_short_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_short_opcode+1
    sta __L_assemble_direct_value_opcode+1
__F_assemble_direct_value_join_33:
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_direct_value_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_direct_value___sel16
    bne __F_assemble_direct_value___sel17
    lda __L_assemble_direct_value_opcode
    cmp #$00
    bcc __F_assemble_direct_value___sel16
    bne __F_assemble_direct_value___sel17
    jmp __F_assemble_direct_value___sel18
__F_assemble_direct_value___sel16:
    jmp __F_assemble_direct_value_yes_37
__F_assemble_direct_value___sel17:
    jmp __F_assemble_direct_value_join_39
__F_assemble_direct_value___sel18:
    jmp __F_assemble_direct_value_join_39
__F_assemble_direct_value_yes_37:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_direct_value_join_39:
    lda __L_assemble_direct_value_opcode
    sta __T_assemble_direct_value___v79
    lda __L_assemble_direct_value_opcode+1
    sta __T_assemble_direct_value___v79+1
    lda __L_assemble_direct_value_mode
    sta __T_assemble_direct_value___v80
    lda captured_symbol
    sta __T_assemble_direct_value___v81
    lda captured_symbol+1
    sta __T_assemble_direct_value___v81+1
    lda captured_addend
    sta __T_assemble_direct_value___v82
    lda captured_addend+1
    sta __T_assemble_direct_value___v82+1
    lda captured_prefix
    sta __T_assemble_direct_value___v83
    lda __T_assemble_direct_value___v79
    sta __call_stage_unresolved_instruction_0
    lda __T_assemble_direct_value___v79+1
    sta __call_stage_unresolved_instruction_0+1
    lda __T_assemble_direct_value___v80
    sta __call_stage_unresolved_instruction_1
    lda __T_assemble_direct_value___v81
    sta __call_stage_unresolved_instruction_2
    lda __T_assemble_direct_value___v81+1
    sta __call_stage_unresolved_instruction_2+1
    lda __T_assemble_direct_value___v82
    sta __call_stage_unresolved_instruction_3
    lda __T_assemble_direct_value___v82+1
    sta __call_stage_unresolved_instruction_3+1
    lda __T_assemble_direct_value___v83
    sta __call_stage_unresolved_instruction_4
    jsr stage_unresolved_instruction
    ldx #$00
    rts
assemble_instruction:
__F_assemble_instruction_entry:
    lda __L_assemble_instruction_name
    sta __T_assemble_instruction___v0
    lda __L_assemble_instruction_name+1
    sta __T_assemble_instruction___v0+1
    lda __L_assemble_instruction_name_length
    sta __T_assemble_instruction___v1
    lda __T_assemble_instruction___v0
    sta __call_find_mnemonic_0
    lda __T_assemble_instruction___v0+1
    sta __call_find_mnemonic_0+1
    lda __T_assemble_instruction___v1
    sta __call_find_mnemonic_1
    jsr find_mnemonic
    sta __L_assemble_instruction_mnemonic
    stx __L_assemble_instruction_mnemonic+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_instruction_mnemonic+1
    eor #$80
    cmp __rh
    bcc __F_assemble_instruction___sel1
    bne __F_assemble_instruction___sel2
    lda __L_assemble_instruction_mnemonic
    cmp #$00
    bcc __F_assemble_instruction___sel1
    bne __F_assemble_instruction___sel2
    jmp __F_assemble_instruction___sel3
__F_assemble_instruction___sel1:
    jmp __F_assemble_instruction_yes_1
__F_assemble_instruction___sel2:
    jmp __F_assemble_instruction_join_3
__F_assemble_instruction___sel3:
    jmp __F_assemble_instruction_join_3
__F_assemble_instruction_yes_1:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_3:
    lda __L_assemble_instruction_argument_length
    cmp #$00
    beq __F_assemble_instruction_yes_4
    jmp __F_assemble_instruction_join_6
__F_assemble_instruction_yes_4:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v10
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v10+1
    lda MODE_IMPLIED
    sta __T_assemble_instruction___v11
    lda __T_assemble_instruction___v10
    sta __call_find_opcode_0
    lda __T_assemble_instruction___v10+1
    sta __call_find_opcode_0+1
    lda __T_assemble_instruction___v11
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_instruction_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_instruction___sel4
    bne __F_assemble_instruction___sel5
    lda __L_assemble_instruction_opcode
    cmp #$00
    bcc __F_assemble_instruction___sel4
    bne __F_assemble_instruction___sel5
    jmp __F_assemble_instruction___sel6
__F_assemble_instruction___sel4:
    jmp __F_assemble_instruction_join_9
__F_assemble_instruction___sel5:
    jmp __F_assemble_instruction_yes_7
__F_assemble_instruction___sel6:
    jmp __F_assemble_instruction_yes_7
__F_assemble_instruction_yes_7:
    lda __L_assemble_instruction_opcode
    sta __T_assemble_instruction___v16
    lda __L_assemble_instruction_opcode+1
    sta __T_assemble_instruction___v16+1
    lda MODE_IMPLIED
    sta __T_assemble_instruction___v17
    lda __T_assemble_instruction___v16
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_instruction___v16+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_instruction___v17
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    lda #$00
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_instruction_join_9:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v20
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v20+1
    lda MODE_ACCUMULATOR
    sta __T_assemble_instruction___v21
    lda __T_assemble_instruction___v20
    sta __call_find_opcode_0
    lda __T_assemble_instruction___v20+1
    sta __call_find_opcode_0+1
    lda __T_assemble_instruction___v21
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_instruction_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_instruction___sel7
    bne __F_assemble_instruction___sel8
    lda __L_assemble_instruction_opcode
    cmp #$00
    bcc __F_assemble_instruction___sel7
    bne __F_assemble_instruction___sel8
    jmp __F_assemble_instruction___sel9
__F_assemble_instruction___sel7:
    jmp __F_assemble_instruction_join_12
__F_assemble_instruction___sel8:
    jmp __F_assemble_instruction_yes_10
__F_assemble_instruction___sel9:
    jmp __F_assemble_instruction_yes_10
__F_assemble_instruction_yes_10:
    lda __L_assemble_instruction_opcode
    sta __T_assemble_instruction___v26
    lda __L_assemble_instruction_opcode+1
    sta __T_assemble_instruction___v26+1
    lda MODE_ACCUMULATOR
    sta __T_assemble_instruction___v27
    lda __T_assemble_instruction___v26
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_instruction___v26+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_instruction___v27
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    lda #$00
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_instruction_join_12:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_6:
    lda __L_assemble_instruction_argument_length
    cmp #$01
    beq __F_assemble_instruction_yes_13
    jmp __F_assemble_instruction_join_15
__F_assemble_instruction_yes_13:
    ldy #$00
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_assemble_instruction___v37
    cmp #$41
    beq __F_assemble_instruction_yes_16
    jmp __F_assemble_instruction_join_15
__F_assemble_instruction_yes_16:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v40
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v40+1
    lda MODE_ACCUMULATOR
    sta __T_assemble_instruction___v41
    lda __T_assemble_instruction___v40
    sta __call_find_opcode_0
    lda __T_assemble_instruction___v40+1
    sta __call_find_opcode_0+1
    lda __T_assemble_instruction___v41
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_instruction_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_instruction___sel10
    bne __F_assemble_instruction___sel11
    lda __L_assemble_instruction_opcode
    cmp #$00
    bcc __F_assemble_instruction___sel10
    bne __F_assemble_instruction___sel11
    jmp __F_assemble_instruction___sel12
__F_assemble_instruction___sel10:
    jmp __F_assemble_instruction_yes_19
__F_assemble_instruction___sel11:
    jmp __F_assemble_instruction_join_21
__F_assemble_instruction___sel12:
    jmp __F_assemble_instruction_join_21
__F_assemble_instruction_yes_19:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_21:
    lda __L_assemble_instruction_opcode
    sta __T_assemble_instruction___v47
    lda __L_assemble_instruction_opcode+1
    sta __T_assemble_instruction___v47+1
    lda MODE_ACCUMULATOR
    sta __T_assemble_instruction___v48
    lda __T_assemble_instruction___v47
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_instruction___v47+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_instruction___v48
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    lda #$00
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_instruction_join_15:
    ldy #$00
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda (__ap),y
    sta __T_assemble_instruction___v53
    cmp #$23
    beq __F_assemble_instruction_yes_22
    jmp __F_assemble_instruction_join_24
__F_assemble_instruction_yes_22:
    lda __L_assemble_instruction_argument_length
    cmp #$02
    bcc __F_assemble_instruction_yes_25
    jmp __F_assemble_instruction_join_27
__F_assemble_instruction_yes_25:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_27:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v60
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v60+1
    lda MODE_IMMEDIATE
    sta __T_assemble_instruction___v61
    lda __L_assemble_instruction_argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda __L_assemble_instruction_argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    sta __call_assemble_mode_value_3
    lda #$00
    sbc #$00
    sta __call_assemble_mode_value_3+1
    lda __T_assemble_instruction___v60
    sta __call_assemble_mode_value_0
    lda __T_assemble_instruction___v60+1
    sta __call_assemble_mode_value_0+1
    lda __T_assemble_instruction___v61
    sta __call_assemble_mode_value_1
    jsr assemble_mode_value
    ldx #$00
    rts
__F_assemble_instruction_join_24:
    cmp #$28
    beq __F_assemble_instruction_yes_28
    jmp __F_assemble_instruction_join_30
__F_assemble_instruction_yes_28:
    lda __L_assemble_instruction_argument_length
    cmp #$03
    bcc __F_assemble_instruction_yes_31
    jmp __F_assemble_instruction_join_33
__F_assemble_instruction_yes_31:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_33:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    sta __T_assemble_instruction___v81
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v81+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v81
    sta __ix
    lda __T_assemble_instruction___v81+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_assemble_instruction___v83
    cmp #$59
    beq __F_assemble_instruction_yes_34
    jmp __F_assemble_instruction_join_36
__F_assemble_instruction_yes_34:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __T_assemble_instruction___v89
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v89+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v89
    sta __ix
    lda __T_assemble_instruction___v89+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_instruction___v90
    cmp #$2c
    beq __F_assemble_instruction_yes_37
    jmp __F_assemble_instruction_join_36
__F_assemble_instruction_yes_37:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$03
    sta __T_assemble_instruction___v96
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v96+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v96
    sta __ix
    lda __T_assemble_instruction___v96+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_instruction___v97
    cmp #$29
    bne __F_assemble_instruction_yes_40
    jmp __F_assemble_instruction_join_42
__F_assemble_instruction_yes_40:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_42:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$04
    sta __L_assemble_instruction_core_length
    lda __L_assemble_instruction_core_length
    cmp #$00
    bcc __F_assemble_instruction_yes_43
    beq __F_assemble_instruction_yes_43
    jmp __F_assemble_instruction_join_45
__F_assemble_instruction_yes_43:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_45:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v108
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v108+1
    lda MODE_INDIRECT_Y
    sta __T_assemble_instruction___v109
    lda __L_assemble_instruction_argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda __L_assemble_instruction_argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda __L_assemble_instruction_core_length
    sta __T_assemble_instruction___v113
    lda __T_assemble_instruction___v108
    sta __call_assemble_mode_value_0
    lda __T_assemble_instruction___v108+1
    sta __call_assemble_mode_value_0+1
    lda __T_assemble_instruction___v109
    sta __call_assemble_mode_value_1
    lda __T_assemble_instruction___v113
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    ldx #$00
    rts
__F_assemble_instruction_join_36:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    sta __T_assemble_instruction___v118
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v118+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v118
    sta __ix
    lda __T_assemble_instruction___v118+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_instruction___v119
    cmp #$29
    bne __F_assemble_instruction_yes_46
    jmp __F_assemble_instruction_join_48
__F_assemble_instruction_yes_46:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_48:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __T_assemble_instruction___v126
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v126+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v126
    sta __ix
    lda __T_assemble_instruction___v126+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_assemble_instruction___v128
    cmp #$58
    beq __F_assemble_instruction_yes_49
    jmp __F_assemble_instruction_join_51
__F_assemble_instruction_yes_49:
    lda __L_assemble_instruction_argument_length
    cmp #$05
    bcc __F_assemble_instruction_yes_52
    jmp __F_assemble_instruction_join_54
__F_assemble_instruction_yes_52:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_54:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$03
    sta __T_assemble_instruction___v138
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v138+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v138
    sta __ix
    lda __T_assemble_instruction___v138+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_instruction___v139
    cmp #$2c
    bne __F_assemble_instruction_yes_55
    jmp __F_assemble_instruction_join_57
__F_assemble_instruction_yes_55:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_57:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$04
    sta __L_assemble_instruction_core_length
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v146
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v146+1
    lda MODE_INDIRECT_X
    sta __T_assemble_instruction___v147
    lda __L_assemble_instruction_argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda __L_assemble_instruction_argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda __L_assemble_instruction_core_length
    sta __T_assemble_instruction___v151
    lda __T_assemble_instruction___v146
    sta __call_assemble_mode_value_0
    lda __T_assemble_instruction___v146+1
    sta __call_assemble_mode_value_0+1
    lda __T_assemble_instruction___v147
    sta __call_assemble_mode_value_1
    lda __T_assemble_instruction___v151
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    ldx #$00
    rts
__F_assemble_instruction_join_51:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v156
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v156+1
    lda MODE_INDIRECT
    sta __T_assemble_instruction___v157
    lda __L_assemble_instruction_argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda __L_assemble_instruction_argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda __L_assemble_instruction_core_length
    sta __T_assemble_instruction___v161
    lda __T_assemble_instruction___v156
    sta __call_assemble_mode_value_0
    lda __T_assemble_instruction___v156+1
    sta __call_assemble_mode_value_0+1
    lda __T_assemble_instruction___v157
    sta __call_assemble_mode_value_1
    lda __T_assemble_instruction___v161
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    ldx #$00
    rts
__F_assemble_instruction_join_30:
    lda #$00
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sta __L_assemble_instruction_core_length
    lda __L_assemble_instruction_argument_length
    cmp #$03
    bcs __F_assemble_instruction_yes_58
    jmp __F_assemble_instruction_join_60
__F_assemble_instruction_yes_58:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __T_assemble_instruction___v171
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v171+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v171
    sta __ix
    lda __T_assemble_instruction___v171+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_instruction___v172
    cmp #$2c
    beq __F_assemble_instruction_yes_61
    jmp __F_assemble_instruction_join_60
__F_assemble_instruction_yes_61:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    sta __T_assemble_instruction___v178
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v178+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v178
    sta __ix
    lda __T_assemble_instruction___v178+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_assemble_instruction___v180
    cmp #$58
    beq __F_assemble_instruction_yes_64
    jmp __F_assemble_instruction_no_65
__F_assemble_instruction_yes_64:
    lda #$01
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
    jmp __F_assemble_instruction_join_60
__F_assemble_instruction_no_65:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    sta __T_assemble_instruction___v190
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v190+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v190
    sta __ix
    lda __T_assemble_instruction___v190+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_assemble_instruction___v192
    cmp #$59
    beq __F_assemble_instruction_yes_67
    jmp __F_assemble_instruction_join_60
__F_assemble_instruction_yes_67:
    lda #$02
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
__F_assemble_instruction_join_60:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v199
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v199+1
    lda __L_assemble_instruction_argument
    sta __T_assemble_instruction___v200
    lda __L_assemble_instruction_argument+1
    sta __T_assemble_instruction___v200+1
    lda __L_assemble_instruction_core_length
    sta __T_assemble_instruction___v201
    lda __L_assemble_instruction_index
    sta __T_assemble_instruction___v202
    lda __T_assemble_instruction___v199
    sta __call_assemble_direct_value_0
    lda __T_assemble_instruction___v199+1
    sta __call_assemble_direct_value_0+1
    lda __T_assemble_instruction___v200
    sta __call_assemble_direct_value_1
    lda __T_assemble_instruction___v200+1
    sta __call_assemble_direct_value_1+1
    lda __T_assemble_instruction___v201
    sta __call_assemble_direct_value_2
    lda __T_assemble_instruction___v202
    sta __call_assemble_direct_value_3
    jsr assemble_direct_value
    ldx #$00
    rts
stage_data_value:
__F_stage_data_value_entry:
    lda __L_stage_data_value_text
    sta __T_stage_data_value___v0
    lda __L_stage_data_value_text+1
    sta __T_stage_data_value___v0+1
    lda __L_stage_data_value_length
    sta __T_stage_data_value___v1
    lda __T_stage_data_value___v0
    sta __call_parse_value_0
    lda __T_stage_data_value___v0+1
    sta __call_parse_value_0+1
    lda __T_stage_data_value___v1
    sta __call_parse_value_1
    jsr parse_value
    sta __L_stage_data_value_status
    lda __L_stage_data_value_status
    cmp VALUE_OK
    beq __F_stage_data_value_yes_1
    jmp __F_stage_data_value_join_3
__F_stage_data_value_yes_1:
    lda __L_stage_data_value_width
    cmp #$01
    beq __F_stage_data_value_yes_4
    jmp __F_stage_data_value_join_6
__F_stage_data_value_yes_4:
    lda value_result+1
    cmp #$00
    bcc __F_stage_data_value___sel1
    bne __F_stage_data_value___sel2
    lda value_result
    cmp #$ff
    bcc __F_stage_data_value___sel1
    bne __F_stage_data_value___sel2
    jmp __F_stage_data_value___sel3
__F_stage_data_value___sel1:
    jmp __F_stage_data_value_join_9
__F_stage_data_value___sel2:
    jmp __F_stage_data_value_yes_7
__F_stage_data_value___sel3:
    jmp __F_stage_data_value_join_9
__F_stage_data_value_yes_7:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_stage_data_value_join_9:
    lda value_result
    sta __T_stage_data_value___v13
    lda value_result+1
    sta __T_stage_data_value___v13+1
    lda __T_stage_data_value___v13
    sta __call_stage_byte_0
    lda __T_stage_data_value___v13+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    ldx #$00
    rts
__F_stage_data_value_join_6:
    lda value_result
    and #$ff
    sta __T_stage_data_value___v17
    lda value_result+1
    and #$00
    sta __T_stage_data_value___v17+1
    lda __T_stage_data_value___v17
    sta __call_stage_byte_0
    lda __T_stage_data_value___v17+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_data_value_status
    lda __L_stage_data_value_status
    cmp ASSEMBLE_OK
    bne __F_stage_data_value_yes_10
    jmp __F_stage_data_value_join_12
__F_stage_data_value_yes_10:
    lda __L_stage_data_value_status
    ldx #$00
    rts
__F_stage_data_value_join_12:
    lda value_result
    sta __T_stage_data_value___v25
    lda value_result+1
    sta __T_stage_data_value___v25+1
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lda __T_stage_data_value___v25
    and #$ff
    sta __T_stage_data_value___v27
    lda __T_stage_data_value___v25+1
    and #$00
    sta __T_stage_data_value___v27+1
    lda __T_stage_data_value___v27
    sta __call_stage_byte_0
    lda __T_stage_data_value___v27+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    ldx #$00
    rts
__F_stage_data_value_join_3:
    lda __L_stage_data_value_status
    cmp VALUE_UNRESOLVED
    beq __F_stage_data_value_yes_13
    jmp __F_stage_data_value_join_15
__F_stage_data_value_yes_13:
    lda __L_stage_data_value_width
    cmp #$02
    beq __F_stage_data_value_yes_16
    jmp __F_stage_data_value_join_18
__F_stage_data_value_yes_16:
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    beq __F_stage_data_value_yes_19
    jmp __F_stage_data_value_join_18
__F_stage_data_value_yes_19:
    lda captured_addend
    sta __T_stage_data_value___v40
    lda captured_addend+1
    sta __T_stage_data_value___v40+1
    lda __T_stage_data_value___v40+1
    cmp #$00
    bne __F_stage_data_value_join_18
    lda __T_stage_data_value___v40
    cmp #$00
    beq __F_stage_data_value_yes_22
    jmp __F_stage_data_value_join_18
__F_stage_data_value_yes_22:
    lda captured_symbol
    sta __T_stage_data_value___v43
    lda captured_symbol+1
    sta __T_stage_data_value___v43+1
    lda __T_stage_data_value___v43
    sta __call_stage_plain_word_reference_0
    lda __T_stage_data_value___v43+1
    sta __call_stage_plain_word_reference_0+1
    jsr stage_plain_word_reference
    ldx #$00
    rts
__F_stage_data_value_join_18:
    lda ass_image_length
    sta __L_stage_data_value_stage
    lda ass_image_length+1
    sta __L_stage_data_value_stage+1
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_data_value_status
    lda __L_stage_data_value_status
    cmp ASSEMBLE_OK
    bne __F_stage_data_value_yes_25
    jmp __F_stage_data_value_join_27
__F_stage_data_value_yes_25:
    lda __L_stage_data_value_status
    ldx #$00
    rts
__F_stage_data_value_join_27:
    lda __L_stage_data_value_width
    cmp #$02
    beq __F_stage_data_value_yes_28
    jmp __F_stage_data_value_no_29
__F_stage_data_value_yes_28:
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_data_value_status
    lda __L_stage_data_value_status
    cmp ASSEMBLE_OK
    bne __F_stage_data_value_yes_31
    jmp __F_stage_data_value_join_33
__F_stage_data_value_yes_31:
    lda __L_stage_data_value_status
    ldx #$00
    rts
__F_stage_data_value_join_33:
    lda FIXUP_WORD
    sta __L_stage_data_value_kind
    jmp __F_stage_data_value_join_30
__F_stage_data_value_no_29:
    lda FIXUP_DATA_BYTE
    sta __L_stage_data_value_kind
__F_stage_data_value_join_30:
    lda __L_stage_data_value_kind
    sta __T_stage_data_value___v63
    lda __L_stage_data_value_stage
    sta __T_stage_data_value___v64
    lda __L_stage_data_value_stage+1
    sta __T_stage_data_value___v64+1
    lda captured_symbol
    sta __T_stage_data_value___v65
    lda captured_symbol+1
    sta __T_stage_data_value___v65+1
    lda captured_addend
    sta __T_stage_data_value___v66
    lda captured_addend+1
    sta __T_stage_data_value___v66+1
    lda captured_prefix
    sta __T_stage_data_value___v67
    lda __T_stage_data_value___v63
    sta __call_append_fixup_0
    lda __T_stage_data_value___v64
    sta __call_append_fixup_1
    lda __T_stage_data_value___v64+1
    sta __call_append_fixup_1+1
    lda __T_stage_data_value___v65
    sta __call_append_fixup_2
    lda __T_stage_data_value___v65+1
    sta __call_append_fixup_2+1
    lda __T_stage_data_value___v66
    sta __call_append_fixup_3
    lda __T_stage_data_value___v66+1
    sta __call_append_fixup_3+1
    lda __T_stage_data_value___v67
    sta __call_append_fixup_4
    jsr append_fixup
    ldx #$00
    rts
__F_stage_data_value_join_15:
    lda __L_stage_data_value_status
    cmp VALUE_SYMBOL_FULL
    beq __F_stage_data_value_yes_34
    jmp __F_stage_data_value_join_36
__F_stage_data_value_yes_34:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_stage_data_value_join_36:
    lda __L_stage_data_value_status
    cmp VALUE_SCOPE_ERROR
    beq __F_stage_data_value_yes_37
    jmp __F_stage_data_value_join_39
__F_stage_data_value_yes_37:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_stage_data_value_join_39:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
assemble_data_list:
__F_assemble_data_list_entry:
    lda #$00
    sta __L_assemble_data_list_cursor
__F_assemble_data_list_while_1:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_while_4
    jmp __F_assemble_data_list_after_3
__F_assemble_data_list_while_4:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_body_5
    jmp __F_assemble_data_list_after_6
__F_assemble_data_list_body_5:
    ldy __L_assemble_data_list_cursor
    lda __L_assemble_data_list_argument
    sta __ap
    lda __L_assemble_data_list_argument+1
    sta __ap+1
    lda (__ap),y
    sta __L_assemble_data_list_c
    lda __L_assemble_data_list_c
    cmp #$20
    beq __F_assemble_data_list_yes_7
    jmp __F_assemble_data_list_no_8
__F_assemble_data_list_yes_7:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_4
__F_assemble_data_list_no_8:
    lda __L_assemble_data_list_c
    cmp #$09
    beq __F_assemble_data_list_yes_10
    jmp __F_assemble_data_list_after_6
__F_assemble_data_list_yes_10:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_4
__F_assemble_data_list_after_6:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_yes_13
    jmp __F_assemble_data_list_join_15
__F_assemble_data_list_yes_13:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_data_list_join_15:
    lda __L_assemble_data_list_cursor
    sta __L_assemble_data_list_item_start
    lda __L_assemble_data_list_cursor
    sta __L_assemble_data_list_item_end
__F_assemble_data_list_while_16:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_body_17
    jmp __F_assemble_data_list_after_18
__F_assemble_data_list_body_17:
    ldy __L_assemble_data_list_cursor
    lda __L_assemble_data_list_argument
    sta __ap
    lda __L_assemble_data_list_argument+1
    sta __ap+1
    lda (__ap),y
    sta __L_assemble_data_list_c
    lda __L_assemble_data_list_c
    cmp #$2c
    beq __F_assemble_data_list_after_18
    jmp __F_assemble_data_list_join_21
__F_assemble_data_list_join_21:
    lda __L_assemble_data_list_c
    cmp #$20
    bne __F_assemble_data_list_yes_22
    jmp __F_assemble_data_list_join_24
__F_assemble_data_list_yes_22:
    lda __L_assemble_data_list_c
    cmp #$09
    bne __F_assemble_data_list_yes_25
    jmp __F_assemble_data_list_join_24
__F_assemble_data_list_yes_25:
    lda __L_assemble_data_list_cursor
    clc
    adc #$01
    sta __L_assemble_data_list_item_end
__F_assemble_data_list_join_24:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_16
__F_assemble_data_list_after_18:
    lda __L_assemble_data_list_item_end
    cmp __L_assemble_data_list_item_start
    beq __F_assemble_data_list_yes_28
    jmp __F_assemble_data_list_join_30
__F_assemble_data_list_yes_28:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_data_list_join_30:
    lda __L_assemble_data_list_argument
    clc
    adc __L_assemble_data_list_item_start
    sta __call_stage_data_value_0
    lda __L_assemble_data_list_argument+1
    adc #$00
    sta __call_stage_data_value_0+1
    lda __L_assemble_data_list_item_end
    sec
    sbc __L_assemble_data_list_item_start
    sta __call_stage_data_value_1
    lda #$00
    sbc #$00
    sta __call_stage_data_value_1+1
    lda __L_assemble_data_list_width
    sta __T_assemble_data_list___v59
    lda __T_assemble_data_list___v59
    sta __call_stage_data_value_2
    jsr stage_data_value
    sta __L_assemble_data_list_status
    lda __L_assemble_data_list_status
    cmp ASSEMBLE_OK
    bne __F_assemble_data_list_yes_31
    jmp __F_assemble_data_list_join_33
__F_assemble_data_list_yes_31:
    lda __L_assemble_data_list_status
    ldx #$00
    rts
__F_assemble_data_list_join_33:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_yes_34
    jmp __F_assemble_data_list_join_36
__F_assemble_data_list_yes_34:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_assemble_data_list_join_36:
    inc __L_assemble_data_list_cursor
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_yes_37
    jmp __F_assemble_data_list_while_1
__F_assemble_data_list_yes_37:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_data_list_after_3:
    lda ASSEMBLE_OK
    ldx #$00
    rts
assemble_string:
__F_assemble_string_entry:
    lda __L_assemble_string_length
    cmp #$02
    bcc __F_assemble_string_yes_1
    jmp __F_assemble_string_join_3
__F_assemble_string_yes_1:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_string_join_3:
    ldy #$00
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    sta __ap+1
    lda (__ap),y
    sta __T_assemble_string___v6
    cmp #$22
    bne __F_assemble_string_yes_4
    jmp __F_assemble_string_join_6
__F_assemble_string_yes_4:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_string_join_6:
    lda __L_assemble_string_length
    sec
    sbc #$01
    sta __T_assemble_string___v13
    lda #$00
    sbc #$00
    sta __T_assemble_string___v13+1
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    sta __ap+1
    lda __T_assemble_string___v13
    sta __ix
    lda __T_assemble_string___v13+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_string___v14
    cmp #$22
    bne __F_assemble_string_yes_7
    jmp __F_assemble_string_join_9
__F_assemble_string_yes_7:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_string_join_9:
    lda #$01
    sta __L_assemble_string_i
__F_assemble_string_while_10:
    lda __L_assemble_string_length
    sec
    sbc #$01
    sta __T_assemble_string___v22
    lda #$00
    sbc #$00
    sta __T_assemble_string___v22+1
    lda __T_assemble_string___v22+1
    eor #$80
    sta __rh
    lda #$00
    eor #$80
    cmp __rh
    bcc __F_assemble_string___sel1
    bne __F_assemble_string___sel2
    lda __L_assemble_string_i
    cmp __T_assemble_string___v22
    bcc __F_assemble_string___sel1
    bne __F_assemble_string___sel2
    jmp __F_assemble_string___sel3
__F_assemble_string___sel1:
    jmp __F_assemble_string_body_11
__F_assemble_string___sel2:
    jmp __F_assemble_string_after_12
__F_assemble_string___sel3:
    jmp __F_assemble_string_after_12
__F_assemble_string_body_11:
    ldy __L_assemble_string_i
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    sta __ap+1
    lda (__ap),y
    sta __call_stage_byte_0
    jsr stage_byte
    sta __L_assemble_string_status
    lda __L_assemble_string_status
    cmp ASSEMBLE_OK
    bne __F_assemble_string_yes_13
    jmp __F_assemble_string_join_15
__F_assemble_string_yes_13:
    lda __L_assemble_string_status
    ldx #$00
    rts
__F_assemble_string_join_15:
    inc __L_assemble_string_i
    jmp __F_assemble_string_while_10
__F_assemble_string_after_12:
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    ldx #$00
    rts
open_include:
__F_open_include_entry:
    lda __L_open_include_length
    cmp #$03
    bcc __F_open_include_yes_1
    jmp __F_open_include_join_3
__F_open_include_yes_1:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_open_include_join_3:
    ldy #$00
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda (__ap),y
    sta __T_open_include___v6
    cmp #$22
    bne __F_open_include_yes_4
    jmp __F_open_include_join_6
__F_open_include_yes_4:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_open_include_join_6:
    lda __L_open_include_length
    sec
    sbc #$01
    sta __T_open_include___v13
    lda #$00
    sbc #$00
    sta __T_open_include___v13+1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda __T_open_include___v13
    sta __ix
    lda __T_open_include___v13+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_open_include___v14
    cmp #$22
    bne __F_open_include_yes_7
    jmp __F_open_include_join_9
__F_open_include_yes_7:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_open_include_join_9:
    lda #$00
    eor #$80
    sta __rh
    lda source_depth+1
    eor #$80
    cmp __rh
    bcc __F_open_include___sel1
    bne __F_open_include___sel2
    lda source_depth
    cmp #$04
    bcc __F_open_include___sel1
    bne __F_open_include___sel2
    jmp __F_open_include___sel3
__F_open_include___sel1:
    jmp __F_open_include_join_12
__F_open_include___sel2:
    jmp __F_open_include_yes_10
__F_open_include___sel3:
    jmp __F_open_include_yes_10
__F_open_include_yes_10:
    lda ASSEMBLE_INCLUDE_DEPTH
    ldx #$00
    rts
__F_open_include_join_12:
    lda #$01
    sta __L_open_include_input_start
    lda __L_open_include_length
    sec
    sbc #$02
    sta __L_open_include_input_length
    lda #$00
    sta __L_open_include_output
    lda #$00
    sta __L_open_include_parent_path
    lda __L_open_include_input_length
    cmp #$03
    bcs __F_open_include_yes_13
    jmp __F_open_include_join_15
__F_open_include_yes_13:
    ldy __L_open_include_input_start
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda (__ap),y
    sta __T_open_include___v33
    cmp #$2e
    beq __F_open_include_yes_16
    jmp __F_open_include_join_15
__F_open_include_yes_16:
    lda __L_open_include_input_start
    clc
    adc #$01
    sta __T_open_include___v39
    lda #$00
    adc #$00
    sta __T_open_include___v39+1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda __T_open_include___v39
    sta __ix
    lda __T_open_include___v39+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_open_include___v40
    cmp #$2e
    beq __F_open_include_yes_19
    jmp __F_open_include_join_15
__F_open_include_yes_19:
    lda __L_open_include_input_start
    clc
    adc #$02
    sta __T_open_include___v46
    lda #$00
    adc #$00
    sta __T_open_include___v46+1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda __T_open_include___v46
    sta __ix
    lda __T_open_include___v46+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_open_include___v47
    cmp #$2f
    beq __F_open_include_yes_22
    jmp __F_open_include_join_15
__F_open_include_yes_22:
    lda #$01
    sta __L_open_include_parent_path
    lda __L_open_include_input_start
    clc
    adc #$03
    sta __L_open_include_input_start
    lda __L_open_include_input_length
    sec
    sbc #$03
    sta __L_open_include_input_length
__F_open_include_join_15:
    lda __L_open_include_parent_path
    cmp #$00
    beq __F_open_include_yes_25
    jmp __F_open_include_join_27
__F_open_include_yes_25:
    lda #$00
    sta __L_open_include_i
__F_open_include_while_28:
    lda __L_open_include_i
    cmp source_directory_length
    bcc __F_open_include_body_29
    jmp __F_open_include_join_27
__F_open_include_body_29:
    lda __L_open_include_output
    sta __T_open_include___v65
    ldy __L_open_include_i
    lda source_directory
    sta __ap
    lda source_directory+1
    sta __ap+1
    lda (__ap),y
    sta __T_open_include___v68
    ldy __T_open_include___v65
    lda __T_open_include___v68
    sta source_path,y
    inc __L_open_include_output
    inc __L_open_include_i
    jmp __F_open_include_while_28
__F_open_include_join_27:
    lda __L_open_include_output
    clc
    adc __L_open_include_input_length
    sta __T_open_include___v77
    lda #$00
    adc #$00
    sta __T_open_include___v77+1
    lda #$00
    eor #$80
    sta __rh
    lda __T_open_include___v77+1
    eor #$80
    cmp __rh
    bcc __F_open_include___sel4
    bne __F_open_include___sel5
    lda __T_open_include___v77
    cmp #$ff
    bcc __F_open_include___sel4
    bne __F_open_include___sel5
    jmp __F_open_include___sel6
__F_open_include___sel4:
    jmp __F_open_include_join_33
__F_open_include___sel5:
    jmp __F_open_include_yes_31
__F_open_include___sel6:
    jmp __F_open_include_join_33
__F_open_include_yes_31:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_open_include_join_33:
    lda #$00
    sta __L_open_include_i
__F_open_include_while_34:
    lda __L_open_include_i
    cmp __L_open_include_input_length
    bcc __F_open_include_body_35
    jmp __F_open_include_after_36
__F_open_include_body_35:
    lda __L_open_include_output
    sta __T_open_include___v86
    lda __L_open_include_input_start
    clc
    adc __L_open_include_i
    sta __T_open_include___v90
    lda #$00
    adc #$00
    sta __T_open_include___v90+1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda __T_open_include___v90
    sta __ix
    lda __T_open_include___v90+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_open_include___v91
    ldy __T_open_include___v86
    lda __T_open_include___v91
    sta source_path,y
    inc __L_open_include_output
    inc __L_open_include_i
    jmp __F_open_include_while_34
__F_open_include_after_36:
    lda __L_open_include_output
    sta __T_open_include___v99
    lda #<source_path
    sta __call_io_open_0
    lda __T_open_include___v99
    sta __call_io_open_1
    jsr io_open
    sta __L_open_include_handle
    stx __L_open_include_handle+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_open_include_handle+1
    eor #$80
    cmp __rh
    bcc __F_open_include___sel7
    bne __F_open_include___sel8
    lda __L_open_include_handle
    cmp #$00
    bcc __F_open_include___sel7
    bne __F_open_include___sel8
    jmp __F_open_include___sel9
__F_open_include___sel7:
    jmp __F_open_include_yes_37
__F_open_include___sel8:
    jmp __F_open_include_join_39
__F_open_include___sel9:
    jmp __F_open_include_join_39
__F_open_include_yes_37:
    lda ASSEMBLE_IO_ERROR
    ldx #$00
    rts
__F_open_include_join_39:
    lda source_depth
    clc
    adc #$01
    sta __T_open_include___v107
    lda source_depth+1
    adc #$00
    sta __T_open_include___v107+1
    lda __T_open_include___v107
    sta source_depth
    lda __T_open_include___v107+1
    sta source_depth+1
    lda source_depth
    sta __T_open_include___v109
    lda source_depth+1
    sta __T_open_include___v109+1
    lda __L_open_include_handle
    sta __T_open_include___v110
    lda __L_open_include_handle+1
    sta __T_open_include___v110+1
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda __T_open_include___v109
    sta __ix
    lda __T_open_include___v109+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_open_include___v110
    sta (__ap),y
    lda ASSEMBLE_OK
    ldx #$00
    rts
read_source_line:
__F_read_source_line_entry:
    lda #$00
    sta source_line_length
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda source_depth
    sta __ix
    lda source_depth+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __L_read_source_line_handle
__F_read_source_line_while_1:
    lda #$01
    ora #$00
    bne __F_read_source_line_body_2
    jmp __F_read_source_line_after_3
__F_read_source_line_body_2:
    lda __L_read_source_line_handle
    sta __T_read_source_line___v5
    lda __T_read_source_line___v5
    sta __call_io_read_0
    jsr io_read
    sta __L_read_source_line_c
    stx __L_read_source_line_c+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_read_source_line_c+1
    eor #$80
    cmp __rh
    bcc __F_read_source_line___sel1
    bne __F_read_source_line___sel2
    lda __L_read_source_line_c
    cmp #$00
    bcc __F_read_source_line___sel1
    bne __F_read_source_line___sel2
    jmp __F_read_source_line___sel3
__F_read_source_line___sel1:
    jmp __F_read_source_line_yes_4
__F_read_source_line___sel2:
    jmp __F_read_source_line_join_6
__F_read_source_line___sel3:
    jmp __F_read_source_line_join_6
__F_read_source_line_yes_4:
    sec
    lda #$00
    sbc #$01
    sta __T_read_source_line___v12
    lda #$00
    sbc #$00
    sta __T_read_source_line___v12+1
    lda __L_read_source_line_c+1
    cmp __T_read_source_line___v12+1
    bne __F_read_source_line_join_9
    lda __L_read_source_line_c
    cmp __T_read_source_line___v12
    beq __F_read_source_line_yes_7
    jmp __F_read_source_line_join_9
__F_read_source_line_yes_7:
    lda source_line_length
    cmp #$00
    bne __F_read_source_line_yes_10
    jmp __F_read_source_line_join_12
__F_read_source_line_yes_10:
    lda source_line_length
    sta __T_read_source_line___v18
    ldy __T_read_source_line___v18
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
__F_read_source_line_join_12:
    lda #$00
    ldx #$00
    rts
__F_read_source_line_join_9:
    sec
    lda #$00
    sbc #$01
    sta __T_read_source_line___v23
    lda #$00
    sbc #$00
    sta __T_read_source_line___v23+1
    lda __T_read_source_line___v23
    ldx __T_read_source_line___v23+1
    rts
__F_read_source_line_join_6:
    lda __L_read_source_line_c+1
    cmp #$00
    bne __F_read_source_line_join_15
    lda __L_read_source_line_c
    cmp #$0d
    beq __F_read_source_line_yes_13
    jmp __F_read_source_line_join_15
__F_read_source_line_yes_13:
    lda source_line_length
    sta __T_read_source_line___v28
    ldy __T_read_source_line___v28
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
__F_read_source_line_join_15:
    lda __L_read_source_line_c+1
    cmp #$00
    bne __F_read_source_line_join_18
    lda __L_read_source_line_c
    cmp #$0a
    beq __F_read_source_line_yes_16
    jmp __F_read_source_line_join_18
__F_read_source_line_yes_16:
    lda source_line_length
    sta __T_read_source_line___v35
    ldy __T_read_source_line___v35
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
__F_read_source_line_join_18:
    lda source_line_length
    cmp #$ff
    bcs __F_read_source_line_yes_19
    jmp __F_read_source_line_join_21
__F_read_source_line_yes_19:
    sec
    lda #$00
    sbc #$02
    sta __T_read_source_line___v42
    lda #$00
    sbc #$00
    sta __T_read_source_line___v42+1
    lda __T_read_source_line___v42
    ldx __T_read_source_line___v42+1
    rts
__F_read_source_line_join_21:
    lda source_line_length
    sta __T_read_source_line___v44
    lda __L_read_source_line_c
    sta __T_read_source_line___v45
    lda __L_read_source_line_c+1
    sta __T_read_source_line___v45+1
    ldy __T_read_source_line___v44
    lda __T_read_source_line___v45
    sta source_line,y
    inc source_line_length
    jmp __F_read_source_line_while_1
__F_read_source_line_after_3:
    lda #$00
    ldx #$00
    rts
close_source_tree:
__F_close_source_tree_entry:
__F_close_source_tree_while_1:
    lda #$00
    eor #$80
    sta __rh
    lda source_depth+1
    eor #$80
    cmp __rh
    bcc __F_close_source_tree___sel1
    bne __F_close_source_tree___sel2
    lda source_depth
    cmp #$00
    bcc __F_close_source_tree___sel1
    bne __F_close_source_tree___sel2
    jmp __F_close_source_tree___sel3
__F_close_source_tree___sel1:
    jmp __F_close_source_tree_after_3
__F_close_source_tree___sel2:
    jmp __F_close_source_tree_body_2
__F_close_source_tree___sel3:
    jmp __F_close_source_tree_body_2
__F_close_source_tree_body_2:
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda source_depth
    sta __ix
    lda source_depth+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_io_close_0
    jsr io_close
    sta __T_close_source_tree___v6
    lda source_depth
    sec
    sbc #$01
    sta __T_close_source_tree___v9
    lda source_depth+1
    sbc #$00
    sta __T_close_source_tree___v9+1
    lda __T_close_source_tree___v9
    sta source_depth
    lda __T_close_source_tree___v9+1
    sta source_depth+1
    jmp __F_close_source_tree_while_1
__F_close_source_tree_after_3:
    lda ASSEMBLE_OK
    ldx #$00
    rts
scan_argument:
__F_scan_argument_entry:
    lda __L_scan_argument_start
    sta __L_scan_argument_i
    lda #$00
    sta __L_scan_argument_quote
    lda __L_scan_argument_start
    sta __L_scan_argument_last
__F_scan_argument_while_1:
    lda __L_scan_argument_i
    cmp source_line_length
    bcc __F_scan_argument_body_2
    jmp __F_scan_argument_after_3
__F_scan_argument_body_2:
    ldy __L_scan_argument_i
    lda source_line,y
    sta __L_scan_argument_c
    lda __L_scan_argument_c
    cmp #$3b
    beq __F_scan_argument_yes_4
    jmp __F_scan_argument_no_5
__F_scan_argument_yes_4:
    lda __L_scan_argument_quote
    cmp #$00
    beq __F_scan_argument_yes_7
    jmp __F_scan_argument_no_8
__F_scan_argument_yes_7:
    lda source_line_length
    sta __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_no_8:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    inc __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_no_5:
    lda __L_scan_argument_c
    cmp #$27
    beq __F_scan_argument_yes_10
    jmp __F_scan_argument_no_11
__F_scan_argument_yes_10:
    lda __L_scan_argument_quote
    cmp #$00
    beq __F_scan_argument_yes_13
    jmp __F_scan_argument_no_14
__F_scan_argument_yes_13:
    lda #$27
    sta __L_scan_argument_quote
    jmp __F_scan_argument_join_15
__F_scan_argument_no_14:
    lda __L_scan_argument_quote
    cmp #$27
    beq __F_scan_argument_yes_16
    jmp __F_scan_argument_join_15
__F_scan_argument_yes_16:
    lda #$00
    sta __L_scan_argument_quote
__F_scan_argument_join_15:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    jmp __F_scan_argument_join_12
__F_scan_argument_no_11:
    lda __L_scan_argument_c
    cmp #$22
    beq __F_scan_argument_yes_19
    jmp __F_scan_argument_no_20
__F_scan_argument_yes_19:
    lda __L_scan_argument_quote
    cmp #$00
    beq __F_scan_argument_yes_22
    jmp __F_scan_argument_no_23
__F_scan_argument_yes_22:
    lda #$22
    sta __L_scan_argument_quote
    jmp __F_scan_argument_join_24
__F_scan_argument_no_23:
    lda __L_scan_argument_quote
    cmp #$22
    beq __F_scan_argument_yes_25
    jmp __F_scan_argument_join_24
__F_scan_argument_yes_25:
    lda #$00
    sta __L_scan_argument_quote
__F_scan_argument_join_24:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    jmp __F_scan_argument_join_12
__F_scan_argument_no_20:
    lda __L_scan_argument_c
    cmp #$20
    bne __F_scan_argument_yes_28
    jmp __F_scan_argument_join_12
__F_scan_argument_yes_28:
    lda __L_scan_argument_c
    cmp #$09
    bne __F_scan_argument_yes_31
    jmp __F_scan_argument_join_12
__F_scan_argument_yes_31:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
__F_scan_argument_join_12:
    inc __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_after_3:
    lda __L_scan_argument_last
    sec
    sbc __L_scan_argument_start
    sta __T_scan_argument___v64
    lda #$00
    sbc #$00
    sta __T_scan_argument___v64+1
    lda __T_scan_argument___v64
    ldx __T_scan_argument___v64+1
    rts
process_label:
__F_process_label_entry:
    lda __L_process_label_length
    cmp #$00
    beq __F_process_label_yes_1
    jmp __F_process_label_join_3
__F_process_label_yes_1:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_process_label_join_3:
    ldy #$00
    lda __L_process_label_name
    sta __ap
    lda __L_process_label_name+1
    sta __ap+1
    lda (__ap),y
    sta __T_process_label___v6
    cmp #$2e
    beq __F_process_label_yes_4
    jmp __F_process_label_no_5
__F_process_label_yes_4:
    lda current_scope
    cmp #$00
    beq __F_process_label_yes_7
    jmp __F_process_label_join_6
__F_process_label_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_process_label_no_5:
    lda current_scope
    cmp #$ff
    beq __F_process_label_yes_10
    jmp __F_process_label_join_12
__F_process_label_yes_10:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_process_label_join_12:
    inc current_scope
__F_process_label_join_6:
    lda #$00
    sta origin_allowed
    lda ass_origin
    clc
    adc ass_image_length
    sta __T_process_label___v23
    lda ass_origin+1
    adc ass_image_length+1
    sta __T_process_label___v23+1
    lda __T_process_label___v23
    sta __T_process_label___v25
    lda __T_process_label___v23+1
    sta __T_process_label___v25+1
    lda __T_process_label___v25
    sta __L_process_label_value
    lda __T_process_label___v25+1
    sta __L_process_label_value+1
    lda __L_process_label_name
    sta __T_process_label___v26
    lda __L_process_label_name+1
    sta __T_process_label___v26+1
    lda __L_process_label_length
    sta __T_process_label___v27
    lda __L_process_label_value
    sta __T_process_label___v28
    lda __L_process_label_value+1
    sta __T_process_label___v28+1
    lda __T_process_label___v26
    sta __call_define_label_0
    lda __T_process_label___v26+1
    sta __call_define_label_0+1
    lda __T_process_label___v27
    sta __call_define_label_1
    lda __T_process_label___v28
    sta __call_define_label_2
    lda __T_process_label___v28+1
    sta __call_define_label_2+1
    jsr define_label
    sta __L_process_label_status
    lda __L_process_label_status
    ldx #$00
    rts
process_symbol:
__F_process_symbol_entry:
    lda __L_process_symbol_name_length
    cmp #$01
    beq __F_process_symbol_yes_1
    jmp __F_process_symbol_join_3
__F_process_symbol_yes_1:
    ldy #$00
    lda __L_process_symbol_name
    sta __ap
    lda __L_process_symbol_name+1
    sta __ap+1
    lda (__ap),y
    sta __T_process_symbol___v5
    cmp #$2a
    beq __F_process_symbol_yes_4
    jmp __F_process_symbol_join_3
__F_process_symbol_yes_4:
    lda origin_allowed
    cmp #$00
    beq __F_process_symbol_yes_7
    jmp __F_process_symbol_join_9
__F_process_symbol_yes_7:
    lda ASSEMBLE_BAD_ORIGIN
    ldx #$00
    rts
__F_process_symbol_join_9:
    lda __L_process_symbol_argument
    sta __T_process_symbol___v12
    lda __L_process_symbol_argument+1
    sta __T_process_symbol___v12+1
    lda __L_process_symbol_argument_length
    sta __T_process_symbol___v13
    lda __T_process_symbol___v12
    sta __call_parse_value_0
    lda __T_process_symbol___v12+1
    sta __call_parse_value_0+1
    lda __T_process_symbol___v13
    sta __call_parse_value_1
    jsr parse_value
    sta __L_process_symbol_status
    lda __L_process_symbol_status
    cmp VALUE_OK
    bne __F_process_symbol_yes_10
    jmp __F_process_symbol_join_12
__F_process_symbol_yes_10:
    lda ASSEMBLE_BAD_ORIGIN
    ldx #$00
    rts
__F_process_symbol_join_12:
    lda value_result
    sta ass_origin
    lda value_result+1
    sta ass_origin+1
    lda #$00
    sta origin_allowed
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_process_symbol_join_3:
    lda __L_process_symbol_argument
    sta __T_process_symbol___v22
    lda __L_process_symbol_argument+1
    sta __T_process_symbol___v22+1
    lda __L_process_symbol_argument_length
    sta __T_process_symbol___v23
    lda __T_process_symbol___v22
    sta __call_parse_value_0
    lda __T_process_symbol___v22+1
    sta __call_parse_value_0+1
    lda __T_process_symbol___v23
    sta __call_parse_value_1
    jsr parse_value
    sta __L_process_symbol_status
    lda __L_process_symbol_status
    cmp VALUE_OK
    bne __F_process_symbol_yes_13
    jmp __F_process_symbol_join_15
__F_process_symbol_yes_13:
    lda __L_process_symbol_status
    cmp VALUE_SYMBOL_FULL
    beq __F_process_symbol_yes_16
    jmp __F_process_symbol_join_18
__F_process_symbol_yes_16:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_process_symbol_join_18:
    lda __L_process_symbol_status
    cmp VALUE_SCOPE_ERROR
    beq __F_process_symbol_yes_19
    jmp __F_process_symbol_join_21
__F_process_symbol_yes_19:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_process_symbol_join_21:
    lda ASSEMBLE_BAD_SYMBOL
    ldx #$00
    rts
__F_process_symbol_join_15:
    lda __L_process_symbol_name
    sta __T_process_symbol___v37
    lda __L_process_symbol_name+1
    sta __T_process_symbol___v37+1
    lda __L_process_symbol_name_length
    sta __T_process_symbol___v38
    lda value_result
    sta __T_process_symbol___v39
    lda value_result+1
    sta __T_process_symbol___v39+1
    lda __T_process_symbol___v37
    sta __call_define_constant_0
    lda __T_process_symbol___v37+1
    sta __call_define_constant_0+1
    lda __T_process_symbol___v38
    sta __call_define_constant_1
    lda __T_process_symbol___v39
    sta __call_define_constant_2
    lda __T_process_symbol___v39+1
    sta __call_define_constant_2+1
    jsr define_constant
    ldx #$00
    rts
process_instruction_like:
__F_process_instruction_like_entry:
    lda __L_process_instruction_like_name
    sta __T_process_instruction_like___v0
    lda __L_process_instruction_like_name+1
    sta __T_process_instruction_like___v0+1
    lda __L_process_instruction_like_name_length
    sta __T_process_instruction_like___v1
    lda __T_process_instruction_like___v0
    sta __call_same_text_0
    lda __T_process_instruction_like___v0+1
    sta __call_same_text_0+1
    lda __T_process_instruction_like___v1
    sta __call_same_text_1
    lda #<__S_process_instruction_like___text_0
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_0
    sta __call_same_text_2+1
    lda #$07
    sta __call_same_text_3
    lda #$00
    sta __call_same_text_3+1
    jsr same_text
    sta __T_process_instruction_like___v4
    cmp #$00
    bne __F_process_instruction_like_yes_1
    jmp __F_process_instruction_like_join_3
__F_process_instruction_like_yes_1:
    lda __L_process_instruction_like_argument
    sta __T_process_instruction_like___v7
    lda __L_process_instruction_like_argument+1
    sta __T_process_instruction_like___v7+1
    lda __L_process_instruction_like_argument_length
    sta __T_process_instruction_like___v8
    lda __T_process_instruction_like___v7
    sta __call_open_include_0
    lda __T_process_instruction_like___v7+1
    sta __call_open_include_0+1
    lda __T_process_instruction_like___v8
    sta __call_open_include_1
    jsr open_include
    ldx #$00
    rts
__F_process_instruction_like_join_3:
    lda #$00
    sta origin_allowed
    lda __L_process_instruction_like_name
    sta __T_process_instruction_like___v11
    lda __L_process_instruction_like_name+1
    sta __T_process_instruction_like___v11+1
    lda __L_process_instruction_like_name_length
    sta __T_process_instruction_like___v12
    lda __T_process_instruction_like___v11
    sta __call_same_text_0
    lda __T_process_instruction_like___v11+1
    sta __call_same_text_0+1
    lda __T_process_instruction_like___v12
    sta __call_same_text_1
    lda #<__S_process_instruction_like___text_1
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_1
    sta __call_same_text_2+1
    lda #$04
    sta __call_same_text_3
    lda #$00
    sta __call_same_text_3+1
    jsr same_text
    sta __T_process_instruction_like___v15
    cmp #$00
    bne __F_process_instruction_like_yes_4
    jmp __F_process_instruction_like_join_6
__F_process_instruction_like_yes_4:
    lda __L_process_instruction_like_argument
    sta __T_process_instruction_like___v18
    lda __L_process_instruction_like_argument+1
    sta __T_process_instruction_like___v18+1
    lda __L_process_instruction_like_argument_length
    sta __T_process_instruction_like___v19
    lda __T_process_instruction_like___v18
    sta __call_assemble_data_list_0
    lda __T_process_instruction_like___v18+1
    sta __call_assemble_data_list_0+1
    lda __T_process_instruction_like___v19
    sta __call_assemble_data_list_1
    lda #$01
    sta __call_assemble_data_list_2
    lda #$00
    sta __call_assemble_data_list_2+1
    jsr assemble_data_list
    ldx #$00
    rts
__F_process_instruction_like_join_6:
    lda __L_process_instruction_like_name
    sta __T_process_instruction_like___v22
    lda __L_process_instruction_like_name+1
    sta __T_process_instruction_like___v22+1
    lda __L_process_instruction_like_name_length
    sta __T_process_instruction_like___v23
    lda __T_process_instruction_like___v22
    sta __call_same_text_0
    lda __T_process_instruction_like___v22+1
    sta __call_same_text_0+1
    lda __T_process_instruction_like___v23
    sta __call_same_text_1
    lda #<__S_process_instruction_like___text_2
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_2
    sta __call_same_text_2+1
    lda #$04
    sta __call_same_text_3
    lda #$00
    sta __call_same_text_3+1
    jsr same_text
    sta __T_process_instruction_like___v26
    cmp #$00
    bne __F_process_instruction_like_yes_7
    jmp __F_process_instruction_like_join_9
__F_process_instruction_like_yes_7:
    lda __L_process_instruction_like_argument
    sta __T_process_instruction_like___v29
    lda __L_process_instruction_like_argument+1
    sta __T_process_instruction_like___v29+1
    lda __L_process_instruction_like_argument_length
    sta __T_process_instruction_like___v30
    lda __T_process_instruction_like___v29
    sta __call_assemble_data_list_0
    lda __T_process_instruction_like___v29+1
    sta __call_assemble_data_list_0+1
    lda __T_process_instruction_like___v30
    sta __call_assemble_data_list_1
    lda #$02
    sta __call_assemble_data_list_2
    lda #$00
    sta __call_assemble_data_list_2+1
    jsr assemble_data_list
    ldx #$00
    rts
__F_process_instruction_like_join_9:
    lda __L_process_instruction_like_name
    sta __T_process_instruction_like___v33
    lda __L_process_instruction_like_name+1
    sta __T_process_instruction_like___v33+1
    lda __L_process_instruction_like_name_length
    sta __T_process_instruction_like___v34
    lda __T_process_instruction_like___v33
    sta __call_same_text_0
    lda __T_process_instruction_like___v33+1
    sta __call_same_text_0+1
    lda __T_process_instruction_like___v34
    sta __call_same_text_1
    lda #<__S_process_instruction_like___text_3
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_3
    sta __call_same_text_2+1
    lda #$06
    sta __call_same_text_3
    lda #$00
    sta __call_same_text_3+1
    jsr same_text
    sta __T_process_instruction_like___v37
    cmp #$00
    bne __F_process_instruction_like_yes_10
    jmp __F_process_instruction_like_join_12
__F_process_instruction_like_yes_10:
    lda __L_process_instruction_like_argument
    sta __T_process_instruction_like___v40
    lda __L_process_instruction_like_argument+1
    sta __T_process_instruction_like___v40+1
    lda __L_process_instruction_like_argument_length
    sta __T_process_instruction_like___v41
    lda __T_process_instruction_like___v40
    sta __call_assemble_string_0
    lda __T_process_instruction_like___v40+1
    sta __call_assemble_string_0+1
    lda __T_process_instruction_like___v41
    sta __call_assemble_string_1
    jsr assemble_string
    ldx #$00
    rts
__F_process_instruction_like_join_12:
    lda __L_process_instruction_like_name
    sta __T_process_instruction_like___v43
    lda __L_process_instruction_like_name+1
    sta __T_process_instruction_like___v43+1
    lda __L_process_instruction_like_name_length
    sta __T_process_instruction_like___v44
    lda __L_process_instruction_like_argument
    sta __T_process_instruction_like___v45
    lda __L_process_instruction_like_argument+1
    sta __T_process_instruction_like___v45+1
    lda __L_process_instruction_like_argument_length
    sta __T_process_instruction_like___v46
    lda __T_process_instruction_like___v43
    sta __call_assemble_instruction_0
    lda __T_process_instruction_like___v43+1
    sta __call_assemble_instruction_0+1
    lda __T_process_instruction_like___v44
    sta __call_assemble_instruction_1
    lda __T_process_instruction_like___v45
    sta __call_assemble_instruction_2
    lda __T_process_instruction_like___v45+1
    sta __call_assemble_instruction_2+1
    lda __T_process_instruction_like___v46
    sta __call_assemble_instruction_3
    jsr assemble_instruction
    ldx #$00
    rts
__S_process_instruction_like___text_0:
    byte 105,110,99,108,117,100,101,0
__S_process_instruction_like___text_1:
    byte 98,121,116,101,0
__S_process_instruction_like___text_2:
    byte 119,111,114,100,0
__S_process_instruction_like___text_3:
    byte 115,116,114,105,110,103,0
process_source_line:
__F_process_source_line_entry:
    lda #$00
    sta __L_process_source_line_cursor
__F_process_source_line_while_1:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_while_4
    jmp __F_process_source_line_after_3
__F_process_source_line_while_4:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_body_5
    jmp __F_process_source_line_after_6
__F_process_source_line_body_5:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v9
    cmp #$20
    beq __F_process_source_line_yes_7
    jmp __F_process_source_line_no_8
__F_process_source_line_yes_7:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_4
__F_process_source_line_no_8:
    cmp #$09
    beq __F_process_source_line_yes_10
    jmp __F_process_source_line_after_6
__F_process_source_line_yes_10:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_4
__F_process_source_line_after_6:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_yes_13
    jmp __F_process_source_line_join_15
__F_process_source_line_yes_13:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_process_source_line_join_15:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v29
    cmp #$3b
    beq __F_process_source_line_yes_16
    jmp __F_process_source_line_join_18
__F_process_source_line_yes_16:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_process_source_line_join_18:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_name_start
__F_process_source_line_while_19:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_body_20
    jmp __F_process_source_line_after_21
__F_process_source_line_body_20:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v39
    cmp #$20
    beq __F_process_source_line_after_21
    jmp __F_process_source_line_join_24
__F_process_source_line_join_24:
    cmp #$09
    beq __F_process_source_line_after_21
    jmp __F_process_source_line_join_27
__F_process_source_line_join_27:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_19
__F_process_source_line_after_21:
    lda __L_process_source_line_cursor
    sec
    sbc __L_process_source_line_name_start
    sta __L_process_source_line_name_length
    lda __L_process_source_line_name_length
    cmp #$00
    beq __F_process_source_line_yes_28
    jmp __F_process_source_line_join_30
__F_process_source_line_yes_28:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_process_source_line_join_30:
    lda __L_process_source_line_name_start
    clc
    adc __L_process_source_line_name_length
    sta __T_process_source_line___v60
    lda #$00
    adc #$00
    sta __T_process_source_line___v60+1
    lda __T_process_source_line___v60
    sec
    sbc #$01
    sta __T_process_source_line___v62
    lda __T_process_source_line___v60+1
    sbc #$00
    sta __T_process_source_line___v62+1
    lda #<source_line
    sta __ap
    lda #>source_line
    sta __ap+1
    lda __T_process_source_line___v62
    sta __ix
    lda __T_process_source_line___v62+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_process_source_line___v63
    cmp #$3a
    beq __F_process_source_line_yes_31
    jmp __F_process_source_line_while_37
__F_process_source_line_yes_31:
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_label_0
    lda #>source_line
    adc #$00
    sta __call_process_label_0+1
    lda __L_process_source_line_name_length
    sec
    sbc #$01
    sta __call_process_label_1
    lda #$00
    sbc #$00
    sta __call_process_label_1+1
    jsr process_label
    sta __L_process_source_line_status
    lda __L_process_source_line_status
    cmp ASSEMBLE_OK
    bne __F_process_source_line_yes_34
    jmp __F_process_source_line_while_1
__F_process_source_line_yes_34:
    lda __L_process_source_line_status
    ldx #$00
    rts
__F_process_source_line_while_37:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_body_38
    jmp __F_process_source_line_after_39
__F_process_source_line_body_38:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v82
    cmp #$20
    beq __F_process_source_line_yes_40
    jmp __F_process_source_line_no_41
__F_process_source_line_yes_40:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_37
__F_process_source_line_no_41:
    cmp #$09
    beq __F_process_source_line_yes_43
    jmp __F_process_source_line_after_39
__F_process_source_line_yes_43:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_37
__F_process_source_line_after_39:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_yes_46
    jmp __F_process_source_line_join_48
__F_process_source_line_yes_46:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v101
    cmp #$3d
    beq __F_process_source_line_yes_49
    jmp __F_process_source_line_join_48
__F_process_source_line_yes_49:
    inc __L_process_source_line_cursor
__F_process_source_line_while_52:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_body_53
    jmp __F_process_source_line_after_54
__F_process_source_line_body_53:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v112
    cmp #$20
    beq __F_process_source_line_yes_55
    jmp __F_process_source_line_no_56
__F_process_source_line_yes_55:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_52
__F_process_source_line_no_56:
    cmp #$09
    beq __F_process_source_line_yes_58
    jmp __F_process_source_line_after_54
__F_process_source_line_yes_58:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_52
__F_process_source_line_after_54:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_argument_start
    lda __L_process_source_line_argument_start
    sta __T_process_source_line___v127
    lda __T_process_source_line___v127
    sta __call_scan_argument_0
    jsr scan_argument
    sta __T_process_source_line___v128
    stx __T_process_source_line___v128+1
    lda __T_process_source_line___v128
    sta __L_process_source_line_argument_length
    lda __L_process_source_line_argument_length
    cmp #$00
    beq __F_process_source_line_yes_61
    jmp __F_process_source_line_join_63
__F_process_source_line_yes_61:
    lda ASSEMBLE_BAD_SYMBOL
    ldx #$00
    rts
__F_process_source_line_join_63:
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_symbol_0
    lda #>source_line
    adc #$00
    sta __call_process_symbol_0+1
    lda __L_process_source_line_name_length
    sta __T_process_source_line___v136
    lda #<source_line
    clc
    adc __L_process_source_line_argument_start
    sta __call_process_symbol_2
    lda #>source_line
    adc #$00
    sta __call_process_symbol_2+1
    lda __L_process_source_line_argument_length
    sta __T_process_source_line___v140
    lda __T_process_source_line___v136
    sta __call_process_symbol_1
    lda __T_process_source_line___v140
    sta __call_process_symbol_3
    jsr process_symbol
    ldx #$00
    rts
__F_process_source_line_join_48:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_argument_start
    lda __L_process_source_line_argument_start
    sta __T_process_source_line___v143
    lda __T_process_source_line___v143
    sta __call_scan_argument_0
    jsr scan_argument
    sta __T_process_source_line___v144
    stx __T_process_source_line___v144+1
    lda __T_process_source_line___v144
    sta __L_process_source_line_argument_length
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_instruction_like_0
    lda #>source_line
    adc #$00
    sta __call_process_instruction_like_0+1
    lda __L_process_source_line_name_length
    sta __T_process_source_line___v148
    lda #<source_line
    clc
    adc __L_process_source_line_argument_start
    sta __call_process_instruction_like_2
    lda #>source_line
    adc #$00
    sta __call_process_instruction_like_2+1
    lda __L_process_source_line_argument_length
    sta __T_process_source_line___v152
    lda __T_process_source_line___v148
    sta __call_process_instruction_like_1
    lda __T_process_source_line___v152
    sta __call_process_instruction_like_3
    jsr process_instruction_like
    ldx #$00
    rts
__F_process_source_line_after_3:
    lda ASSEMBLE_OK
    ldx #$00
    rts
reset_assembler:
__F_reset_assembler_entry:
    lda #$00
    sta ass_image_length
    lda #$00
    sta ass_image_length+1
    lda __L_reset_assembler_default_origin
    sta __T_reset_assembler___v3
    lda __L_reset_assembler_default_origin+1
    sta __T_reset_assembler___v3+1
    lda __T_reset_assembler___v3
    sta ass_origin
    lda __T_reset_assembler___v3+1
    sta ass_origin+1
    sec
    lda #$00
    sbc #$01
    sta source_depth
    lda #$00
    sbc #$00
    sta source_depth+1
    lda __L_reset_assembler_directory
    sta source_directory
    lda __L_reset_assembler_directory+1
    sta source_directory+1
    lda __L_reset_assembler_directory_length
    sta source_directory_length
    lda #$00
    sta symbol_count
    lda #$00
    sta symbol_count+1
    lda #$00
    sta symbol_name_used
    lda #$00
    sta symbol_name_used+1
    lda #$00
    sta current_scope
    lda #$00
    sta fixup_count
    lda #$00
    sta fixup_count+1
    lda #$01
    sta origin_allowed
    lda ASSEMBLE_OK
    ldx #$00
    rts
all_symbols_defined:
__F_all_symbols_defined_entry:
    lda #$00
    sta __L_all_symbols_defined_i
    lda #$00
    sta __L_all_symbols_defined_i+1
    ldy #$00
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
__F_all_symbols_defined_while_1:
    lda symbol_count+1
    eor #$80
    sta __rh
    lda __L_all_symbols_defined_i+1
    eor #$80
    cmp __rh
    bcc __F_all_symbols_defined___sel1
    bne __F_all_symbols_defined___sel2
    lda __L_all_symbols_defined_i
    cmp symbol_count
    bcc __F_all_symbols_defined___sel1
    bne __F_all_symbols_defined___sel2
    jmp __F_all_symbols_defined___sel3
__F_all_symbols_defined___sel1:
    jmp __F_all_symbols_defined_body_2
__F_all_symbols_defined___sel2:
    jmp __F_all_symbols_defined_after_3
__F_all_symbols_defined___sel3:
    jmp __F_all_symbols_defined_after_3
__F_all_symbols_defined_body_2:
    lda (__ap),y
    sta __T_all_symbols_defined___v6
    cmp SYMBOL_LABEL_UNDEFINED
    beq __F_all_symbols_defined_yes_4
    jmp __F_all_symbols_defined_join_6
__F_all_symbols_defined_yes_4:
    lda #$00
    ldx #$00
    rts
__F_all_symbols_defined_join_6:
    lda __L_all_symbols_defined_i
    clc
    adc #$01
    sta __T_all_symbols_defined___v12
    lda __L_all_symbols_defined_i+1
    adc #$00
    sta __T_all_symbols_defined___v12+1
    lda __T_all_symbols_defined___v12
    sta __L_all_symbols_defined_i
    lda __T_all_symbols_defined___v12+1
    sta __L_all_symbols_defined_i+1
    inc __ap
    bne __F_all_symbols_defined___sel4
    inc __ap+1
__F_all_symbols_defined___sel4:
    jmp __F_all_symbols_defined_while_1
__F_all_symbols_defined_after_3:
    lda #$01
    ldx #$00
    rts
all_fixups_resolved:
__F_all_fixups_resolved_entry:
    lda #$00
    sta __L_all_fixups_resolved_i
    lda #$00
    sta __L_all_fixups_resolved_i+1
    ldy #$00
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
__F_all_fixups_resolved_while_1:
    lda fixup_count+1
    eor #$80
    sta __rh
    lda __L_all_fixups_resolved_i+1
    eor #$80
    cmp __rh
    bcc __F_all_fixups_resolved___sel1
    bne __F_all_fixups_resolved___sel2
    lda __L_all_fixups_resolved_i
    cmp fixup_count
    bcc __F_all_fixups_resolved___sel1
    bne __F_all_fixups_resolved___sel2
    jmp __F_all_fixups_resolved___sel3
__F_all_fixups_resolved___sel1:
    jmp __F_all_fixups_resolved_body_2
__F_all_fixups_resolved___sel2:
    jmp __F_all_fixups_resolved_after_3
__F_all_fixups_resolved___sel3:
    jmp __F_all_fixups_resolved_after_3
__F_all_fixups_resolved_body_2:
    lda (__ap),y
    sta __T_all_fixups_resolved___v6
    cmp FIXUP_NONE
    bne __F_all_fixups_resolved_yes_4
    jmp __F_all_fixups_resolved_join_6
__F_all_fixups_resolved_yes_4:
    lda #$00
    ldx #$00
    rts
__F_all_fixups_resolved_join_6:
    lda __L_all_fixups_resolved_i
    clc
    adc #$01
    sta __T_all_fixups_resolved___v12
    lda __L_all_fixups_resolved_i+1
    adc #$00
    sta __T_all_fixups_resolved___v12+1
    lda __T_all_fixups_resolved___v12
    sta __L_all_fixups_resolved_i
    lda __T_all_fixups_resolved___v12+1
    sta __L_all_fixups_resolved_i+1
    inc __ap
    bne __F_all_fixups_resolved___sel4
    inc __ap+1
__F_all_fixups_resolved___sel4:
    jmp __F_all_fixups_resolved_while_1
__F_all_fixups_resolved_after_3:
    lda #$01
    ldx #$00
    rts
ass_assemble:
__F_ass_assemble_entry:
    lda __L_ass_assemble_default_origin
    sta __T_ass_assemble___v0
    lda __L_ass_assemble_default_origin+1
    sta __T_ass_assemble___v0+1
    lda __L_ass_assemble_directory
    sta __T_ass_assemble___v1
    lda __L_ass_assemble_directory+1
    sta __T_ass_assemble___v1+1
    lda __L_ass_assemble_directory_length
    sta __T_ass_assemble___v2
    lda __T_ass_assemble___v0
    sta __call_reset_assembler_0
    lda __T_ass_assemble___v0+1
    sta __call_reset_assembler_0+1
    lda __T_ass_assemble___v1
    sta __call_reset_assembler_1
    lda __T_ass_assemble___v1+1
    sta __call_reset_assembler_1+1
    lda __T_ass_assemble___v2
    sta __call_reset_assembler_2
    jsr reset_assembler
    sta __T_ass_assemble___v3
    lda __L_ass_assemble_root_name
    sta __T_ass_assemble___v4
    lda __L_ass_assemble_root_name+1
    sta __T_ass_assemble___v4+1
    lda __L_ass_assemble_root_name_length
    sta __T_ass_assemble___v5
    lda __T_ass_assemble___v4
    sta __call_io_open_0
    lda __T_ass_assemble___v4+1
    sta __call_io_open_0+1
    lda __T_ass_assemble___v5
    sta __call_io_open_1
    jsr io_open
    sta __L_ass_assemble_handle
    stx __L_ass_assemble_handle+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_ass_assemble_handle+1
    eor #$80
    cmp __rh
    bcc __F_ass_assemble___sel1
    bne __F_ass_assemble___sel2
    lda __L_ass_assemble_handle
    cmp #$00
    bcc __F_ass_assemble___sel1
    bne __F_ass_assemble___sel2
    jmp __F_ass_assemble___sel3
__F_ass_assemble___sel1:
    jmp __F_ass_assemble_yes_1
__F_ass_assemble___sel2:
    jmp __F_ass_assemble_join_3
__F_ass_assemble___sel3:
    jmp __F_ass_assemble_join_3
__F_ass_assemble_yes_1:
    lda ASSEMBLE_IO_ERROR
    ldx #$00
    rts
__F_ass_assemble_join_3:
    lda #$00
    sta source_depth
    lda #$00
    sta source_depth+1
    lda __L_ass_assemble_handle
    sta __T_ass_assemble___v14
    lda __L_ass_assemble_handle+1
    sta __T_ass_assemble___v14+1
    ldy #$00
    lda __T_ass_assemble___v14
    sta source_handle,y
__F_ass_assemble_while_4:
    lda #$00
    eor #$80
    sta __rh
    lda source_depth+1
    eor #$80
    cmp __rh
    bcc __F_ass_assemble___sel4
    bne __F_ass_assemble___sel5
    lda source_depth
    cmp #$00
    bcc __F_ass_assemble___sel4
    bne __F_ass_assemble___sel5
    jmp __F_ass_assemble___sel6
__F_ass_assemble___sel4:
    jmp __F_ass_assemble_after_6
__F_ass_assemble___sel5:
    jmp __F_ass_assemble_body_5
__F_ass_assemble___sel6:
    jmp __F_ass_assemble_body_5
__F_ass_assemble_body_5:
    jsr read_source_line
    sta __L_ass_assemble_line_status
    stx __L_ass_assemble_line_status+1
    lda __L_ass_assemble_line_status+1
    cmp #$00
    bne __F_ass_assemble_no_8
    lda __L_ass_assemble_line_status
    cmp #$01
    beq __F_ass_assemble_yes_7
    jmp __F_ass_assemble_no_8
__F_ass_assemble_yes_7:
    jsr process_source_line
    sta __L_ass_assemble_status
    lda __L_ass_assemble_status
    cmp ASSEMBLE_OK
    bne __F_ass_assemble_yes_10
    jmp __F_ass_assemble_while_4
__F_ass_assemble_yes_10:
    jsr close_source_tree
    sta __T_ass_assemble___v26
    lda __L_ass_assemble_status
    ldx #$00
    rts
__F_ass_assemble_no_8:
    lda __L_ass_assemble_line_status+1
    cmp #$00
    bne __F_ass_assemble_no_14
    lda __L_ass_assemble_line_status
    cmp #$00
    beq __F_ass_assemble_yes_13
    jmp __F_ass_assemble_no_14
__F_ass_assemble_yes_13:
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda source_depth
    sta __ix
    lda source_depth+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_io_close_0
    jsr io_close
    sta __T_ass_assemble___v34
    lda source_depth
    sec
    sbc #$01
    sta __T_ass_assemble___v37
    lda source_depth+1
    sbc #$00
    sta __T_ass_assemble___v37+1
    lda __T_ass_assemble___v37
    sta source_depth
    lda __T_ass_assemble___v37+1
    sta source_depth+1
    jmp __F_ass_assemble_while_4
__F_ass_assemble_no_14:
    jsr close_source_tree
    sta __T_ass_assemble___v38
    sec
    lda #$00
    sbc #$02
    sta __T_ass_assemble___v41
    lda #$00
    sbc #$00
    sta __T_ass_assemble___v41+1
    lda __L_ass_assemble_line_status+1
    cmp __T_ass_assemble___v41+1
    bne __F_ass_assemble_join_18
    lda __L_ass_assemble_line_status
    cmp __T_ass_assemble___v41
    beq __F_ass_assemble_yes_16
    jmp __F_ass_assemble_join_18
__F_ass_assemble_yes_16:
    lda ASSEMBLE_LINE_TOO_LONG
    ldx #$00
    rts
__F_ass_assemble_join_18:
    lda ASSEMBLE_IO_ERROR
    ldx #$00
    rts
__F_ass_assemble_after_6:
    jsr all_symbols_defined
    sta __T_ass_assemble___v45
    cmp #$00
    beq __F_ass_assemble_yes_19
    jmp __F_ass_assemble_join_21
__F_ass_assemble_yes_19:
    lda ASSEMBLE_UNDEFINED
    ldx #$00
    rts
__F_ass_assemble_join_21:
    jsr all_fixups_resolved
    sta __T_ass_assemble___v49
    cmp #$00
    beq __F_ass_assemble_yes_22
    jmp __F_ass_assemble_join_24
__F_ass_assemble_yes_22:
    lda ASSEMBLE_UNDEFINED
    ldx #$00
    rts
__F_ass_assemble_join_24:
    lda ASSEMBLE_OK
    ldx #$00
    rts
