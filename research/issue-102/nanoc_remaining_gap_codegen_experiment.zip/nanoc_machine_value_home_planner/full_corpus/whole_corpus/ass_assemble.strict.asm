* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
ASSEMBLE_IO_ERROR = $4000
ASSEMBLE_LINE_TOO_LONG = $4002
ASSEMBLE_OK = $4004
ASSEMBLE_UNDEFINED = $4006
__L_ass_assemble_default_origin = $4008
__L_ass_assemble_directory = $400a
__L_ass_assemble_directory_length = $400c
__L_ass_assemble_handle = $400e
__L_ass_assemble_line_status = $4010
__L_ass_assemble_root_name = $4012
__L_ass_assemble_root_name_length = $4014
__L_ass_assemble_status = $4016
__T_ass_assemble___v0 = $4018
__T_ass_assemble___v1 = $401a
__T_ass_assemble___v14 = $401c
__T_ass_assemble___v2 = $401e
__T_ass_assemble___v26 = $4020
__T_ass_assemble___v3 = $4022
__T_ass_assemble___v34 = $4024
__T_ass_assemble___v37 = $4026
__T_ass_assemble___v38 = $4028
__T_ass_assemble___v4 = $402a
__T_ass_assemble___v41 = $402c
__T_ass_assemble___v45 = $402e
__T_ass_assemble___v49 = $4030
__T_ass_assemble___v5 = $4032
__call_io_close_0 = $4034
__call_io_open_0 = $4036
__call_io_open_1 = $4038
__call_reset_assembler_0 = $403a
__call_reset_assembler_1 = $403c
__call_reset_assembler_2 = $403e
all_fixups_resolved = $4040
all_symbols_defined = $4042
close_source_tree = $4044
io_close = $4046
io_open = $4048
process_source_line = $404a
read_source_line = $404c
reset_assembler = $404e
source_depth = $4050
source_handle = $4052
ass_assemble:
__F_ass_assemble_entry:
    lda __L_ass_assemble_default_origin
    sta __T_ass_assemble___v0
    lda __L_ass_assemble_default_origin+1
    sta __T_ass_assemble___v0+1
    lda __L_ass_assemble_directory
    sta __T_ass_assemble___v1
    lda __L_ass_assemble_directory+1
    sta __T_ass_assemble___v1+1
    lda __L_ass_assemble_directory_length
    sta __T_ass_assemble___v2
    lda __T_ass_assemble___v0
    sta __call_reset_assembler_0
    lda __T_ass_assemble___v0+1
    sta __call_reset_assembler_0+1
    lda __T_ass_assemble___v1
    sta __call_reset_assembler_1
    lda __T_ass_assemble___v1+1
    sta __call_reset_assembler_1+1
    lda __T_ass_assemble___v2
    sta __call_reset_assembler_2
    jsr reset_assembler
    sta __T_ass_assemble___v3
    lda __L_ass_assemble_root_name
    sta __T_ass_assemble___v4
    lda __L_ass_assemble_root_name+1
    sta __T_ass_assemble___v4+1
    lda __L_ass_assemble_root_name_length
    sta __T_ass_assemble___v5
    lda __T_ass_assemble___v4
    sta __call_io_open_0
    lda __T_ass_assemble___v4+1
    sta __call_io_open_0+1
    lda __T_ass_assemble___v5
    sta __call_io_open_1
    jsr io_open
    sta __L_ass_assemble_handle
    stx __L_ass_assemble_handle+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_ass_assemble_handle+1
    eor #$80
    cmp __rh
    bcc __F_ass_assemble___sel1
    bne __F_ass_assemble___sel2
    lda __L_ass_assemble_handle
    cmp #$00
    bcc __F_ass_assemble___sel1
    bne __F_ass_assemble___sel2
    jmp __F_ass_assemble___sel3
__F_ass_assemble___sel1:
    jmp __F_ass_assemble_yes_1
__F_ass_assemble___sel2:
    jmp __F_ass_assemble_join_3
__F_ass_assemble___sel3:
    jmp __F_ass_assemble_join_3
__F_ass_assemble_yes_1:
    lda ASSEMBLE_IO_ERROR
    ldx #$00
    rts
__F_ass_assemble_join_3:
    lda #$00
    sta source_depth
    lda #$00
    sta source_depth+1
    lda __L_ass_assemble_handle
    sta __T_ass_assemble___v14
    lda __L_ass_assemble_handle+1
    sta __T_ass_assemble___v14+1
    ldy #$00
    lda __T_ass_assemble___v14
    sta source_handle,y
__F_ass_assemble_while_4:
    lda #$00
    eor #$80
    sta __rh
    lda source_depth+1
    eor #$80
    cmp __rh
    bcc __F_ass_assemble___sel4
    bne __F_ass_assemble___sel5
    lda source_depth
    cmp #$00
    bcc __F_ass_assemble___sel4
    bne __F_ass_assemble___sel5
    jmp __F_ass_assemble___sel6
__F_ass_assemble___sel4:
    jmp __F_ass_assemble_after_6
__F_ass_assemble___sel5:
    jmp __F_ass_assemble_body_5
__F_ass_assemble___sel6:
    jmp __F_ass_assemble_body_5
__F_ass_assemble_body_5:
    jsr read_source_line
    sta __L_ass_assemble_line_status
    stx __L_ass_assemble_line_status+1
    lda __L_ass_assemble_line_status+1
    cmp #$00
    bne __F_ass_assemble_no_8
    lda __L_ass_assemble_line_status
    cmp #$01
    beq __F_ass_assemble_yes_7
    jmp __F_ass_assemble_no_8
__F_ass_assemble_yes_7:
    jsr process_source_line
    sta __L_ass_assemble_status
    lda __L_ass_assemble_status
    cmp ASSEMBLE_OK
    bne __F_ass_assemble_yes_10
    jmp __F_ass_assemble_while_4
__F_ass_assemble_yes_10:
    jsr close_source_tree
    sta __T_ass_assemble___v26
    lda __L_ass_assemble_status
    ldx #$00
    rts
__F_ass_assemble_no_8:
    lda __L_ass_assemble_line_status+1
    cmp #$00
    bne __F_ass_assemble_no_14
    lda __L_ass_assemble_line_status
    cmp #$00
    beq __F_ass_assemble_yes_13
    jmp __F_ass_assemble_no_14
__F_ass_assemble_yes_13:
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda source_depth
    sta __ix
    lda source_depth+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_io_close_0
    jsr io_close
    sta __T_ass_assemble___v34
    lda source_depth
    sec
    sbc #$01
    sta __T_ass_assemble___v37
    lda source_depth+1
    sbc #$00
    sta __T_ass_assemble___v37+1
    lda __T_ass_assemble___v37
    sta source_depth
    lda __T_ass_assemble___v37+1
    sta source_depth+1
    jmp __F_ass_assemble_while_4
__F_ass_assemble_no_14:
    jsr close_source_tree
    sta __T_ass_assemble___v38
    sec
    lda #$00
    sbc #$02
    sta __T_ass_assemble___v41
    lda #$00
    sbc #$00
    sta __T_ass_assemble___v41+1
    lda __L_ass_assemble_line_status+1
    cmp __T_ass_assemble___v41+1
    bne __F_ass_assemble_join_18
    lda __L_ass_assemble_line_status
    cmp __T_ass_assemble___v41
    beq __F_ass_assemble_yes_16
    jmp __F_ass_assemble_join_18
__F_ass_assemble_yes_16:
    lda ASSEMBLE_LINE_TOO_LONG
    ldx #$00
    rts
__F_ass_assemble_join_18:
    lda ASSEMBLE_IO_ERROR
    ldx #$00
    rts
__F_ass_assemble_after_6:
    jsr all_symbols_defined
    sta __T_ass_assemble___v45
    cmp #$00
    beq __F_ass_assemble_yes_19
    jmp __F_ass_assemble_join_21
__F_ass_assemble_yes_19:
    lda ASSEMBLE_UNDEFINED
    ldx #$00
    rts
__F_ass_assemble_join_21:
    jsr all_fixups_resolved
    sta __T_ass_assemble___v49
    cmp #$00
    beq __F_ass_assemble_yes_22
    jmp __F_ass_assemble_join_24
__F_ass_assemble_yes_22:
    lda ASSEMBLE_UNDEFINED
    ldx #$00
    rts
__F_ass_assemble_join_24:
    lda ASSEMBLE_OK
    ldx #$00
    rts
