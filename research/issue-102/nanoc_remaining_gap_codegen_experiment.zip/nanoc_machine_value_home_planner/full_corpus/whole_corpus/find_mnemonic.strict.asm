* = $0800
__ap = $0010
__ix = $0012
__mw = $0015
__L_find_mnemonic_candidate = $4000
__L_find_mnemonic_length = $4002
__L_find_mnemonic_name = $4004
__L_find_mnemonic_offset = $4006
__T_find_mnemonic___v11 = $4008
__T_find_mnemonic___v15 = $400a
__T_find_mnemonic___v18 = $400c
__T_find_mnemonic___v23 = $400e
__T_find_mnemonic___v27 = $4010
__T_find_mnemonic___v28 = $4012
__T_find_mnemonic___v33 = $4014
__T_find_mnemonic___v37 = $4016
__T_find_mnemonic___v38 = $4018
__T_find_mnemonic___v4 = $401a
__T_find_mnemonic___v45 = $401c
__call_upper_char_0 = $401e
mnemonic_table = $4020
upper_char = $4022
find_mnemonic:
__F_find_mnemonic_entry:
    lda __L_find_mnemonic_length
    cmp #$03
    bne __F_find_mnemonic_yes_1
    jmp __F_find_mnemonic_join_3
__F_find_mnemonic_yes_1:
    sec
    lda #$00
    sbc #$01
    sta __T_find_mnemonic___v4
    lda #$00
    sbc #$00
    sta __T_find_mnemonic___v4+1
    lda __T_find_mnemonic___v4
    ldx __T_find_mnemonic___v4+1
    rts
__F_find_mnemonic_join_3:
    lda #$00
    sta __L_find_mnemonic_candidate
__F_find_mnemonic_while_4:
    lda __L_find_mnemonic_candidate
    cmp #$38
    bcc __F_find_mnemonic_body_5
    jmp __F_find_mnemonic_after_6
__F_find_mnemonic_body_5:
    lda #$00
    sta __T_find_mnemonic___v11
    sta __T_find_mnemonic___v11+1
    lda __L_find_mnemonic_candidate
    sta __mw
    lda #$00
    sta __mw+1
    clc
    lda __T_find_mnemonic___v11
    adc __mw
    sta __T_find_mnemonic___v11
    lda __T_find_mnemonic___v11+1
    adc __mw+1
    sta __T_find_mnemonic___v11+1
    asl __mw
    rol __mw+1
    clc
    lda __T_find_mnemonic___v11
    adc __mw
    sta __T_find_mnemonic___v11
    lda __T_find_mnemonic___v11+1
    adc __mw+1
    sta __T_find_mnemonic___v11+1
    lda __T_find_mnemonic___v11
    sta __L_find_mnemonic_offset
    ldy #$00
    lda __L_find_mnemonic_name
    sta __ap
    lda __L_find_mnemonic_name+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_find_mnemonic___v15
    ldy __L_find_mnemonic_offset
    lda mnemonic_table,y
    sta __T_find_mnemonic___v18
    lda __T_find_mnemonic___v15
    cmp __T_find_mnemonic___v18
    beq __F_find_mnemonic_yes_7
    jmp __F_find_mnemonic_join_9
__F_find_mnemonic_yes_7:
    ldy #$01
    lda __L_find_mnemonic_name
    sta __ap
    lda __L_find_mnemonic_name+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_find_mnemonic___v23
    lda __L_find_mnemonic_offset
    clc
    adc #$01
    sta __T_find_mnemonic___v27
    lda #$00
    adc #$00
    sta __T_find_mnemonic___v27+1
    lda #<mnemonic_table
    sta __ap
    lda #>mnemonic_table
    sta __ap+1
    lda __T_find_mnemonic___v27
    sta __ix
    lda __T_find_mnemonic___v27+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_mnemonic___v28
    lda __T_find_mnemonic___v23
    cmp __T_find_mnemonic___v28
    beq __F_find_mnemonic_yes_10
    jmp __F_find_mnemonic_join_9
__F_find_mnemonic_yes_10:
    ldy #$02
    lda __L_find_mnemonic_name
    sta __ap
    lda __L_find_mnemonic_name+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_find_mnemonic___v33
    lda __L_find_mnemonic_offset
    clc
    adc #$02
    sta __T_find_mnemonic___v37
    lda #$00
    adc #$00
    sta __T_find_mnemonic___v37+1
    lda #<mnemonic_table
    sta __ap
    lda #>mnemonic_table
    sta __ap+1
    lda __T_find_mnemonic___v37
    sta __ix
    lda __T_find_mnemonic___v37+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_mnemonic___v38
    lda __T_find_mnemonic___v33
    cmp __T_find_mnemonic___v38
    beq __F_find_mnemonic_yes_13
    jmp __F_find_mnemonic_join_9
__F_find_mnemonic_yes_13:
    lda __L_find_mnemonic_candidate
    ldx #$00
    rts
__F_find_mnemonic_join_9:
    inc __L_find_mnemonic_candidate
    jmp __F_find_mnemonic_while_4
__F_find_mnemonic_after_6:
    sec
    lda #$00
    sbc #$01
    sta __T_find_mnemonic___v45
    lda #$00
    sbc #$00
    sta __T_find_mnemonic___v45+1
    lda __T_find_mnemonic___v45
    ldx __T_find_mnemonic___v45+1
    rts
