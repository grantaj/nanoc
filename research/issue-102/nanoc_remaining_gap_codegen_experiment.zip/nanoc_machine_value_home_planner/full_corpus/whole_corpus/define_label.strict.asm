* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
ASSEMBLE_BAD_SYMBOL = $4000
ASSEMBLE_OK = $4002
ASSEMBLE_SCOPE_ERROR = $4004
ASSEMBLE_SYMBOL_FULL = $4006
SYMBOL_LABEL_DEFINED = $4008
SYMBOL_LABEL_UNDEFINED = $400a
__L_define_label_length = $400c
__L_define_label_name = $400e
__L_define_label_old_head = $4010
__L_define_label_status = $4012
__L_define_label_symbol = $4014
__L_define_label_value = $4016
__T_define_label___v0 = $4018
__T_define_label___v1 = $401a
__T_define_label___v11 = $401c
__T_define_label___v12 = $401e
__T_define_label___v13 = $4020
__T_define_label___v14 = $4022
__T_define_label___v18 = $4024
__T_define_label___v28 = $4026
__T_define_label___v34 = $4028
__T_define_label___v36 = $402a
__T_define_label___v39 = $402c
__T_define_label___v41 = $402e
__T_define_label___v42 = $4030
__T_define_label___v43 = $4032
__T_define_label___v44 = $4034
__T_define_label___v5 = $4036
__T_define_label___v50 = $4038
__call_allocate_symbol_0 = $403a
__call_allocate_symbol_1 = $403c
__call_allocate_symbol_2 = $403e
__call_allocate_symbol_3 = $4040
__call_find_symbol_0 = $4042
__call_find_symbol_1 = $4044
__call_patch_word_chain_0 = $4046
__call_patch_word_chain_1 = $4048
__call_resolve_fixups_for_symbol_0 = $404a
allocate_symbol = $404c
find_symbol = $404e
patch_word_chain = $4050
resolve_fixups_for_symbol = $4052
symbol_kind = $4054
symbol_payload = $4056
define_label:
__F_define_label_entry:
    lda __L_define_label_name
    sta __T_define_label___v0
    lda __L_define_label_name+1
    sta __T_define_label___v0+1
    lda __L_define_label_length
    sta __T_define_label___v1
    lda __T_define_label___v0
    sta __call_find_symbol_0
    lda __T_define_label___v0+1
    sta __call_find_symbol_0+1
    lda __T_define_label___v1
    sta __call_find_symbol_1
    jsr find_symbol
    sta __L_define_label_symbol
    stx __L_define_label_symbol+1
    sec
    lda #$00
    sbc #$02
    sta __T_define_label___v5
    lda #$00
    sbc #$00
    sta __T_define_label___v5+1
    lda __L_define_label_symbol+1
    cmp __T_define_label___v5+1
    bne __F_define_label_join_3
    lda __L_define_label_symbol
    cmp __T_define_label___v5
    beq __F_define_label_yes_1
    jmp __F_define_label_join_3
__F_define_label_yes_1:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_define_label_join_3:
    lda #$00
    eor #$80
    sta __rh
    lda __L_define_label_symbol+1
    eor #$80
    cmp __rh
    bcc __F_define_label___sel1
    bne __F_define_label___sel2
    lda __L_define_label_symbol
    cmp #$00
    bcc __F_define_label___sel1
    bne __F_define_label___sel2
    jmp __F_define_label___sel3
__F_define_label___sel1:
    jmp __F_define_label_yes_4
__F_define_label___sel2:
    jmp __F_define_label_join_6
__F_define_label___sel3:
    jmp __F_define_label_join_6
__F_define_label_yes_4:
    lda __L_define_label_name
    sta __T_define_label___v11
    lda __L_define_label_name+1
    sta __T_define_label___v11+1
    lda __L_define_label_length
    sta __T_define_label___v12
    lda SYMBOL_LABEL_DEFINED
    sta __T_define_label___v13
    lda __L_define_label_value
    sta __T_define_label___v14
    lda __L_define_label_value+1
    sta __T_define_label___v14+1
    lda __T_define_label___v11
    sta __call_allocate_symbol_0
    lda __T_define_label___v11+1
    sta __call_allocate_symbol_0+1
    lda __T_define_label___v12
    sta __call_allocate_symbol_1
    lda __T_define_label___v13
    sta __call_allocate_symbol_2
    lda __T_define_label___v14
    sta __call_allocate_symbol_3
    lda __T_define_label___v14+1
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    sta __L_define_label_symbol
    stx __L_define_label_symbol+1
    sec
    lda #$00
    sbc #$02
    sta __T_define_label___v18
    lda #$00
    sbc #$00
    sta __T_define_label___v18+1
    lda __L_define_label_symbol+1
    cmp __T_define_label___v18+1
    bne __F_define_label_join_9
    lda __L_define_label_symbol
    cmp __T_define_label___v18
    beq __F_define_label_yes_7
    jmp __F_define_label_join_9
__F_define_label_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_define_label_join_9:
    lda #$00
    eor #$80
    sta __rh
    lda __L_define_label_symbol+1
    eor #$80
    cmp __rh
    bcc __F_define_label___sel4
    bne __F_define_label___sel5
    lda __L_define_label_symbol
    cmp #$00
    bcc __F_define_label___sel4
    bne __F_define_label___sel5
    jmp __F_define_label___sel6
__F_define_label___sel4:
    jmp __F_define_label_yes_10
__F_define_label___sel5:
    jmp __F_define_label_join_12
__F_define_label___sel6:
    jmp __F_define_label_join_12
__F_define_label_yes_10:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_define_label_join_12:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_define_label_join_6:
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda __L_define_label_symbol
    sta __ix
    lda __L_define_label_symbol+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_define_label___v28
    cmp SYMBOL_LABEL_UNDEFINED
    bne __F_define_label_yes_13
    jmp __F_define_label_join_15
__F_define_label_yes_13:
    lda ASSEMBLE_BAD_SYMBOL
    ldx #$00
    rts
__F_define_label_join_15:
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __L_define_label_symbol
    asl
    sta __ix
    lda __L_define_label_symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_define_label___v34
    iny
    lda (__ap),y
    sta __T_define_label___v34+1
    lda __T_define_label___v34
    sta __L_define_label_old_head
    lda __T_define_label___v34+1
    sta __L_define_label_old_head+1
    lda __L_define_label_symbol
    sta __T_define_label___v36
    lda __L_define_label_symbol+1
    sta __T_define_label___v36+1
    lda __L_define_label_value
    sta __T_define_label___v39
    lda __L_define_label_value+1
    sta __T_define_label___v39+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __T_define_label___v36
    asl
    sta __ix
    lda __T_define_label___v36+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_define_label___v39
    sta (__ap),y
    iny
    lda __T_define_label___v39+1
    sta (__ap),y
    lda __L_define_label_symbol
    sta __T_define_label___v41
    lda __L_define_label_symbol+1
    sta __T_define_label___v41+1
    lda SYMBOL_LABEL_DEFINED
    sta __T_define_label___v42
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda __T_define_label___v41
    sta __ix
    lda __T_define_label___v41+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_define_label___v42
    sta (__ap),y
    lda __L_define_label_old_head
    sta __T_define_label___v43
    lda __L_define_label_old_head+1
    sta __T_define_label___v43+1
    lda __L_define_label_value
    sta __T_define_label___v44
    lda __L_define_label_value+1
    sta __T_define_label___v44+1
    lda __T_define_label___v43
    sta __call_patch_word_chain_0
    lda __T_define_label___v43+1
    sta __call_patch_word_chain_0+1
    lda __T_define_label___v44
    sta __call_patch_word_chain_1
    lda __T_define_label___v44+1
    sta __call_patch_word_chain_1+1
    jsr patch_word_chain
    sta __L_define_label_status
    lda __L_define_label_status
    cmp ASSEMBLE_OK
    bne __F_define_label_yes_16
    jmp __F_define_label_join_18
__F_define_label_yes_16:
    lda __L_define_label_status
    ldx #$00
    rts
__F_define_label_join_18:
    lda __L_define_label_symbol
    sta __T_define_label___v50
    lda __L_define_label_symbol+1
    sta __T_define_label___v50+1
    lda __T_define_label___v50
    sta __call_resolve_fixups_for_symbol_0
    lda __T_define_label___v50+1
    sta __call_resolve_fixups_for_symbol_0+1
    jsr resolve_fixups_for_symbol
    ldx #$00
    rts
