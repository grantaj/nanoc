* = $0800
__L_process_instruction_like_argument = $4000
__L_process_instruction_like_argument_length = $4002
__L_process_instruction_like_name = $4004
__L_process_instruction_like_name_length = $4006
__S_process_instruction_like___text_0 = $4008
__S_process_instruction_like___text_1 = $400a
__S_process_instruction_like___text_2 = $400c
__S_process_instruction_like___text_3 = $400e
__T_process_instruction_like___v0 = $4010
__T_process_instruction_like___v1 = $4012
__T_process_instruction_like___v11 = $4014
__T_process_instruction_like___v12 = $4016
__T_process_instruction_like___v15 = $4018
__T_process_instruction_like___v18 = $401a
__T_process_instruction_like___v19 = $401c
__T_process_instruction_like___v22 = $401e
__T_process_instruction_like___v23 = $4020
__T_process_instruction_like___v26 = $4022
__T_process_instruction_like___v29 = $4024
__T_process_instruction_like___v30 = $4026
__T_process_instruction_like___v33 = $4028
__T_process_instruction_like___v34 = $402a
__T_process_instruction_like___v37 = $402c
__T_process_instruction_like___v4 = $402e
__T_process_instruction_like___v40 = $4030
__T_process_instruction_like___v41 = $4032
__T_process_instruction_like___v43 = $4034
__T_process_instruction_like___v44 = $4036
__T_process_instruction_like___v45 = $4038
__T_process_instruction_like___v46 = $403a
__T_process_instruction_like___v7 = $403c
__T_process_instruction_like___v8 = $403e
__call_assemble_data_list_0 = $4040
__call_assemble_data_list_1 = $4042
__call_assemble_data_list_2 = $4044
__call_assemble_instruction_0 = $4046
__call_assemble_instruction_1 = $4048
__call_assemble_instruction_2 = $404a
__call_assemble_instruction_3 = $404c
__call_assemble_string_0 = $404e
__call_assemble_string_1 = $4050
__call_open_include_0 = $4052
__call_open_include_1 = $4054
__call_same_text_0 = $4056
__call_same_text_1 = $4058
__call_same_text_2 = $405a
__call_same_text_3 = $405c
assemble_data_list = $405e
assemble_instruction = $4060
assemble_string = $4062
open_include = $4064
origin_allowed = $4066
same_text = $4068
process_instruction_like:
__F_process_instruction_like_entry:
    lda __L_process_instruction_like_name
    sta __T_process_instruction_like___v0
    lda __L_process_instruction_like_name+1
    sta __T_process_instruction_like___v0+1
    lda __L_process_instruction_like_name_length
    sta __T_process_instruction_like___v1
    lda __T_process_instruction_like___v0
    sta __call_same_text_0
    lda __T_process_instruction_like___v0+1
    sta __call_same_text_0+1
    lda __T_process_instruction_like___v1
    sta __call_same_text_1
    lda #<__S_process_instruction_like___text_0
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_0
    sta __call_same_text_2+1
    lda #$07
    sta __call_same_text_3
    lda #$00
    sta __call_same_text_3+1
    jsr same_text
    sta __T_process_instruction_like___v4
    cmp #$00
    bne __F_process_instruction_like_yes_1
    jmp __F_process_instruction_like_join_3
__F_process_instruction_like_yes_1:
    lda __L_process_instruction_like_argument
    sta __T_process_instruction_like___v7
    lda __L_process_instruction_like_argument+1
    sta __T_process_instruction_like___v7+1
    lda __L_process_instruction_like_argument_length
    sta __T_process_instruction_like___v8
    lda __T_process_instruction_like___v7
    sta __call_open_include_0
    lda __T_process_instruction_like___v7+1
    sta __call_open_include_0+1
    lda __T_process_instruction_like___v8
    sta __call_open_include_1
    jsr open_include
    ldx #$00
    rts
__F_process_instruction_like_join_3:
    lda #$00
    sta origin_allowed
    lda __L_process_instruction_like_name
    sta __T_process_instruction_like___v11
    lda __L_process_instruction_like_name+1
    sta __T_process_instruction_like___v11+1
    lda __L_process_instruction_like_name_length
    sta __T_process_instruction_like___v12
    lda __T_process_instruction_like___v11
    sta __call_same_text_0
    lda __T_process_instruction_like___v11+1
    sta __call_same_text_0+1
    lda __T_process_instruction_like___v12
    sta __call_same_text_1
    lda #<__S_process_instruction_like___text_1
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_1
    sta __call_same_text_2+1
    lda #$04
    sta __call_same_text_3
    lda #$00
    sta __call_same_text_3+1
    jsr same_text
    sta __T_process_instruction_like___v15
    cmp #$00
    bne __F_process_instruction_like_yes_4
    jmp __F_process_instruction_like_join_6
__F_process_instruction_like_yes_4:
    lda __L_process_instruction_like_argument
    sta __T_process_instruction_like___v18
    lda __L_process_instruction_like_argument+1
    sta __T_process_instruction_like___v18+1
    lda __L_process_instruction_like_argument_length
    sta __T_process_instruction_like___v19
    lda __T_process_instruction_like___v18
    sta __call_assemble_data_list_0
    lda __T_process_instruction_like___v18+1
    sta __call_assemble_data_list_0+1
    lda __T_process_instruction_like___v19
    sta __call_assemble_data_list_1
    lda #$01
    sta __call_assemble_data_list_2
    lda #$00
    sta __call_assemble_data_list_2+1
    jsr assemble_data_list
    ldx #$00
    rts
__F_process_instruction_like_join_6:
    lda __L_process_instruction_like_name
    sta __T_process_instruction_like___v22
    lda __L_process_instruction_like_name+1
    sta __T_process_instruction_like___v22+1
    lda __L_process_instruction_like_name_length
    sta __T_process_instruction_like___v23
    lda __T_process_instruction_like___v22
    sta __call_same_text_0
    lda __T_process_instruction_like___v22+1
    sta __call_same_text_0+1
    lda __T_process_instruction_like___v23
    sta __call_same_text_1
    lda #<__S_process_instruction_like___text_2
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_2
    sta __call_same_text_2+1
    lda #$04
    sta __call_same_text_3
    lda #$00
    sta __call_same_text_3+1
    jsr same_text
    sta __T_process_instruction_like___v26
    cmp #$00
    bne __F_process_instruction_like_yes_7
    jmp __F_process_instruction_like_join_9
__F_process_instruction_like_yes_7:
    lda __L_process_instruction_like_argument
    sta __T_process_instruction_like___v29
    lda __L_process_instruction_like_argument+1
    sta __T_process_instruction_like___v29+1
    lda __L_process_instruction_like_argument_length
    sta __T_process_instruction_like___v30
    lda __T_process_instruction_like___v29
    sta __call_assemble_data_list_0
    lda __T_process_instruction_like___v29+1
    sta __call_assemble_data_list_0+1
    lda __T_process_instruction_like___v30
    sta __call_assemble_data_list_1
    lda #$02
    sta __call_assemble_data_list_2
    lda #$00
    sta __call_assemble_data_list_2+1
    jsr assemble_data_list
    ldx #$00
    rts
__F_process_instruction_like_join_9:
    lda __L_process_instruction_like_name
    sta __T_process_instruction_like___v33
    lda __L_process_instruction_like_name+1
    sta __T_process_instruction_like___v33+1
    lda __L_process_instruction_like_name_length
    sta __T_process_instruction_like___v34
    lda __T_process_instruction_like___v33
    sta __call_same_text_0
    lda __T_process_instruction_like___v33+1
    sta __call_same_text_0+1
    lda __T_process_instruction_like___v34
    sta __call_same_text_1
    lda #<__S_process_instruction_like___text_3
    sta __call_same_text_2
    lda #>__S_process_instruction_like___text_3
    sta __call_same_text_2+1
    lda #$06
    sta __call_same_text_3
    lda #$00
    sta __call_same_text_3+1
    jsr same_text
    sta __T_process_instruction_like___v37
    cmp #$00
    bne __F_process_instruction_like_yes_10
    jmp __F_process_instruction_like_join_12
__F_process_instruction_like_yes_10:
    lda __L_process_instruction_like_argument
    sta __T_process_instruction_like___v40
    lda __L_process_instruction_like_argument+1
    sta __T_process_instruction_like___v40+1
    lda __L_process_instruction_like_argument_length
    sta __T_process_instruction_like___v41
    lda __T_process_instruction_like___v40
    sta __call_assemble_string_0
    lda __T_process_instruction_like___v40+1
    sta __call_assemble_string_0+1
    lda __T_process_instruction_like___v41
    sta __call_assemble_string_1
    jsr assemble_string
    ldx #$00
    rts
__F_process_instruction_like_join_12:
    lda __L_process_instruction_like_name
    sta __T_process_instruction_like___v43
    lda __L_process_instruction_like_name+1
    sta __T_process_instruction_like___v43+1
    lda __L_process_instruction_like_name_length
    sta __T_process_instruction_like___v44
    lda __L_process_instruction_like_argument
    sta __T_process_instruction_like___v45
    lda __L_process_instruction_like_argument+1
    sta __T_process_instruction_like___v45+1
    lda __L_process_instruction_like_argument_length
    sta __T_process_instruction_like___v46
    lda __T_process_instruction_like___v43
    sta __call_assemble_instruction_0
    lda __T_process_instruction_like___v43+1
    sta __call_assemble_instruction_0+1
    lda __T_process_instruction_like___v44
    sta __call_assemble_instruction_1
    lda __T_process_instruction_like___v45
    sta __call_assemble_instruction_2
    lda __T_process_instruction_like___v45+1
    sta __call_assemble_instruction_2+1
    lda __T_process_instruction_like___v46
    sta __call_assemble_instruction_3
    jsr assemble_instruction
    ldx #$00
    rts
