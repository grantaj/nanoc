* = $0800
__L_upper_char_c = $4000
__T_upper_char___v8 = $4002
upper_char:
__F_upper_char_entry:
    lda __L_upper_char_c
    cmp #$61
    bcs __F_upper_char_yes_1
    jmp __F_upper_char_join_3
__F_upper_char_yes_1:
    lda __L_upper_char_c
    cmp #$7a
    bcc __F_upper_char_yes_4
    beq __F_upper_char_yes_4
    jmp __F_upper_char_join_3
__F_upper_char_yes_4:
    lda __L_upper_char_c
    sec
    sbc #$20
    sta __T_upper_char___v8
    lda #$00
    sbc #$00
    sta __T_upper_char___v8+1
    lda __T_upper_char___v8
    ldx #$00
    rts
__F_upper_char_join_3:
    lda __L_upper_char_c
    ldx #$00
    rts
