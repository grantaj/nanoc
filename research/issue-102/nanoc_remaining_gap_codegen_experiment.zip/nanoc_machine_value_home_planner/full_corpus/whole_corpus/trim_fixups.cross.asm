entry:
while_1:
    lda #$00
    eor #$80
    sta __rh
    lda fixup_count+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda fixup_count
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp after_3
__sel2:
    jmp body_2
__sel3:
    jmp after_3
body_2:
    lda fixup_count
    sec
    sbc #$01
    sta __v6
    lda fixup_count+1
    sbc #$00
    sta __v6+1
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda __v6
    sta __ix
    lda __v6+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v7
    cmp FIXUP_NONE
    bne yes_4
    jmp join_6
yes_4:
    lda ASSEMBLE_OK
    rts
join_6:
    lda fixup_count
    sec
    sbc #$01
    sta __v13
    lda fixup_count+1
    sbc #$00
    sta __v13+1
    lda __v13
    sta fixup_count
    lda __v13+1
    sta fixup_count+1
    jmp while_1
after_3:
    lda ASSEMBLE_OK
    rts
