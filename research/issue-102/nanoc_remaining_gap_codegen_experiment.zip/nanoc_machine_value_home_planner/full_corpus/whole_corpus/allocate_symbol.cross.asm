entry:
    lda name
    sta __call_scope_for_name_0
    lda name+1
    sta __call_scope_for_name_0+1
    lda length
    sta __call_scope_for_name_1
    jsr scope_for_name
    sta scope
    stx scope+1
    lda #$00
    eor #$80
    sta __rh
    lda scope+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda scope
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp yes_1
__sel2:
    jmp join_3
__sel3:
    jmp join_3
yes_1:
    sec
    lda #$00
    sbc #$02
    sta __v7
    lda #$00
    sbc #$00
    sta __v7+1
    lda __v7
    ldx __v7+1
    rts
join_3:
    lda #$03
    eor #$80
    sta __rh
    lda symbol_count+1
    eor #$80
    cmp __rh
    bcc __sel4
    bne __sel5
    lda symbol_count
    cmp #$80
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp join_6
__sel5:
    jmp yes_4
__sel6:
    jmp yes_4
yes_4:
    sec
    lda #$00
    sbc #$03
    sta __v12
    lda #$00
    sbc #$00
    sta __v12+1
    lda __v12
    ldx __v12+1
    rts
join_6:
    lda symbol_name_used
    clc
    adc length
    sta __v15
    lda symbol_name_used+1
    adc #$00
    sta __v15+1
    lda #$24
    eor #$80
    sta __rh
    lda __v15+1
    eor #$80
    cmp __rh
    bcc __sel7
    bne __sel8
    lda __v15
    cmp #$80
    bcc __sel7
    bne __sel8
    jmp __sel9
__sel7:
    jmp join_9
__sel8:
    jmp yes_7
__sel9:
    jmp join_9
yes_7:
    sec
    lda #$00
    sbc #$03
    sta __v19
    lda #$00
    sbc #$00
    sta __v19+1
    lda __v19
    ldx __v19+1
    rts
join_9:
    lda symbol_count
    sta n
    lda symbol_count+1
    sta n+1
    lda #<symbol_name_offset
    sta __ap
    lda #>symbol_name_offset
    sta __ap+1
    lda n
    asl
    sta __ix
    lda n+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda symbol_name_used
    sta (__ap),y
    iny
    lda symbol_name_used+1
    sta (__ap),y
    lda #<symbol_name_length
    sta __ap
    lda #>symbol_name_length
    sta __ap+1
    lda n
    sta __ix
    lda n+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda length
    sta (__ap),y
    lda payload
    sta __v31
    lda payload+1
    sta __v31+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda n
    asl
    sta __ix
    lda n+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __v31
    sta (__ap),y
    iny
    lda __v31+1
    sta (__ap),y
    lda #<symbol_scope
    sta __ap
    lda #>symbol_scope
    sta __ap+1
    lda n
    sta __ix
    lda n+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda scope
    sta (__ap),y
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda n
    sta __ix
    lda n+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda kind
    sta (__ap),y
    lda #$00
    sta i
while_10:
    lda i
    cmp length
    bcc body_11
    jmp after_12
body_11:
    lda symbol_name_used
    clc
    adc i
    sta __v45
    lda symbol_name_used+1
    adc #$00
    sta __v45+1
    ldy i
    lda name
    sta __ap
    lda name+1
    sta __ap+1
    lda (__ap),y
    sta __v48
    lda #<symbol_name_bytes
    sta __ap
    lda #>symbol_name_bytes
    sta __ap+1
    lda __v45
    sta __ix
    lda __v45+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __v48
    sta (__ap),y
    inc i
    jmp while_10
after_12:
    lda symbol_name_used
    clc
    adc length
    sta __v54
    lda symbol_name_used+1
    adc #$00
    sta __v54+1
    lda __v54
    sta symbol_name_used
    lda __v54+1
    sta symbol_name_used+1
    lda n
    clc
    adc #$01
    sta symbol_count
    lda n+1
    adc #$00
    sta symbol_count+1
    lda n
    ldx n+1
    rts
