* = $0800
__ap = $0010
__rh = $0014
VALUE_BAD = $4000
VALUE_OK = $4002
VALUE_PREFIX_HIGH = $4004
VALUE_PREFIX_LOW = $4006
VALUE_PREFIX_NONE = $4008
VALUE_UNRESOLVED = $400a
__L_parse_value_first_kind = $400c
__L_parse_value_first_symbol = $400e
__L_parse_value_first_value = $4010
__L_parse_value_length = $4012
__L_parse_value_operation = $4014
__L_parse_value_position = $4016
__L_parse_value_second_kind = $4018
__L_parse_value_status = $401a
__L_parse_value_text = $401c
__T_parse_value___v101 = $401e
__T_parse_value___v104 = $4020
__T_parse_value___v106 = $4022
__T_parse_value___v11 = $4024
__T_parse_value___v124 = $4026
__T_parse_value___v125 = $4028
__T_parse_value___v126 = $402a
__T_parse_value___v99 = $402c
__call_apply_byte_prefix_0 = $402e
__call_apply_byte_prefix_1 = $4030
__call_parse_atom_0 = $4032
__call_parse_atom_1 = $4034
apply_byte_prefix = $4036
atom_kind = $4038
atom_symbol = $403a
atom_used = $403c
atom_value = $403e
captured_addend = $4040
captured_prefix = $4042
captured_symbol = $4044
parse_atom = $4046
value_result = $4048
parse_value:
__F_parse_value_entry:
    sec
    lda #$00
    sbc #$01
    sta captured_symbol
    lda #$00
    sbc #$00
    sta captured_symbol+1
    lda #$00
    sta captured_addend
    lda #$00
    sta captured_addend+1
    lda VALUE_PREFIX_NONE
    sta captured_prefix
    lda __L_parse_value_length
    cmp #$00
    beq __F_parse_value_yes_1
    jmp __F_parse_value_join_3
__F_parse_value_yes_1:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_value_join_3:
    lda #$00
    sta __L_parse_value_position
    ldy __L_parse_value_position
    lda __L_parse_value_text
    sta __ap
    lda __L_parse_value_text+1
    sta __ap+1
    lda (__ap),y
    sta __T_parse_value___v11
    cmp #$3c
    beq __F_parse_value_yes_4
    jmp __F_parse_value_no_5
__F_parse_value_yes_4:
    lda VALUE_PREFIX_LOW
    sta captured_prefix
    inc __L_parse_value_position
    jmp __F_parse_value_join_6
__F_parse_value_no_5:
    cmp #$3e
    beq __F_parse_value_yes_7
    jmp __F_parse_value_join_6
__F_parse_value_yes_7:
    lda VALUE_PREFIX_HIGH
    sta captured_prefix
    inc __L_parse_value_position
__F_parse_value_join_6:
    lda __L_parse_value_text
    clc
    adc __L_parse_value_position
    sta __call_parse_atom_0
    lda __L_parse_value_text+1
    adc #$00
    sta __call_parse_atom_0+1
    lda __L_parse_value_length
    sec
    sbc __L_parse_value_position
    sta __call_parse_atom_1
    lda #$00
    sbc #$00
    sta __call_parse_atom_1+1
    jsr parse_atom
    sta __L_parse_value_status
    lda __L_parse_value_status
    cmp VALUE_OK
    bne __F_parse_value_yes_10
    jmp __F_parse_value_join_12
__F_parse_value_yes_10:
    lda __L_parse_value_status
    cmp VALUE_UNRESOLVED
    bne __F_parse_value_yes_13
    jmp __F_parse_value_join_12
__F_parse_value_yes_13:
    lda __L_parse_value_status
    ldx #$00
    rts
__F_parse_value_join_12:
    lda atom_kind
    sta __L_parse_value_first_kind
    lda atom_value
    sta __L_parse_value_first_value
    lda atom_value+1
    sta __L_parse_value_first_value+1
    lda atom_symbol
    sta __L_parse_value_first_symbol
    lda atom_symbol+1
    sta __L_parse_value_first_symbol+1
    lda __L_parse_value_position
    clc
    adc atom_used
    sta __L_parse_value_position
    lda __L_parse_value_first_kind
    cmp #$00
    beq __F_parse_value_yes_16
    jmp __F_parse_value_no_17
__F_parse_value_yes_16:
    lda __L_parse_value_first_value
    sta captured_addend
    lda __L_parse_value_first_value+1
    sta captured_addend+1
    jmp __F_parse_value_join_18
__F_parse_value_no_17:
    lda __L_parse_value_first_symbol
    sta captured_symbol
    lda __L_parse_value_first_symbol+1
    sta captured_symbol+1
    lda #$00
    sta captured_addend
    lda #$00
    sta captured_addend+1
__F_parse_value_join_18:
    lda __L_parse_value_position
    cmp __L_parse_value_length
    bcc __F_parse_value_yes_19
    jmp __F_parse_value_join_21
__F_parse_value_yes_19:
    ldy __L_parse_value_position
    lda __L_parse_value_text
    sta __ap
    lda __L_parse_value_text+1
    sta __ap+1
    lda (__ap),y
    sta __L_parse_value_operation
    lda __L_parse_value_operation
    cmp #$2b
    bne __F_parse_value_yes_22
    jmp __F_parse_value_join_24
__F_parse_value_yes_22:
    lda __L_parse_value_operation
    cmp #$2d
    bne __F_parse_value_yes_25
    jmp __F_parse_value_join_24
__F_parse_value_yes_25:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_value_join_24:
    inc __L_parse_value_position
    lda __L_parse_value_text
    clc
    adc __L_parse_value_position
    sta __call_parse_atom_0
    lda __L_parse_value_text+1
    adc #$00
    sta __call_parse_atom_0+1
    lda __L_parse_value_length
    sec
    sbc __L_parse_value_position
    sta __call_parse_atom_1
    lda #$00
    sbc #$00
    sta __call_parse_atom_1+1
    jsr parse_atom
    sta __L_parse_value_status
    lda __L_parse_value_status
    cmp VALUE_OK
    bne __F_parse_value_yes_28
    jmp __F_parse_value_join_30
__F_parse_value_yes_28:
    lda __L_parse_value_status
    cmp VALUE_UNRESOLVED
    bne __F_parse_value_yes_31
    jmp __F_parse_value_join_30
__F_parse_value_yes_31:
    lda __L_parse_value_status
    ldx #$00
    rts
__F_parse_value_join_30:
    lda atom_kind
    sta __L_parse_value_second_kind
    lda __L_parse_value_position
    clc
    adc atom_used
    sta __L_parse_value_position
    lda __L_parse_value_position
    cmp __L_parse_value_length
    bne __F_parse_value_yes_34
    jmp __F_parse_value_join_36
__F_parse_value_yes_34:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_value_join_36:
    lda __L_parse_value_second_kind
    cmp #$00
    beq __F_parse_value_yes_37
    jmp __F_parse_value_no_38
__F_parse_value_yes_37:
    lda __L_parse_value_operation
    cmp #$2b
    beq __F_parse_value_yes_40
    jmp __F_parse_value_no_41
__F_parse_value_yes_40:
    lda captured_addend
    clc
    adc atom_value
    sta __T_parse_value___v99
    lda captured_addend+1
    adc atom_value+1
    sta __T_parse_value___v99+1
    lda __T_parse_value___v99
    sta __T_parse_value___v101
    lda __T_parse_value___v99+1
    sta __T_parse_value___v101+1
    lda __T_parse_value___v101
    sta captured_addend
    lda __T_parse_value___v101+1
    sta captured_addend+1
    jmp __F_parse_value_join_21
__F_parse_value_no_41:
    lda captured_addend
    sec
    sbc atom_value
    sta __T_parse_value___v104
    lda captured_addend+1
    sbc atom_value+1
    sta __T_parse_value___v104+1
    lda __T_parse_value___v104
    sta __T_parse_value___v106
    lda __T_parse_value___v104+1
    sta __T_parse_value___v106+1
    lda __T_parse_value___v106
    sta captured_addend
    lda __T_parse_value___v106+1
    sta captured_addend+1
    jmp __F_parse_value_join_21
__F_parse_value_no_38:
    lda #$00
    eor #$80
    sta __rh
    lda captured_symbol+1
    eor #$80
    cmp __rh
    bcc __F_parse_value___sel1
    bne __F_parse_value___sel2
    lda captured_symbol
    cmp #$00
    bcc __F_parse_value___sel1
    bne __F_parse_value___sel2
    jmp __F_parse_value___sel3
__F_parse_value___sel1:
    jmp __F_parse_value_join_45
__F_parse_value___sel2:
    jmp __F_parse_value_yes_43
__F_parse_value___sel3:
    jmp __F_parse_value_yes_43
__F_parse_value_yes_43:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_value_join_45:
    lda __L_parse_value_operation
    cmp #$2b
    bne __F_parse_value_yes_46
    jmp __F_parse_value_join_48
__F_parse_value_yes_46:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_value_join_48:
    lda atom_symbol
    sta captured_symbol
    lda atom_symbol+1
    sta captured_symbol+1
__F_parse_value_join_21:
    lda #$00
    eor #$80
    sta __rh
    lda captured_symbol+1
    eor #$80
    cmp __rh
    bcc __F_parse_value___sel4
    bne __F_parse_value___sel5
    lda captured_symbol
    cmp #$00
    bcc __F_parse_value___sel4
    bne __F_parse_value___sel5
    jmp __F_parse_value___sel6
__F_parse_value___sel4:
    jmp __F_parse_value_join_51
__F_parse_value___sel5:
    jmp __F_parse_value_yes_49
__F_parse_value___sel6:
    jmp __F_parse_value_yes_49
__F_parse_value_yes_49:
    lda VALUE_UNRESOLVED
    ldx #$00
    rts
__F_parse_value_join_51:
    lda captured_addend
    sta value_result
    lda captured_addend+1
    sta value_result+1
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    bne __F_parse_value_yes_52
    jmp __F_parse_value_join_54
__F_parse_value_yes_52:
    lda captured_addend
    sta __T_parse_value___v124
    lda captured_addend+1
    sta __T_parse_value___v124+1
    lda captured_prefix
    sta __T_parse_value___v125
    lda __T_parse_value___v124
    sta __call_apply_byte_prefix_0
    lda __T_parse_value___v124+1
    sta __call_apply_byte_prefix_0+1
    lda __T_parse_value___v125
    sta __call_apply_byte_prefix_1
    jsr apply_byte_prefix
    sta __T_parse_value___v126
    lda __T_parse_value___v126
    sta value_result
    lda #$00
    sta value_result+1
__F_parse_value_join_54:
    lda VALUE_OK
    ldx #$00
    rts
