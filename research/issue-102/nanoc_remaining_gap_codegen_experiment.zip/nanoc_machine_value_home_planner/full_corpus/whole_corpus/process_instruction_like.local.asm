entry:
    lda name
    sta __call_same_text_0
    lda name+1
    sta __call_same_text_0+1
    lda name_length
    sta __call_same_text_1
    lda #<__text_0
    sta __call_same_text_2
    lda #>__text_0
    sta __call_same_text_2+1
    lda #$07
    sta __call_same_text_3
    jsr same_text
    sta __v4
    lda __v4
    cmp #$00
    bne yes_1
    jmp join_3
yes_1:
    lda argument
    sta __call_open_include_0
    lda argument+1
    sta __call_open_include_0+1
    lda argument_length
    sta __call_open_include_1
    jsr open_include
    rts
join_3:
    lda #$00
    sta origin_allowed
    lda name
    sta __call_same_text_0
    lda name+1
    sta __call_same_text_0+1
    lda name_length
    sta __call_same_text_1
    lda #<__text_1
    sta __call_same_text_2
    lda #>__text_1
    sta __call_same_text_2+1
    lda #$04
    sta __call_same_text_3
    jsr same_text
    sta __v15
    lda __v15
    cmp #$00
    bne yes_4
    jmp join_6
yes_4:
    lda argument
    sta __call_assemble_data_list_0
    lda argument+1
    sta __call_assemble_data_list_0+1
    lda argument_length
    sta __call_assemble_data_list_1
    lda #$01
    sta __call_assemble_data_list_2
    jsr assemble_data_list
    rts
join_6:
    lda name
    sta __call_same_text_0
    lda name+1
    sta __call_same_text_0+1
    lda name_length
    sta __call_same_text_1
    lda #<__text_2
    sta __call_same_text_2
    lda #>__text_2
    sta __call_same_text_2+1
    lda #$04
    sta __call_same_text_3
    jsr same_text
    sta __v26
    lda __v26
    cmp #$00
    bne yes_7
    jmp join_9
yes_7:
    lda argument
    sta __call_assemble_data_list_0
    lda argument+1
    sta __call_assemble_data_list_0+1
    lda argument_length
    sta __call_assemble_data_list_1
    lda #$02
    sta __call_assemble_data_list_2
    jsr assemble_data_list
    rts
join_9:
    lda name
    sta __call_same_text_0
    lda name+1
    sta __call_same_text_0+1
    lda name_length
    sta __call_same_text_1
    lda #<__text_3
    sta __call_same_text_2
    lda #>__text_3
    sta __call_same_text_2+1
    lda #$06
    sta __call_same_text_3
    jsr same_text
    sta __v37
    lda __v37
    cmp #$00
    bne yes_10
    jmp join_12
yes_10:
    lda argument
    sta __call_assemble_string_0
    lda argument+1
    sta __call_assemble_string_0+1
    lda argument_length
    sta __call_assemble_string_1
    jsr assemble_string
    rts
join_12:
    lda name
    sta __call_assemble_instruction_0
    lda name+1
    sta __call_assemble_instruction_0+1
    lda name_length
    sta __call_assemble_instruction_1
    lda argument
    sta __call_assemble_instruction_2
    lda argument+1
    sta __call_assemble_instruction_2+1
    lda argument_length
    sta __call_assemble_instruction_3
    jsr assemble_instruction
    rts
