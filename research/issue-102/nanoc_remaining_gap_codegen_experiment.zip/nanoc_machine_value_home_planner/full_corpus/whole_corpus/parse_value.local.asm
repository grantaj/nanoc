entry:
    sec
    lda #$00
    sbc #$01
    sta captured_symbol
    lda #$00
    sbc #$00
    sta captured_symbol+1
    lda #$00
    sta captured_addend
    lda #$00
    sta captured_addend+1
    lda VALUE_PREFIX_NONE
    sta captured_prefix
    lda length
    cmp #$00
    beq yes_1
    jmp join_3
yes_1:
    lda VALUE_BAD
    rts
join_3:
    lda #$00
    sta position
    ldy position
    lda text
    sta __ap
    lda text+1
    sta __ap+1
    lda (__ap),y
    sta __v11
    lda __v11
    cmp #$3c
    beq yes_4
    jmp no_5
yes_4:
    lda VALUE_PREFIX_LOW
    sta captured_prefix
    inc position
    jmp join_6
no_5:
    ldy position
    lda text
    sta __ap
    lda text+1
    sta __ap+1
    lda (__ap),y
    sta __v20
    lda __v20
    cmp #$3e
    beq yes_7
    jmp join_6
yes_7:
    lda VALUE_PREFIX_HIGH
    sta captured_prefix
    inc position
join_6:
    lda text
    clc
    adc position
    sta __call_parse_atom_0
    lda text+1
    adc #$00
    sta __call_parse_atom_0+1
    lda length
    sec
    sbc position
    sta __v32
    lda #$00
    sbc #$00
    sta __v32+1
    lda __v32
    sta __call_parse_atom_1
    jsr parse_atom
    sta status
    lda status
    cmp VALUE_OK
    bne yes_10
    jmp join_12
yes_10:
    lda status
    cmp VALUE_UNRESOLVED
    bne yes_13
    jmp join_12
yes_13:
    lda status
    rts
join_12:
    lda atom_kind
    sta first_kind
    lda atom_value
    sta first_value
    lda atom_value+1
    sta first_value+1
    lda atom_symbol
    sta first_symbol
    lda atom_symbol+1
    sta first_symbol+1
    lda position
    clc
    adc atom_used
    sta position
    lda first_kind
    cmp #$00
    beq yes_16
    jmp no_17
yes_16:
    lda first_value
    sta captured_addend
    lda first_value+1
    sta captured_addend+1
    jmp join_18
no_17:
    lda first_symbol
    sta captured_symbol
    lda first_symbol+1
    sta captured_symbol+1
    lda #$00
    sta captured_addend
    lda #$00
    sta captured_addend+1
join_18:
    lda position
    cmp length
    bcc yes_19
    jmp join_21
yes_19:
    ldy position
    lda text
    sta __ap
    lda text+1
    sta __ap+1
    lda (__ap),y
    sta operation
    lda operation
    cmp #$2b
    bne yes_22
    jmp join_24
yes_22:
    lda operation
    cmp #$2d
    bne yes_25
    jmp join_24
yes_25:
    lda VALUE_BAD
    rts
join_24:
    inc position
    lda text
    clc
    adc position
    sta __call_parse_atom_0
    lda text+1
    adc #$00
    sta __call_parse_atom_0+1
    lda length
    sec
    sbc position
    sta __v74
    lda #$00
    sbc #$00
    sta __v74+1
    lda __v74
    sta __call_parse_atom_1
    jsr parse_atom
    sta status
    lda status
    cmp VALUE_OK
    bne yes_28
    jmp join_30
yes_28:
    lda status
    cmp VALUE_UNRESOLVED
    bne yes_31
    jmp join_30
yes_31:
    lda status
    rts
join_30:
    lda atom_kind
    sta second_kind
    lda position
    clc
    adc atom_used
    sta position
    lda position
    cmp length
    bne yes_34
    jmp join_36
yes_34:
    lda VALUE_BAD
    rts
join_36:
    lda second_kind
    cmp #$00
    beq yes_37
    jmp no_38
yes_37:
    lda operation
    cmp #$2b
    beq yes_40
    jmp no_41
yes_40:
    lda captured_addend
    clc
    adc atom_value
    sta __v99
    lda captured_addend+1
    adc atom_value+1
    sta __v99+1
    lda __v99
    sta __v101
    lda __v99+1
    sta __v101+1
    lda __v101
    sta captured_addend
    lda __v101+1
    sta captured_addend+1
    jmp join_21
no_41:
    lda captured_addend
    sec
    sbc atom_value
    sta __v104
    lda captured_addend+1
    sbc atom_value+1
    sta __v104+1
    lda __v104
    sta __v106
    lda __v104+1
    sta __v106+1
    lda __v106
    sta captured_addend
    lda __v106+1
    sta captured_addend+1
    jmp join_21
no_38:
    lda #$00
    eor #$80
    sta __rh
    lda captured_symbol+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda captured_symbol
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp join_45
__sel2:
    jmp yes_43
__sel3:
    jmp yes_43
yes_43:
    lda VALUE_BAD
    rts
join_45:
    lda operation
    cmp #$2b
    bne yes_46
    jmp join_48
yes_46:
    lda VALUE_BAD
    rts
join_48:
    lda atom_symbol
    sta captured_symbol
    lda atom_symbol+1
    sta captured_symbol+1
join_21:
    lda #$00
    eor #$80
    sta __rh
    lda captured_symbol+1
    eor #$80
    cmp __rh
    bcc __sel4
    bne __sel5
    lda captured_symbol
    cmp #$00
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp join_51
__sel5:
    jmp yes_49
__sel6:
    jmp yes_49
yes_49:
    lda VALUE_UNRESOLVED
    rts
join_51:
    lda captured_addend
    sta value_result
    lda captured_addend+1
    sta value_result+1
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    bne yes_52
    jmp join_54
yes_52:
    lda captured_addend
    sta __call_apply_byte_prefix_0
    lda captured_addend+1
    sta __call_apply_byte_prefix_0+1
    lda captured_prefix
    sta __call_apply_byte_prefix_1
    jsr apply_byte_prefix
    sta __v126
    lda __v126
    sta value_result
    lda #$00
    sta value_result+1
join_54:
    lda VALUE_OK
    rts
