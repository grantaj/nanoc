entry:
    lda #$00
    sta i
    lda #$00
    sta i+1
while_1:
    lda fixup_count+1
    eor #$80
    sta __rh
    lda i+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda i
    cmp fixup_count
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp body_2
__sel2:
    jmp after_3
__sel3:
    jmp after_3
body_2:
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda i
    sta __ix
    lda i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta kind
    lda kind
    cmp FIXUP_NONE
    bne yes_4
    jmp join_6
yes_4:
    lda #<fixup_symbol
    sta __ap
    lda #>fixup_symbol
    sta __ap+1
    lda i
    asl
    sta __ix
    lda i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v12
    iny
    lda (__ap),y
    sta __v12+1
    lda __v12+1
    cmp symbol+1
    beq __far_skip_0
    jmp join_6
__far_skip_0:
    lda __v12
    cmp symbol
    beq yes_7
    jmp join_6
yes_7:
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda symbol
    asl
    sta __ix
    lda symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v17
    iny
    lda (__ap),y
    sta __v17+1
    lda #<fixup_addend
    sta __ap
    lda #>fixup_addend
    sta __ap+1
    lda i
    asl
    sta __ix
    lda i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v20
    iny
    lda (__ap),y
    sta __v20+1
    lda __v17
    clc
    adc __v20
    sta __v21
    lda __v17+1
    adc __v20+1
    sta __v21+1
    lda __v21
    sta __v23
    lda __v21+1
    sta __v23+1
    lda __v23
    sta value
    lda __v23+1
    sta value+1
    lda #<fixup_prefix
    sta __ap
    lda #>fixup_prefix
    sta __ap+1
    lda i
    sta __ix
    lda i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v26
    lda __v26
    cmp VALUE_PREFIX_NONE
    bne yes_10
    jmp join_12
yes_10:
    lda #<fixup_prefix
    sta __ap
    lda #>fixup_prefix
    sta __ap+1
    lda i
    sta __ix
    lda i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_apply_byte_prefix_1
    lda value
    sta __call_apply_byte_prefix_0
    lda value+1
    sta __call_apply_byte_prefix_0+1
    jsr apply_byte_prefix
    sta __v33
    lda __v33
    sta value
    lda #$00
    sta value+1
join_12:
    lda #<fixup_stage
    sta __ap
    lda #>fixup_stage
    sta __ap+1
    lda i
    asl
    sta __ix
    lda i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta stage
    iny
    lda (__ap),y
    sta stage+1
    lda kind
    cmp FIXUP_WORD
    beq yes_13
    jmp no_14
yes_13:
    lda value
    and #$ff
    sta __v44
    lda value+1
    and #$00
    sta __v44+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda stage
    sta __ix
    lda stage+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __v44
    sta (__ap),y
    lda stage
    clc
    adc #$01
    sta __v48
    lda stage+1
    adc #$00
    sta __v48+1
    lda value
    sta __v51
    lda value+1
    sta __v51+1
    lsr __v51+1
    ror __v51
    lsr __v51+1
    ror __v51
    lsr __v51+1
    ror __v51
    lsr __v51+1
    ror __v51
    lsr __v51+1
    ror __v51
    lsr __v51+1
    ror __v51
    lsr __v51+1
    ror __v51
    lsr __v51+1
    ror __v51
    lda __v51
    and #$ff
    sta __v53
    lda __v51+1
    and #$00
    sta __v53+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __v48
    sta __ix
    lda __v48+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __v53
    sta (__ap),y
    jmp join_15
no_14:
    lda kind
    cmp FIXUP_RELATIVE
    beq yes_16
    jmp no_17
yes_16:
    lda ass_origin
    clc
    adc stage
    sta __v60
    lda ass_origin+1
    adc stage+1
    sta __v60+1
    lda __v60
    clc
    adc #$01
    sta __v62
    lda __v60+1
    adc #$00
    sta __v62+1
    lda __v62
    sta __v64
    lda __v62+1
    sta __v64+1
    lda value
    sta __call_relative_byte_0
    lda value+1
    sta __call_relative_byte_0+1
    lda __v64
    sta __call_relative_byte_1
    lda __v64+1
    sta __call_relative_byte_1+1
    jsr relative_byte
    sta relative
    stx relative+1
    lda #$00
    eor #$80
    sta __rh
    lda relative+1
    eor #$80
    cmp __rh
    bcc __sel4
    bne __sel5
    lda relative
    cmp #$00
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp yes_19
__sel5:
    jmp join_21
__sel6:
    jmp join_21
yes_19:
    lda ASSEMBLE_EMIT_ERROR
    rts
join_21:
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda stage
    sta __ix
    lda stage+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda relative
    sta (__ap),y
    jmp join_15
no_17:
    lda value+1
    cmp #$00
    bcc __sel7
    bne __sel8
    lda value
    cmp #$ff
    bcc __sel7
    bne __sel8
    jmp __sel9
__sel7:
    jmp join_24
__sel8:
    jmp yes_22
__sel9:
    jmp join_24
yes_22:
    lda kind
    cmp FIXUP_DATA_BYTE
    beq yes_25
    jmp join_27
yes_25:
    lda ASSEMBLE_BAD_DATA
    rts
join_27:
    lda ASSEMBLE_EMIT_ERROR
    rts
join_24:
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda stage
    sta __ix
    lda stage+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda value
    sta (__ap),y
join_15:
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda i
    sta __ix
    lda i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda FIXUP_NONE
    sta (__ap),y
join_6:
    lda i
    clc
    adc #$01
    sta __v89
    lda i+1
    adc #$00
    sta __v89+1
    lda __v89
    sta i
    lda __v89+1
    sta i+1
    jmp while_1
after_3:
    jsr trim_fixups
    rts
