* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
ASSEMBLE_OK = $4000
FIXUP_NONE = $4002
__T_trim_fixups___v13 = $4004
__T_trim_fixups___v6 = $4006
__T_trim_fixups___v7 = $4008
fixup_count = $400a
fixup_kind = $400c
trim_fixups:
__F_trim_fixups_entry:
__F_trim_fixups_while_1:
    lda #$00
    eor #$80
    sta __rh
    lda fixup_count+1
    eor #$80
    cmp __rh
    bcc __F_trim_fixups___sel1
    bne __F_trim_fixups___sel2
    lda fixup_count
    cmp #$00
    bcc __F_trim_fixups___sel1
    bne __F_trim_fixups___sel2
    jmp __F_trim_fixups___sel3
__F_trim_fixups___sel1:
    jmp __F_trim_fixups_after_3
__F_trim_fixups___sel2:
    jmp __F_trim_fixups_body_2
__F_trim_fixups___sel3:
    jmp __F_trim_fixups_after_3
__F_trim_fixups_body_2:
    lda fixup_count
    sec
    sbc #$01
    sta __T_trim_fixups___v6
    lda fixup_count+1
    sbc #$00
    sta __T_trim_fixups___v6+1
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda __T_trim_fixups___v6
    sta __ix
    lda __T_trim_fixups___v6+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_trim_fixups___v7
    cmp FIXUP_NONE
    bne __F_trim_fixups_yes_4
    jmp __F_trim_fixups_join_6
__F_trim_fixups_yes_4:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_trim_fixups_join_6:
    lda fixup_count
    sec
    sbc #$01
    sta __T_trim_fixups___v13
    lda fixup_count+1
    sbc #$00
    sta __T_trim_fixups___v13+1
    lda __T_trim_fixups___v13
    sta fixup_count
    lda __T_trim_fixups___v13+1
    sta fixup_count+1
    jmp __F_trim_fixups_while_1
__F_trim_fixups_after_3:
    lda ASSEMBLE_OK
    ldx #$00
    rts
