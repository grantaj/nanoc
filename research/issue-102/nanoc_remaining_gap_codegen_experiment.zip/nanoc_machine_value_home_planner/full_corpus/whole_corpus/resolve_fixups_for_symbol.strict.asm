* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
ASSEMBLE_BAD_DATA = $4000
ASSEMBLE_EMIT_ERROR = $4002
FIXUP_DATA_BYTE = $4004
FIXUP_NONE = $4006
FIXUP_RELATIVE = $4008
FIXUP_WORD = $400a
VALUE_PREFIX_NONE = $400c
__L_resolve_fixups_for_symbol_i = $400e
__L_resolve_fixups_for_symbol_kind = $4010
__L_resolve_fixups_for_symbol_relative = $4012
__L_resolve_fixups_for_symbol_stage = $4014
__L_resolve_fixups_for_symbol_symbol = $4016
__L_resolve_fixups_for_symbol_value = $4018
__T_resolve_fixups_for_symbol___v12 = $401a
__T_resolve_fixups_for_symbol___v17 = $401c
__T_resolve_fixups_for_symbol___v20 = $401e
__T_resolve_fixups_for_symbol___v21 = $4020
__T_resolve_fixups_for_symbol___v23 = $4022
__T_resolve_fixups_for_symbol___v26 = $4024
__T_resolve_fixups_for_symbol___v29 = $4026
__T_resolve_fixups_for_symbol___v33 = $4028
__T_resolve_fixups_for_symbol___v41 = $402a
__T_resolve_fixups_for_symbol___v44 = $402c
__T_resolve_fixups_for_symbol___v48 = $402e
__T_resolve_fixups_for_symbol___v51 = $4030
__T_resolve_fixups_for_symbol___v53 = $4032
__T_resolve_fixups_for_symbol___v57 = $4034
__T_resolve_fixups_for_symbol___v60 = $4036
__T_resolve_fixups_for_symbol___v62 = $4038
__T_resolve_fixups_for_symbol___v64 = $403a
__T_resolve_fixups_for_symbol___v71 = $403c
__T_resolve_fixups_for_symbol___v72 = $403e
__T_resolve_fixups_for_symbol___v82 = $4040
__T_resolve_fixups_for_symbol___v83 = $4042
__T_resolve_fixups_for_symbol___v85 = $4044
__T_resolve_fixups_for_symbol___v86 = $4046
__T_resolve_fixups_for_symbol___v89 = $4048
__call_apply_byte_prefix_0 = $404a
__call_apply_byte_prefix_1 = $404c
__call_relative_byte_0 = $404e
__call_relative_byte_1 = $4050
apply_byte_prefix = $4052
ass_image = $4054
ass_origin = $4056
fixup_addend = $4058
fixup_count = $405a
fixup_kind = $405c
fixup_prefix = $405e
fixup_stage = $4060
fixup_symbol = $4062
relative_byte = $4064
symbol_payload = $4066
trim_fixups = $4068
resolve_fixups_for_symbol:
__F_resolve_fixups_for_symbol_entry:
    lda #$00
    sta __L_resolve_fixups_for_symbol_i
    lda #$00
    sta __L_resolve_fixups_for_symbol_i+1
__F_resolve_fixups_for_symbol_while_1:
    lda fixup_count+1
    eor #$80
    sta __rh
    lda __L_resolve_fixups_for_symbol_i+1
    eor #$80
    cmp __rh
    bcc __F_resolve_fixups_for_symbol___sel1
    bne __F_resolve_fixups_for_symbol___sel2
    lda __L_resolve_fixups_for_symbol_i
    cmp fixup_count
    bcc __F_resolve_fixups_for_symbol___sel1
    bne __F_resolve_fixups_for_symbol___sel2
    jmp __F_resolve_fixups_for_symbol___sel3
__F_resolve_fixups_for_symbol___sel1:
    jmp __F_resolve_fixups_for_symbol_body_2
__F_resolve_fixups_for_symbol___sel2:
    jmp __F_resolve_fixups_for_symbol_after_3
__F_resolve_fixups_for_symbol___sel3:
    jmp __F_resolve_fixups_for_symbol_after_3
__F_resolve_fixups_for_symbol_body_2:
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_i
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_kind
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_NONE
    bne __F_resolve_fixups_for_symbol_yes_4
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol_yes_4:
    lda #<fixup_symbol
    sta __ap
    lda #>fixup_symbol
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_i
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v12
    iny
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v12+1
    lda __T_resolve_fixups_for_symbol___v12+1
    cmp __L_resolve_fixups_for_symbol_symbol+1
    beq __F_resolve_fixups_for_symbol___far_skip_0
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol___far_skip_0:
    lda __T_resolve_fixups_for_symbol___v12
    cmp __L_resolve_fixups_for_symbol_symbol
    beq __F_resolve_fixups_for_symbol_yes_7
    jmp __F_resolve_fixups_for_symbol_join_6
__F_resolve_fixups_for_symbol_yes_7:
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_symbol
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v17
    iny
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v17+1
    lda #<fixup_addend
    sta __ap
    lda #>fixup_addend
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_i
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v20
    iny
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v20+1
    lda __T_resolve_fixups_for_symbol___v17
    clc
    adc __T_resolve_fixups_for_symbol___v20
    sta __T_resolve_fixups_for_symbol___v21
    lda __T_resolve_fixups_for_symbol___v17+1
    adc __T_resolve_fixups_for_symbol___v20+1
    sta __T_resolve_fixups_for_symbol___v21+1
    lda __T_resolve_fixups_for_symbol___v21
    sta __T_resolve_fixups_for_symbol___v23
    lda __T_resolve_fixups_for_symbol___v21+1
    sta __T_resolve_fixups_for_symbol___v23+1
    lda __T_resolve_fixups_for_symbol___v23
    sta __L_resolve_fixups_for_symbol_value
    lda __T_resolve_fixups_for_symbol___v23+1
    sta __L_resolve_fixups_for_symbol_value+1
    lda #<fixup_prefix
    sta __ap
    lda #>fixup_prefix
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_i
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_resolve_fixups_for_symbol___v26
    cmp VALUE_PREFIX_NONE
    bne __F_resolve_fixups_for_symbol_yes_10
    jmp __F_resolve_fixups_for_symbol_join_12
__F_resolve_fixups_for_symbol_yes_10:
    lda __L_resolve_fixups_for_symbol_value
    sta __T_resolve_fixups_for_symbol___v29
    lda __L_resolve_fixups_for_symbol_value+1
    sta __T_resolve_fixups_for_symbol___v29+1
    lda __T_resolve_fixups_for_symbol___v29
    sta __call_apply_byte_prefix_0
    lda __T_resolve_fixups_for_symbol___v29+1
    sta __call_apply_byte_prefix_0+1
    lda __T_resolve_fixups_for_symbol___v26
    sta __call_apply_byte_prefix_1
    jsr apply_byte_prefix
    sta __T_resolve_fixups_for_symbol___v33
    lda __T_resolve_fixups_for_symbol___v33
    sta __L_resolve_fixups_for_symbol_value
    lda #$00
    sta __L_resolve_fixups_for_symbol_value+1
__F_resolve_fixups_for_symbol_join_12:
    lda #<fixup_stage
    sta __ap
    lda #>fixup_stage
    sta __ap+1
    lda __L_resolve_fixups_for_symbol_i
    asl
    sta __ix
    lda __L_resolve_fixups_for_symbol_i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_stage
    iny
    lda (__ap),y
    sta __L_resolve_fixups_for_symbol_stage+1
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_WORD
    beq __F_resolve_fixups_for_symbol_yes_13
    jmp __F_resolve_fixups_for_symbol_no_14
__F_resolve_fixups_for_symbol_yes_13:
    lda __L_resolve_fixups_for_symbol_stage
    sta __T_resolve_fixups_for_symbol___v41
    lda __L_resolve_fixups_for_symbol_stage+1
    sta __T_resolve_fixups_for_symbol___v41+1
    lda __L_resolve_fixups_for_symbol_value
    and #$ff
    sta __T_resolve_fixups_for_symbol___v44
    lda __L_resolve_fixups_for_symbol_value+1
    and #$00
    sta __T_resolve_fixups_for_symbol___v44+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_resolve_fixups_for_symbol___v41
    sta __ix
    lda __T_resolve_fixups_for_symbol___v41+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_resolve_fixups_for_symbol___v44
    sta (__ap),y
    lda __L_resolve_fixups_for_symbol_stage
    clc
    adc #$01
    sta __T_resolve_fixups_for_symbol___v48
    lda __L_resolve_fixups_for_symbol_stage+1
    adc #$00
    sta __T_resolve_fixups_for_symbol___v48+1
    lda __L_resolve_fixups_for_symbol_value
    sta __T_resolve_fixups_for_symbol___v51
    lda __L_resolve_fixups_for_symbol_value+1
    sta __T_resolve_fixups_for_symbol___v51+1
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lsr __T_resolve_fixups_for_symbol___v51+1
    ror __T_resolve_fixups_for_symbol___v51
    lda __T_resolve_fixups_for_symbol___v51
    and #$ff
    sta __T_resolve_fixups_for_symbol___v53
    lda __T_resolve_fixups_for_symbol___v51+1
    and #$00
    sta __T_resolve_fixups_for_symbol___v53+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_resolve_fixups_for_symbol___v48
    sta __ix
    lda __T_resolve_fixups_for_symbol___v48+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_resolve_fixups_for_symbol___v53
    sta (__ap),y
    jmp __F_resolve_fixups_for_symbol_join_15
__F_resolve_fixups_for_symbol_no_14:
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_RELATIVE
    beq __F_resolve_fixups_for_symbol_yes_16
    jmp __F_resolve_fixups_for_symbol_no_17
__F_resolve_fixups_for_symbol_yes_16:
    lda __L_resolve_fixups_for_symbol_value
    sta __T_resolve_fixups_for_symbol___v57
    lda __L_resolve_fixups_for_symbol_value+1
    sta __T_resolve_fixups_for_symbol___v57+1
    lda ass_origin
    clc
    adc __L_resolve_fixups_for_symbol_stage
    sta __T_resolve_fixups_for_symbol___v60
    lda ass_origin+1
    adc __L_resolve_fixups_for_symbol_stage+1
    sta __T_resolve_fixups_for_symbol___v60+1
    lda __T_resolve_fixups_for_symbol___v60
    clc
    adc #$01
    sta __T_resolve_fixups_for_symbol___v62
    lda __T_resolve_fixups_for_symbol___v60+1
    adc #$00
    sta __T_resolve_fixups_for_symbol___v62+1
    lda __T_resolve_fixups_for_symbol___v62
    sta __T_resolve_fixups_for_symbol___v64
    lda __T_resolve_fixups_for_symbol___v62+1
    sta __T_resolve_fixups_for_symbol___v64+1
    lda __T_resolve_fixups_for_symbol___v57
    sta __call_relative_byte_0
    lda __T_resolve_fixups_for_symbol___v57+1
    sta __call_relative_byte_0+1
    lda __T_resolve_fixups_for_symbol___v64
    sta __call_relative_byte_1
    lda __T_resolve_fixups_for_symbol___v64+1
    sta __call_relative_byte_1+1
    jsr relative_byte
    sta __L_resolve_fixups_for_symbol_relative
    stx __L_resolve_fixups_for_symbol_relative+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_resolve_fixups_for_symbol_relative+1
    eor #$80
    cmp __rh
    bcc __F_resolve_fixups_for_symbol___sel4
    bne __F_resolve_fixups_for_symbol___sel5
    lda __L_resolve_fixups_for_symbol_relative
    cmp #$00
    bcc __F_resolve_fixups_for_symbol___sel4
    bne __F_resolve_fixups_for_symbol___sel5
    jmp __F_resolve_fixups_for_symbol___sel6
__F_resolve_fixups_for_symbol___sel4:
    jmp __F_resolve_fixups_for_symbol_yes_19
__F_resolve_fixups_for_symbol___sel5:
    jmp __F_resolve_fixups_for_symbol_join_21
__F_resolve_fixups_for_symbol___sel6:
    jmp __F_resolve_fixups_for_symbol_join_21
__F_resolve_fixups_for_symbol_yes_19:
    lda ASSEMBLE_EMIT_ERROR
    ldx #$00
    rts
__F_resolve_fixups_for_symbol_join_21:
    lda __L_resolve_fixups_for_symbol_stage
    sta __T_resolve_fixups_for_symbol___v71
    lda __L_resolve_fixups_for_symbol_stage+1
    sta __T_resolve_fixups_for_symbol___v71+1
    lda __L_resolve_fixups_for_symbol_relative
    sta __T_resolve_fixups_for_symbol___v72
    lda __L_resolve_fixups_for_symbol_relative+1
    sta __T_resolve_fixups_for_symbol___v72+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_resolve_fixups_for_symbol___v71
    sta __ix
    lda __T_resolve_fixups_for_symbol___v71+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_resolve_fixups_for_symbol___v72
    sta (__ap),y
    jmp __F_resolve_fixups_for_symbol_join_15
__F_resolve_fixups_for_symbol_no_17:
    lda __L_resolve_fixups_for_symbol_value+1
    cmp #$00
    bcc __F_resolve_fixups_for_symbol___sel7
    bne __F_resolve_fixups_for_symbol___sel8
    lda __L_resolve_fixups_for_symbol_value
    cmp #$ff
    bcc __F_resolve_fixups_for_symbol___sel7
    bne __F_resolve_fixups_for_symbol___sel8
    jmp __F_resolve_fixups_for_symbol___sel9
__F_resolve_fixups_for_symbol___sel7:
    jmp __F_resolve_fixups_for_symbol_join_24
__F_resolve_fixups_for_symbol___sel8:
    jmp __F_resolve_fixups_for_symbol_yes_22
__F_resolve_fixups_for_symbol___sel9:
    jmp __F_resolve_fixups_for_symbol_join_24
__F_resolve_fixups_for_symbol_yes_22:
    lda __L_resolve_fixups_for_symbol_kind
    cmp FIXUP_DATA_BYTE
    beq __F_resolve_fixups_for_symbol_yes_25
    jmp __F_resolve_fixups_for_symbol_join_27
__F_resolve_fixups_for_symbol_yes_25:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_resolve_fixups_for_symbol_join_27:
    lda ASSEMBLE_EMIT_ERROR
    ldx #$00
    rts
__F_resolve_fixups_for_symbol_join_24:
    lda __L_resolve_fixups_for_symbol_stage
    sta __T_resolve_fixups_for_symbol___v82
    lda __L_resolve_fixups_for_symbol_stage+1
    sta __T_resolve_fixups_for_symbol___v82+1
    lda __L_resolve_fixups_for_symbol_value
    sta __T_resolve_fixups_for_symbol___v83
    lda __L_resolve_fixups_for_symbol_value+1
    sta __T_resolve_fixups_for_symbol___v83+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_resolve_fixups_for_symbol___v82
    sta __ix
    lda __T_resolve_fixups_for_symbol___v82+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_resolve_fixups_for_symbol___v83
    sta (__ap),y
__F_resolve_fixups_for_symbol_join_15:
    lda __L_resolve_fixups_for_symbol_i
    sta __T_resolve_fixups_for_symbol___v85
    lda __L_resolve_fixups_for_symbol_i+1
    sta __T_resolve_fixups_for_symbol___v85+1
    lda FIXUP_NONE
    sta __T_resolve_fixups_for_symbol___v86
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda __T_resolve_fixups_for_symbol___v85
    sta __ix
    lda __T_resolve_fixups_for_symbol___v85+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_resolve_fixups_for_symbol___v86
    sta (__ap),y
__F_resolve_fixups_for_symbol_join_6:
    lda __L_resolve_fixups_for_symbol_i
    clc
    adc #$01
    sta __T_resolve_fixups_for_symbol___v89
    lda __L_resolve_fixups_for_symbol_i+1
    adc #$00
    sta __T_resolve_fixups_for_symbol___v89+1
    lda __T_resolve_fixups_for_symbol___v89
    sta __L_resolve_fixups_for_symbol_i
    lda __T_resolve_fixups_for_symbol___v89+1
    sta __L_resolve_fixups_for_symbol_i+1
    jmp __F_resolve_fixups_for_symbol_while_1
__F_resolve_fixups_for_symbol_after_3:
    jsr trim_fixups
    ldx #$00
    rts
