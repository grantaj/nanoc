* = $0800
__ap = $0010
__ix = $0012
ASSEMBLE_BAD_STATEMENT = $4000
ASSEMBLE_BAD_SYMBOL = $4002
ASSEMBLE_OK = $4004
__L_process_source_line_argument_length = $4006
__L_process_source_line_argument_start = $4008
__L_process_source_line_cursor = $400a
__L_process_source_line_name_length = $400c
__L_process_source_line_name_start = $400e
__L_process_source_line_status = $4010
__T_process_source_line___v101 = $4012
__T_process_source_line___v112 = $4014
__T_process_source_line___v127 = $4016
__T_process_source_line___v128 = $4018
__T_process_source_line___v136 = $401a
__T_process_source_line___v140 = $401c
__T_process_source_line___v143 = $401e
__T_process_source_line___v144 = $4020
__T_process_source_line___v148 = $4022
__T_process_source_line___v152 = $4024
__T_process_source_line___v29 = $4026
__T_process_source_line___v39 = $4028
__T_process_source_line___v60 = $402a
__T_process_source_line___v62 = $402c
__T_process_source_line___v63 = $402e
__T_process_source_line___v82 = $4030
__T_process_source_line___v9 = $4032
__call_process_instruction_like_0 = $4034
__call_process_instruction_like_1 = $4036
__call_process_instruction_like_2 = $4038
__call_process_instruction_like_3 = $403a
__call_process_label_0 = $403c
__call_process_label_1 = $403e
__call_process_symbol_0 = $4040
__call_process_symbol_1 = $4042
__call_process_symbol_2 = $4044
__call_process_symbol_3 = $4046
__call_scan_argument_0 = $4048
process_instruction_like = $404a
process_label = $404c
process_symbol = $404e
scan_argument = $4050
source_line = $4052
source_line_length = $4054
process_source_line:
__F_process_source_line_entry:
    lda #$00
    sta __L_process_source_line_cursor
__F_process_source_line_while_1:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_while_4
    jmp __F_process_source_line_after_3
__F_process_source_line_while_4:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_body_5
    jmp __F_process_source_line_after_6
__F_process_source_line_body_5:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v9
    cmp #$20
    beq __F_process_source_line_yes_7
    jmp __F_process_source_line_no_8
__F_process_source_line_yes_7:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_4
__F_process_source_line_no_8:
    cmp #$09
    beq __F_process_source_line_yes_10
    jmp __F_process_source_line_after_6
__F_process_source_line_yes_10:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_4
__F_process_source_line_after_6:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcs __F_process_source_line_yes_13
    jmp __F_process_source_line_join_15
__F_process_source_line_yes_13:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_process_source_line_join_15:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v29
    cmp #$3b
    beq __F_process_source_line_yes_16
    jmp __F_process_source_line_join_18
__F_process_source_line_yes_16:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_process_source_line_join_18:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_name_start
__F_process_source_line_while_19:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_body_20
    jmp __F_process_source_line_after_21
__F_process_source_line_body_20:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v39
    cmp #$20
    beq __F_process_source_line_after_21
    jmp __F_process_source_line_join_24
__F_process_source_line_join_24:
    cmp #$09
    beq __F_process_source_line_after_21
    jmp __F_process_source_line_join_27
__F_process_source_line_join_27:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_19
__F_process_source_line_after_21:
    lda __L_process_source_line_cursor
    sec
    sbc __L_process_source_line_name_start
    sta __L_process_source_line_name_length
    lda __L_process_source_line_name_length
    cmp #$00
    beq __F_process_source_line_yes_28
    jmp __F_process_source_line_join_30
__F_process_source_line_yes_28:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_process_source_line_join_30:
    lda __L_process_source_line_name_start
    clc
    adc __L_process_source_line_name_length
    sta __T_process_source_line___v60
    lda #$00
    adc #$00
    sta __T_process_source_line___v60+1
    lda __T_process_source_line___v60
    sec
    sbc #$01
    sta __T_process_source_line___v62
    lda __T_process_source_line___v60+1
    sbc #$00
    sta __T_process_source_line___v62+1
    lda #<source_line
    sta __ap
    lda #>source_line
    sta __ap+1
    lda __T_process_source_line___v62
    sta __ix
    lda __T_process_source_line___v62+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_process_source_line___v63
    cmp #$3a
    beq __F_process_source_line_yes_31
    jmp __F_process_source_line_while_37
__F_process_source_line_yes_31:
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_label_0
    lda #>source_line
    adc #$00
    sta __call_process_label_0+1
    lda __L_process_source_line_name_length
    sec
    sbc #$01
    sta __call_process_label_1
    lda #$00
    sbc #$00
    sta __call_process_label_1+1
    jsr process_label
    sta __L_process_source_line_status
    lda __L_process_source_line_status
    cmp ASSEMBLE_OK
    bne __F_process_source_line_yes_34
    jmp __F_process_source_line_while_1
__F_process_source_line_yes_34:
    lda __L_process_source_line_status
    ldx #$00
    rts
__F_process_source_line_while_37:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_body_38
    jmp __F_process_source_line_after_39
__F_process_source_line_body_38:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v82
    cmp #$20
    beq __F_process_source_line_yes_40
    jmp __F_process_source_line_no_41
__F_process_source_line_yes_40:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_37
__F_process_source_line_no_41:
    cmp #$09
    beq __F_process_source_line_yes_43
    jmp __F_process_source_line_after_39
__F_process_source_line_yes_43:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_37
__F_process_source_line_after_39:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_yes_46
    jmp __F_process_source_line_join_48
__F_process_source_line_yes_46:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v101
    cmp #$3d
    beq __F_process_source_line_yes_49
    jmp __F_process_source_line_join_48
__F_process_source_line_yes_49:
    inc __L_process_source_line_cursor
__F_process_source_line_while_52:
    lda __L_process_source_line_cursor
    cmp source_line_length
    bcc __F_process_source_line_body_53
    jmp __F_process_source_line_after_54
__F_process_source_line_body_53:
    ldy __L_process_source_line_cursor
    lda source_line,y
    sta __T_process_source_line___v112
    cmp #$20
    beq __F_process_source_line_yes_55
    jmp __F_process_source_line_no_56
__F_process_source_line_yes_55:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_52
__F_process_source_line_no_56:
    cmp #$09
    beq __F_process_source_line_yes_58
    jmp __F_process_source_line_after_54
__F_process_source_line_yes_58:
    inc __L_process_source_line_cursor
    jmp __F_process_source_line_while_52
__F_process_source_line_after_54:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_argument_start
    lda __L_process_source_line_argument_start
    sta __T_process_source_line___v127
    lda __T_process_source_line___v127
    sta __call_scan_argument_0
    jsr scan_argument
    sta __T_process_source_line___v128
    stx __T_process_source_line___v128+1
    lda __T_process_source_line___v128
    sta __L_process_source_line_argument_length
    lda __L_process_source_line_argument_length
    cmp #$00
    beq __F_process_source_line_yes_61
    jmp __F_process_source_line_join_63
__F_process_source_line_yes_61:
    lda ASSEMBLE_BAD_SYMBOL
    ldx #$00
    rts
__F_process_source_line_join_63:
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_symbol_0
    lda #>source_line
    adc #$00
    sta __call_process_symbol_0+1
    lda __L_process_source_line_name_length
    sta __T_process_source_line___v136
    lda #<source_line
    clc
    adc __L_process_source_line_argument_start
    sta __call_process_symbol_2
    lda #>source_line
    adc #$00
    sta __call_process_symbol_2+1
    lda __L_process_source_line_argument_length
    sta __T_process_source_line___v140
    lda __T_process_source_line___v136
    sta __call_process_symbol_1
    lda __T_process_source_line___v140
    sta __call_process_symbol_3
    jsr process_symbol
    ldx #$00
    rts
__F_process_source_line_join_48:
    lda __L_process_source_line_cursor
    sta __L_process_source_line_argument_start
    lda __L_process_source_line_argument_start
    sta __T_process_source_line___v143
    lda __T_process_source_line___v143
    sta __call_scan_argument_0
    jsr scan_argument
    sta __T_process_source_line___v144
    stx __T_process_source_line___v144+1
    lda __T_process_source_line___v144
    sta __L_process_source_line_argument_length
    lda #<source_line
    clc
    adc __L_process_source_line_name_start
    sta __call_process_instruction_like_0
    lda #>source_line
    adc #$00
    sta __call_process_instruction_like_0+1
    lda __L_process_source_line_name_length
    sta __T_process_source_line___v148
    lda #<source_line
    clc
    adc __L_process_source_line_argument_start
    sta __call_process_instruction_like_2
    lda #>source_line
    adc #$00
    sta __call_process_instruction_like_2+1
    lda __L_process_source_line_argument_length
    sta __T_process_source_line___v152
    lda __T_process_source_line___v148
    sta __call_process_instruction_like_1
    lda __T_process_source_line___v152
    sta __call_process_instruction_like_3
    jsr process_instruction_like
    ldx #$00
    rts
__F_process_source_line_after_3:
    lda ASSEMBLE_OK
    ldx #$00
    rts
