entry:
    lda name
    sta __call_scope_for_name_0
    lda name+1
    sta __call_scope_for_name_0+1
    lda length
    sta __call_scope_for_name_1
    jsr scope_for_name
    sta wanted_scope
    stx wanted_scope+1
    lda #$00
    eor #$80
    sta __rh
    lda wanted_scope+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda wanted_scope
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp yes_1
__sel2:
    jmp join_3
__sel3:
    jmp join_3
yes_1:
    sec
    lda #$00
    sbc #$02
    sta __v7
    lda #$00
    sbc #$00
    sta __v7+1
    lda __v7
    ldx __v7+1
    rts
join_3:
    lda #$00
    sta i
    lda #$00
    sta i+1
while_4:
    lda symbol_count+1
    eor #$80
    sta __rh
    lda i+1
    eor #$80
    cmp __rh
    bcc __sel4
    bne __sel5
    lda i
    cmp symbol_count
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp body_5
__sel5:
    jmp after_6
__sel6:
    jmp after_6
body_5:
    lda #<symbol_scope
    sta __ap
    lda #>symbol_scope
    sta __ap+1
    lda i
    sta __ix
    lda i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v14
    lda #$00
    cmp wanted_scope+1
    beq __far_skip_0
    jmp join_9
__far_skip_0:
    lda __v14
    cmp wanted_scope
    beq yes_7
    jmp join_9
yes_7:
    lda #<symbol_name_length
    sta __ap
    lda #>symbol_name_length
    sta __ap+1
    lda i
    sta __ix
    lda i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v19
    cmp length
    beq yes_10
    jmp join_9
yes_10:
    lda #<symbol_name_offset
    sta __ap
    lda #>symbol_name_offset
    sta __ap+1
    lda i
    asl
    sta __ix
    lda i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta offset
    iny
    lda (__ap),y
    sta offset+1
    lda #$01
    sta same
    lda #$00
    sta j
while_13:
    lda j
    cmp length
    bcc body_14
    jmp after_15
body_14:
    lda offset
    clc
    adc j
    sta __v33
    lda offset+1
    adc #$00
    sta __v33+1
    lda #<symbol_name_bytes
    sta __ap
    lda #>symbol_name_bytes
    sta __ap+1
    lda __v33
    sta __ix
    lda __v33+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v34
    ldy j
    lda name
    sta __ap
    lda name+1
    sta __ap+1
    lda (__ap),y
    sta __v37
    lda __v34
    cmp __v37
    bne yes_16
    jmp join_18
yes_16:
    lda #$00
    sta same
join_18:
    inc j
    jmp while_13
after_15:
    lda same
    cmp #$00
    bne yes_19
    jmp join_9
yes_19:
    lda i
    ldx i+1
    rts
join_9:
    lda i
    clc
    adc #$01
    sta __v49
    lda i+1
    adc #$00
    sta __v49+1
    lda __v49
    sta i
    lda __v49+1
    sta i+1
    jmp while_4
after_6:
    sec
    lda #$00
    sbc #$01
    sta __v51
    lda #$00
    sbc #$00
    sta __v51+1
    lda __v51
    ldx __v51+1
    rts
