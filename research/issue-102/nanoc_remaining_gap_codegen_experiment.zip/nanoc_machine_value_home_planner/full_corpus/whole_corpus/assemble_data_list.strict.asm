* = $0800
__ap = $0010
ASSEMBLE_BAD_DATA = $4000
ASSEMBLE_OK = $4002
__L_assemble_data_list_argument = $4004
__L_assemble_data_list_c = $4006
__L_assemble_data_list_cursor = $4008
__L_assemble_data_list_item_end = $400a
__L_assemble_data_list_item_start = $400c
__L_assemble_data_list_length = $400e
__L_assemble_data_list_status = $4010
__L_assemble_data_list_width = $4012
__T_assemble_data_list___v59 = $4014
__call_stage_data_value_0 = $4016
__call_stage_data_value_1 = $4018
__call_stage_data_value_2 = $401a
stage_data_value = $401c
assemble_data_list:
__F_assemble_data_list_entry:
    lda #$00
    sta __L_assemble_data_list_cursor
__F_assemble_data_list_while_1:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_while_4
    jmp __F_assemble_data_list_after_3
__F_assemble_data_list_while_4:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_body_5
    jmp __F_assemble_data_list_after_6
__F_assemble_data_list_body_5:
    ldy __L_assemble_data_list_cursor
    lda __L_assemble_data_list_argument
    sta __ap
    lda __L_assemble_data_list_argument+1
    sta __ap+1
    lda (__ap),y
    sta __L_assemble_data_list_c
    lda __L_assemble_data_list_c
    cmp #$20
    beq __F_assemble_data_list_yes_7
    jmp __F_assemble_data_list_no_8
__F_assemble_data_list_yes_7:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_4
__F_assemble_data_list_no_8:
    lda __L_assemble_data_list_c
    cmp #$09
    beq __F_assemble_data_list_yes_10
    jmp __F_assemble_data_list_after_6
__F_assemble_data_list_yes_10:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_4
__F_assemble_data_list_after_6:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_yes_13
    jmp __F_assemble_data_list_join_15
__F_assemble_data_list_yes_13:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_data_list_join_15:
    lda __L_assemble_data_list_cursor
    sta __L_assemble_data_list_item_start
    lda __L_assemble_data_list_cursor
    sta __L_assemble_data_list_item_end
__F_assemble_data_list_while_16:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcc __F_assemble_data_list_body_17
    jmp __F_assemble_data_list_after_18
__F_assemble_data_list_body_17:
    ldy __L_assemble_data_list_cursor
    lda __L_assemble_data_list_argument
    sta __ap
    lda __L_assemble_data_list_argument+1
    sta __ap+1
    lda (__ap),y
    sta __L_assemble_data_list_c
    lda __L_assemble_data_list_c
    cmp #$2c
    beq __F_assemble_data_list_after_18
    jmp __F_assemble_data_list_join_21
__F_assemble_data_list_join_21:
    lda __L_assemble_data_list_c
    cmp #$20
    bne __F_assemble_data_list_yes_22
    jmp __F_assemble_data_list_join_24
__F_assemble_data_list_yes_22:
    lda __L_assemble_data_list_c
    cmp #$09
    bne __F_assemble_data_list_yes_25
    jmp __F_assemble_data_list_join_24
__F_assemble_data_list_yes_25:
    lda __L_assemble_data_list_cursor
    clc
    adc #$01
    sta __L_assemble_data_list_item_end
__F_assemble_data_list_join_24:
    inc __L_assemble_data_list_cursor
    jmp __F_assemble_data_list_while_16
__F_assemble_data_list_after_18:
    lda __L_assemble_data_list_item_end
    cmp __L_assemble_data_list_item_start
    beq __F_assemble_data_list_yes_28
    jmp __F_assemble_data_list_join_30
__F_assemble_data_list_yes_28:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_data_list_join_30:
    lda __L_assemble_data_list_argument
    clc
    adc __L_assemble_data_list_item_start
    sta __call_stage_data_value_0
    lda __L_assemble_data_list_argument+1
    adc #$00
    sta __call_stage_data_value_0+1
    lda __L_assemble_data_list_item_end
    sec
    sbc __L_assemble_data_list_item_start
    sta __call_stage_data_value_1
    lda #$00
    sbc #$00
    sta __call_stage_data_value_1+1
    lda __L_assemble_data_list_width
    sta __T_assemble_data_list___v59
    lda __T_assemble_data_list___v59
    sta __call_stage_data_value_2
    jsr stage_data_value
    sta __L_assemble_data_list_status
    lda __L_assemble_data_list_status
    cmp ASSEMBLE_OK
    bne __F_assemble_data_list_yes_31
    jmp __F_assemble_data_list_join_33
__F_assemble_data_list_yes_31:
    lda __L_assemble_data_list_status
    ldx #$00
    rts
__F_assemble_data_list_join_33:
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_yes_34
    jmp __F_assemble_data_list_join_36
__F_assemble_data_list_yes_34:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_assemble_data_list_join_36:
    inc __L_assemble_data_list_cursor
    lda __L_assemble_data_list_cursor
    cmp __L_assemble_data_list_length
    bcs __F_assemble_data_list_yes_37
    jmp __F_assemble_data_list_while_1
__F_assemble_data_list_yes_37:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_data_list_after_3:
    lda ASSEMBLE_OK
    ldx #$00
    rts
