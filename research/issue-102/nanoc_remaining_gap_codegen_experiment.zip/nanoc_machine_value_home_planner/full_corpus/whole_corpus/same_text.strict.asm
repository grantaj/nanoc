* = $0800
__ap = $0010
__L_same_text_a = $4000
__L_same_text_a_length = $4002
__L_same_text_b = $4004
__L_same_text_b_length = $4006
__L_same_text_i = $4008
__T_same_text___v10 = $400a
__T_same_text___v13 = $400c
same_text:
__F_same_text_entry:
    lda __L_same_text_a_length
    cmp __L_same_text_b_length
    bne __F_same_text_yes_1
    jmp __F_same_text_join_3
__F_same_text_yes_1:
    lda #$00
    ldx #$00
    rts
__F_same_text_join_3:
    lda #$00
    sta __L_same_text_i
__F_same_text_while_4:
    lda __L_same_text_i
    cmp __L_same_text_a_length
    bcc __F_same_text_body_5
    jmp __F_same_text_after_6
__F_same_text_body_5:
    ldy __L_same_text_i
    lda __L_same_text_a
    sta __ap
    lda __L_same_text_a+1
    sta __ap+1
    lda (__ap),y
    sta __T_same_text___v10
    ldy __L_same_text_i
    lda __L_same_text_b
    sta __ap
    lda __L_same_text_b+1
    sta __ap+1
    lda (__ap),y
    sta __T_same_text___v13
    lda __T_same_text___v10
    cmp __T_same_text___v13
    bne __F_same_text_yes_7
    jmp __F_same_text_join_9
__F_same_text_yes_7:
    lda #$00
    ldx #$00
    rts
__F_same_text_join_9:
    inc __L_same_text_i
    jmp __F_same_text_while_4
__F_same_text_after_6:
    lda #$01
    ldx #$00
    rts
