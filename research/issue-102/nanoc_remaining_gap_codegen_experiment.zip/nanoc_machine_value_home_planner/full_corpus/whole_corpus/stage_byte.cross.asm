entry:
    lda #$2c
    eor #$80
    sta __rh
    lda ass_image_length+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda ass_image_length
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp join_3
__sel2:
    jmp yes_1
__sel3:
    jmp yes_1
yes_1:
    lda ASSEMBLE_WORK_FULL
    rts
join_3:
    lda value
    and #$ff
    sta __v8
    lda #$00
    and #$00
    sta __v8+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda ass_image_length
    sta __ix
    lda ass_image_length+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __v8
    sta (__ap),y
    lda ass_image_length
    clc
    adc #$01
    sta __v11
    lda ass_image_length+1
    adc #$00
    sta __v11+1
    lda __v11
    sta ass_image_length
    lda __v11+1
    sta ass_image_length+1
    lda ASSEMBLE_OK
    rts
