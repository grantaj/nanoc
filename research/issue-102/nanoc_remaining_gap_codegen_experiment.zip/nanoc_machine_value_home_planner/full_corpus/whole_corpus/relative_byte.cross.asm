entry:
    lda target
    sec
    sbc base
    sta __v2
    lda target+1
    sbc base+1
    sta __v2+1
    lda __v2
    sta __v4
    lda __v2+1
    sta __v4+1
    lda __v4
    sta difference
    lda __v4+1
    sta difference+1
    lda difference+1
    cmp #$00
    bcc __sel1
    bne __sel2
    lda difference
    cmp #$7f
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp yes_1
__sel2:
    jmp join_3
__sel3:
    jmp yes_1
yes_1:
    lda difference
    ldx difference+1
    rts
join_3:
    lda difference+1
    cmp #$ff
    bcc __sel4
    bne __sel5
    lda difference
    cmp #$80
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp join_6
__sel5:
    jmp yes_4
__sel6:
    jmp yes_4
yes_4:
    lda difference
    and #$ff
    sta __v14
    lda difference+1
    and #$00
    sta __v14+1
    lda __v14
    ldx __v14+1
    rts
join_6:
    sec
    lda #$00
    sbc #$01
    sta __v16
    lda #$00
    sbc #$00
    sta __v16+1
    lda __v16
    ldx __v16+1
    rts
