entry:
    lda length
    cmp #$02
    bcc yes_1
    jmp join_3
yes_1:
    lda ASSEMBLE_BAD_DATA
    rts
join_3:
    ldy #$00
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda (__ap),y
    sta __v6
    lda __v6
    cmp #$22
    bne yes_4
    jmp join_6
yes_4:
    lda ASSEMBLE_BAD_DATA
    rts
join_6:
    lda length
    sec
    sbc #$01
    sta __v13
    lda #$00
    sbc #$00
    sta __v13+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v13
    sta __ix
    lda __v13+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v14
    lda __v14
    cmp #$22
    bne yes_7
    jmp join_9
yes_7:
    lda ASSEMBLE_BAD_DATA
    rts
join_9:
    lda #$01
    sta i
while_10:
    lda length
    sec
    sbc #$01
    sta __v22
    lda #$00
    sbc #$00
    sta __v22+1
    lda __v22+1
    eor #$80
    sta __rh
    lda #$00
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda i
    cmp __v22
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp body_11
__sel2:
    jmp after_12
__sel3:
    jmp after_12
body_11:
    ldy i
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda (__ap),y
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_13
    jmp join_15
yes_13:
    lda status
    rts
join_15:
    inc i
    jmp while_10
after_12:
    lda #$00
    sta __call_stage_byte_0
    jsr stage_byte
    rts
