* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
__L_find_symbol_i = $4000
__L_find_symbol_j = $4002
__L_find_symbol_length = $4004
__L_find_symbol_name = $4006
__L_find_symbol_offset = $4008
__L_find_symbol_same = $400a
__L_find_symbol_wanted_scope = $400c
__T_find_symbol___v0 = $400e
__T_find_symbol___v1 = $4010
__T_find_symbol___v14 = $4012
__T_find_symbol___v19 = $4014
__T_find_symbol___v33 = $4016
__T_find_symbol___v34 = $4018
__T_find_symbol___v37 = $401a
__T_find_symbol___v49 = $401c
__T_find_symbol___v51 = $401e
__T_find_symbol___v7 = $4020
__call_scope_for_name_0 = $4022
__call_scope_for_name_1 = $4024
scope_for_name = $4026
symbol_count = $4028
symbol_name_bytes = $402a
symbol_name_length = $402c
symbol_name_offset = $402e
symbol_scope = $4030
find_symbol:
__F_find_symbol_entry:
    lda __L_find_symbol_name
    sta __T_find_symbol___v0
    lda __L_find_symbol_name+1
    sta __T_find_symbol___v0+1
    lda __L_find_symbol_length
    sta __T_find_symbol___v1
    lda __T_find_symbol___v0
    sta __call_scope_for_name_0
    lda __T_find_symbol___v0+1
    sta __call_scope_for_name_0+1
    lda __T_find_symbol___v1
    sta __call_scope_for_name_1
    jsr scope_for_name
    sta __L_find_symbol_wanted_scope
    stx __L_find_symbol_wanted_scope+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_find_symbol_wanted_scope+1
    eor #$80
    cmp __rh
    bcc __F_find_symbol___sel1
    bne __F_find_symbol___sel2
    lda __L_find_symbol_wanted_scope
    cmp #$00
    bcc __F_find_symbol___sel1
    bne __F_find_symbol___sel2
    jmp __F_find_symbol___sel3
__F_find_symbol___sel1:
    jmp __F_find_symbol_yes_1
__F_find_symbol___sel2:
    jmp __F_find_symbol_join_3
__F_find_symbol___sel3:
    jmp __F_find_symbol_join_3
__F_find_symbol_yes_1:
    sec
    lda #$00
    sbc #$02
    sta __T_find_symbol___v7
    lda #$00
    sbc #$00
    sta __T_find_symbol___v7+1
    lda __T_find_symbol___v7
    ldx __T_find_symbol___v7+1
    rts
__F_find_symbol_join_3:
    lda #$00
    sta __L_find_symbol_i
    lda #$00
    sta __L_find_symbol_i+1
__F_find_symbol_while_4:
    lda symbol_count+1
    eor #$80
    sta __rh
    lda __L_find_symbol_i+1
    eor #$80
    cmp __rh
    bcc __F_find_symbol___sel4
    bne __F_find_symbol___sel5
    lda __L_find_symbol_i
    cmp symbol_count
    bcc __F_find_symbol___sel4
    bne __F_find_symbol___sel5
    jmp __F_find_symbol___sel6
__F_find_symbol___sel4:
    jmp __F_find_symbol_body_5
__F_find_symbol___sel5:
    jmp __F_find_symbol_after_6
__F_find_symbol___sel6:
    jmp __F_find_symbol_after_6
__F_find_symbol_body_5:
    lda #<symbol_scope
    sta __ap
    lda #>symbol_scope
    sta __ap+1
    lda __L_find_symbol_i
    sta __ix
    lda __L_find_symbol_i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_symbol___v14
    lda #$00
    cmp __L_find_symbol_wanted_scope+1
    beq __F_find_symbol___far_skip_0
    jmp __F_find_symbol_join_9
__F_find_symbol___far_skip_0:
    lda __T_find_symbol___v14
    cmp __L_find_symbol_wanted_scope
    beq __F_find_symbol_yes_7
    jmp __F_find_symbol_join_9
__F_find_symbol_yes_7:
    lda #<symbol_name_length
    sta __ap
    lda #>symbol_name_length
    sta __ap+1
    lda __L_find_symbol_i
    sta __ix
    lda __L_find_symbol_i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_symbol___v19
    cmp __L_find_symbol_length
    beq __F_find_symbol_yes_10
    jmp __F_find_symbol_join_9
__F_find_symbol_yes_10:
    lda #<symbol_name_offset
    sta __ap
    lda #>symbol_name_offset
    sta __ap+1
    lda __L_find_symbol_i
    asl
    sta __ix
    lda __L_find_symbol_i+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __L_find_symbol_offset
    iny
    lda (__ap),y
    sta __L_find_symbol_offset+1
    lda #$01
    sta __L_find_symbol_same
    lda #$00
    sta __L_find_symbol_j
__F_find_symbol_while_13:
    lda __L_find_symbol_j
    cmp __L_find_symbol_length
    bcc __F_find_symbol_body_14
    jmp __F_find_symbol_after_15
__F_find_symbol_body_14:
    lda __L_find_symbol_offset
    clc
    adc __L_find_symbol_j
    sta __T_find_symbol___v33
    lda __L_find_symbol_offset+1
    adc #$00
    sta __T_find_symbol___v33+1
    lda #<symbol_name_bytes
    sta __ap
    lda #>symbol_name_bytes
    sta __ap+1
    lda __T_find_symbol___v33
    sta __ix
    lda __T_find_symbol___v33+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_symbol___v34
    ldy __L_find_symbol_j
    lda __L_find_symbol_name
    sta __ap
    lda __L_find_symbol_name+1
    sta __ap+1
    lda (__ap),y
    sta __T_find_symbol___v37
    lda __T_find_symbol___v34
    cmp __T_find_symbol___v37
    bne __F_find_symbol_yes_16
    jmp __F_find_symbol_join_18
__F_find_symbol_yes_16:
    lda #$00
    sta __L_find_symbol_same
__F_find_symbol_join_18:
    inc __L_find_symbol_j
    jmp __F_find_symbol_while_13
__F_find_symbol_after_15:
    lda __L_find_symbol_same
    cmp #$00
    bne __F_find_symbol_yes_19
    jmp __F_find_symbol_join_9
__F_find_symbol_yes_19:
    lda __L_find_symbol_i
    ldx __L_find_symbol_i+1
    rts
__F_find_symbol_join_9:
    lda __L_find_symbol_i
    clc
    adc #$01
    sta __T_find_symbol___v49
    lda __L_find_symbol_i+1
    adc #$00
    sta __T_find_symbol___v49+1
    lda __T_find_symbol___v49
    sta __L_find_symbol_i
    lda __T_find_symbol___v49+1
    sta __L_find_symbol_i+1
    jmp __F_find_symbol_while_4
__F_find_symbol_after_6:
    sec
    lda #$00
    sbc #$01
    sta __T_find_symbol___v51
    lda #$00
    sbc #$00
    sta __T_find_symbol___v51+1
    lda __T_find_symbol___v51
    ldx __T_find_symbol___v51+1
    rts
