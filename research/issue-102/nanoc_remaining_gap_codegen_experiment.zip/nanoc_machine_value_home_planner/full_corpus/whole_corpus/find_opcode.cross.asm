entry:
    lda #$00
    sta opcode
    lda #$00
    sta opcode+1
while_1:
    lda #$01
    eor #$80
    sta __rh
    lda opcode+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda opcode
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp body_2
__sel2:
    jmp after_3
__sel3:
    jmp after_3
body_2:
    lda #<opcode_mnemonic
    sta __ap
    lda #>opcode_mnemonic
    sta __ap+1
    lda opcode
    sta __ix
    lda opcode+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v6
    cmp mnemonic
    beq yes_4
    jmp join_6
yes_4:
    lda #<opcode_mode
    sta __ap
    lda #>opcode_mode
    sta __ap+1
    lda opcode
    sta __ix
    lda opcode+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v11
    cmp mode
    beq yes_7
    jmp join_6
yes_7:
    lda opcode
    ldx opcode+1
    rts
join_6:
    lda opcode
    clc
    adc #$01
    sta __v17
    lda opcode+1
    adc #$00
    sta __v17+1
    lda __v17
    sta opcode
    lda __v17+1
    sta opcode+1
    jmp while_1
after_3:
    sec
    lda #$00
    sbc #$01
    sta __v19
    lda #$00
    sbc #$00
    sta __v19+1
    lda __v19
    ldx __v19+1
    rts
