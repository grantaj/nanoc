* = $0800
__ap = $0010
__rh = $0014
SYMBOL_LABEL_UNDEFINED = $4000
__L_all_symbols_defined_i = $4002
__T_all_symbols_defined___v12 = $4004
__T_all_symbols_defined___v6 = $4006
symbol_count = $4008
symbol_kind = $400a
all_symbols_defined:
__F_all_symbols_defined_entry:
    lda #$00
    sta __L_all_symbols_defined_i
    lda #$00
    sta __L_all_symbols_defined_i+1
    ldy #$00
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
__F_all_symbols_defined_while_1:
    lda symbol_count+1
    eor #$80
    sta __rh
    lda __L_all_symbols_defined_i+1
    eor #$80
    cmp __rh
    bcc __F_all_symbols_defined___sel1
    bne __F_all_symbols_defined___sel2
    lda __L_all_symbols_defined_i
    cmp symbol_count
    bcc __F_all_symbols_defined___sel1
    bne __F_all_symbols_defined___sel2
    jmp __F_all_symbols_defined___sel3
__F_all_symbols_defined___sel1:
    jmp __F_all_symbols_defined_body_2
__F_all_symbols_defined___sel2:
    jmp __F_all_symbols_defined_after_3
__F_all_symbols_defined___sel3:
    jmp __F_all_symbols_defined_after_3
__F_all_symbols_defined_body_2:
    lda (__ap),y
    sta __T_all_symbols_defined___v6
    cmp SYMBOL_LABEL_UNDEFINED
    beq __F_all_symbols_defined_yes_4
    jmp __F_all_symbols_defined_join_6
__F_all_symbols_defined_yes_4:
    lda #$00
    ldx #$00
    rts
__F_all_symbols_defined_join_6:
    lda __L_all_symbols_defined_i
    clc
    adc #$01
    sta __T_all_symbols_defined___v12
    lda __L_all_symbols_defined_i+1
    adc #$00
    sta __T_all_symbols_defined___v12+1
    lda __T_all_symbols_defined___v12
    sta __L_all_symbols_defined_i
    lda __T_all_symbols_defined___v12+1
    sta __L_all_symbols_defined_i+1
    inc __ap
    bne __F_all_symbols_defined___sel4
    inc __ap+1
__F_all_symbols_defined___sel4:
    jmp __F_all_symbols_defined_while_1
__F_all_symbols_defined_after_3:
    lda #$01
    ldx #$00
    rts
