entry:
    lda #$00
    sta i
    lda #$00
    sta i+1
    ldy #$00
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
while_1:
    lda fixup_count+1
    eor #$80
    sta __rh
    lda i+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda i
    cmp fixup_count
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp body_2
__sel2:
    jmp after_3
__sel3:
    jmp after_3
body_2:
    lda (__ap),y
    sta __v6
    cmp FIXUP_NONE
    bne yes_4
    jmp join_6
yes_4:
    lda #$00
    rts
join_6:
    lda i
    clc
    adc #$01
    sta __v12
    lda i+1
    adc #$00
    sta __v12+1
    lda __v12
    sta i
    lda __v12+1
    sta i+1
    inc __ap
    bne __sel4
    inc __ap+1
__sel4:
    jmp while_1
after_3:
    lda #$01
    rts
