* = $0800
__rh = $0014
ASSEMBLE_BAD_INSTRUCTION = $4000
ASSEMBLE_SCOPE_ERROR = $4002
ASSEMBLE_SYMBOL_FULL = $4004
MODE_RELATIVE = $4006
VALUE_OK = $4008
VALUE_SCOPE_ERROR = $400a
VALUE_SYMBOL_FULL = $400c
VALUE_UNRESOLVED = $400e
__L_assemble_mode_value_length = $4010
__L_assemble_mode_value_mnemonic = $4012
__L_assemble_mode_value_mode = $4014
__L_assemble_mode_value_opcode = $4016
__L_assemble_mode_value_status = $4018
__L_assemble_mode_value_text = $401a
__T_assemble_mode_value___v0 = $401c
__T_assemble_mode_value___v1 = $401e
__T_assemble_mode_value___v16 = $4020
__T_assemble_mode_value___v17 = $4022
__T_assemble_mode_value___v19 = $4024
__T_assemble_mode_value___v20 = $4026
__T_assemble_mode_value___v21 = $4028
__T_assemble_mode_value___v26 = $402a
__T_assemble_mode_value___v27 = $402c
__T_assemble_mode_value___v28 = $402e
__T_assemble_mode_value___v29 = $4030
__T_assemble_mode_value___v30 = $4032
__T_assemble_mode_value___v7 = $4034
__T_assemble_mode_value___v8 = $4036
__call_find_opcode_0 = $4038
__call_find_opcode_1 = $403a
__call_parse_value_0 = $403c
__call_parse_value_1 = $403e
__call_stage_resolved_instruction_0 = $4040
__call_stage_resolved_instruction_1 = $4042
__call_stage_resolved_instruction_2 = $4044
__call_stage_resolved_relative_0 = $4046
__call_stage_resolved_relative_1 = $4048
__call_stage_unresolved_instruction_0 = $404a
__call_stage_unresolved_instruction_1 = $404c
__call_stage_unresolved_instruction_2 = $404e
__call_stage_unresolved_instruction_3 = $4050
__call_stage_unresolved_instruction_4 = $4052
captured_addend = $4054
captured_prefix = $4056
captured_symbol = $4058
find_opcode = $405a
parse_value = $405c
stage_resolved_instruction = $405e
stage_resolved_relative = $4060
stage_unresolved_instruction = $4062
value_result = $4064
assemble_mode_value:
__F_assemble_mode_value_entry:
    lda __L_assemble_mode_value_mnemonic
    sta __T_assemble_mode_value___v0
    lda __L_assemble_mode_value_mode
    sta __T_assemble_mode_value___v1
    lda __T_assemble_mode_value___v0
    sta __call_find_opcode_0
    lda __T_assemble_mode_value___v1
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_mode_value_opcode
    stx __L_assemble_mode_value_opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_mode_value_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_mode_value___sel1
    bne __F_assemble_mode_value___sel2
    lda __L_assemble_mode_value_opcode
    cmp #$00
    bcc __F_assemble_mode_value___sel1
    bne __F_assemble_mode_value___sel2
    jmp __F_assemble_mode_value___sel3
__F_assemble_mode_value___sel1:
    jmp __F_assemble_mode_value_yes_1
__F_assemble_mode_value___sel2:
    jmp __F_assemble_mode_value_join_3
__F_assemble_mode_value___sel3:
    jmp __F_assemble_mode_value_join_3
__F_assemble_mode_value_yes_1:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_mode_value_join_3:
    lda __L_assemble_mode_value_text
    sta __T_assemble_mode_value___v7
    lda __L_assemble_mode_value_text+1
    sta __T_assemble_mode_value___v7+1
    lda __L_assemble_mode_value_length
    sta __T_assemble_mode_value___v8
    lda __T_assemble_mode_value___v7
    sta __call_parse_value_0
    lda __T_assemble_mode_value___v7+1
    sta __call_parse_value_0+1
    lda __T_assemble_mode_value___v8
    sta __call_parse_value_1
    jsr parse_value
    sta __L_assemble_mode_value_status
    lda __L_assemble_mode_value_status
    cmp VALUE_OK
    beq __F_assemble_mode_value_yes_4
    jmp __F_assemble_mode_value_join_6
__F_assemble_mode_value_yes_4:
    lda __L_assemble_mode_value_mode
    cmp MODE_RELATIVE
    beq __F_assemble_mode_value_yes_7
    jmp __F_assemble_mode_value_join_9
__F_assemble_mode_value_yes_7:
    lda __L_assemble_mode_value_opcode
    sta __T_assemble_mode_value___v16
    lda __L_assemble_mode_value_opcode+1
    sta __T_assemble_mode_value___v16+1
    lda value_result
    sta __T_assemble_mode_value___v17
    lda value_result+1
    sta __T_assemble_mode_value___v17+1
    lda __T_assemble_mode_value___v16
    sta __call_stage_resolved_relative_0
    lda __T_assemble_mode_value___v16+1
    sta __call_stage_resolved_relative_0+1
    lda __T_assemble_mode_value___v17
    sta __call_stage_resolved_relative_1
    lda __T_assemble_mode_value___v17+1
    sta __call_stage_resolved_relative_1+1
    jsr stage_resolved_relative
    ldx #$00
    rts
__F_assemble_mode_value_join_9:
    lda __L_assemble_mode_value_opcode
    sta __T_assemble_mode_value___v19
    lda __L_assemble_mode_value_opcode+1
    sta __T_assemble_mode_value___v19+1
    lda __L_assemble_mode_value_mode
    sta __T_assemble_mode_value___v20
    lda value_result
    sta __T_assemble_mode_value___v21
    lda value_result+1
    sta __T_assemble_mode_value___v21+1
    lda __T_assemble_mode_value___v19
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_mode_value___v19+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_mode_value___v20
    sta __call_stage_resolved_instruction_1
    lda __T_assemble_mode_value___v21
    sta __call_stage_resolved_instruction_2
    lda __T_assemble_mode_value___v21+1
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_mode_value_join_6:
    lda __L_assemble_mode_value_status
    cmp VALUE_UNRESOLVED
    beq __F_assemble_mode_value_yes_10
    jmp __F_assemble_mode_value_join_12
__F_assemble_mode_value_yes_10:
    lda __L_assemble_mode_value_opcode
    sta __T_assemble_mode_value___v26
    lda __L_assemble_mode_value_opcode+1
    sta __T_assemble_mode_value___v26+1
    lda __L_assemble_mode_value_mode
    sta __T_assemble_mode_value___v27
    lda captured_symbol
    sta __T_assemble_mode_value___v28
    lda captured_symbol+1
    sta __T_assemble_mode_value___v28+1
    lda captured_addend
    sta __T_assemble_mode_value___v29
    lda captured_addend+1
    sta __T_assemble_mode_value___v29+1
    lda captured_prefix
    sta __T_assemble_mode_value___v30
    lda __T_assemble_mode_value___v26
    sta __call_stage_unresolved_instruction_0
    lda __T_assemble_mode_value___v26+1
    sta __call_stage_unresolved_instruction_0+1
    lda __T_assemble_mode_value___v27
    sta __call_stage_unresolved_instruction_1
    lda __T_assemble_mode_value___v28
    sta __call_stage_unresolved_instruction_2
    lda __T_assemble_mode_value___v28+1
    sta __call_stage_unresolved_instruction_2+1
    lda __T_assemble_mode_value___v29
    sta __call_stage_unresolved_instruction_3
    lda __T_assemble_mode_value___v29+1
    sta __call_stage_unresolved_instruction_3+1
    lda __T_assemble_mode_value___v30
    sta __call_stage_unresolved_instruction_4
    jsr stage_unresolved_instruction
    ldx #$00
    rts
__F_assemble_mode_value_join_12:
    lda __L_assemble_mode_value_status
    cmp VALUE_SYMBOL_FULL
    beq __F_assemble_mode_value_yes_13
    jmp __F_assemble_mode_value_join_15
__F_assemble_mode_value_yes_13:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_assemble_mode_value_join_15:
    lda __L_assemble_mode_value_status
    cmp VALUE_SCOPE_ERROR
    beq __F_assemble_mode_value_yes_16
    jmp __F_assemble_mode_value_join_18
__F_assemble_mode_value_yes_16:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_assemble_mode_value_join_18:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
