* = $0800
__rh = $0014
ASSEMBLE_EMIT_ERROR = $4000
ASSEMBLE_OK = $4002
__L_stage_resolved_relative_base = $4004
__L_stage_resolved_relative_opcode = $4006
__L_stage_resolved_relative_relative = $4008
__L_stage_resolved_relative_status = $400a
__L_stage_resolved_relative_target = $400c
__T_stage_resolved_relative___v14 = $400e
__T_stage_resolved_relative___v2 = $4010
__T_stage_resolved_relative___v20 = $4012
__T_stage_resolved_relative___v4 = $4014
__T_stage_resolved_relative___v6 = $4016
__T_stage_resolved_relative___v7 = $4018
__T_stage_resolved_relative___v8 = $401a
__call_relative_byte_0 = $401c
__call_relative_byte_1 = $401e
__call_stage_byte_0 = $4020
ass_image_length = $4022
ass_origin = $4024
relative_byte = $4026
stage_byte = $4028
stage_resolved_relative:
__F_stage_resolved_relative_entry:
    lda ass_origin
    clc
    adc ass_image_length
    sta __T_stage_resolved_relative___v2
    lda ass_origin+1
    adc ass_image_length+1
    sta __T_stage_resolved_relative___v2+1
    lda __T_stage_resolved_relative___v2
    clc
    adc #$02
    sta __T_stage_resolved_relative___v4
    lda __T_stage_resolved_relative___v2+1
    adc #$00
    sta __T_stage_resolved_relative___v4+1
    lda __T_stage_resolved_relative___v4
    sta __T_stage_resolved_relative___v6
    lda __T_stage_resolved_relative___v4+1
    sta __T_stage_resolved_relative___v6+1
    lda __T_stage_resolved_relative___v6
    sta __L_stage_resolved_relative_base
    lda __T_stage_resolved_relative___v6+1
    sta __L_stage_resolved_relative_base+1
    lda __L_stage_resolved_relative_target
    sta __T_stage_resolved_relative___v7
    lda __L_stage_resolved_relative_target+1
    sta __T_stage_resolved_relative___v7+1
    lda __L_stage_resolved_relative_base
    sta __T_stage_resolved_relative___v8
    lda __L_stage_resolved_relative_base+1
    sta __T_stage_resolved_relative___v8+1
    lda __T_stage_resolved_relative___v7
    sta __call_relative_byte_0
    lda __T_stage_resolved_relative___v7+1
    sta __call_relative_byte_0+1
    lda __T_stage_resolved_relative___v8
    sta __call_relative_byte_1
    lda __T_stage_resolved_relative___v8+1
    sta __call_relative_byte_1+1
    jsr relative_byte
    sta __L_stage_resolved_relative_relative
    stx __L_stage_resolved_relative_relative+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_stage_resolved_relative_relative+1
    eor #$80
    cmp __rh
    bcc __F_stage_resolved_relative___sel1
    bne __F_stage_resolved_relative___sel2
    lda __L_stage_resolved_relative_relative
    cmp #$00
    bcc __F_stage_resolved_relative___sel1
    bne __F_stage_resolved_relative___sel2
    jmp __F_stage_resolved_relative___sel3
__F_stage_resolved_relative___sel1:
    jmp __F_stage_resolved_relative_yes_1
__F_stage_resolved_relative___sel2:
    jmp __F_stage_resolved_relative_join_3
__F_stage_resolved_relative___sel3:
    jmp __F_stage_resolved_relative_join_3
__F_stage_resolved_relative_yes_1:
    lda ASSEMBLE_EMIT_ERROR
    ldx #$00
    rts
__F_stage_resolved_relative_join_3:
    lda __L_stage_resolved_relative_opcode
    sta __T_stage_resolved_relative___v14
    lda __T_stage_resolved_relative___v14
    sta __call_stage_byte_0
    jsr stage_byte
    sta __L_stage_resolved_relative_status
    lda __L_stage_resolved_relative_status
    cmp ASSEMBLE_OK
    bne __F_stage_resolved_relative_yes_4
    jmp __F_stage_resolved_relative_join_6
__F_stage_resolved_relative_yes_4:
    lda __L_stage_resolved_relative_status
    ldx #$00
    rts
__F_stage_resolved_relative_join_6:
    lda __L_stage_resolved_relative_relative
    sta __T_stage_resolved_relative___v20
    lda __L_stage_resolved_relative_relative+1
    sta __T_stage_resolved_relative___v20+1
    lda __T_stage_resolved_relative___v20
    sta __call_stage_byte_0
    lda __T_stage_resolved_relative___v20+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    ldx #$00
    rts
