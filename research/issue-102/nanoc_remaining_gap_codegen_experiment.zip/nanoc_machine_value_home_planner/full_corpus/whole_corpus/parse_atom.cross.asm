entry:
    lda #$00
    sta atom_used
    lda length
    cmp #$00
    beq yes_1
    jmp join_3
yes_1:
    lda VALUE_BAD
    rts
join_3:
    ldy #$00
    lda text
    sta __ap
    lda text+1
    sta __ap+1
    lda (__ap),y
    sta __v7
    cmp #$24
    beq yes_4
    jmp join_6
yes_4:
    lda #$01
    sta i
    lda #$00
    sta value
    lda #$00
    sta value+1
while_7:
    lda i
    cmp length
    bcc body_8
    jmp after_9
body_8:
    ldy i
    lda text
    sta __ap
    lda text+1
    sta __ap+1
    lda (__ap),y
    sta __v17
    cmp #$2b
    bne __far_skip_0
    jmp after_9
__far_skip_0:
    jmp no_11
no_11:
    cmp #$2d
    bne __far_skip_1
    jmp after_9
__far_skip_1:
    jmp no_14
no_14:
    lda __v17
    sta __call_hex_nibble_0
    jsr hex_nibble
    sta digit
    stx digit+1
    lda #$00
    eor #$80
    sta __rh
    lda digit+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda digit
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp yes_16
__sel2:
    jmp join_18
__sel3:
    jmp join_18
yes_16:
    lda VALUE_BAD
    rts
join_18:
    lda atom_used
    cmp #$04
    bcs yes_19
    jmp join_21
yes_19:
    lda VALUE_BAD
    rts
join_21:
    lda value
    sta __v39
    lda value+1
    sta __v39+1
    asl __v39
    rol __v39+1
    asl __v39
    rol __v39+1
    asl __v39
    rol __v39+1
    asl __v39
    rol __v39+1
    lda __v39
    ora digit
    sta __v41
    lda __v39+1
    ora digit+1
    sta __v41+1
    lda __v41
    sta __v43
    lda __v41+1
    sta __v43+1
    lda __v43
    sta value
    lda __v43+1
    sta value+1
    inc atom_used
    inc i
    jmp while_7
after_9:
    lda atom_used
    cmp #$00
    beq yes_22
    jmp join_24
yes_22:
    lda VALUE_BAD
    rts
join_24:
    inc atom_used
    lda value
    sta atom_value
    lda value+1
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    rts
join_6:
    cmp #$27
    beq yes_25
    jmp join_27
yes_25:
    lda length
    cmp #$03
    bcc yes_28
    jmp join_30
yes_28:
    lda VALUE_BAD
    rts
join_30:
    ldy #$02
    lda text
    sta __ap
    lda text+1
    sta __ap+1
    lda (__ap),y
    sta __v71
    cmp #$27
    bne yes_31
    jmp join_33
yes_31:
    lda VALUE_BAD
    rts
join_33:
    ldy #$01
    lda text
    sta __ap
    lda text+1
    sta __ap+1
    lda (__ap),y
    sta __v77
    lda __v77
    sta atom_value
    lda #$00
    sta atom_value+1
    lda #$03
    sta atom_used
    lda #$00
    sta atom_kind
    lda VALUE_OK
    rts
join_27:
    cmp #$30
    bcs yes_34
    jmp join_36
yes_34:
    cmp #$39
    bcc yes_37
    beq yes_37
    jmp join_36
yes_37:
    lda #$00
    sta i
    lda #$00
    sta value
    lda #$00
    sta value+1
    ldy i
    lda text
    sta __ap
    lda text+1
    sta __ap+1
while_40:
    cpy length
    bcc body_41
    jmp after_42
body_41:
    lda (__ap),y
    sta __v98
    cmp #$2b
    bne __far_skip_2
    jmp after_42
__far_skip_2:
    jmp no_44
no_44:
    cmp #$2d
    bne __far_skip_3
    jmp after_42
__far_skip_3:
    jmp no_47
no_47:
    cmp #$30
    bcc yes_49
    jmp join_51
yes_49:
    lda VALUE_BAD
    rts
join_51:
    cmp #$39
    bcc join_54
    beq join_54
    jmp yes_52
yes_52:
    lda VALUE_BAD
    rts
join_54:
    lda #$00
    sta __v120
    sta __v120+1
    lda value
    sta __mw
    lda value+1
    sta __mw+1
    asl __mw
    rol __mw+1
    clc
    lda __v120
    adc __mw
    sta __v120
    lda __v120+1
    adc __mw+1
    sta __v120+1
    asl __mw
    rol __mw+1
    asl __mw
    rol __mw+1
    clc
    lda __v120
    adc __mw
    sta __v120
    lda __v120+1
    adc __mw+1
    sta __v120+1
    lda __v120
    clc
    adc __v98
    sta __v124
    lda __v120+1
    adc #$00
    sta __v124+1
    lda __v124
    sec
    sbc #$30
    sta __v126
    lda __v124+1
    sbc #$00
    sta __v126+1
    lda __v126
    sta __v128
    lda __v126+1
    sta __v128+1
    lda __v128
    sta value
    lda __v128+1
    sta value+1
    inc atom_used
    inc i
    iny
    jmp while_40
after_42:
    lda value
    sta atom_value
    lda value+1
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    rts
join_36:
    lda #$00
    sta i
    ldy i
    lda text
    sta __ap
    lda text+1
    sta __ap+1
while_55:
    cpy length
    bcc body_56
    jmp after_57
body_56:
    lda (__ap),y
    sta __v144
    cmp #$2b
    beq after_57
    jmp no_59
no_59:
    cmp #$2d
    beq after_57
    jmp no_62
no_62:
    inc atom_used
    inc i
    iny
    jmp while_55
after_57:
    lda atom_used
    cmp #$00
    beq yes_64
    jmp join_66
yes_64:
    lda VALUE_BAD
    rts
join_66:
    lda text
    sta __call_find_symbol_0
    lda text+1
    sta __call_find_symbol_0+1
    lda atom_used
    sta __call_find_symbol_1
    jsr find_symbol
    sta symbol
    stx symbol+1
    sec
    lda #$00
    sbc #$02
    sta __v167
    lda #$00
    sbc #$00
    sta __v167+1
    lda symbol+1
    cmp __v167+1
    bne join_69
    lda symbol
    cmp __v167
    beq yes_67
    jmp join_69
yes_67:
    lda VALUE_SCOPE_ERROR
    rts
join_69:
    lda #$00
    eor #$80
    sta __rh
    lda symbol+1
    eor #$80
    cmp __rh
    bcc __sel4
    bne __sel5
    lda symbol
    cmp #$00
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp yes_70
__sel5:
    jmp join_72
__sel6:
    jmp join_72
yes_70:
    lda text
    sta __call_intern_label_0
    lda text+1
    sta __call_intern_label_0+1
    lda atom_used
    sta __call_intern_label_1
    jsr intern_label
    sta symbol
    stx symbol+1
    sec
    lda #$00
    sbc #$02
    sta __v178
    lda #$00
    sbc #$00
    sta __v178+1
    lda symbol+1
    cmp __v178+1
    bne join_75
    lda symbol
    cmp __v178
    beq yes_73
    jmp join_75
yes_73:
    lda VALUE_SCOPE_ERROR
    rts
join_75:
    sec
    lda #$00
    sbc #$03
    sta __v183
    lda #$00
    sbc #$00
    sta __v183+1
    lda symbol+1
    cmp __v183+1
    bne join_78
    lda symbol
    cmp __v183
    beq yes_76
    jmp join_78
yes_76:
    lda VALUE_SYMBOL_FULL
    rts
join_78:
    lda #$00
    eor #$80
    sta __rh
    lda symbol+1
    eor #$80
    cmp __rh
    bcc __sel7
    bne __sel8
    lda symbol
    cmp #$00
    bcc __sel7
    bne __sel8
    jmp __sel9
__sel7:
    jmp yes_79
__sel8:
    jmp join_72
__sel9:
    jmp join_72
yes_79:
    lda VALUE_BAD
    rts
join_72:
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda symbol
    sta __ix
    lda symbol+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v192
    cmp SYMBOL_LABEL_UNDEFINED
    beq yes_82
    jmp join_84
yes_82:
    lda symbol
    sta atom_symbol
    lda symbol+1
    sta atom_symbol+1
    lda #$01
    sta atom_kind
    lda VALUE_UNRESOLVED
    rts
join_84:
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda symbol
    asl
    sta __ix
    lda symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta atom_value
    iny
    lda (__ap),y
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    rts
