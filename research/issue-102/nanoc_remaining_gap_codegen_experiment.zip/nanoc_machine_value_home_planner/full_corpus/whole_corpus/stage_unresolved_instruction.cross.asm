entry:
    ldy mode
    lda mode_width,y
    sta width
    lda opcode
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_1
    jmp join_3
yes_1:
    lda status
    rts
join_3:
    lda ass_image_length
    sta stage
    lda ass_image_length+1
    sta stage+1
    lda width
    cmp #$02
    beq yes_4
    jmp join_6
yes_4:
    lda prefix
    cmp VALUE_PREFIX_NONE
    beq yes_7
    jmp join_9
yes_7:
    lda addend
    sta __v18
    lda addend+1
    sta __v18+1
    lda __v18+1
    cmp #$00
    bne join_9
    lda __v18
    cmp #$00
    beq yes_10
    jmp join_9
yes_10:
    lda symbol
    sta __call_stage_plain_word_reference_0
    lda symbol+1
    sta __call_stage_plain_word_reference_0+1
    jsr stage_plain_word_reference
    rts
join_9:
    lda #$00
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_13
    jmp join_15
yes_13:
    lda status
    rts
join_15:
    lda #$00
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_16
    jmp join_18
yes_16:
    lda status
    rts
join_18:
    lda FIXUP_WORD
    sta __call_append_fixup_0
    lda stage
    sta __call_append_fixup_1
    lda stage+1
    sta __call_append_fixup_1+1
    lda symbol
    sta __call_append_fixup_2
    lda symbol+1
    sta __call_append_fixup_2+1
    lda addend
    sta __call_append_fixup_3
    lda addend+1
    sta __call_append_fixup_3+1
    lda prefix
    sta __call_append_fixup_4
    jsr append_fixup
    rts
join_6:
    lda width
    cmp #$01
    bne yes_19
    jmp join_21
yes_19:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_21:
    lda #$00
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_22
    jmp join_24
yes_22:
    lda status
    rts
join_24:
    lda FIXUP_BYTE
    sta kind
    lda mode
    cmp MODE_RELATIVE
    beq yes_25
    jmp join_27
yes_25:
    lda FIXUP_RELATIVE
    sta kind
join_27:
    lda kind
    sta __call_append_fixup_0
    lda stage
    sta __call_append_fixup_1
    lda stage+1
    sta __call_append_fixup_1+1
    lda symbol
    sta __call_append_fixup_2
    lda symbol+1
    sta __call_append_fixup_2+1
    lda addend
    sta __call_append_fixup_3
    lda addend+1
    sta __call_append_fixup_3+1
    lda prefix
    sta __call_append_fixup_4
    jsr append_fixup
    rts
