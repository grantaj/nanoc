entry:
    lda length
    cmp #$00
    beq yes_1
    jmp join_3
yes_1:
    sec
    lda #$00
    sbc #$01
    sta __v4
    lda #$00
    sbc #$00
    sta __v4+1
    lda __v4
    ldx __v4+1
    rts
join_3:
    ldy #$00
    lda name
    sta __ap
    lda name+1
    sta __ap+1
    lda (__ap),y
    sta __v7
    lda __v7
    cmp #$2e
    beq yes_4
    jmp join_6
yes_4:
    lda current_scope
    cmp #$00
    beq yes_7
    jmp join_9
yes_7:
    sec
    lda #$00
    sbc #$01
    sta __v14
    lda #$00
    sbc #$00
    sta __v14+1
    lda __v14
    ldx __v14+1
    rts
join_9:
    lda current_scope
    ldx #$00
    rts
join_6:
    lda #$00
    ldx #$00
    rts
