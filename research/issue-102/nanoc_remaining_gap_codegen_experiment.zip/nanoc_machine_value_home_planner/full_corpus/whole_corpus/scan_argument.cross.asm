entry:
    lda start
    sta i
    lda #$00
    sta quote
    lda start
    sta last
while_1:
    lda i
    cmp source_line_length
    bcc body_2
    jmp after_3
body_2:
    ldy i
    lda source_line,y
    sta c
    lda c
    cmp #$3b
    beq yes_4
    jmp no_5
yes_4:
    lda quote
    cmp #$00
    beq yes_7
    jmp no_8
yes_7:
    lda source_line_length
    sta i
    jmp while_1
no_8:
    lda i
    clc
    adc #$01
    sta last
    inc i
    jmp while_1
no_5:
    lda c
    cmp #$27
    beq yes_10
    jmp no_11
yes_10:
    lda quote
    cmp #$00
    beq yes_13
    jmp no_14
yes_13:
    lda #$27
    sta quote
    jmp join_15
no_14:
    lda quote
    cmp #$27
    beq yes_16
    jmp join_15
yes_16:
    lda #$00
    sta quote
join_15:
    lda i
    clc
    adc #$01
    sta last
    jmp join_12
no_11:
    lda c
    cmp #$22
    beq yes_19
    jmp no_20
yes_19:
    lda quote
    cmp #$00
    beq yes_22
    jmp no_23
yes_22:
    lda #$22
    sta quote
    jmp join_24
no_23:
    lda quote
    cmp #$22
    beq yes_25
    jmp join_24
yes_25:
    lda #$00
    sta quote
join_24:
    lda i
    clc
    adc #$01
    sta last
    jmp join_12
no_20:
    lda c
    cmp #$20
    bne yes_28
    jmp join_12
yes_28:
    lda c
    cmp #$09
    bne yes_31
    jmp join_12
yes_31:
    lda i
    clc
    adc #$01
    sta last
join_12:
    inc i
    jmp while_1
after_3:
    lda last
    sec
    sbc start
    sta __v64
    lda #$00
    sbc #$00
    sta __v64+1
    lda __v64
    ldx __v64+1
    rts
