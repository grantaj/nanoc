entry:
    lda #$00
    sta cursor
while_1:
    lda cursor
    cmp length
    bcc while_4
    jmp after_3
while_4:
    lda cursor
    cmp length
    bcc body_5
    jmp after_6
body_5:
    ldy cursor
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda (__ap),y
    sta c
    lda c
    cmp #$20
    beq yes_7
    jmp no_8
yes_7:
    inc cursor
    jmp while_4
no_8:
    lda c
    cmp #$09
    beq yes_10
    jmp after_6
yes_10:
    inc cursor
    jmp while_4
after_6:
    lda cursor
    cmp length
    bcs yes_13
    jmp join_15
yes_13:
    lda ASSEMBLE_BAD_DATA
    rts
join_15:
    lda cursor
    sta item_start
    lda cursor
    sta item_end
while_16:
    lda cursor
    cmp length
    bcc body_17
    jmp after_18
body_17:
    ldy cursor
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda (__ap),y
    sta c
    lda c
    cmp #$2c
    beq after_18
    jmp join_21
join_21:
    lda c
    cmp #$20
    bne yes_22
    jmp join_24
yes_22:
    lda c
    cmp #$09
    bne yes_25
    jmp join_24
yes_25:
    lda cursor
    clc
    adc #$01
    sta item_end
join_24:
    inc cursor
    jmp while_16
after_18:
    lda item_end
    cmp item_start
    beq yes_28
    jmp join_30
yes_28:
    lda ASSEMBLE_BAD_DATA
    rts
join_30:
    lda argument
    clc
    adc item_start
    sta __call_stage_data_value_0
    lda argument+1
    adc #$00
    sta __call_stage_data_value_0+1
    lda item_end
    sec
    sbc item_start
    sta __v58
    lda #$00
    sbc #$00
    sta __v58+1
    lda __v58
    sta __call_stage_data_value_1
    lda width
    sta __call_stage_data_value_2
    jsr stage_data_value
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_31
    jmp join_33
yes_31:
    lda status
    rts
join_33:
    lda cursor
    cmp length
    bcs yes_34
    jmp join_36
yes_34:
    lda ASSEMBLE_OK
    rts
join_36:
    inc cursor
    lda cursor
    cmp length
    bcs yes_37
    jmp while_1
yes_37:
    lda ASSEMBLE_BAD_DATA
    rts
after_3:
    lda ASSEMBLE_OK
    rts
