entry:
    lda #$00
    sta source_line_length
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda source_depth
    sta __ix
    lda source_depth+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta handle
while_1:
    lda #$01
    ora #$00
    bne body_2
    jmp after_3
body_2:
    lda handle
    sta __call_io_read_0
    lda #$00
    sta __call_io_read_0+1
    jsr io_read
    sta c
    stx c+1
    lda #$00
    eor #$80
    sta __rh
    lda c+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda c
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp yes_4
__sel2:
    jmp join_6
__sel3:
    jmp join_6
yes_4:
    sec
    lda #$00
    sbc #$01
    sta __v12
    lda #$00
    sbc #$00
    sta __v12+1
    lda c+1
    cmp __v12+1
    bne join_9
    lda c
    cmp __v12
    beq yes_7
    jmp join_9
yes_7:
    lda source_line_length
    cmp #$00
    bne yes_10
    jmp join_12
yes_10:
    ldy source_line_length
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
join_12:
    lda #$00
    ldx #$00
    rts
join_9:
    sec
    lda #$00
    sbc #$01
    sta __v23
    lda #$00
    sbc #$00
    sta __v23+1
    lda __v23
    ldx __v23+1
    rts
join_6:
    lda c+1
    cmp #$00
    bne join_15
    lda c
    cmp #$0d
    beq yes_13
    jmp join_15
yes_13:
    ldy source_line_length
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
join_15:
    lda c+1
    cmp #$00
    bne join_18
    lda c
    cmp #$0a
    beq yes_16
    jmp join_18
yes_16:
    ldy source_line_length
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
join_18:
    lda source_line_length
    cmp #$ff
    bcs yes_19
    jmp join_21
yes_19:
    sec
    lda #$00
    sbc #$02
    sta __v42
    lda #$00
    sbc #$00
    sta __v42+1
    lda __v42
    ldx __v42+1
    rts
join_21:
    ldy source_line_length
    lda c
    sta source_line,y
    inc source_line_length
    jmp while_1
after_3:
    lda #$00
    ldx #$00
    rts
