entry:
    lda ass_origin
    clc
    adc ass_image_length
    sta __v2
    lda ass_origin+1
    adc ass_image_length+1
    sta __v2+1
    lda __v2
    clc
    adc #$02
    sta __v4
    lda __v2+1
    adc #$00
    sta __v4+1
    lda __v4
    sta __v6
    lda __v4+1
    sta __v6+1
    lda __v6
    sta base
    lda __v6+1
    sta base+1
    lda target
    sta __call_relative_byte_0
    lda target+1
    sta __call_relative_byte_0+1
    lda base
    sta __call_relative_byte_1
    lda base+1
    sta __call_relative_byte_1+1
    jsr relative_byte
    sta relative
    stx relative+1
    lda #$00
    eor #$80
    sta __rh
    lda relative+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda relative
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp yes_1
__sel2:
    jmp join_3
__sel3:
    jmp join_3
yes_1:
    lda ASSEMBLE_EMIT_ERROR
    rts
join_3:
    lda opcode
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_4
    jmp join_6
yes_4:
    lda status
    rts
join_6:
    lda relative
    sta __call_stage_byte_0
    jsr stage_byte
    rts
