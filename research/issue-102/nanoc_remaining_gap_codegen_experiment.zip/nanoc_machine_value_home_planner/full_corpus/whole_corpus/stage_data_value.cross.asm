entry:
    lda text
    sta __call_parse_value_0
    lda text+1
    sta __call_parse_value_0+1
    lda length
    sta __call_parse_value_1
    jsr parse_value
    sta status
    lda status
    cmp VALUE_OK
    beq yes_1
    jmp join_3
yes_1:
    lda width
    cmp #$01
    beq yes_4
    jmp join_6
yes_4:
    lda value_result+1
    cmp #$00
    bcc __sel1
    bne __sel2
    lda value_result
    cmp #$ff
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp join_9
__sel2:
    jmp yes_7
__sel3:
    jmp join_9
yes_7:
    lda ASSEMBLE_BAD_DATA
    rts
join_9:
    lda value_result
    sta __call_stage_byte_0
    jsr stage_byte
    rts
join_6:
    lda value_result
    and #$ff
    sta __v17
    lda value_result+1
    and #$00
    sta __v17+1
    lda __v17
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_10
    jmp join_12
yes_10:
    lda status
    rts
join_12:
    lda value_result
    sta __v25
    lda value_result+1
    sta __v25+1
    lsr __v25+1
    ror __v25
    lsr __v25+1
    ror __v25
    lsr __v25+1
    ror __v25
    lsr __v25+1
    ror __v25
    lsr __v25+1
    ror __v25
    lsr __v25+1
    ror __v25
    lsr __v25+1
    ror __v25
    lsr __v25+1
    ror __v25
    lda __v25
    and #$ff
    sta __v27
    lda __v25+1
    and #$00
    sta __v27+1
    lda __v27
    sta __call_stage_byte_0
    jsr stage_byte
    rts
join_3:
    lda status
    cmp VALUE_UNRESOLVED
    beq yes_13
    jmp join_15
yes_13:
    lda width
    cmp #$02
    beq yes_16
    jmp join_18
yes_16:
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    beq yes_19
    jmp join_18
yes_19:
    lda captured_addend
    sta __v40
    lda captured_addend+1
    sta __v40+1
    lda __v40+1
    cmp #$00
    bne join_18
    lda __v40
    cmp #$00
    beq yes_22
    jmp join_18
yes_22:
    lda captured_symbol
    sta __call_stage_plain_word_reference_0
    lda captured_symbol+1
    sta __call_stage_plain_word_reference_0+1
    jsr stage_plain_word_reference
    rts
join_18:
    lda ass_image_length
    sta stage
    lda ass_image_length+1
    sta stage+1
    lda #$00
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_25
    jmp join_27
yes_25:
    lda status
    rts
join_27:
    lda width
    cmp #$02
    beq yes_28
    jmp no_29
yes_28:
    lda #$00
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_31
    jmp join_33
yes_31:
    lda status
    rts
join_33:
    lda FIXUP_WORD
    sta kind
    jmp join_30
no_29:
    lda FIXUP_DATA_BYTE
    sta kind
join_30:
    lda kind
    sta __call_append_fixup_0
    lda stage
    sta __call_append_fixup_1
    lda stage+1
    sta __call_append_fixup_1+1
    lda captured_symbol
    sta __call_append_fixup_2
    lda captured_symbol+1
    sta __call_append_fixup_2+1
    lda captured_addend
    sta __call_append_fixup_3
    lda captured_addend+1
    sta __call_append_fixup_3+1
    lda captured_prefix
    sta __call_append_fixup_4
    jsr append_fixup
    rts
join_15:
    lda status
    cmp VALUE_SYMBOL_FULL
    beq yes_34
    jmp join_36
yes_34:
    lda ASSEMBLE_SYMBOL_FULL
    rts
join_36:
    lda status
    cmp VALUE_SCOPE_ERROR
    beq yes_37
    jmp join_39
yes_37:
    lda ASSEMBLE_SCOPE_ERROR
    rts
join_39:
    lda ASSEMBLE_BAD_DATA
    rts
