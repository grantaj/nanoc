* = $0800
__ap = $0010
__ix = $0012
__mw = $0015
__rh = $0014
SYMBOL_LABEL_UNDEFINED = $4000
VALUE_BAD = $4002
VALUE_OK = $4004
VALUE_SCOPE_ERROR = $4006
VALUE_SYMBOL_FULL = $4008
VALUE_UNRESOLVED = $400a
__L_parse_atom_digit = $400c
__L_parse_atom_i = $400e
__L_parse_atom_length = $4010
__L_parse_atom_symbol = $4012
__L_parse_atom_text = $4014
__L_parse_atom_value = $4016
__T_parse_atom___v120 = $4018
__T_parse_atom___v124 = $401a
__T_parse_atom___v126 = $401c
__T_parse_atom___v128 = $401e
__T_parse_atom___v144 = $4020
__T_parse_atom___v162 = $4022
__T_parse_atom___v163 = $4024
__T_parse_atom___v167 = $4026
__T_parse_atom___v17 = $4028
__T_parse_atom___v173 = $402a
__T_parse_atom___v174 = $402c
__T_parse_atom___v178 = $402e
__T_parse_atom___v183 = $4030
__T_parse_atom___v192 = $4032
__T_parse_atom___v39 = $4034
__T_parse_atom___v41 = $4036
__T_parse_atom___v43 = $4038
__T_parse_atom___v7 = $403a
__T_parse_atom___v71 = $403c
__T_parse_atom___v77 = $403e
__T_parse_atom___v98 = $4040
__call_find_symbol_0 = $4042
__call_find_symbol_1 = $4044
__call_hex_nibble_0 = $4046
__call_intern_label_0 = $4048
__call_intern_label_1 = $404a
atom_kind = $404c
atom_symbol = $404e
atom_used = $4050
atom_value = $4052
find_symbol = $4054
hex_nibble = $4056
intern_label = $4058
symbol_kind = $405a
symbol_payload = $405c
parse_atom:
__F_parse_atom_entry:
    lda #$00
    sta atom_used
    lda __L_parse_atom_length
    cmp #$00
    beq __F_parse_atom_yes_1
    jmp __F_parse_atom_join_3
__F_parse_atom_yes_1:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_3:
    ldy #$00
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
    lda (__ap),y
    sta __T_parse_atom___v7
    cmp #$24
    beq __F_parse_atom_yes_4
    jmp __F_parse_atom_join_6
__F_parse_atom_yes_4:
    lda #$01
    sta __L_parse_atom_i
    lda #$00
    sta __L_parse_atom_value
    lda #$00
    sta __L_parse_atom_value+1
__F_parse_atom_while_7:
    lda __L_parse_atom_i
    cmp __L_parse_atom_length
    bcc __F_parse_atom_body_8
    jmp __F_parse_atom_after_9
__F_parse_atom_body_8:
    ldy __L_parse_atom_i
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
    lda (__ap),y
    sta __T_parse_atom___v17
    cmp #$2b
    bne __F_parse_atom___far_skip_0
    jmp __F_parse_atom_after_9
__F_parse_atom___far_skip_0:
    jmp __F_parse_atom_no_11
__F_parse_atom_no_11:
    cmp #$2d
    bne __F_parse_atom___far_skip_1
    jmp __F_parse_atom_after_9
__F_parse_atom___far_skip_1:
    jmp __F_parse_atom_no_14
__F_parse_atom_no_14:
    lda __T_parse_atom___v17
    sta __call_hex_nibble_0
    jsr hex_nibble
    sta __L_parse_atom_digit
    stx __L_parse_atom_digit+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_parse_atom_digit+1
    eor #$80
    cmp __rh
    bcc __F_parse_atom___sel1
    bne __F_parse_atom___sel2
    lda __L_parse_atom_digit
    cmp #$00
    bcc __F_parse_atom___sel1
    bne __F_parse_atom___sel2
    jmp __F_parse_atom___sel3
__F_parse_atom___sel1:
    jmp __F_parse_atom_yes_16
__F_parse_atom___sel2:
    jmp __F_parse_atom_join_18
__F_parse_atom___sel3:
    jmp __F_parse_atom_join_18
__F_parse_atom_yes_16:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_18:
    lda atom_used
    cmp #$04
    bcs __F_parse_atom_yes_19
    jmp __F_parse_atom_join_21
__F_parse_atom_yes_19:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_21:
    lda __L_parse_atom_value
    sta __T_parse_atom___v39
    lda __L_parse_atom_value+1
    sta __T_parse_atom___v39+1
    asl __T_parse_atom___v39
    rol __T_parse_atom___v39+1
    asl __T_parse_atom___v39
    rol __T_parse_atom___v39+1
    asl __T_parse_atom___v39
    rol __T_parse_atom___v39+1
    asl __T_parse_atom___v39
    rol __T_parse_atom___v39+1
    lda __T_parse_atom___v39
    ora __L_parse_atom_digit
    sta __T_parse_atom___v41
    lda __T_parse_atom___v39+1
    ora __L_parse_atom_digit+1
    sta __T_parse_atom___v41+1
    lda __T_parse_atom___v41
    sta __T_parse_atom___v43
    lda __T_parse_atom___v41+1
    sta __T_parse_atom___v43+1
    lda __T_parse_atom___v43
    sta __L_parse_atom_value
    lda __T_parse_atom___v43+1
    sta __L_parse_atom_value+1
    inc atom_used
    inc __L_parse_atom_i
    jmp __F_parse_atom_while_7
__F_parse_atom_after_9:
    lda atom_used
    cmp #$00
    beq __F_parse_atom_yes_22
    jmp __F_parse_atom_join_24
__F_parse_atom_yes_22:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_24:
    inc atom_used
    lda __L_parse_atom_value
    sta atom_value
    lda __L_parse_atom_value+1
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    ldx #$00
    rts
__F_parse_atom_join_6:
    cmp #$27
    beq __F_parse_atom_yes_25
    jmp __F_parse_atom_join_27
__F_parse_atom_yes_25:
    lda __L_parse_atom_length
    cmp #$03
    bcc __F_parse_atom_yes_28
    jmp __F_parse_atom_join_30
__F_parse_atom_yes_28:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_30:
    ldy #$02
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
    lda (__ap),y
    sta __T_parse_atom___v71
    cmp #$27
    bne __F_parse_atom_yes_31
    jmp __F_parse_atom_join_33
__F_parse_atom_yes_31:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_33:
    ldy #$01
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
    lda (__ap),y
    sta __T_parse_atom___v77
    lda __T_parse_atom___v77
    sta atom_value
    lda #$00
    sta atom_value+1
    lda #$03
    sta atom_used
    lda #$00
    sta atom_kind
    lda VALUE_OK
    ldx #$00
    rts
__F_parse_atom_join_27:
    cmp #$30
    bcs __F_parse_atom_yes_34
    jmp __F_parse_atom_join_36
__F_parse_atom_yes_34:
    cmp #$39
    bcc __F_parse_atom_yes_37
    beq __F_parse_atom_yes_37
    jmp __F_parse_atom_join_36
__F_parse_atom_yes_37:
    lda #$00
    sta __L_parse_atom_i
    lda #$00
    sta __L_parse_atom_value
    lda #$00
    sta __L_parse_atom_value+1
    ldy __L_parse_atom_i
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
__F_parse_atom_while_40:
    cpy __L_parse_atom_length
    bcc __F_parse_atom_body_41
    jmp __F_parse_atom_after_42
__F_parse_atom_body_41:
    lda (__ap),y
    sta __T_parse_atom___v98
    cmp #$2b
    bne __F_parse_atom___far_skip_2
    jmp __F_parse_atom_after_42
__F_parse_atom___far_skip_2:
    jmp __F_parse_atom_no_44
__F_parse_atom_no_44:
    cmp #$2d
    bne __F_parse_atom___far_skip_3
    jmp __F_parse_atom_after_42
__F_parse_atom___far_skip_3:
    jmp __F_parse_atom_no_47
__F_parse_atom_no_47:
    cmp #$30
    bcc __F_parse_atom_yes_49
    jmp __F_parse_atom_join_51
__F_parse_atom_yes_49:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_51:
    cmp #$39
    bcc __F_parse_atom_join_54
    beq __F_parse_atom_join_54
    jmp __F_parse_atom_yes_52
__F_parse_atom_yes_52:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_54:
    lda #$00
    sta __T_parse_atom___v120
    sta __T_parse_atom___v120+1
    lda __L_parse_atom_value
    sta __mw
    lda __L_parse_atom_value+1
    sta __mw+1
    asl __mw
    rol __mw+1
    clc
    lda __T_parse_atom___v120
    adc __mw
    sta __T_parse_atom___v120
    lda __T_parse_atom___v120+1
    adc __mw+1
    sta __T_parse_atom___v120+1
    asl __mw
    rol __mw+1
    asl __mw
    rol __mw+1
    clc
    lda __T_parse_atom___v120
    adc __mw
    sta __T_parse_atom___v120
    lda __T_parse_atom___v120+1
    adc __mw+1
    sta __T_parse_atom___v120+1
    lda __T_parse_atom___v120
    clc
    adc __T_parse_atom___v98
    sta __T_parse_atom___v124
    lda __T_parse_atom___v120+1
    adc #$00
    sta __T_parse_atom___v124+1
    lda __T_parse_atom___v124
    sec
    sbc #$30
    sta __T_parse_atom___v126
    lda __T_parse_atom___v124+1
    sbc #$00
    sta __T_parse_atom___v126+1
    lda __T_parse_atom___v126
    sta __T_parse_atom___v128
    lda __T_parse_atom___v126+1
    sta __T_parse_atom___v128+1
    lda __T_parse_atom___v128
    sta __L_parse_atom_value
    lda __T_parse_atom___v128+1
    sta __L_parse_atom_value+1
    inc atom_used
    inc __L_parse_atom_i
    iny
    jmp __F_parse_atom_while_40
__F_parse_atom_after_42:
    lda __L_parse_atom_value
    sta atom_value
    lda __L_parse_atom_value+1
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    ldx #$00
    rts
__F_parse_atom_join_36:
    lda #$00
    sta __L_parse_atom_i
    ldy __L_parse_atom_i
    lda __L_parse_atom_text
    sta __ap
    lda __L_parse_atom_text+1
    sta __ap+1
__F_parse_atom_while_55:
    cpy __L_parse_atom_length
    bcc __F_parse_atom_body_56
    jmp __F_parse_atom_after_57
__F_parse_atom_body_56:
    lda (__ap),y
    sta __T_parse_atom___v144
    cmp #$2b
    beq __F_parse_atom_after_57
    jmp __F_parse_atom_no_59
__F_parse_atom_no_59:
    cmp #$2d
    beq __F_parse_atom_after_57
    jmp __F_parse_atom_no_62
__F_parse_atom_no_62:
    inc atom_used
    inc __L_parse_atom_i
    iny
    jmp __F_parse_atom_while_55
__F_parse_atom_after_57:
    lda atom_used
    cmp #$00
    beq __F_parse_atom_yes_64
    jmp __F_parse_atom_join_66
__F_parse_atom_yes_64:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_66:
    lda __L_parse_atom_text
    sta __T_parse_atom___v162
    lda __L_parse_atom_text+1
    sta __T_parse_atom___v162+1
    lda atom_used
    sta __T_parse_atom___v163
    lda __T_parse_atom___v162
    sta __call_find_symbol_0
    lda __T_parse_atom___v162+1
    sta __call_find_symbol_0+1
    lda __T_parse_atom___v163
    sta __call_find_symbol_1
    jsr find_symbol
    sta __L_parse_atom_symbol
    stx __L_parse_atom_symbol+1
    sec
    lda #$00
    sbc #$02
    sta __T_parse_atom___v167
    lda #$00
    sbc #$00
    sta __T_parse_atom___v167+1
    lda __L_parse_atom_symbol+1
    cmp __T_parse_atom___v167+1
    bne __F_parse_atom_join_69
    lda __L_parse_atom_symbol
    cmp __T_parse_atom___v167
    beq __F_parse_atom_yes_67
    jmp __F_parse_atom_join_69
__F_parse_atom_yes_67:
    lda VALUE_SCOPE_ERROR
    ldx #$00
    rts
__F_parse_atom_join_69:
    lda #$00
    eor #$80
    sta __rh
    lda __L_parse_atom_symbol+1
    eor #$80
    cmp __rh
    bcc __F_parse_atom___sel4
    bne __F_parse_atom___sel5
    lda __L_parse_atom_symbol
    cmp #$00
    bcc __F_parse_atom___sel4
    bne __F_parse_atom___sel5
    jmp __F_parse_atom___sel6
__F_parse_atom___sel4:
    jmp __F_parse_atom_yes_70
__F_parse_atom___sel5:
    jmp __F_parse_atom_join_72
__F_parse_atom___sel6:
    jmp __F_parse_atom_join_72
__F_parse_atom_yes_70:
    lda __L_parse_atom_text
    sta __T_parse_atom___v173
    lda __L_parse_atom_text+1
    sta __T_parse_atom___v173+1
    lda atom_used
    sta __T_parse_atom___v174
    lda __T_parse_atom___v173
    sta __call_intern_label_0
    lda __T_parse_atom___v173+1
    sta __call_intern_label_0+1
    lda __T_parse_atom___v174
    sta __call_intern_label_1
    jsr intern_label
    sta __L_parse_atom_symbol
    stx __L_parse_atom_symbol+1
    sec
    lda #$00
    sbc #$02
    sta __T_parse_atom___v178
    lda #$00
    sbc #$00
    sta __T_parse_atom___v178+1
    lda __L_parse_atom_symbol+1
    cmp __T_parse_atom___v178+1
    bne __F_parse_atom_join_75
    lda __L_parse_atom_symbol
    cmp __T_parse_atom___v178
    beq __F_parse_atom_yes_73
    jmp __F_parse_atom_join_75
__F_parse_atom_yes_73:
    lda VALUE_SCOPE_ERROR
    ldx #$00
    rts
__F_parse_atom_join_75:
    sec
    lda #$00
    sbc #$03
    sta __T_parse_atom___v183
    lda #$00
    sbc #$00
    sta __T_parse_atom___v183+1
    lda __L_parse_atom_symbol+1
    cmp __T_parse_atom___v183+1
    bne __F_parse_atom_join_78
    lda __L_parse_atom_symbol
    cmp __T_parse_atom___v183
    beq __F_parse_atom_yes_76
    jmp __F_parse_atom_join_78
__F_parse_atom_yes_76:
    lda VALUE_SYMBOL_FULL
    ldx #$00
    rts
__F_parse_atom_join_78:
    lda #$00
    eor #$80
    sta __rh
    lda __L_parse_atom_symbol+1
    eor #$80
    cmp __rh
    bcc __F_parse_atom___sel7
    bne __F_parse_atom___sel8
    lda __L_parse_atom_symbol
    cmp #$00
    bcc __F_parse_atom___sel7
    bne __F_parse_atom___sel8
    jmp __F_parse_atom___sel9
__F_parse_atom___sel7:
    jmp __F_parse_atom_yes_79
__F_parse_atom___sel8:
    jmp __F_parse_atom_join_72
__F_parse_atom___sel9:
    jmp __F_parse_atom_join_72
__F_parse_atom_yes_79:
    lda VALUE_BAD
    ldx #$00
    rts
__F_parse_atom_join_72:
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda __L_parse_atom_symbol
    sta __ix
    lda __L_parse_atom_symbol+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_parse_atom___v192
    cmp SYMBOL_LABEL_UNDEFINED
    beq __F_parse_atom_yes_82
    jmp __F_parse_atom_join_84
__F_parse_atom_yes_82:
    lda __L_parse_atom_symbol
    sta atom_symbol
    lda __L_parse_atom_symbol+1
    sta atom_symbol+1
    lda #$01
    sta atom_kind
    lda VALUE_UNRESOLVED
    ldx #$00
    rts
__F_parse_atom_join_84:
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __L_parse_atom_symbol
    asl
    sta __ix
    lda __L_parse_atom_symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta atom_value
    iny
    lda (__ap),y
    sta atom_value+1
    lda #$00
    sta atom_kind
    lda VALUE_OK
    ldx #$00
    rts
