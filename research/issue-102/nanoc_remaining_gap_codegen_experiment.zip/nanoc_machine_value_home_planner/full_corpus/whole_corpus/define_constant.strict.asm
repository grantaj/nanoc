* = $0800
__rh = $0014
ASSEMBLE_BAD_SYMBOL = $4000
ASSEMBLE_OK = $4002
ASSEMBLE_SCOPE_ERROR = $4004
ASSEMBLE_SYMBOL_FULL = $4006
SYMBOL_CONSTANT = $4008
__L_define_constant_length = $400a
__L_define_constant_name = $400c
__L_define_constant_symbol = $400e
__L_define_constant_value = $4010
__T_define_constant___v0 = $4012
__T_define_constant___v1 = $4014
__T_define_constant___v12 = $4016
__T_define_constant___v13 = $4018
__T_define_constant___v14 = $401a
__T_define_constant___v15 = $401c
__T_define_constant___v19 = $401e
__T_define_constant___v9 = $4020
__call_allocate_symbol_0 = $4022
__call_allocate_symbol_1 = $4024
__call_allocate_symbol_2 = $4026
__call_allocate_symbol_3 = $4028
__call_find_symbol_0 = $402a
__call_find_symbol_1 = $402c
allocate_symbol = $402e
find_symbol = $4030
define_constant:
__F_define_constant_entry:
    lda __L_define_constant_name
    sta __T_define_constant___v0
    lda __L_define_constant_name+1
    sta __T_define_constant___v0+1
    lda __L_define_constant_length
    sta __T_define_constant___v1
    lda __T_define_constant___v0
    sta __call_find_symbol_0
    lda __T_define_constant___v0+1
    sta __call_find_symbol_0+1
    lda __T_define_constant___v1
    sta __call_find_symbol_1
    jsr find_symbol
    sta __L_define_constant_symbol
    stx __L_define_constant_symbol+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_define_constant_symbol+1
    eor #$80
    cmp __rh
    bcc __F_define_constant___sel1
    bne __F_define_constant___sel2
    lda __L_define_constant_symbol
    cmp #$00
    bcc __F_define_constant___sel1
    bne __F_define_constant___sel2
    jmp __F_define_constant___sel3
__F_define_constant___sel1:
    jmp __F_define_constant_join_3
__F_define_constant___sel2:
    jmp __F_define_constant_yes_1
__F_define_constant___sel3:
    jmp __F_define_constant_yes_1
__F_define_constant_yes_1:
    lda ASSEMBLE_BAD_SYMBOL
    ldx #$00
    rts
__F_define_constant_join_3:
    sec
    lda #$00
    sbc #$02
    sta __T_define_constant___v9
    lda #$00
    sbc #$00
    sta __T_define_constant___v9+1
    lda __L_define_constant_symbol+1
    cmp __T_define_constant___v9+1
    bne __F_define_constant_join_6
    lda __L_define_constant_symbol
    cmp __T_define_constant___v9
    beq __F_define_constant_yes_4
    jmp __F_define_constant_join_6
__F_define_constant_yes_4:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_define_constant_join_6:
    lda __L_define_constant_name
    sta __T_define_constant___v12
    lda __L_define_constant_name+1
    sta __T_define_constant___v12+1
    lda __L_define_constant_length
    sta __T_define_constant___v13
    lda SYMBOL_CONSTANT
    sta __T_define_constant___v14
    lda __L_define_constant_value
    sta __T_define_constant___v15
    lda __L_define_constant_value+1
    sta __T_define_constant___v15+1
    lda __T_define_constant___v12
    sta __call_allocate_symbol_0
    lda __T_define_constant___v12+1
    sta __call_allocate_symbol_0+1
    lda __T_define_constant___v13
    sta __call_allocate_symbol_1
    lda __T_define_constant___v14
    sta __call_allocate_symbol_2
    lda __T_define_constant___v15
    sta __call_allocate_symbol_3
    lda __T_define_constant___v15+1
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    sta __L_define_constant_symbol
    stx __L_define_constant_symbol+1
    sec
    lda #$00
    sbc #$02
    sta __T_define_constant___v19
    lda #$00
    sbc #$00
    sta __T_define_constant___v19+1
    lda __L_define_constant_symbol+1
    cmp __T_define_constant___v19+1
    bne __F_define_constant_join_9
    lda __L_define_constant_symbol
    cmp __T_define_constant___v19
    beq __F_define_constant_yes_7
    jmp __F_define_constant_join_9
__F_define_constant_yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_define_constant_join_9:
    lda #$00
    eor #$80
    sta __rh
    lda __L_define_constant_symbol+1
    eor #$80
    cmp __rh
    bcc __F_define_constant___sel4
    bne __F_define_constant___sel5
    lda __L_define_constant_symbol
    cmp #$00
    bcc __F_define_constant___sel4
    bne __F_define_constant___sel5
    jmp __F_define_constant___sel6
__F_define_constant___sel4:
    jmp __F_define_constant_yes_10
__F_define_constant___sel5:
    jmp __F_define_constant_join_12
__F_define_constant___sel6:
    jmp __F_define_constant_join_12
__F_define_constant_yes_10:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_define_constant_join_12:
    lda ASSEMBLE_OK
    ldx #$00
    rts
