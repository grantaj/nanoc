* = $0800
ASSEMBLE_BAD_DATA = $4000
ASSEMBLE_OK = $4002
ASSEMBLE_SCOPE_ERROR = $4004
ASSEMBLE_SYMBOL_FULL = $4006
FIXUP_DATA_BYTE = $4008
FIXUP_WORD = $400a
VALUE_OK = $400c
VALUE_PREFIX_NONE = $400e
VALUE_SCOPE_ERROR = $4010
VALUE_SYMBOL_FULL = $4012
VALUE_UNRESOLVED = $4014
__L_stage_data_value_kind = $4016
__L_stage_data_value_length = $4018
__L_stage_data_value_stage = $401a
__L_stage_data_value_status = $401c
__L_stage_data_value_text = $401e
__L_stage_data_value_width = $4020
__T_stage_data_value___v0 = $4022
__T_stage_data_value___v1 = $4024
__T_stage_data_value___v13 = $4026
__T_stage_data_value___v17 = $4028
__T_stage_data_value___v25 = $402a
__T_stage_data_value___v27 = $402c
__T_stage_data_value___v40 = $402e
__T_stage_data_value___v43 = $4030
__T_stage_data_value___v63 = $4032
__T_stage_data_value___v64 = $4034
__T_stage_data_value___v65 = $4036
__T_stage_data_value___v66 = $4038
__T_stage_data_value___v67 = $403a
__call_append_fixup_0 = $403c
__call_append_fixup_1 = $403e
__call_append_fixup_2 = $4040
__call_append_fixup_3 = $4042
__call_append_fixup_4 = $4044
__call_parse_value_0 = $4046
__call_parse_value_1 = $4048
__call_stage_byte_0 = $404a
__call_stage_plain_word_reference_0 = $404c
append_fixup = $404e
ass_image_length = $4050
captured_addend = $4052
captured_prefix = $4054
captured_symbol = $4056
parse_value = $4058
stage_byte = $405a
stage_plain_word_reference = $405c
value_result = $405e
stage_data_value:
__F_stage_data_value_entry:
    lda __L_stage_data_value_text
    sta __T_stage_data_value___v0
    lda __L_stage_data_value_text+1
    sta __T_stage_data_value___v0+1
    lda __L_stage_data_value_length
    sta __T_stage_data_value___v1
    lda __T_stage_data_value___v0
    sta __call_parse_value_0
    lda __T_stage_data_value___v0+1
    sta __call_parse_value_0+1
    lda __T_stage_data_value___v1
    sta __call_parse_value_1
    jsr parse_value
    sta __L_stage_data_value_status
    lda __L_stage_data_value_status
    cmp VALUE_OK
    beq __F_stage_data_value_yes_1
    jmp __F_stage_data_value_join_3
__F_stage_data_value_yes_1:
    lda __L_stage_data_value_width
    cmp #$01
    beq __F_stage_data_value_yes_4
    jmp __F_stage_data_value_join_6
__F_stage_data_value_yes_4:
    lda value_result+1
    cmp #$00
    bcc __F_stage_data_value___sel1
    bne __F_stage_data_value___sel2
    lda value_result
    cmp #$ff
    bcc __F_stage_data_value___sel1
    bne __F_stage_data_value___sel2
    jmp __F_stage_data_value___sel3
__F_stage_data_value___sel1:
    jmp __F_stage_data_value_join_9
__F_stage_data_value___sel2:
    jmp __F_stage_data_value_yes_7
__F_stage_data_value___sel3:
    jmp __F_stage_data_value_join_9
__F_stage_data_value_yes_7:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_stage_data_value_join_9:
    lda value_result
    sta __T_stage_data_value___v13
    lda value_result+1
    sta __T_stage_data_value___v13+1
    lda __T_stage_data_value___v13
    sta __call_stage_byte_0
    lda __T_stage_data_value___v13+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    ldx #$00
    rts
__F_stage_data_value_join_6:
    lda value_result
    and #$ff
    sta __T_stage_data_value___v17
    lda value_result+1
    and #$00
    sta __T_stage_data_value___v17+1
    lda __T_stage_data_value___v17
    sta __call_stage_byte_0
    lda __T_stage_data_value___v17+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_data_value_status
    lda __L_stage_data_value_status
    cmp ASSEMBLE_OK
    bne __F_stage_data_value_yes_10
    jmp __F_stage_data_value_join_12
__F_stage_data_value_yes_10:
    lda __L_stage_data_value_status
    ldx #$00
    rts
__F_stage_data_value_join_12:
    lda value_result
    sta __T_stage_data_value___v25
    lda value_result+1
    sta __T_stage_data_value___v25+1
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lsr __T_stage_data_value___v25+1
    ror __T_stage_data_value___v25
    lda __T_stage_data_value___v25
    and #$ff
    sta __T_stage_data_value___v27
    lda __T_stage_data_value___v25+1
    and #$00
    sta __T_stage_data_value___v27+1
    lda __T_stage_data_value___v27
    sta __call_stage_byte_0
    lda __T_stage_data_value___v27+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    ldx #$00
    rts
__F_stage_data_value_join_3:
    lda __L_stage_data_value_status
    cmp VALUE_UNRESOLVED
    beq __F_stage_data_value_yes_13
    jmp __F_stage_data_value_join_15
__F_stage_data_value_yes_13:
    lda __L_stage_data_value_width
    cmp #$02
    beq __F_stage_data_value_yes_16
    jmp __F_stage_data_value_join_18
__F_stage_data_value_yes_16:
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    beq __F_stage_data_value_yes_19
    jmp __F_stage_data_value_join_18
__F_stage_data_value_yes_19:
    lda captured_addend
    sta __T_stage_data_value___v40
    lda captured_addend+1
    sta __T_stage_data_value___v40+1
    lda __T_stage_data_value___v40+1
    cmp #$00
    bne __F_stage_data_value_join_18
    lda __T_stage_data_value___v40
    cmp #$00
    beq __F_stage_data_value_yes_22
    jmp __F_stage_data_value_join_18
__F_stage_data_value_yes_22:
    lda captured_symbol
    sta __T_stage_data_value___v43
    lda captured_symbol+1
    sta __T_stage_data_value___v43+1
    lda __T_stage_data_value___v43
    sta __call_stage_plain_word_reference_0
    lda __T_stage_data_value___v43+1
    sta __call_stage_plain_word_reference_0+1
    jsr stage_plain_word_reference
    ldx #$00
    rts
__F_stage_data_value_join_18:
    lda ass_image_length
    sta __L_stage_data_value_stage
    lda ass_image_length+1
    sta __L_stage_data_value_stage+1
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_data_value_status
    lda __L_stage_data_value_status
    cmp ASSEMBLE_OK
    bne __F_stage_data_value_yes_25
    jmp __F_stage_data_value_join_27
__F_stage_data_value_yes_25:
    lda __L_stage_data_value_status
    ldx #$00
    rts
__F_stage_data_value_join_27:
    lda __L_stage_data_value_width
    cmp #$02
    beq __F_stage_data_value_yes_28
    jmp __F_stage_data_value_no_29
__F_stage_data_value_yes_28:
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_data_value_status
    lda __L_stage_data_value_status
    cmp ASSEMBLE_OK
    bne __F_stage_data_value_yes_31
    jmp __F_stage_data_value_join_33
__F_stage_data_value_yes_31:
    lda __L_stage_data_value_status
    ldx #$00
    rts
__F_stage_data_value_join_33:
    lda FIXUP_WORD
    sta __L_stage_data_value_kind
    jmp __F_stage_data_value_join_30
__F_stage_data_value_no_29:
    lda FIXUP_DATA_BYTE
    sta __L_stage_data_value_kind
__F_stage_data_value_join_30:
    lda __L_stage_data_value_kind
    sta __T_stage_data_value___v63
    lda __L_stage_data_value_stage
    sta __T_stage_data_value___v64
    lda __L_stage_data_value_stage+1
    sta __T_stage_data_value___v64+1
    lda captured_symbol
    sta __T_stage_data_value___v65
    lda captured_symbol+1
    sta __T_stage_data_value___v65+1
    lda captured_addend
    sta __T_stage_data_value___v66
    lda captured_addend+1
    sta __T_stage_data_value___v66+1
    lda captured_prefix
    sta __T_stage_data_value___v67
    lda __T_stage_data_value___v63
    sta __call_append_fixup_0
    lda __T_stage_data_value___v64
    sta __call_append_fixup_1
    lda __T_stage_data_value___v64+1
    sta __call_append_fixup_1+1
    lda __T_stage_data_value___v65
    sta __call_append_fixup_2
    lda __T_stage_data_value___v65+1
    sta __call_append_fixup_2+1
    lda __T_stage_data_value___v66
    sta __call_append_fixup_3
    lda __T_stage_data_value___v66+1
    sta __call_append_fixup_3+1
    lda __T_stage_data_value___v67
    sta __call_append_fixup_4
    jsr append_fixup
    ldx #$00
    rts
__F_stage_data_value_join_15:
    lda __L_stage_data_value_status
    cmp VALUE_SYMBOL_FULL
    beq __F_stage_data_value_yes_34
    jmp __F_stage_data_value_join_36
__F_stage_data_value_yes_34:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_stage_data_value_join_36:
    lda __L_stage_data_value_status
    cmp VALUE_SCOPE_ERROR
    beq __F_stage_data_value_yes_37
    jmp __F_stage_data_value_join_39
__F_stage_data_value_yes_37:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_stage_data_value_join_39:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
