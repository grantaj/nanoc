* = $0800
__L_hex_nibble_c = $4000
__T_hex_nibble___v0 = $4002
__T_hex_nibble___v10 = $4004
__T_hex_nibble___v19 = $4006
__T_hex_nibble___v21 = $4008
__T_hex_nibble___v23 = $400a
__call_upper_char_0 = $400c
upper_char = $400e
hex_nibble:
__F_hex_nibble_entry:
    lda __L_hex_nibble_c
    sta __T_hex_nibble___v0
    lda __T_hex_nibble___v0
    sta __call_upper_char_0
    jsr upper_char
    sta __L_hex_nibble_c
    lda __L_hex_nibble_c
    cmp #$30
    bcs __F_hex_nibble_yes_1
    jmp __F_hex_nibble_join_3
__F_hex_nibble_yes_1:
    lda __L_hex_nibble_c
    cmp #$39
    bcc __F_hex_nibble_yes_4
    beq __F_hex_nibble_yes_4
    jmp __F_hex_nibble_join_3
__F_hex_nibble_yes_4:
    lda __L_hex_nibble_c
    sec
    sbc #$30
    sta __T_hex_nibble___v10
    lda #$00
    sbc #$00
    sta __T_hex_nibble___v10+1
    lda __T_hex_nibble___v10
    ldx __T_hex_nibble___v10+1
    rts
__F_hex_nibble_join_3:
    lda __L_hex_nibble_c
    cmp #$41
    bcs __F_hex_nibble_yes_7
    jmp __F_hex_nibble_join_9
__F_hex_nibble_yes_7:
    lda __L_hex_nibble_c
    cmp #$46
    bcc __F_hex_nibble_yes_10
    beq __F_hex_nibble_yes_10
    jmp __F_hex_nibble_join_9
__F_hex_nibble_yes_10:
    lda __L_hex_nibble_c
    sec
    sbc #$41
    sta __T_hex_nibble___v19
    lda #$00
    sbc #$00
    sta __T_hex_nibble___v19+1
    lda __T_hex_nibble___v19
    clc
    adc #$0a
    sta __T_hex_nibble___v21
    lda __T_hex_nibble___v19+1
    adc #$00
    sta __T_hex_nibble___v21+1
    lda __T_hex_nibble___v21
    ldx __T_hex_nibble___v21+1
    rts
__F_hex_nibble_join_9:
    sec
    lda #$00
    sbc #$01
    sta __T_hex_nibble___v23
    lda #$00
    sbc #$00
    sta __T_hex_nibble___v23+1
    lda __T_hex_nibble___v23
    ldx __T_hex_nibble___v23+1
    rts
