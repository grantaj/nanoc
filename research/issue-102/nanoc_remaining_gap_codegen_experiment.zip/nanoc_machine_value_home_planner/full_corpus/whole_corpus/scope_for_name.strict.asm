* = $0800
__ap = $0010
__L_scope_for_name_length = $4000
__L_scope_for_name_name = $4002
__T_scope_for_name___v14 = $4004
__T_scope_for_name___v4 = $4006
__T_scope_for_name___v7 = $4008
current_scope = $400a
scope_for_name:
__F_scope_for_name_entry:
    lda __L_scope_for_name_length
    cmp #$00
    beq __F_scope_for_name_yes_1
    jmp __F_scope_for_name_join_3
__F_scope_for_name_yes_1:
    sec
    lda #$00
    sbc #$01
    sta __T_scope_for_name___v4
    lda #$00
    sbc #$00
    sta __T_scope_for_name___v4+1
    lda __T_scope_for_name___v4
    ldx __T_scope_for_name___v4+1
    rts
__F_scope_for_name_join_3:
    ldy #$00
    lda __L_scope_for_name_name
    sta __ap
    lda __L_scope_for_name_name+1
    sta __ap+1
    lda (__ap),y
    sta __T_scope_for_name___v7
    cmp #$2e
    beq __F_scope_for_name_yes_4
    jmp __F_scope_for_name_join_6
__F_scope_for_name_yes_4:
    lda current_scope
    cmp #$00
    beq __F_scope_for_name_yes_7
    jmp __F_scope_for_name_join_9
__F_scope_for_name_yes_7:
    sec
    lda #$00
    sbc #$01
    sta __T_scope_for_name___v14
    lda #$00
    sbc #$00
    sta __T_scope_for_name___v14+1
    lda __T_scope_for_name___v14
    ldx __T_scope_for_name___v14+1
    rts
__F_scope_for_name_join_9:
    lda current_scope
    ldx #$00
    rts
__F_scope_for_name_join_6:
    lda #$00
    ldx #$00
    rts
