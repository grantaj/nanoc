entry:
    ldy mode
    lda mode_width,y
    sta width
    lda width
    cmp #$01
    beq yes_1
    jmp join_3
yes_1:
    lda value+1
    cmp #$00
    bcc __sel1
    bne __sel2
    lda value
    cmp #$ff
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp join_3
__sel2:
    jmp yes_4
__sel3:
    jmp join_3
yes_4:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_3:
    lda opcode
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_7
    jmp join_9
yes_7:
    lda status
    rts
join_9:
    lda width
    cmp #$00
    beq yes_10
    jmp join_12
yes_10:
    lda ASSEMBLE_OK
    rts
join_12:
    lda value
    and #$ff
    sta __v22
    lda value+1
    and #$00
    sta __v22+1
    lda __v22
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_13
    jmp join_15
yes_13:
    lda status
    rts
join_15:
    lda width
    cmp #$02
    beq yes_16
    jmp join_18
yes_16:
    lda value
    sta __v33
    lda value+1
    sta __v33+1
    lsr __v33+1
    ror __v33
    lsr __v33+1
    ror __v33
    lsr __v33+1
    ror __v33
    lsr __v33+1
    ror __v33
    lsr __v33+1
    ror __v33
    lsr __v33+1
    ror __v33
    lsr __v33+1
    ror __v33
    lsr __v33+1
    ror __v33
    lda __v33
    and #$ff
    sta __v35
    lda __v33+1
    and #$00
    sta __v35+1
    lda __v35
    sta __call_stage_byte_0
    jsr stage_byte
    rts
join_18:
    lda ASSEMBLE_OK
    rts
