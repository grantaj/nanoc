* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
ASSEMBLE_BAD_DATA = $4000
ASSEMBLE_OK = $4002
__L_assemble_string_argument = $4004
__L_assemble_string_i = $4006
__L_assemble_string_length = $4008
__L_assemble_string_status = $400a
__T_assemble_string___v13 = $400c
__T_assemble_string___v14 = $400e
__T_assemble_string___v22 = $4010
__T_assemble_string___v6 = $4012
__call_stage_byte_0 = $4014
stage_byte = $4016
assemble_string:
__F_assemble_string_entry:
    lda __L_assemble_string_length
    cmp #$02
    bcc __F_assemble_string_yes_1
    jmp __F_assemble_string_join_3
__F_assemble_string_yes_1:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_string_join_3:
    ldy #$00
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    sta __ap+1
    lda (__ap),y
    sta __T_assemble_string___v6
    cmp #$22
    bne __F_assemble_string_yes_4
    jmp __F_assemble_string_join_6
__F_assemble_string_yes_4:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_string_join_6:
    lda __L_assemble_string_length
    sec
    sbc #$01
    sta __T_assemble_string___v13
    lda #$00
    sbc #$00
    sta __T_assemble_string___v13+1
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    sta __ap+1
    lda __T_assemble_string___v13
    sta __ix
    lda __T_assemble_string___v13+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_string___v14
    cmp #$22
    bne __F_assemble_string_yes_7
    jmp __F_assemble_string_join_9
__F_assemble_string_yes_7:
    lda ASSEMBLE_BAD_DATA
    ldx #$00
    rts
__F_assemble_string_join_9:
    lda #$01
    sta __L_assemble_string_i
__F_assemble_string_while_10:
    lda __L_assemble_string_length
    sec
    sbc #$01
    sta __T_assemble_string___v22
    lda #$00
    sbc #$00
    sta __T_assemble_string___v22+1
    lda __T_assemble_string___v22+1
    eor #$80
    sta __rh
    lda #$00
    eor #$80
    cmp __rh
    bcc __F_assemble_string___sel1
    bne __F_assemble_string___sel2
    lda __L_assemble_string_i
    cmp __T_assemble_string___v22
    bcc __F_assemble_string___sel1
    bne __F_assemble_string___sel2
    jmp __F_assemble_string___sel3
__F_assemble_string___sel1:
    jmp __F_assemble_string_body_11
__F_assemble_string___sel2:
    jmp __F_assemble_string_after_12
__F_assemble_string___sel3:
    jmp __F_assemble_string_after_12
__F_assemble_string_body_11:
    ldy __L_assemble_string_i
    lda __L_assemble_string_argument
    sta __ap
    lda __L_assemble_string_argument+1
    sta __ap+1
    lda (__ap),y
    sta __call_stage_byte_0
    jsr stage_byte
    sta __L_assemble_string_status
    lda __L_assemble_string_status
    cmp ASSEMBLE_OK
    bne __F_assemble_string_yes_13
    jmp __F_assemble_string_join_15
__F_assemble_string_yes_13:
    lda __L_assemble_string_status
    ldx #$00
    rts
__F_assemble_string_join_15:
    inc __L_assemble_string_i
    jmp __F_assemble_string_while_10
__F_assemble_string_after_12:
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    ldx #$00
    rts
