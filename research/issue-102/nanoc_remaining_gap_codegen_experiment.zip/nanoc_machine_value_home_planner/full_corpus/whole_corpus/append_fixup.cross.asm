entry:
    lda fixup_count
    sta n
    lda fixup_count+1
    sta n+1
    lda #$02
    eor #$80
    sta __rh
    lda n+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda n
    cmp #$80
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp join_3
__sel2:
    jmp yes_1
__sel3:
    jmp yes_1
yes_1:
    lda ASSEMBLE_WORK_FULL
    rts
join_3:
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda n
    sta __ix
    lda n+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda kind
    sta (__ap),y
    lda #<fixup_stage
    sta __ap
    lda #>fixup_stage
    sta __ap+1
    lda n
    asl
    sta __ix
    lda n+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda stage
    sta (__ap),y
    iny
    lda stage+1
    sta (__ap),y
    lda #<fixup_symbol
    sta __ap
    lda #>fixup_symbol
    sta __ap+1
    lda n
    asl
    sta __ix
    lda n+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda symbol
    sta (__ap),y
    iny
    lda symbol+1
    sta (__ap),y
    lda addend
    sta __v18
    lda addend+1
    sta __v18+1
    lda #<fixup_addend
    sta __ap
    lda #>fixup_addend
    sta __ap+1
    lda n
    asl
    sta __ix
    lda n+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __v18
    sta (__ap),y
    iny
    lda __v18+1
    sta (__ap),y
    lda #<fixup_prefix
    sta __ap
    lda #>fixup_prefix
    sta __ap+1
    lda n
    sta __ix
    lda n+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda prefix
    sta (__ap),y
    lda n
    clc
    adc #$01
    sta fixup_count
    lda n+1
    adc #$00
    sta fixup_count+1
    lda ASSEMBLE_OK
    rts
