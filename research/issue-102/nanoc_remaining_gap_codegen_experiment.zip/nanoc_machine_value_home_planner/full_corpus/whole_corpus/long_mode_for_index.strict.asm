* = $0800
MODE_ABSOLUTE = $4000
MODE_ABSOLUTE_X = $4002
MODE_ABSOLUTE_Y = $4004
__L_long_mode_for_index_index = $4006
long_mode_for_index:
__F_long_mode_for_index_entry:
    lda __L_long_mode_for_index_index
    cmp #$01
    beq __F_long_mode_for_index_yes_1
    jmp __F_long_mode_for_index_join_3
__F_long_mode_for_index_yes_1:
    lda MODE_ABSOLUTE_X
    ldx #$00
    rts
__F_long_mode_for_index_join_3:
    lda __L_long_mode_for_index_index
    cmp #$02
    beq __F_long_mode_for_index_yes_4
    jmp __F_long_mode_for_index_join_6
__F_long_mode_for_index_yes_4:
    lda MODE_ABSOLUTE_Y
    ldx #$00
    rts
__F_long_mode_for_index_join_6:
    lda MODE_ABSOLUTE
    ldx #$00
    rts
