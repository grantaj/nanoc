* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
ASSEMBLE_BAD_INSTRUCTION = $4000
MODE_ACCUMULATOR = $4002
MODE_IMMEDIATE = $4004
MODE_IMPLIED = $4006
MODE_INDIRECT = $4008
MODE_INDIRECT_X = $400a
MODE_INDIRECT_Y = $400c
__L_assemble_instruction_argument = $400e
__L_assemble_instruction_argument_length = $4010
__L_assemble_instruction_core_length = $4012
__L_assemble_instruction_index = $4014
__L_assemble_instruction_mnemonic = $4016
__L_assemble_instruction_name = $4018
__L_assemble_instruction_name_length = $401a
__L_assemble_instruction_opcode = $401c
__T_assemble_instruction___v0 = $401e
__T_assemble_instruction___v1 = $4020
__T_assemble_instruction___v10 = $4022
__T_assemble_instruction___v108 = $4024
__T_assemble_instruction___v109 = $4026
__T_assemble_instruction___v11 = $4028
__T_assemble_instruction___v113 = $402a
__T_assemble_instruction___v118 = $402c
__T_assemble_instruction___v119 = $402e
__T_assemble_instruction___v126 = $4030
__T_assemble_instruction___v128 = $4032
__T_assemble_instruction___v138 = $4034
__T_assemble_instruction___v139 = $4036
__T_assemble_instruction___v146 = $4038
__T_assemble_instruction___v147 = $403a
__T_assemble_instruction___v151 = $403c
__T_assemble_instruction___v156 = $403e
__T_assemble_instruction___v157 = $4040
__T_assemble_instruction___v16 = $4042
__T_assemble_instruction___v161 = $4044
__T_assemble_instruction___v17 = $4046
__T_assemble_instruction___v171 = $4048
__T_assemble_instruction___v172 = $404a
__T_assemble_instruction___v178 = $404c
__T_assemble_instruction___v180 = $404e
__T_assemble_instruction___v190 = $4050
__T_assemble_instruction___v192 = $4052
__T_assemble_instruction___v199 = $4054
__T_assemble_instruction___v20 = $4056
__T_assemble_instruction___v200 = $4058
__T_assemble_instruction___v201 = $405a
__T_assemble_instruction___v202 = $405c
__T_assemble_instruction___v21 = $405e
__T_assemble_instruction___v26 = $4060
__T_assemble_instruction___v27 = $4062
__T_assemble_instruction___v37 = $4064
__T_assemble_instruction___v40 = $4066
__T_assemble_instruction___v41 = $4068
__T_assemble_instruction___v47 = $406a
__T_assemble_instruction___v48 = $406c
__T_assemble_instruction___v53 = $406e
__T_assemble_instruction___v60 = $4070
__T_assemble_instruction___v61 = $4072
__T_assemble_instruction___v81 = $4074
__T_assemble_instruction___v83 = $4076
__T_assemble_instruction___v89 = $4078
__T_assemble_instruction___v90 = $407a
__T_assemble_instruction___v96 = $407c
__T_assemble_instruction___v97 = $407e
__call_assemble_direct_value_0 = $4080
__call_assemble_direct_value_1 = $4082
__call_assemble_direct_value_2 = $4084
__call_assemble_direct_value_3 = $4086
__call_assemble_mode_value_0 = $4088
__call_assemble_mode_value_1 = $408a
__call_assemble_mode_value_2 = $408c
__call_assemble_mode_value_3 = $408e
__call_find_mnemonic_0 = $4090
__call_find_mnemonic_1 = $4092
__call_find_opcode_0 = $4094
__call_find_opcode_1 = $4096
__call_stage_resolved_instruction_0 = $4098
__call_stage_resolved_instruction_1 = $409a
__call_stage_resolved_instruction_2 = $409c
__call_upper_char_0 = $409e
assemble_direct_value = $40a0
assemble_mode_value = $40a2
find_mnemonic = $40a4
find_opcode = $40a6
stage_resolved_instruction = $40a8
upper_char = $40aa
assemble_instruction:
__F_assemble_instruction_entry:
    lda __L_assemble_instruction_name
    sta __T_assemble_instruction___v0
    lda __L_assemble_instruction_name+1
    sta __T_assemble_instruction___v0+1
    lda __L_assemble_instruction_name_length
    sta __T_assemble_instruction___v1
    lda __T_assemble_instruction___v0
    sta __call_find_mnemonic_0
    lda __T_assemble_instruction___v0+1
    sta __call_find_mnemonic_0+1
    lda __T_assemble_instruction___v1
    sta __call_find_mnemonic_1
    jsr find_mnemonic
    sta __L_assemble_instruction_mnemonic
    stx __L_assemble_instruction_mnemonic+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_instruction_mnemonic+1
    eor #$80
    cmp __rh
    bcc __F_assemble_instruction___sel1
    bne __F_assemble_instruction___sel2
    lda __L_assemble_instruction_mnemonic
    cmp #$00
    bcc __F_assemble_instruction___sel1
    bne __F_assemble_instruction___sel2
    jmp __F_assemble_instruction___sel3
__F_assemble_instruction___sel1:
    jmp __F_assemble_instruction_yes_1
__F_assemble_instruction___sel2:
    jmp __F_assemble_instruction_join_3
__F_assemble_instruction___sel3:
    jmp __F_assemble_instruction_join_3
__F_assemble_instruction_yes_1:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_3:
    lda __L_assemble_instruction_argument_length
    cmp #$00
    beq __F_assemble_instruction_yes_4
    jmp __F_assemble_instruction_join_6
__F_assemble_instruction_yes_4:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v10
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v10+1
    lda MODE_IMPLIED
    sta __T_assemble_instruction___v11
    lda __T_assemble_instruction___v10
    sta __call_find_opcode_0
    lda __T_assemble_instruction___v10+1
    sta __call_find_opcode_0+1
    lda __T_assemble_instruction___v11
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_instruction_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_instruction___sel4
    bne __F_assemble_instruction___sel5
    lda __L_assemble_instruction_opcode
    cmp #$00
    bcc __F_assemble_instruction___sel4
    bne __F_assemble_instruction___sel5
    jmp __F_assemble_instruction___sel6
__F_assemble_instruction___sel4:
    jmp __F_assemble_instruction_join_9
__F_assemble_instruction___sel5:
    jmp __F_assemble_instruction_yes_7
__F_assemble_instruction___sel6:
    jmp __F_assemble_instruction_yes_7
__F_assemble_instruction_yes_7:
    lda __L_assemble_instruction_opcode
    sta __T_assemble_instruction___v16
    lda __L_assemble_instruction_opcode+1
    sta __T_assemble_instruction___v16+1
    lda MODE_IMPLIED
    sta __T_assemble_instruction___v17
    lda __T_assemble_instruction___v16
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_instruction___v16+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_instruction___v17
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    lda #$00
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_instruction_join_9:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v20
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v20+1
    lda MODE_ACCUMULATOR
    sta __T_assemble_instruction___v21
    lda __T_assemble_instruction___v20
    sta __call_find_opcode_0
    lda __T_assemble_instruction___v20+1
    sta __call_find_opcode_0+1
    lda __T_assemble_instruction___v21
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_instruction_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_instruction___sel7
    bne __F_assemble_instruction___sel8
    lda __L_assemble_instruction_opcode
    cmp #$00
    bcc __F_assemble_instruction___sel7
    bne __F_assemble_instruction___sel8
    jmp __F_assemble_instruction___sel9
__F_assemble_instruction___sel7:
    jmp __F_assemble_instruction_join_12
__F_assemble_instruction___sel8:
    jmp __F_assemble_instruction_yes_10
__F_assemble_instruction___sel9:
    jmp __F_assemble_instruction_yes_10
__F_assemble_instruction_yes_10:
    lda __L_assemble_instruction_opcode
    sta __T_assemble_instruction___v26
    lda __L_assemble_instruction_opcode+1
    sta __T_assemble_instruction___v26+1
    lda MODE_ACCUMULATOR
    sta __T_assemble_instruction___v27
    lda __T_assemble_instruction___v26
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_instruction___v26+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_instruction___v27
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    lda #$00
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_instruction_join_12:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_6:
    lda __L_assemble_instruction_argument_length
    cmp #$01
    beq __F_assemble_instruction_yes_13
    jmp __F_assemble_instruction_join_15
__F_assemble_instruction_yes_13:
    ldy #$00
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_assemble_instruction___v37
    cmp #$41
    beq __F_assemble_instruction_yes_16
    jmp __F_assemble_instruction_join_15
__F_assemble_instruction_yes_16:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v40
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v40+1
    lda MODE_ACCUMULATOR
    sta __T_assemble_instruction___v41
    lda __T_assemble_instruction___v40
    sta __call_find_opcode_0
    lda __T_assemble_instruction___v40+1
    sta __call_find_opcode_0+1
    lda __T_assemble_instruction___v41
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_instruction_opcode
    stx __L_assemble_instruction_opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_instruction_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_instruction___sel10
    bne __F_assemble_instruction___sel11
    lda __L_assemble_instruction_opcode
    cmp #$00
    bcc __F_assemble_instruction___sel10
    bne __F_assemble_instruction___sel11
    jmp __F_assemble_instruction___sel12
__F_assemble_instruction___sel10:
    jmp __F_assemble_instruction_yes_19
__F_assemble_instruction___sel11:
    jmp __F_assemble_instruction_join_21
__F_assemble_instruction___sel12:
    jmp __F_assemble_instruction_join_21
__F_assemble_instruction_yes_19:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_21:
    lda __L_assemble_instruction_opcode
    sta __T_assemble_instruction___v47
    lda __L_assemble_instruction_opcode+1
    sta __T_assemble_instruction___v47+1
    lda MODE_ACCUMULATOR
    sta __T_assemble_instruction___v48
    lda __T_assemble_instruction___v47
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_instruction___v47+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_instruction___v48
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    lda #$00
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_instruction_join_15:
    ldy #$00
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda (__ap),y
    sta __T_assemble_instruction___v53
    cmp #$23
    beq __F_assemble_instruction_yes_22
    jmp __F_assemble_instruction_join_24
__F_assemble_instruction_yes_22:
    lda __L_assemble_instruction_argument_length
    cmp #$02
    bcc __F_assemble_instruction_yes_25
    jmp __F_assemble_instruction_join_27
__F_assemble_instruction_yes_25:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_27:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v60
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v60+1
    lda MODE_IMMEDIATE
    sta __T_assemble_instruction___v61
    lda __L_assemble_instruction_argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda __L_assemble_instruction_argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    sta __call_assemble_mode_value_3
    lda #$00
    sbc #$00
    sta __call_assemble_mode_value_3+1
    lda __T_assemble_instruction___v60
    sta __call_assemble_mode_value_0
    lda __T_assemble_instruction___v60+1
    sta __call_assemble_mode_value_0+1
    lda __T_assemble_instruction___v61
    sta __call_assemble_mode_value_1
    jsr assemble_mode_value
    ldx #$00
    rts
__F_assemble_instruction_join_24:
    cmp #$28
    beq __F_assemble_instruction_yes_28
    jmp __F_assemble_instruction_join_30
__F_assemble_instruction_yes_28:
    lda __L_assemble_instruction_argument_length
    cmp #$03
    bcc __F_assemble_instruction_yes_31
    jmp __F_assemble_instruction_join_33
__F_assemble_instruction_yes_31:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_33:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    sta __T_assemble_instruction___v81
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v81+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v81
    sta __ix
    lda __T_assemble_instruction___v81+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_assemble_instruction___v83
    cmp #$59
    beq __F_assemble_instruction_yes_34
    jmp __F_assemble_instruction_join_36
__F_assemble_instruction_yes_34:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __T_assemble_instruction___v89
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v89+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v89
    sta __ix
    lda __T_assemble_instruction___v89+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_instruction___v90
    cmp #$2c
    beq __F_assemble_instruction_yes_37
    jmp __F_assemble_instruction_join_36
__F_assemble_instruction_yes_37:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$03
    sta __T_assemble_instruction___v96
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v96+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v96
    sta __ix
    lda __T_assemble_instruction___v96+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_instruction___v97
    cmp #$29
    bne __F_assemble_instruction_yes_40
    jmp __F_assemble_instruction_join_42
__F_assemble_instruction_yes_40:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_42:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$04
    sta __L_assemble_instruction_core_length
    lda __L_assemble_instruction_core_length
    cmp #$00
    bcc __F_assemble_instruction_yes_43
    beq __F_assemble_instruction_yes_43
    jmp __F_assemble_instruction_join_45
__F_assemble_instruction_yes_43:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_45:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v108
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v108+1
    lda MODE_INDIRECT_Y
    sta __T_assemble_instruction___v109
    lda __L_assemble_instruction_argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda __L_assemble_instruction_argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda __L_assemble_instruction_core_length
    sta __T_assemble_instruction___v113
    lda __T_assemble_instruction___v108
    sta __call_assemble_mode_value_0
    lda __T_assemble_instruction___v108+1
    sta __call_assemble_mode_value_0+1
    lda __T_assemble_instruction___v109
    sta __call_assemble_mode_value_1
    lda __T_assemble_instruction___v113
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    ldx #$00
    rts
__F_assemble_instruction_join_36:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    sta __T_assemble_instruction___v118
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v118+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v118
    sta __ix
    lda __T_assemble_instruction___v118+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_instruction___v119
    cmp #$29
    bne __F_assemble_instruction_yes_46
    jmp __F_assemble_instruction_join_48
__F_assemble_instruction_yes_46:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_48:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __T_assemble_instruction___v126
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v126+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v126
    sta __ix
    lda __T_assemble_instruction___v126+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_assemble_instruction___v128
    cmp #$58
    beq __F_assemble_instruction_yes_49
    jmp __F_assemble_instruction_join_51
__F_assemble_instruction_yes_49:
    lda __L_assemble_instruction_argument_length
    cmp #$05
    bcc __F_assemble_instruction_yes_52
    jmp __F_assemble_instruction_join_54
__F_assemble_instruction_yes_52:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_54:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$03
    sta __T_assemble_instruction___v138
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v138+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v138
    sta __ix
    lda __T_assemble_instruction___v138+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_instruction___v139
    cmp #$2c
    bne __F_assemble_instruction_yes_55
    jmp __F_assemble_instruction_join_57
__F_assemble_instruction_yes_55:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_instruction_join_57:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$04
    sta __L_assemble_instruction_core_length
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v146
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v146+1
    lda MODE_INDIRECT_X
    sta __T_assemble_instruction___v147
    lda __L_assemble_instruction_argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda __L_assemble_instruction_argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda __L_assemble_instruction_core_length
    sta __T_assemble_instruction___v151
    lda __T_assemble_instruction___v146
    sta __call_assemble_mode_value_0
    lda __T_assemble_instruction___v146+1
    sta __call_assemble_mode_value_0+1
    lda __T_assemble_instruction___v147
    sta __call_assemble_mode_value_1
    lda __T_assemble_instruction___v151
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    ldx #$00
    rts
__F_assemble_instruction_join_51:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v156
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v156+1
    lda MODE_INDIRECT
    sta __T_assemble_instruction___v157
    lda __L_assemble_instruction_argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda __L_assemble_instruction_argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda __L_assemble_instruction_core_length
    sta __T_assemble_instruction___v161
    lda __T_assemble_instruction___v156
    sta __call_assemble_mode_value_0
    lda __T_assemble_instruction___v156+1
    sta __call_assemble_mode_value_0+1
    lda __T_assemble_instruction___v157
    sta __call_assemble_mode_value_1
    lda __T_assemble_instruction___v161
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    ldx #$00
    rts
__F_assemble_instruction_join_30:
    lda #$00
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sta __L_assemble_instruction_core_length
    lda __L_assemble_instruction_argument_length
    cmp #$03
    bcs __F_assemble_instruction_yes_58
    jmp __F_assemble_instruction_join_60
__F_assemble_instruction_yes_58:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __T_assemble_instruction___v171
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v171+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v171
    sta __ix
    lda __T_assemble_instruction___v171+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_assemble_instruction___v172
    cmp #$2c
    beq __F_assemble_instruction_yes_61
    jmp __F_assemble_instruction_join_60
__F_assemble_instruction_yes_61:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    sta __T_assemble_instruction___v178
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v178+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v178
    sta __ix
    lda __T_assemble_instruction___v178+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_assemble_instruction___v180
    cmp #$58
    beq __F_assemble_instruction_yes_64
    jmp __F_assemble_instruction_no_65
__F_assemble_instruction_yes_64:
    lda #$01
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
    jmp __F_assemble_instruction_join_60
__F_assemble_instruction_no_65:
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$01
    sta __T_assemble_instruction___v190
    lda #$00
    sbc #$00
    sta __T_assemble_instruction___v190+1
    lda __L_assemble_instruction_argument
    sta __ap
    lda __L_assemble_instruction_argument+1
    sta __ap+1
    lda __T_assemble_instruction___v190
    sta __ix
    lda __T_assemble_instruction___v190+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __T_assemble_instruction___v192
    cmp #$59
    beq __F_assemble_instruction_yes_67
    jmp __F_assemble_instruction_join_60
__F_assemble_instruction_yes_67:
    lda #$02
    sta __L_assemble_instruction_index
    lda __L_assemble_instruction_argument_length
    sec
    sbc #$02
    sta __L_assemble_instruction_core_length
__F_assemble_instruction_join_60:
    lda __L_assemble_instruction_mnemonic
    sta __T_assemble_instruction___v199
    lda __L_assemble_instruction_mnemonic+1
    sta __T_assemble_instruction___v199+1
    lda __L_assemble_instruction_argument
    sta __T_assemble_instruction___v200
    lda __L_assemble_instruction_argument+1
    sta __T_assemble_instruction___v200+1
    lda __L_assemble_instruction_core_length
    sta __T_assemble_instruction___v201
    lda __L_assemble_instruction_index
    sta __T_assemble_instruction___v202
    lda __T_assemble_instruction___v199
    sta __call_assemble_direct_value_0
    lda __T_assemble_instruction___v199+1
    sta __call_assemble_direct_value_0+1
    lda __T_assemble_instruction___v200
    sta __call_assemble_direct_value_1
    lda __T_assemble_instruction___v200+1
    sta __call_assemble_direct_value_1+1
    lda __T_assemble_instruction___v201
    sta __call_assemble_direct_value_2
    lda __T_assemble_instruction___v202
    sta __call_assemble_direct_value_3
    jsr assemble_direct_value
    ldx #$00
    rts
