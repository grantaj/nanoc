entry:
    lda length
    cmp #$03
    bcc yes_1
    jmp join_3
yes_1:
    lda ASSEMBLE_BAD_STATEMENT
    rts
join_3:
    ldy #$00
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda (__ap),y
    sta __v6
    lda __v6
    cmp #$22
    bne yes_4
    jmp join_6
yes_4:
    lda ASSEMBLE_BAD_STATEMENT
    rts
join_6:
    lda length
    sec
    sbc #$01
    sta __v13
    lda #$00
    sbc #$00
    sta __v13+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v13
    sta __ix
    lda __v13+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v14
    lda __v14
    cmp #$22
    bne yes_7
    jmp join_9
yes_7:
    lda ASSEMBLE_BAD_STATEMENT
    rts
join_9:
    lda #$00
    eor #$80
    sta __rh
    lda source_depth+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda source_depth
    cmp #$04
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp join_12
__sel2:
    jmp yes_10
__sel3:
    jmp yes_10
yes_10:
    lda ASSEMBLE_INCLUDE_DEPTH
    rts
join_12:
    lda #$01
    sta input_start
    lda length
    sec
    sbc #$02
    sta input_length
    lda #$00
    sta output
    lda #$00
    sta parent_path
    lda input_length
    cmp #$03
    bcs yes_13
    jmp join_15
yes_13:
    ldy input_start
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda (__ap),y
    sta __v33
    lda __v33
    cmp #$2e
    beq yes_16
    jmp join_15
yes_16:
    lda input_start
    clc
    adc #$01
    sta __v39
    lda #$00
    adc #$00
    sta __v39+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v39
    sta __ix
    lda __v39+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v40
    lda __v40
    cmp #$2e
    beq yes_19
    jmp join_15
yes_19:
    lda input_start
    clc
    adc #$02
    sta __v46
    lda #$00
    adc #$00
    sta __v46+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v46
    sta __ix
    lda __v46+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v47
    lda __v47
    cmp #$2f
    beq yes_22
    jmp join_15
yes_22:
    lda #$01
    sta parent_path
    lda input_start
    clc
    adc #$03
    sta input_start
    lda input_length
    sec
    sbc #$03
    sta input_length
join_15:
    lda parent_path
    cmp #$00
    beq yes_25
    jmp join_27
yes_25:
    lda #$00
    sta i
while_28:
    lda i
    cmp source_directory_length
    bcc body_29
    jmp join_27
body_29:
    ldy i
    lda source_directory
    sta __ap
    lda source_directory+1
    sta __ap+1
    lda (__ap),y
    sta __v68
    ldy output
    lda __v68
    sta source_path,y
    inc output
    inc i
    jmp while_28
join_27:
    lda output
    clc
    adc input_length
    sta __v77
    lda #$00
    adc #$00
    sta __v77+1
    lda #$00
    eor #$80
    sta __rh
    lda __v77+1
    eor #$80
    cmp __rh
    bcc __sel4
    bne __sel5
    lda __v77
    cmp #$ff
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp join_33
__sel5:
    jmp yes_31
__sel6:
    jmp join_33
yes_31:
    lda ASSEMBLE_BAD_STATEMENT
    rts
join_33:
    lda #$00
    sta i
while_34:
    lda i
    cmp input_length
    bcc body_35
    jmp after_36
body_35:
    lda input_start
    clc
    adc i
    sta __v90
    lda #$00
    adc #$00
    sta __v90+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v90
    sta __ix
    lda __v90+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v91
    ldy output
    lda __v91
    sta source_path,y
    inc output
    inc i
    jmp while_34
after_36:
    lda #<source_path
    sta __call_io_open_0
    lda #>source_path
    sta __call_io_open_0+1
    lda output
    sta __call_io_open_1
    lda #$00
    sta __call_io_open_1+1
    jsr io_open
    sta handle
    stx handle+1
    lda #$00
    eor #$80
    sta __rh
    lda handle+1
    eor #$80
    cmp __rh
    bcc __sel7
    bne __sel8
    lda handle
    cmp #$00
    bcc __sel7
    bne __sel8
    jmp __sel9
__sel7:
    jmp yes_37
__sel8:
    jmp join_39
__sel9:
    jmp join_39
yes_37:
    lda ASSEMBLE_IO_ERROR
    rts
join_39:
    lda source_depth
    clc
    adc #$01
    sta __v107
    lda source_depth+1
    adc #$00
    sta __v107+1
    lda __v107
    sta source_depth
    lda __v107+1
    sta source_depth+1
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda source_depth
    sta __ix
    lda source_depth+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda handle
    sta (__ap),y
    lda ASSEMBLE_OK
    rts
