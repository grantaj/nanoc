entry:
    lda ass_image_length
    sta stage
    lda ass_image_length+1
    sta stage+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda symbol
    asl
    sta __ix
    lda symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v3
    iny
    lda (__ap),y
    sta __v3+1
    lda __v3
    sta old_head
    lda __v3+1
    sta old_head+1
    lda old_head
    and #$ff
    sta __v6
    lda old_head+1
    and #$00
    sta __v6+1
    lda __v6
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_1
    jmp join_3
yes_1:
    lda status
    rts
join_3:
    lda old_head
    sta __v14
    lda old_head+1
    sta __v14+1
    lda __v14+1
    cmp #$80
    ror
    sta __v14+1
    ror __v14
    lda __v14+1
    cmp #$80
    ror
    sta __v14+1
    ror __v14
    lda __v14+1
    cmp #$80
    ror
    sta __v14+1
    ror __v14
    lda __v14+1
    cmp #$80
    ror
    sta __v14+1
    ror __v14
    lda __v14+1
    cmp #$80
    ror
    sta __v14+1
    ror __v14
    lda __v14+1
    cmp #$80
    ror
    sta __v14+1
    ror __v14
    lda __v14+1
    cmp #$80
    ror
    sta __v14+1
    ror __v14
    lda __v14+1
    cmp #$80
    ror
    sta __v14+1
    ror __v14
    lda __v14
    and #$ff
    sta __v16
    lda __v14+1
    and #$00
    sta __v16+1
    lda __v16
    sta __call_stage_byte_0
    jsr stage_byte
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_4
    jmp join_6
yes_4:
    lda status
    rts
join_6:
    lda stage
    clc
    adc #$01
    sta __v26
    lda stage+1
    adc #$00
    sta __v26+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda symbol
    asl
    sta __ix
    lda symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __v26
    sta (__ap),y
    iny
    lda __v26+1
    sta (__ap),y
    lda ASSEMBLE_OK
    rts
