* = $0800
__L_relative_byte_base = $4000
__L_relative_byte_difference = $4002
__L_relative_byte_target = $4004
__T_relative_byte___v14 = $4006
__T_relative_byte___v16 = $4008
__T_relative_byte___v2 = $400a
__T_relative_byte___v4 = $400c
relative_byte:
__F_relative_byte_entry:
    lda __L_relative_byte_target
    sec
    sbc __L_relative_byte_base
    sta __T_relative_byte___v2
    lda __L_relative_byte_target+1
    sbc __L_relative_byte_base+1
    sta __T_relative_byte___v2+1
    lda __T_relative_byte___v2
    sta __T_relative_byte___v4
    lda __T_relative_byte___v2+1
    sta __T_relative_byte___v4+1
    lda __T_relative_byte___v4
    sta __L_relative_byte_difference
    lda __T_relative_byte___v4+1
    sta __L_relative_byte_difference+1
    lda __L_relative_byte_difference+1
    cmp #$00
    bcc __F_relative_byte___sel1
    bne __F_relative_byte___sel2
    lda __L_relative_byte_difference
    cmp #$7f
    bcc __F_relative_byte___sel1
    bne __F_relative_byte___sel2
    jmp __F_relative_byte___sel3
__F_relative_byte___sel1:
    jmp __F_relative_byte_yes_1
__F_relative_byte___sel2:
    jmp __F_relative_byte_join_3
__F_relative_byte___sel3:
    jmp __F_relative_byte_yes_1
__F_relative_byte_yes_1:
    lda __L_relative_byte_difference
    ldx __L_relative_byte_difference+1
    rts
__F_relative_byte_join_3:
    lda __L_relative_byte_difference+1
    cmp #$ff
    bcc __F_relative_byte___sel4
    bne __F_relative_byte___sel5
    lda __L_relative_byte_difference
    cmp #$80
    bcc __F_relative_byte___sel4
    bne __F_relative_byte___sel5
    jmp __F_relative_byte___sel6
__F_relative_byte___sel4:
    jmp __F_relative_byte_join_6
__F_relative_byte___sel5:
    jmp __F_relative_byte_yes_4
__F_relative_byte___sel6:
    jmp __F_relative_byte_yes_4
__F_relative_byte_yes_4:
    lda __L_relative_byte_difference
    and #$ff
    sta __T_relative_byte___v14
    lda __L_relative_byte_difference+1
    and #$00
    sta __T_relative_byte___v14+1
    lda __T_relative_byte___v14
    ldx __T_relative_byte___v14+1
    rts
__F_relative_byte_join_6:
    sec
    lda #$00
    sbc #$01
    sta __T_relative_byte___v16
    lda #$00
    sbc #$00
    sta __T_relative_byte___v16+1
    lda __T_relative_byte___v16
    ldx __T_relative_byte___v16+1
    rts
