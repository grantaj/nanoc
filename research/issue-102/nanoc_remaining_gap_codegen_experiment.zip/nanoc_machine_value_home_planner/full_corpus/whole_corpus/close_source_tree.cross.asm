entry:
while_1:
    lda #$00
    eor #$80
    sta __rh
    lda source_depth+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda source_depth
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp after_3
__sel2:
    jmp body_2
__sel3:
    jmp body_2
body_2:
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda source_depth
    sta __ix
    lda source_depth+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v5
    lda __v5
    sta __call_io_close_0
    lda #$00
    sta __call_io_close_0+1
    jsr io_close
    sta __v6
    lda source_depth
    sec
    sbc #$01
    sta __v9
    lda source_depth+1
    sbc #$00
    sta __v9+1
    lda __v9
    sta source_depth
    lda __v9+1
    sta source_depth+1
    jmp while_1
after_3:
    lda ASSEMBLE_OK
    rts
