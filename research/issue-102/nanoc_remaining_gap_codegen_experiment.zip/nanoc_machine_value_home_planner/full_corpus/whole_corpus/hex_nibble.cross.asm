entry:
    lda c
    sta __call_upper_char_0
    jsr upper_char
    sta c
    lda c
    cmp #$30
    bcs yes_1
    jmp join_3
yes_1:
    lda c
    cmp #$39
    bcc yes_4
    beq yes_4
    jmp join_3
yes_4:
    lda c
    sec
    sbc #$30
    sta __v10
    lda #$00
    sbc #$00
    sta __v10+1
    lda __v10
    ldx __v10+1
    rts
join_3:
    lda c
    cmp #$41
    bcs yes_7
    jmp join_9
yes_7:
    lda c
    cmp #$46
    bcc yes_10
    beq yes_10
    jmp join_9
yes_10:
    lda c
    sec
    sbc #$41
    sta __v19
    lda #$00
    sbc #$00
    sta __v19+1
    lda __v19
    clc
    adc #$0a
    sta __v21
    lda __v19+1
    adc #$00
    sta __v21+1
    lda __v21
    ldx __v21+1
    rts
join_9:
    sec
    lda #$00
    sbc #$01
    sta __v23
    lda #$00
    sbc #$00
    sta __v23+1
    lda __v23
    ldx __v23+1
    rts
