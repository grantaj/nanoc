* = $0800
__ap = $0010
__ix = $0012
ASSEMBLE_OK = $4000
__L_patch_word_chain_head = $4002
__L_patch_word_chain_next = $4004
__L_patch_word_chain_stage = $4006
__L_patch_word_chain_value = $4008
__T_patch_word_chain___v12 = $400a
__T_patch_word_chain___v13 = $400c
__T_patch_word_chain___v15 = $400e
__T_patch_word_chain___v16 = $4010
__T_patch_word_chain___v18 = $4012
__T_patch_word_chain___v21 = $4014
__T_patch_word_chain___v25 = $4016
__T_patch_word_chain___v28 = $4018
__T_patch_word_chain___v30 = $401a
__T_patch_word_chain___v8 = $401c
ass_image = $401e
patch_word_chain:
__F_patch_word_chain_entry:
__F_patch_word_chain_while_1:
    lda __L_patch_word_chain_head+1
    cmp #$00
    bne __F_patch_word_chain_body_2
    lda __L_patch_word_chain_head
    cmp #$00
    bne __F_patch_word_chain___far_skip_0
    jmp __F_patch_word_chain_after_3
__F_patch_word_chain___far_skip_0:
    jmp __F_patch_word_chain_body_2
__F_patch_word_chain_body_2:
    lda __L_patch_word_chain_head
    sec
    sbc #$01
    sta __L_patch_word_chain_stage
    lda __L_patch_word_chain_head+1
    sbc #$00
    sta __L_patch_word_chain_stage+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __L_patch_word_chain_stage
    sta __ix
    lda __L_patch_word_chain_stage+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_patch_word_chain___v8
    lda __L_patch_word_chain_stage
    clc
    adc #$01
    sta __T_patch_word_chain___v12
    lda __L_patch_word_chain_stage+1
    adc #$00
    sta __T_patch_word_chain___v12+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_patch_word_chain___v12
    sta __ix
    lda __T_patch_word_chain___v12+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_patch_word_chain___v13
    lda __T_patch_word_chain___v13
    sta __T_patch_word_chain___v15
    lda #$00
    sta __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    asl __T_patch_word_chain___v15
    rol __T_patch_word_chain___v15+1
    lda __T_patch_word_chain___v8
    ora __T_patch_word_chain___v15
    sta __T_patch_word_chain___v16
    lda #$00
    ora __T_patch_word_chain___v15+1
    sta __T_patch_word_chain___v16+1
    lda __T_patch_word_chain___v16
    sta __L_patch_word_chain_next
    lda __T_patch_word_chain___v16+1
    sta __L_patch_word_chain_next+1
    lda __L_patch_word_chain_stage
    sta __T_patch_word_chain___v18
    lda __L_patch_word_chain_stage+1
    sta __T_patch_word_chain___v18+1
    lda __L_patch_word_chain_value
    and #$ff
    sta __T_patch_word_chain___v21
    lda __L_patch_word_chain_value+1
    and #$00
    sta __T_patch_word_chain___v21+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_patch_word_chain___v18
    sta __ix
    lda __T_patch_word_chain___v18+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_patch_word_chain___v21
    sta (__ap),y
    lda __L_patch_word_chain_stage
    clc
    adc #$01
    sta __T_patch_word_chain___v25
    lda __L_patch_word_chain_stage+1
    adc #$00
    sta __T_patch_word_chain___v25+1
    lda __L_patch_word_chain_value
    sta __T_patch_word_chain___v28
    lda __L_patch_word_chain_value+1
    sta __T_patch_word_chain___v28+1
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lsr __T_patch_word_chain___v28+1
    ror __T_patch_word_chain___v28
    lda __T_patch_word_chain___v28
    and #$ff
    sta __T_patch_word_chain___v30
    lda __T_patch_word_chain___v28+1
    and #$00
    sta __T_patch_word_chain___v30+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_patch_word_chain___v25
    sta __ix
    lda __T_patch_word_chain___v25+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_patch_word_chain___v30
    sta (__ap),y
    lda __L_patch_word_chain_next
    sta __L_patch_word_chain_head
    lda __L_patch_word_chain_next+1
    sta __L_patch_word_chain_head+1
    jmp __F_patch_word_chain_while_1
__F_patch_word_chain_after_3:
    lda ASSEMBLE_OK
    ldx #$00
    rts
