entry:
    lda name
    sta __call_find_symbol_0
    lda name+1
    sta __call_find_symbol_0+1
    lda length
    sta __call_find_symbol_1
    jsr find_symbol
    sta symbol
    stx symbol+1
    lda #$00
    eor #$80
    sta __rh
    lda symbol+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda symbol
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp join_3
__sel2:
    jmp yes_1
__sel3:
    jmp yes_1
yes_1:
    lda ASSEMBLE_BAD_SYMBOL
    rts
join_3:
    sec
    lda #$00
    sbc #$02
    sta __v9
    lda #$00
    sbc #$00
    sta __v9+1
    lda symbol+1
    cmp __v9+1
    bne join_6
    lda symbol
    cmp __v9
    beq yes_4
    jmp join_6
yes_4:
    lda ASSEMBLE_SCOPE_ERROR
    rts
join_6:
    lda name
    sta __call_allocate_symbol_0
    lda name+1
    sta __call_allocate_symbol_0+1
    lda length
    sta __call_allocate_symbol_1
    lda SYMBOL_CONSTANT
    sta __call_allocate_symbol_2
    lda value
    sta __call_allocate_symbol_3
    lda value+1
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    sta symbol
    stx symbol+1
    sec
    lda #$00
    sbc #$02
    sta __v19
    lda #$00
    sbc #$00
    sta __v19+1
    lda symbol+1
    cmp __v19+1
    bne join_9
    lda symbol
    cmp __v19
    beq yes_7
    jmp join_9
yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    rts
join_9:
    lda #$00
    eor #$80
    sta __rh
    lda symbol+1
    eor #$80
    cmp __rh
    bcc __sel4
    bne __sel5
    lda symbol
    cmp #$00
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp yes_10
__sel5:
    jmp join_12
__sel6:
    jmp join_12
yes_10:
    lda ASSEMBLE_SYMBOL_FULL
    rts
join_12:
    lda ASSEMBLE_OK
    rts
