* = $0800
__L_scan_argument_c = $4000
__L_scan_argument_i = $4002
__L_scan_argument_last = $4004
__L_scan_argument_quote = $4006
__L_scan_argument_start = $4008
__T_scan_argument___v64 = $400a
source_line = $400c
source_line_length = $400e
scan_argument:
__F_scan_argument_entry:
    lda __L_scan_argument_start
    sta __L_scan_argument_i
    lda #$00
    sta __L_scan_argument_quote
    lda __L_scan_argument_start
    sta __L_scan_argument_last
__F_scan_argument_while_1:
    lda __L_scan_argument_i
    cmp source_line_length
    bcc __F_scan_argument_body_2
    jmp __F_scan_argument_after_3
__F_scan_argument_body_2:
    ldy __L_scan_argument_i
    lda source_line,y
    sta __L_scan_argument_c
    lda __L_scan_argument_c
    cmp #$3b
    beq __F_scan_argument_yes_4
    jmp __F_scan_argument_no_5
__F_scan_argument_yes_4:
    lda __L_scan_argument_quote
    cmp #$00
    beq __F_scan_argument_yes_7
    jmp __F_scan_argument_no_8
__F_scan_argument_yes_7:
    lda source_line_length
    sta __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_no_8:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    inc __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_no_5:
    lda __L_scan_argument_c
    cmp #$27
    beq __F_scan_argument_yes_10
    jmp __F_scan_argument_no_11
__F_scan_argument_yes_10:
    lda __L_scan_argument_quote
    cmp #$00
    beq __F_scan_argument_yes_13
    jmp __F_scan_argument_no_14
__F_scan_argument_yes_13:
    lda #$27
    sta __L_scan_argument_quote
    jmp __F_scan_argument_join_15
__F_scan_argument_no_14:
    lda __L_scan_argument_quote
    cmp #$27
    beq __F_scan_argument_yes_16
    jmp __F_scan_argument_join_15
__F_scan_argument_yes_16:
    lda #$00
    sta __L_scan_argument_quote
__F_scan_argument_join_15:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    jmp __F_scan_argument_join_12
__F_scan_argument_no_11:
    lda __L_scan_argument_c
    cmp #$22
    beq __F_scan_argument_yes_19
    jmp __F_scan_argument_no_20
__F_scan_argument_yes_19:
    lda __L_scan_argument_quote
    cmp #$00
    beq __F_scan_argument_yes_22
    jmp __F_scan_argument_no_23
__F_scan_argument_yes_22:
    lda #$22
    sta __L_scan_argument_quote
    jmp __F_scan_argument_join_24
__F_scan_argument_no_23:
    lda __L_scan_argument_quote
    cmp #$22
    beq __F_scan_argument_yes_25
    jmp __F_scan_argument_join_24
__F_scan_argument_yes_25:
    lda #$00
    sta __L_scan_argument_quote
__F_scan_argument_join_24:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
    jmp __F_scan_argument_join_12
__F_scan_argument_no_20:
    lda __L_scan_argument_c
    cmp #$20
    bne __F_scan_argument_yes_28
    jmp __F_scan_argument_join_12
__F_scan_argument_yes_28:
    lda __L_scan_argument_c
    cmp #$09
    bne __F_scan_argument_yes_31
    jmp __F_scan_argument_join_12
__F_scan_argument_yes_31:
    lda __L_scan_argument_i
    clc
    adc #$01
    sta __L_scan_argument_last
__F_scan_argument_join_12:
    inc __L_scan_argument_i
    jmp __F_scan_argument_while_1
__F_scan_argument_after_3:
    lda __L_scan_argument_last
    sec
    sbc __L_scan_argument_start
    sta __T_scan_argument___v64
    lda #$00
    sbc #$00
    sta __T_scan_argument___v64+1
    lda __T_scan_argument___v64
    ldx __T_scan_argument___v64+1
    rts
