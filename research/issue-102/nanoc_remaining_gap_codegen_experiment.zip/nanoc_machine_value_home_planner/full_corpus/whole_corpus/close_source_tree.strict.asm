* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
ASSEMBLE_OK = $4000
__T_close_source_tree___v6 = $4002
__T_close_source_tree___v9 = $4004
__call_io_close_0 = $4006
io_close = $4008
source_depth = $400a
source_handle = $400c
close_source_tree:
__F_close_source_tree_entry:
__F_close_source_tree_while_1:
    lda #$00
    eor #$80
    sta __rh
    lda source_depth+1
    eor #$80
    cmp __rh
    bcc __F_close_source_tree___sel1
    bne __F_close_source_tree___sel2
    lda source_depth
    cmp #$00
    bcc __F_close_source_tree___sel1
    bne __F_close_source_tree___sel2
    jmp __F_close_source_tree___sel3
__F_close_source_tree___sel1:
    jmp __F_close_source_tree_after_3
__F_close_source_tree___sel2:
    jmp __F_close_source_tree_body_2
__F_close_source_tree___sel3:
    jmp __F_close_source_tree_body_2
__F_close_source_tree_body_2:
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda source_depth
    sta __ix
    lda source_depth+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_io_close_0
    jsr io_close
    sta __T_close_source_tree___v6
    lda source_depth
    sec
    sbc #$01
    sta __T_close_source_tree___v9
    lda source_depth+1
    sbc #$00
    sta __T_close_source_tree___v9+1
    lda __T_close_source_tree___v9
    sta source_depth
    lda __T_close_source_tree___v9+1
    sta source_depth+1
    jmp __F_close_source_tree_while_1
__F_close_source_tree_after_3:
    lda ASSEMBLE_OK
    ldx #$00
    rts
