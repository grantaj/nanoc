entry:
    lda value
    sta __v2
    lda value+1
    sta __v2+1
    lda __v2
    sta value
    lda __v2+1
    sta value+1
    lda prefix
    cmp VALUE_PREFIX_LOW
    beq yes_1
    jmp join_3
yes_1:
    lda value
    and #$ff
    sta __v8
    lda value+1
    and #$00
    sta __v8+1
    lda __v8
    rts
join_3:
    lda value
    sta __v11
    lda value+1
    sta __v11+1
    lsr __v11+1
    ror __v11
    lsr __v11+1
    ror __v11
    lsr __v11+1
    ror __v11
    lsr __v11+1
    ror __v11
    lsr __v11+1
    ror __v11
    lsr __v11+1
    ror __v11
    lsr __v11+1
    ror __v11
    lsr __v11+1
    ror __v11
    lda __v11
    and #$ff
    sta __v13
    lda __v11+1
    and #$00
    sta __v13+1
    lda __v13
    rts
