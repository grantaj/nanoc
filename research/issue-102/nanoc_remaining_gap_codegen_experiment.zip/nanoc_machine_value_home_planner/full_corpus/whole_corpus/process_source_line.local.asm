entry:
    lda #$00
    sta cursor
while_1:
    lda cursor
    cmp source_line_length
    bcc while_4
    jmp after_3
while_4:
    lda cursor
    cmp source_line_length
    bcc body_5
    jmp after_6
body_5:
    ldy cursor
    lda source_line,y
    sta __v9
    lda __v9
    cmp #$20
    beq yes_7
    jmp no_8
yes_7:
    inc cursor
    jmp while_4
no_8:
    ldy cursor
    lda source_line,y
    sta __v17
    lda __v17
    cmp #$09
    beq yes_10
    jmp after_6
yes_10:
    inc cursor
    jmp while_4
after_6:
    lda cursor
    cmp source_line_length
    bcs yes_13
    jmp join_15
yes_13:
    lda ASSEMBLE_OK
    rts
join_15:
    ldy cursor
    lda source_line,y
    sta __v29
    lda __v29
    cmp #$3b
    beq yes_16
    jmp join_18
yes_16:
    lda ASSEMBLE_OK
    rts
join_18:
    lda cursor
    sta name_start
while_19:
    lda cursor
    cmp source_line_length
    bcc body_20
    jmp after_21
body_20:
    ldy cursor
    lda source_line,y
    sta __v39
    lda __v39
    cmp #$20
    beq after_21
    jmp join_24
join_24:
    ldy cursor
    lda source_line,y
    sta __v44
    lda __v44
    cmp #$09
    beq after_21
    jmp join_27
join_27:
    inc cursor
    jmp while_19
after_21:
    lda cursor
    sec
    sbc name_start
    sta name_length
    lda name_length
    cmp #$00
    beq yes_28
    jmp join_30
yes_28:
    lda ASSEMBLE_BAD_STATEMENT
    rts
join_30:
    lda name_start
    clc
    adc name_length
    sta __v60
    lda #$00
    adc #$00
    sta __v60+1
    lda __v60
    sec
    sbc #$01
    sta __v62
    lda __v60+1
    sbc #$00
    sta __v62+1
    lda #<source_line
    sta __ap
    lda #>source_line
    sta __ap+1
    lda __v62
    sta __ix
    lda __v62+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v63
    lda __v63
    cmp #$3a
    beq yes_31
    jmp while_37
yes_31:
    lda #<source_line
    clc
    adc name_start
    sta __call_process_label_0
    lda #>source_line
    adc #$00
    sta __call_process_label_0+1
    lda name_length
    sec
    sbc #$01
    sta __v71
    lda #$00
    sbc #$00
    sta __v71+1
    lda __v71
    sta __call_process_label_1
    jsr process_label
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_34
    jmp while_1
yes_34:
    lda status
    rts
while_37:
    lda cursor
    cmp source_line_length
    bcc body_38
    jmp after_39
body_38:
    ldy cursor
    lda source_line,y
    sta __v82
    lda __v82
    cmp #$20
    beq yes_40
    jmp no_41
yes_40:
    inc cursor
    jmp while_37
no_41:
    ldy cursor
    lda source_line,y
    sta __v90
    lda __v90
    cmp #$09
    beq yes_43
    jmp after_39
yes_43:
    inc cursor
    jmp while_37
after_39:
    lda cursor
    cmp source_line_length
    bcc yes_46
    jmp join_48
yes_46:
    ldy cursor
    lda source_line,y
    sta __v101
    lda __v101
    cmp #$3d
    beq yes_49
    jmp join_48
yes_49:
    inc cursor
while_52:
    lda cursor
    cmp source_line_length
    bcc body_53
    jmp after_54
body_53:
    ldy cursor
    lda source_line,y
    sta __v112
    lda __v112
    cmp #$20
    beq yes_55
    jmp no_56
yes_55:
    inc cursor
    jmp while_52
no_56:
    ldy cursor
    lda source_line,y
    sta __v120
    lda __v120
    cmp #$09
    beq yes_58
    jmp after_54
yes_58:
    inc cursor
    jmp while_52
after_54:
    lda cursor
    sta argument_start
    lda argument_start
    sta __call_scan_argument_0
    jsr scan_argument
    sta __v128
    stx __v128+1
    lda __v128
    sta argument_length
    lda argument_length
    cmp #$00
    beq yes_61
    jmp join_63
yes_61:
    lda ASSEMBLE_BAD_SYMBOL
    rts
join_63:
    lda #<source_line
    clc
    adc name_start
    sta __call_process_symbol_0
    lda #>source_line
    adc #$00
    sta __call_process_symbol_0+1
    lda #<source_line
    clc
    adc argument_start
    sta __call_process_symbol_2
    lda #>source_line
    adc #$00
    sta __call_process_symbol_2+1
    lda name_length
    sta __call_process_symbol_1
    lda argument_length
    sta __call_process_symbol_3
    jsr process_symbol
    rts
join_48:
    lda cursor
    sta argument_start
    lda argument_start
    sta __call_scan_argument_0
    jsr scan_argument
    sta __v144
    stx __v144+1
    lda __v144
    sta argument_length
    lda #<source_line
    clc
    adc name_start
    sta __call_process_instruction_like_0
    lda #>source_line
    adc #$00
    sta __call_process_instruction_like_0+1
    lda #<source_line
    clc
    adc argument_start
    sta __call_process_instruction_like_2
    lda #>source_line
    adc #$00
    sta __call_process_instruction_like_2+1
    lda name_length
    sta __call_process_instruction_like_1
    lda argument_length
    sta __call_process_instruction_like_3
    jsr process_instruction_like
    rts
after_3:
    lda ASSEMBLE_OK
    rts
