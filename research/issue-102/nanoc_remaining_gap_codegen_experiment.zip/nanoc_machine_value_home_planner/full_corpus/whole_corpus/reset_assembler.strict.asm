* = $0800
ASSEMBLE_OK = $4000
__L_reset_assembler_default_origin = $4002
__L_reset_assembler_directory = $4004
__L_reset_assembler_directory_length = $4006
__T_reset_assembler___v3 = $4008
ass_image_length = $400a
ass_origin = $400c
current_scope = $400e
fixup_count = $4010
origin_allowed = $4012
source_depth = $4014
source_directory = $4016
source_directory_length = $4018
symbol_count = $401a
symbol_name_used = $401c
reset_assembler:
__F_reset_assembler_entry:
    lda #$00
    sta ass_image_length
    lda #$00
    sta ass_image_length+1
    lda __L_reset_assembler_default_origin
    sta __T_reset_assembler___v3
    lda __L_reset_assembler_default_origin+1
    sta __T_reset_assembler___v3+1
    lda __T_reset_assembler___v3
    sta ass_origin
    lda __T_reset_assembler___v3+1
    sta ass_origin+1
    sec
    lda #$00
    sbc #$01
    sta source_depth
    lda #$00
    sbc #$00
    sta source_depth+1
    lda __L_reset_assembler_directory
    sta source_directory
    lda __L_reset_assembler_directory+1
    sta source_directory+1
    lda __L_reset_assembler_directory_length
    sta source_directory_length
    lda #$00
    sta symbol_count
    lda #$00
    sta symbol_count+1
    lda #$00
    sta symbol_name_used
    lda #$00
    sta symbol_name_used+1
    lda #$00
    sta current_scope
    lda #$00
    sta fixup_count
    lda #$00
    sta fixup_count+1
    lda #$01
    sta origin_allowed
    lda ASSEMBLE_OK
    ldx #$00
    rts
