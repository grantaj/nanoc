entry:
    lda index
    cmp #$01
    beq yes_1
    jmp join_3
yes_1:
    lda MODE_ZERO_PAGE_X
    rts
join_3:
    lda index
    cmp #$02
    beq yes_4
    jmp join_6
yes_4:
    lda MODE_ZERO_PAGE_Y
    rts
join_6:
    lda MODE_ZERO_PAGE
    rts
