* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
SYMBOL_CONSTANT = $4000
SYMBOL_LABEL_UNDEFINED = $4002
__L_intern_label_length = $4004
__L_intern_label_name = $4006
__L_intern_label_symbol = $4008
__T_intern_label___v0 = $400a
__T_intern_label___v1 = $400c
__T_intern_label___v12 = $400e
__T_intern_label___v16 = $4010
__T_intern_label___v19 = $4012
__T_intern_label___v20 = $4014
__T_intern_label___v21 = $4016
__T_intern_label___v22 = $4018
__T_intern_label___v8 = $401a
__call_allocate_symbol_0 = $401c
__call_allocate_symbol_1 = $401e
__call_allocate_symbol_2 = $4020
__call_allocate_symbol_3 = $4022
__call_find_symbol_0 = $4024
__call_find_symbol_1 = $4026
allocate_symbol = $4028
find_symbol = $402a
symbol_kind = $402c
intern_label:
__F_intern_label_entry:
    lda __L_intern_label_name
    sta __T_intern_label___v0
    lda __L_intern_label_name+1
    sta __T_intern_label___v0+1
    lda __L_intern_label_length
    sta __T_intern_label___v1
    lda __T_intern_label___v0
    sta __call_find_symbol_0
    lda __T_intern_label___v0+1
    sta __call_find_symbol_0+1
    lda __T_intern_label___v1
    sta __call_find_symbol_1
    jsr find_symbol
    sta __L_intern_label_symbol
    stx __L_intern_label_symbol+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_intern_label_symbol+1
    eor #$80
    cmp __rh
    bcc __F_intern_label___sel1
    bne __F_intern_label___sel2
    lda __L_intern_label_symbol
    cmp #$00
    bcc __F_intern_label___sel1
    bne __F_intern_label___sel2
    jmp __F_intern_label___sel3
__F_intern_label___sel1:
    jmp __F_intern_label_join_3
__F_intern_label___sel2:
    jmp __F_intern_label_yes_1
__F_intern_label___sel3:
    jmp __F_intern_label_yes_1
__F_intern_label_yes_1:
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda __L_intern_label_symbol
    sta __ix
    lda __L_intern_label_symbol+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_intern_label___v8
    cmp SYMBOL_CONSTANT
    beq __F_intern_label_yes_4
    jmp __F_intern_label_join_6
__F_intern_label_yes_4:
    sec
    lda #$00
    sbc #$04
    sta __T_intern_label___v12
    lda #$00
    sbc #$00
    sta __T_intern_label___v12+1
    lda __T_intern_label___v12
    ldx __T_intern_label___v12+1
    rts
__F_intern_label_join_6:
    lda __L_intern_label_symbol
    ldx __L_intern_label_symbol+1
    rts
__F_intern_label_join_3:
    sec
    lda #$00
    sbc #$02
    sta __T_intern_label___v16
    lda #$00
    sbc #$00
    sta __T_intern_label___v16+1
    lda __L_intern_label_symbol+1
    cmp __T_intern_label___v16+1
    bne __F_intern_label_join_9
    lda __L_intern_label_symbol
    cmp __T_intern_label___v16
    beq __F_intern_label_yes_7
    jmp __F_intern_label_join_9
__F_intern_label_yes_7:
    sec
    lda #$00
    sbc #$02
    sta __T_intern_label___v19
    lda #$00
    sbc #$00
    sta __T_intern_label___v19+1
    lda __T_intern_label___v19
    ldx __T_intern_label___v19+1
    rts
__F_intern_label_join_9:
    lda __L_intern_label_name
    sta __T_intern_label___v20
    lda __L_intern_label_name+1
    sta __T_intern_label___v20+1
    lda __L_intern_label_length
    sta __T_intern_label___v21
    lda SYMBOL_LABEL_UNDEFINED
    sta __T_intern_label___v22
    lda __T_intern_label___v20
    sta __call_allocate_symbol_0
    lda __T_intern_label___v20+1
    sta __call_allocate_symbol_0+1
    lda __T_intern_label___v21
    sta __call_allocate_symbol_1
    lda __T_intern_label___v22
    sta __call_allocate_symbol_2
    lda #$00
    sta __call_allocate_symbol_3
    lda #$00
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    rts
