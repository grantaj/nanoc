entry:
    lda default_origin
    sta __call_reset_assembler_0
    lda default_origin+1
    sta __call_reset_assembler_0+1
    lda directory
    sta __call_reset_assembler_1
    lda directory+1
    sta __call_reset_assembler_1+1
    lda directory_length
    sta __call_reset_assembler_2
    jsr reset_assembler
    sta __v3
    lda root_name
    sta __call_io_open_0
    lda root_name+1
    sta __call_io_open_0+1
    lda root_name_length
    sta __call_io_open_1
    lda #$00
    sta __call_io_open_1+1
    jsr io_open
    sta handle
    stx handle+1
    lda #$00
    eor #$80
    sta __rh
    lda handle+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda handle
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp yes_1
__sel2:
    jmp join_3
__sel3:
    jmp join_3
yes_1:
    lda ASSEMBLE_IO_ERROR
    rts
join_3:
    lda #$00
    sta source_depth
    lda #$00
    sta source_depth+1
    ldy #$00
    lda handle
    sta source_handle,y
while_4:
    lda #$00
    eor #$80
    sta __rh
    lda source_depth+1
    eor #$80
    cmp __rh
    bcc __sel4
    bne __sel5
    lda source_depth
    cmp #$00
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp after_6
__sel5:
    jmp body_5
__sel6:
    jmp body_5
body_5:
    jsr read_source_line
    sta line_status
    stx line_status+1
    lda line_status+1
    cmp #$00
    bne no_8
    lda line_status
    cmp #$01
    beq yes_7
    jmp no_8
yes_7:
    jsr process_source_line
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_10
    jmp while_4
yes_10:
    jsr close_source_tree
    sta __v26
    lda status
    rts
no_8:
    lda line_status+1
    cmp #$00
    bne no_14
    lda line_status
    cmp #$00
    beq yes_13
    jmp no_14
yes_13:
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda source_depth
    sta __ix
    lda source_depth+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v33
    lda __v33
    sta __call_io_close_0
    lda #$00
    sta __call_io_close_0+1
    jsr io_close
    sta __v34
    lda source_depth
    sec
    sbc #$01
    sta __v37
    lda source_depth+1
    sbc #$00
    sta __v37+1
    lda __v37
    sta source_depth
    lda __v37+1
    sta source_depth+1
    jmp while_4
no_14:
    jsr close_source_tree
    sta __v38
    sec
    lda #$00
    sbc #$02
    sta __v41
    lda #$00
    sbc #$00
    sta __v41+1
    lda line_status+1
    cmp __v41+1
    bne join_18
    lda line_status
    cmp __v41
    beq yes_16
    jmp join_18
yes_16:
    lda ASSEMBLE_LINE_TOO_LONG
    rts
join_18:
    lda ASSEMBLE_IO_ERROR
    rts
after_6:
    jsr all_symbols_defined
    sta __v45
    lda __v45
    cmp #$00
    beq yes_19
    jmp join_21
yes_19:
    lda ASSEMBLE_UNDEFINED
    rts
join_21:
    jsr all_fixups_resolved
    sta __v49
    lda __v49
    cmp #$00
    beq yes_22
    jmp join_24
yes_22:
    lda ASSEMBLE_UNDEFINED
    rts
join_24:
    lda ASSEMBLE_OK
    rts
