* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
__L_allocate_symbol_i = $4000
__L_allocate_symbol_kind = $4002
__L_allocate_symbol_length = $4004
__L_allocate_symbol_n = $4006
__L_allocate_symbol_name = $4008
__L_allocate_symbol_payload = $400a
__L_allocate_symbol_scope = $400c
__T_allocate_symbol___v0 = $400e
__T_allocate_symbol___v1 = $4010
__T_allocate_symbol___v12 = $4012
__T_allocate_symbol___v15 = $4014
__T_allocate_symbol___v19 = $4016
__T_allocate_symbol___v22 = $4018
__T_allocate_symbol___v23 = $401a
__T_allocate_symbol___v25 = $401c
__T_allocate_symbol___v26 = $401e
__T_allocate_symbol___v28 = $4020
__T_allocate_symbol___v31 = $4022
__T_allocate_symbol___v33 = $4024
__T_allocate_symbol___v34 = $4026
__T_allocate_symbol___v36 = $4028
__T_allocate_symbol___v37 = $402a
__T_allocate_symbol___v45 = $402c
__T_allocate_symbol___v48 = $402e
__T_allocate_symbol___v54 = $4030
__T_allocate_symbol___v7 = $4032
__call_scope_for_name_0 = $4034
__call_scope_for_name_1 = $4036
scope_for_name = $4038
symbol_count = $403a
symbol_kind = $403c
symbol_name_bytes = $403e
symbol_name_length = $4040
symbol_name_offset = $4042
symbol_name_used = $4044
symbol_payload = $4046
symbol_scope = $4048
allocate_symbol:
__F_allocate_symbol_entry:
    lda __L_allocate_symbol_name
    sta __T_allocate_symbol___v0
    lda __L_allocate_symbol_name+1
    sta __T_allocate_symbol___v0+1
    lda __L_allocate_symbol_length
    sta __T_allocate_symbol___v1
    lda __T_allocate_symbol___v0
    sta __call_scope_for_name_0
    lda __T_allocate_symbol___v0+1
    sta __call_scope_for_name_0+1
    lda __T_allocate_symbol___v1
    sta __call_scope_for_name_1
    jsr scope_for_name
    sta __L_allocate_symbol_scope
    stx __L_allocate_symbol_scope+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_allocate_symbol_scope+1
    eor #$80
    cmp __rh
    bcc __F_allocate_symbol___sel1
    bne __F_allocate_symbol___sel2
    lda __L_allocate_symbol_scope
    cmp #$00
    bcc __F_allocate_symbol___sel1
    bne __F_allocate_symbol___sel2
    jmp __F_allocate_symbol___sel3
__F_allocate_symbol___sel1:
    jmp __F_allocate_symbol_yes_1
__F_allocate_symbol___sel2:
    jmp __F_allocate_symbol_join_3
__F_allocate_symbol___sel3:
    jmp __F_allocate_symbol_join_3
__F_allocate_symbol_yes_1:
    sec
    lda #$00
    sbc #$02
    sta __T_allocate_symbol___v7
    lda #$00
    sbc #$00
    sta __T_allocate_symbol___v7+1
    lda __T_allocate_symbol___v7
    ldx __T_allocate_symbol___v7+1
    rts
__F_allocate_symbol_join_3:
    lda #$03
    eor #$80
    sta __rh
    lda symbol_count+1
    eor #$80
    cmp __rh
    bcc __F_allocate_symbol___sel4
    bne __F_allocate_symbol___sel5
    lda symbol_count
    cmp #$80
    bcc __F_allocate_symbol___sel4
    bne __F_allocate_symbol___sel5
    jmp __F_allocate_symbol___sel6
__F_allocate_symbol___sel4:
    jmp __F_allocate_symbol_join_6
__F_allocate_symbol___sel5:
    jmp __F_allocate_symbol_yes_4
__F_allocate_symbol___sel6:
    jmp __F_allocate_symbol_yes_4
__F_allocate_symbol_yes_4:
    sec
    lda #$00
    sbc #$03
    sta __T_allocate_symbol___v12
    lda #$00
    sbc #$00
    sta __T_allocate_symbol___v12+1
    lda __T_allocate_symbol___v12
    ldx __T_allocate_symbol___v12+1
    rts
__F_allocate_symbol_join_6:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_length
    sta __T_allocate_symbol___v15
    lda symbol_name_used+1
    adc #$00
    sta __T_allocate_symbol___v15+1
    lda #$24
    eor #$80
    sta __rh
    lda __T_allocate_symbol___v15+1
    eor #$80
    cmp __rh
    bcc __F_allocate_symbol___sel7
    bne __F_allocate_symbol___sel8
    lda __T_allocate_symbol___v15
    cmp #$80
    bcc __F_allocate_symbol___sel7
    bne __F_allocate_symbol___sel8
    jmp __F_allocate_symbol___sel9
__F_allocate_symbol___sel7:
    jmp __F_allocate_symbol_join_9
__F_allocate_symbol___sel8:
    jmp __F_allocate_symbol_yes_7
__F_allocate_symbol___sel9:
    jmp __F_allocate_symbol_join_9
__F_allocate_symbol_yes_7:
    sec
    lda #$00
    sbc #$03
    sta __T_allocate_symbol___v19
    lda #$00
    sbc #$00
    sta __T_allocate_symbol___v19+1
    lda __T_allocate_symbol___v19
    ldx __T_allocate_symbol___v19+1
    rts
__F_allocate_symbol_join_9:
    lda symbol_count
    sta __L_allocate_symbol_n
    lda symbol_count+1
    sta __L_allocate_symbol_n+1
    lda __L_allocate_symbol_n
    sta __T_allocate_symbol___v22
    lda __L_allocate_symbol_n+1
    sta __T_allocate_symbol___v22+1
    lda symbol_name_used
    sta __T_allocate_symbol___v23
    lda symbol_name_used+1
    sta __T_allocate_symbol___v23+1
    lda #<symbol_name_offset
    sta __ap
    lda #>symbol_name_offset
    sta __ap+1
    lda __T_allocate_symbol___v22
    asl
    sta __ix
    lda __T_allocate_symbol___v22+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v23
    sta (__ap),y
    iny
    lda __T_allocate_symbol___v23+1
    sta (__ap),y
    lda __L_allocate_symbol_n
    sta __T_allocate_symbol___v25
    lda __L_allocate_symbol_n+1
    sta __T_allocate_symbol___v25+1
    lda __L_allocate_symbol_length
    sta __T_allocate_symbol___v26
    lda #<symbol_name_length
    sta __ap
    lda #>symbol_name_length
    sta __ap+1
    lda __T_allocate_symbol___v25
    sta __ix
    lda __T_allocate_symbol___v25+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v26
    sta (__ap),y
    lda __L_allocate_symbol_n
    sta __T_allocate_symbol___v28
    lda __L_allocate_symbol_n+1
    sta __T_allocate_symbol___v28+1
    lda __L_allocate_symbol_payload
    sta __T_allocate_symbol___v31
    lda __L_allocate_symbol_payload+1
    sta __T_allocate_symbol___v31+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __T_allocate_symbol___v28
    asl
    sta __ix
    lda __T_allocate_symbol___v28+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v31
    sta (__ap),y
    iny
    lda __T_allocate_symbol___v31+1
    sta (__ap),y
    lda __L_allocate_symbol_n
    sta __T_allocate_symbol___v33
    lda __L_allocate_symbol_n+1
    sta __T_allocate_symbol___v33+1
    lda __L_allocate_symbol_scope
    sta __T_allocate_symbol___v34
    lda __L_allocate_symbol_scope+1
    sta __T_allocate_symbol___v34+1
    lda #<symbol_scope
    sta __ap
    lda #>symbol_scope
    sta __ap+1
    lda __T_allocate_symbol___v33
    sta __ix
    lda __T_allocate_symbol___v33+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v34
    sta (__ap),y
    lda __L_allocate_symbol_n
    sta __T_allocate_symbol___v36
    lda __L_allocate_symbol_n+1
    sta __T_allocate_symbol___v36+1
    lda __L_allocate_symbol_kind
    sta __T_allocate_symbol___v37
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda __T_allocate_symbol___v36
    sta __ix
    lda __T_allocate_symbol___v36+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v37
    sta (__ap),y
    lda #$00
    sta __L_allocate_symbol_i
__F_allocate_symbol_while_10:
    lda __L_allocate_symbol_i
    cmp __L_allocate_symbol_length
    bcc __F_allocate_symbol_body_11
    jmp __F_allocate_symbol_after_12
__F_allocate_symbol_body_11:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_i
    sta __T_allocate_symbol___v45
    lda symbol_name_used+1
    adc #$00
    sta __T_allocate_symbol___v45+1
    ldy __L_allocate_symbol_i
    lda __L_allocate_symbol_name
    sta __ap
    lda __L_allocate_symbol_name+1
    sta __ap+1
    lda (__ap),y
    sta __T_allocate_symbol___v48
    lda #<symbol_name_bytes
    sta __ap
    lda #>symbol_name_bytes
    sta __ap+1
    lda __T_allocate_symbol___v45
    sta __ix
    lda __T_allocate_symbol___v45+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_allocate_symbol___v48
    sta (__ap),y
    inc __L_allocate_symbol_i
    jmp __F_allocate_symbol_while_10
__F_allocate_symbol_after_12:
    lda symbol_name_used
    clc
    adc __L_allocate_symbol_length
    sta __T_allocate_symbol___v54
    lda symbol_name_used+1
    adc #$00
    sta __T_allocate_symbol___v54+1
    lda __T_allocate_symbol___v54
    sta symbol_name_used
    lda __T_allocate_symbol___v54+1
    sta symbol_name_used+1
    lda __L_allocate_symbol_n
    clc
    adc #$01
    sta symbol_count
    lda __L_allocate_symbol_n+1
    adc #$00
    sta symbol_count+1
    lda __L_allocate_symbol_n
    ldx __L_allocate_symbol_n+1
    rts
