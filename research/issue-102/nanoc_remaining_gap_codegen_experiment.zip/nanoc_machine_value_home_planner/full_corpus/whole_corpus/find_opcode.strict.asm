* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
__L_find_opcode_mnemonic = $4000
__L_find_opcode_mode = $4002
__L_find_opcode_opcode = $4004
__T_find_opcode___v11 = $4006
__T_find_opcode___v17 = $4008
__T_find_opcode___v19 = $400a
__T_find_opcode___v6 = $400c
opcode_mnemonic = $400e
opcode_mode = $4010
find_opcode:
__F_find_opcode_entry:
    lda #$00
    sta __L_find_opcode_opcode
    lda #$00
    sta __L_find_opcode_opcode+1
__F_find_opcode_while_1:
    lda #$01
    eor #$80
    sta __rh
    lda __L_find_opcode_opcode+1
    eor #$80
    cmp __rh
    bcc __F_find_opcode___sel1
    bne __F_find_opcode___sel2
    lda __L_find_opcode_opcode
    cmp #$00
    bcc __F_find_opcode___sel1
    bne __F_find_opcode___sel2
    jmp __F_find_opcode___sel3
__F_find_opcode___sel1:
    jmp __F_find_opcode_body_2
__F_find_opcode___sel2:
    jmp __F_find_opcode_after_3
__F_find_opcode___sel3:
    jmp __F_find_opcode_after_3
__F_find_opcode_body_2:
    lda #<opcode_mnemonic
    sta __ap
    lda #>opcode_mnemonic
    sta __ap+1
    lda __L_find_opcode_opcode
    sta __ix
    lda __L_find_opcode_opcode+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_opcode___v6
    cmp __L_find_opcode_mnemonic
    beq __F_find_opcode_yes_4
    jmp __F_find_opcode_join_6
__F_find_opcode_yes_4:
    lda #<opcode_mode
    sta __ap
    lda #>opcode_mode
    sta __ap+1
    lda __L_find_opcode_opcode
    sta __ix
    lda __L_find_opcode_opcode+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_find_opcode___v11
    cmp __L_find_opcode_mode
    beq __F_find_opcode_yes_7
    jmp __F_find_opcode_join_6
__F_find_opcode_yes_7:
    lda __L_find_opcode_opcode
    ldx __L_find_opcode_opcode+1
    rts
__F_find_opcode_join_6:
    lda __L_find_opcode_opcode
    clc
    adc #$01
    sta __T_find_opcode___v17
    lda __L_find_opcode_opcode+1
    adc #$00
    sta __T_find_opcode___v17+1
    lda __T_find_opcode___v17
    sta __L_find_opcode_opcode
    lda __T_find_opcode___v17+1
    sta __L_find_opcode_opcode+1
    jmp __F_find_opcode_while_1
__F_find_opcode_after_3:
    sec
    lda #$00
    sbc #$01
    sta __T_find_opcode___v19
    lda #$00
    sbc #$00
    sta __T_find_opcode___v19+1
    lda __T_find_opcode___v19
    ldx __T_find_opcode___v19+1
    rts
