entry:
    lda name_length
    cmp #$01
    beq yes_1
    jmp join_3
yes_1:
    ldy #$00
    lda name
    sta __ap
    lda name+1
    sta __ap+1
    lda (__ap),y
    sta __v5
    cmp #$2a
    beq yes_4
    jmp join_3
yes_4:
    lda origin_allowed
    cmp #$00
    beq yes_7
    jmp join_9
yes_7:
    lda ASSEMBLE_BAD_ORIGIN
    rts
join_9:
    lda argument
    sta __call_parse_value_0
    lda argument+1
    sta __call_parse_value_0+1
    lda argument_length
    sta __call_parse_value_1
    jsr parse_value
    sta status
    lda status
    cmp VALUE_OK
    bne yes_10
    jmp join_12
yes_10:
    lda ASSEMBLE_BAD_ORIGIN
    rts
join_12:
    lda value_result
    sta ass_origin
    lda value_result+1
    sta ass_origin+1
    lda #$00
    sta origin_allowed
    lda ASSEMBLE_OK
    rts
join_3:
    lda argument
    sta __call_parse_value_0
    lda argument+1
    sta __call_parse_value_0+1
    lda argument_length
    sta __call_parse_value_1
    jsr parse_value
    sta status
    lda status
    cmp VALUE_OK
    bne yes_13
    jmp join_15
yes_13:
    lda status
    cmp VALUE_SYMBOL_FULL
    beq yes_16
    jmp join_18
yes_16:
    lda ASSEMBLE_SYMBOL_FULL
    rts
join_18:
    lda status
    cmp VALUE_SCOPE_ERROR
    beq yes_19
    jmp join_21
yes_19:
    lda ASSEMBLE_SCOPE_ERROR
    rts
join_21:
    lda ASSEMBLE_BAD_SYMBOL
    rts
join_15:
    lda name
    sta __call_define_constant_0
    lda name+1
    sta __call_define_constant_0+1
    lda name_length
    sta __call_define_constant_1
    lda value_result
    sta __call_define_constant_2
    lda value_result+1
    sta __call_define_constant_2+1
    jsr define_constant
    rts
