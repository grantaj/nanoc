entry:
    lda name
    sta __call_find_symbol_0
    lda name+1
    sta __call_find_symbol_0+1
    lda length
    sta __call_find_symbol_1
    jsr find_symbol
    sta symbol
    stx symbol+1
    lda #$00
    eor #$80
    sta __rh
    lda symbol+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda symbol
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp join_3
__sel2:
    jmp yes_1
__sel3:
    jmp yes_1
yes_1:
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda symbol
    sta __ix
    lda symbol+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v8
    lda __v8
    cmp SYMBOL_CONSTANT
    beq yes_4
    jmp join_6
yes_4:
    sec
    lda #$00
    sbc #$04
    sta __v12
    lda #$00
    sbc #$00
    sta __v12+1
    lda __v12
    ldx __v12+1
    rts
join_6:
    lda symbol
    ldx symbol+1
    rts
join_3:
    sec
    lda #$00
    sbc #$02
    sta __v16
    lda #$00
    sbc #$00
    sta __v16+1
    lda symbol+1
    cmp __v16+1
    bne join_9
    lda symbol
    cmp __v16
    beq yes_7
    jmp join_9
yes_7:
    sec
    lda #$00
    sbc #$02
    sta __v19
    lda #$00
    sbc #$00
    sta __v19+1
    lda __v19
    ldx __v19+1
    rts
join_9:
    lda name
    sta __call_allocate_symbol_0
    lda name+1
    sta __call_allocate_symbol_0+1
    lda length
    sta __call_allocate_symbol_1
    lda SYMBOL_LABEL_UNDEFINED
    sta __call_allocate_symbol_2
    lda #$00
    sta __call_allocate_symbol_3
    lda #$00
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    rts
