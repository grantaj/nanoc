* = $0800
__ap = $0010
ASSEMBLE_BAD_ORIGIN = $4000
ASSEMBLE_BAD_SYMBOL = $4002
ASSEMBLE_OK = $4004
ASSEMBLE_SCOPE_ERROR = $4006
ASSEMBLE_SYMBOL_FULL = $4008
VALUE_OK = $400a
VALUE_SCOPE_ERROR = $400c
VALUE_SYMBOL_FULL = $400e
__L_process_symbol_argument = $4010
__L_process_symbol_argument_length = $4012
__L_process_symbol_name = $4014
__L_process_symbol_name_length = $4016
__L_process_symbol_status = $4018
__T_process_symbol___v12 = $401a
__T_process_symbol___v13 = $401c
__T_process_symbol___v22 = $401e
__T_process_symbol___v23 = $4020
__T_process_symbol___v37 = $4022
__T_process_symbol___v38 = $4024
__T_process_symbol___v39 = $4026
__T_process_symbol___v5 = $4028
__call_define_constant_0 = $402a
__call_define_constant_1 = $402c
__call_define_constant_2 = $402e
__call_parse_value_0 = $4030
__call_parse_value_1 = $4032
ass_origin = $4034
define_constant = $4036
origin_allowed = $4038
parse_value = $403a
value_result = $403c
process_symbol:
__F_process_symbol_entry:
    lda __L_process_symbol_name_length
    cmp #$01
    beq __F_process_symbol_yes_1
    jmp __F_process_symbol_join_3
__F_process_symbol_yes_1:
    ldy #$00
    lda __L_process_symbol_name
    sta __ap
    lda __L_process_symbol_name+1
    sta __ap+1
    lda (__ap),y
    sta __T_process_symbol___v5
    cmp #$2a
    beq __F_process_symbol_yes_4
    jmp __F_process_symbol_join_3
__F_process_symbol_yes_4:
    lda origin_allowed
    cmp #$00
    beq __F_process_symbol_yes_7
    jmp __F_process_symbol_join_9
__F_process_symbol_yes_7:
    lda ASSEMBLE_BAD_ORIGIN
    ldx #$00
    rts
__F_process_symbol_join_9:
    lda __L_process_symbol_argument
    sta __T_process_symbol___v12
    lda __L_process_symbol_argument+1
    sta __T_process_symbol___v12+1
    lda __L_process_symbol_argument_length
    sta __T_process_symbol___v13
    lda __T_process_symbol___v12
    sta __call_parse_value_0
    lda __T_process_symbol___v12+1
    sta __call_parse_value_0+1
    lda __T_process_symbol___v13
    sta __call_parse_value_1
    jsr parse_value
    sta __L_process_symbol_status
    lda __L_process_symbol_status
    cmp VALUE_OK
    bne __F_process_symbol_yes_10
    jmp __F_process_symbol_join_12
__F_process_symbol_yes_10:
    lda ASSEMBLE_BAD_ORIGIN
    ldx #$00
    rts
__F_process_symbol_join_12:
    lda value_result
    sta ass_origin
    lda value_result+1
    sta ass_origin+1
    lda #$00
    sta origin_allowed
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_process_symbol_join_3:
    lda __L_process_symbol_argument
    sta __T_process_symbol___v22
    lda __L_process_symbol_argument+1
    sta __T_process_symbol___v22+1
    lda __L_process_symbol_argument_length
    sta __T_process_symbol___v23
    lda __T_process_symbol___v22
    sta __call_parse_value_0
    lda __T_process_symbol___v22+1
    sta __call_parse_value_0+1
    lda __T_process_symbol___v23
    sta __call_parse_value_1
    jsr parse_value
    sta __L_process_symbol_status
    lda __L_process_symbol_status
    cmp VALUE_OK
    bne __F_process_symbol_yes_13
    jmp __F_process_symbol_join_15
__F_process_symbol_yes_13:
    lda __L_process_symbol_status
    cmp VALUE_SYMBOL_FULL
    beq __F_process_symbol_yes_16
    jmp __F_process_symbol_join_18
__F_process_symbol_yes_16:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_process_symbol_join_18:
    lda __L_process_symbol_status
    cmp VALUE_SCOPE_ERROR
    beq __F_process_symbol_yes_19
    jmp __F_process_symbol_join_21
__F_process_symbol_yes_19:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_process_symbol_join_21:
    lda ASSEMBLE_BAD_SYMBOL
    ldx #$00
    rts
__F_process_symbol_join_15:
    lda __L_process_symbol_name
    sta __T_process_symbol___v37
    lda __L_process_symbol_name+1
    sta __T_process_symbol___v37+1
    lda __L_process_symbol_name_length
    sta __T_process_symbol___v38
    lda value_result
    sta __T_process_symbol___v39
    lda value_result+1
    sta __T_process_symbol___v39+1
    lda __T_process_symbol___v37
    sta __call_define_constant_0
    lda __T_process_symbol___v37+1
    sta __call_define_constant_0+1
    lda __T_process_symbol___v38
    sta __call_define_constant_1
    lda __T_process_symbol___v39
    sta __call_define_constant_2
    lda __T_process_symbol___v39+1
    sta __call_define_constant_2+1
    jsr define_constant
    ldx #$00
    rts
