* = $0800
VALUE_PREFIX_LOW = $4000
__L_apply_byte_prefix_prefix = $4002
__L_apply_byte_prefix_value = $4004
__T_apply_byte_prefix___v11 = $4006
__T_apply_byte_prefix___v13 = $4008
__T_apply_byte_prefix___v2 = $400a
__T_apply_byte_prefix___v8 = $400c
apply_byte_prefix:
__F_apply_byte_prefix_entry:
    lda __L_apply_byte_prefix_value
    sta __T_apply_byte_prefix___v2
    lda __L_apply_byte_prefix_value+1
    sta __T_apply_byte_prefix___v2+1
    lda __T_apply_byte_prefix___v2
    sta __L_apply_byte_prefix_value
    lda __T_apply_byte_prefix___v2+1
    sta __L_apply_byte_prefix_value+1
    lda __L_apply_byte_prefix_prefix
    cmp VALUE_PREFIX_LOW
    beq __F_apply_byte_prefix_yes_1
    jmp __F_apply_byte_prefix_join_3
__F_apply_byte_prefix_yes_1:
    lda __L_apply_byte_prefix_value
    and #$ff
    sta __T_apply_byte_prefix___v8
    lda __L_apply_byte_prefix_value+1
    and #$00
    sta __T_apply_byte_prefix___v8+1
    lda __T_apply_byte_prefix___v8
    ldx #$00
    rts
__F_apply_byte_prefix_join_3:
    lda __L_apply_byte_prefix_value
    sta __T_apply_byte_prefix___v11
    lda __L_apply_byte_prefix_value+1
    sta __T_apply_byte_prefix___v11+1
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lsr __T_apply_byte_prefix___v11+1
    ror __T_apply_byte_prefix___v11
    lda __T_apply_byte_prefix___v11
    and #$ff
    sta __T_apply_byte_prefix___v13
    lda __T_apply_byte_prefix___v11+1
    and #$00
    sta __T_apply_byte_prefix___v13+1
    lda __T_apply_byte_prefix___v13
    ldx #$00
    rts
