* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
ASSEMBLE_OK = $4000
ASSEMBLE_WORK_FULL = $4002
__L_append_fixup_addend = $4004
__L_append_fixup_kind = $4006
__L_append_fixup_n = $4008
__L_append_fixup_prefix = $400a
__L_append_fixup_stage = $400c
__L_append_fixup_symbol = $400e
__T_append_fixup___v10 = $4010
__T_append_fixup___v12 = $4012
__T_append_fixup___v13 = $4014
__T_append_fixup___v15 = $4016
__T_append_fixup___v18 = $4018
__T_append_fixup___v20 = $401a
__T_append_fixup___v21 = $401c
__T_append_fixup___v6 = $401e
__T_append_fixup___v7 = $4020
__T_append_fixup___v9 = $4022
fixup_addend = $4024
fixup_count = $4026
fixup_kind = $4028
fixup_prefix = $402a
fixup_stage = $402c
fixup_symbol = $402e
append_fixup:
__F_append_fixup_entry:
    lda fixup_count
    sta __L_append_fixup_n
    lda fixup_count+1
    sta __L_append_fixup_n+1
    lda #$02
    eor #$80
    sta __rh
    lda __L_append_fixup_n+1
    eor #$80
    cmp __rh
    bcc __F_append_fixup___sel1
    bne __F_append_fixup___sel2
    lda __L_append_fixup_n
    cmp #$80
    bcc __F_append_fixup___sel1
    bne __F_append_fixup___sel2
    jmp __F_append_fixup___sel3
__F_append_fixup___sel1:
    jmp __F_append_fixup_join_3
__F_append_fixup___sel2:
    jmp __F_append_fixup_yes_1
__F_append_fixup___sel3:
    jmp __F_append_fixup_yes_1
__F_append_fixup_yes_1:
    lda ASSEMBLE_WORK_FULL
    ldx #$00
    rts
__F_append_fixup_join_3:
    lda __L_append_fixup_n
    sta __T_append_fixup___v6
    lda __L_append_fixup_n+1
    sta __T_append_fixup___v6+1
    lda __L_append_fixup_kind
    sta __T_append_fixup___v7
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
    lda __T_append_fixup___v6
    sta __ix
    lda __T_append_fixup___v6+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_append_fixup___v7
    sta (__ap),y
    lda __L_append_fixup_n
    sta __T_append_fixup___v9
    lda __L_append_fixup_n+1
    sta __T_append_fixup___v9+1
    lda __L_append_fixup_stage
    sta __T_append_fixup___v10
    lda __L_append_fixup_stage+1
    sta __T_append_fixup___v10+1
    lda #<fixup_stage
    sta __ap
    lda #>fixup_stage
    sta __ap+1
    lda __T_append_fixup___v9
    asl
    sta __ix
    lda __T_append_fixup___v9+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_append_fixup___v10
    sta (__ap),y
    iny
    lda __T_append_fixup___v10+1
    sta (__ap),y
    lda __L_append_fixup_n
    sta __T_append_fixup___v12
    lda __L_append_fixup_n+1
    sta __T_append_fixup___v12+1
    lda __L_append_fixup_symbol
    sta __T_append_fixup___v13
    lda __L_append_fixup_symbol+1
    sta __T_append_fixup___v13+1
    lda #<fixup_symbol
    sta __ap
    lda #>fixup_symbol
    sta __ap+1
    lda __T_append_fixup___v12
    asl
    sta __ix
    lda __T_append_fixup___v12+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_append_fixup___v13
    sta (__ap),y
    iny
    lda __T_append_fixup___v13+1
    sta (__ap),y
    lda __L_append_fixup_n
    sta __T_append_fixup___v15
    lda __L_append_fixup_n+1
    sta __T_append_fixup___v15+1
    lda __L_append_fixup_addend
    sta __T_append_fixup___v18
    lda __L_append_fixup_addend+1
    sta __T_append_fixup___v18+1
    lda #<fixup_addend
    sta __ap
    lda #>fixup_addend
    sta __ap+1
    lda __T_append_fixup___v15
    asl
    sta __ix
    lda __T_append_fixup___v15+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_append_fixup___v18
    sta (__ap),y
    iny
    lda __T_append_fixup___v18+1
    sta (__ap),y
    lda __L_append_fixup_n
    sta __T_append_fixup___v20
    lda __L_append_fixup_n+1
    sta __T_append_fixup___v20+1
    lda __L_append_fixup_prefix
    sta __T_append_fixup___v21
    lda #<fixup_prefix
    sta __ap
    lda #>fixup_prefix
    sta __ap+1
    lda __T_append_fixup___v20
    sta __ix
    lda __T_append_fixup___v20+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_append_fixup___v21
    sta (__ap),y
    lda __L_append_fixup_n
    clc
    adc #$01
    sta fixup_count
    lda __L_append_fixup_n+1
    adc #$00
    sta fixup_count+1
    lda ASSEMBLE_OK
    ldx #$00
    rts
