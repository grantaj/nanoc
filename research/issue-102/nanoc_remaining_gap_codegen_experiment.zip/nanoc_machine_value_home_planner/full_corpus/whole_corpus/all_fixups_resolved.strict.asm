* = $0800
__ap = $0010
__rh = $0014
FIXUP_NONE = $4000
__L_all_fixups_resolved_i = $4002
__T_all_fixups_resolved___v12 = $4004
__T_all_fixups_resolved___v6 = $4006
fixup_count = $4008
fixup_kind = $400a
all_fixups_resolved:
__F_all_fixups_resolved_entry:
    lda #$00
    sta __L_all_fixups_resolved_i
    lda #$00
    sta __L_all_fixups_resolved_i+1
    ldy #$00
    lda #<fixup_kind
    sta __ap
    lda #>fixup_kind
    sta __ap+1
__F_all_fixups_resolved_while_1:
    lda fixup_count+1
    eor #$80
    sta __rh
    lda __L_all_fixups_resolved_i+1
    eor #$80
    cmp __rh
    bcc __F_all_fixups_resolved___sel1
    bne __F_all_fixups_resolved___sel2
    lda __L_all_fixups_resolved_i
    cmp fixup_count
    bcc __F_all_fixups_resolved___sel1
    bne __F_all_fixups_resolved___sel2
    jmp __F_all_fixups_resolved___sel3
__F_all_fixups_resolved___sel1:
    jmp __F_all_fixups_resolved_body_2
__F_all_fixups_resolved___sel2:
    jmp __F_all_fixups_resolved_after_3
__F_all_fixups_resolved___sel3:
    jmp __F_all_fixups_resolved_after_3
__F_all_fixups_resolved_body_2:
    lda (__ap),y
    sta __T_all_fixups_resolved___v6
    cmp FIXUP_NONE
    bne __F_all_fixups_resolved_yes_4
    jmp __F_all_fixups_resolved_join_6
__F_all_fixups_resolved_yes_4:
    lda #$00
    ldx #$00
    rts
__F_all_fixups_resolved_join_6:
    lda __L_all_fixups_resolved_i
    clc
    adc #$01
    sta __T_all_fixups_resolved___v12
    lda __L_all_fixups_resolved_i+1
    adc #$00
    sta __T_all_fixups_resolved___v12+1
    lda __T_all_fixups_resolved___v12
    sta __L_all_fixups_resolved_i
    lda __T_all_fixups_resolved___v12+1
    sta __L_all_fixups_resolved_i+1
    inc __ap
    bne __F_all_fixups_resolved___sel4
    inc __ap+1
__F_all_fixups_resolved___sel4:
    jmp __F_all_fixups_resolved_while_1
__F_all_fixups_resolved_after_3:
    lda #$01
    ldx #$00
    rts
