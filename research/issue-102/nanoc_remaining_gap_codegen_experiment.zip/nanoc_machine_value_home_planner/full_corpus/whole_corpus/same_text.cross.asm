entry:
    lda a_length
    cmp b_length
    bne yes_1
    jmp join_3
yes_1:
    lda #$00
    rts
join_3:
    lda #$00
    sta i
while_4:
    lda i
    cmp a_length
    bcc body_5
    jmp after_6
body_5:
    ldy i
    lda a
    sta __ap
    lda a+1
    sta __ap+1
    lda (__ap),y
    sta __v10
    ldy i
    lda b
    sta __ap
    lda b+1
    sta __ap+1
    lda (__ap),y
    sta __v13
    lda __v10
    cmp __v13
    bne yes_7
    jmp join_9
yes_7:
    lda #$00
    rts
join_9:
    inc i
    jmp while_4
after_6:
    lda #$01
    rts
