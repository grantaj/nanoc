entry:
    lda mnemonic
    sta __call_find_opcode_0
    lda mode
    sta __call_find_opcode_1
    jsr find_opcode
    sta opcode
    stx opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda opcode+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda opcode
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp yes_1
__sel2:
    jmp join_3
__sel3:
    jmp join_3
yes_1:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_3:
    lda text
    sta __call_parse_value_0
    lda text+1
    sta __call_parse_value_0+1
    lda length
    sta __call_parse_value_1
    jsr parse_value
    sta status
    lda status
    cmp VALUE_OK
    beq yes_4
    jmp join_6
yes_4:
    lda mode
    cmp MODE_RELATIVE
    beq yes_7
    jmp join_9
yes_7:
    lda opcode
    sta __call_stage_resolved_relative_0
    lda value_result
    sta __call_stage_resolved_relative_1
    lda value_result+1
    sta __call_stage_resolved_relative_1+1
    jsr stage_resolved_relative
    rts
join_9:
    lda opcode
    sta __call_stage_resolved_instruction_0
    lda mode
    sta __call_stage_resolved_instruction_1
    lda value_result
    sta __call_stage_resolved_instruction_2
    lda value_result+1
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    rts
join_6:
    lda status
    cmp VALUE_UNRESOLVED
    beq yes_10
    jmp join_12
yes_10:
    lda opcode
    sta __call_stage_unresolved_instruction_0
    lda mode
    sta __call_stage_unresolved_instruction_1
    lda captured_symbol
    sta __call_stage_unresolved_instruction_2
    lda captured_symbol+1
    sta __call_stage_unresolved_instruction_2+1
    lda captured_addend
    sta __call_stage_unresolved_instruction_3
    lda captured_addend+1
    sta __call_stage_unresolved_instruction_3+1
    lda captured_prefix
    sta __call_stage_unresolved_instruction_4
    jsr stage_unresolved_instruction
    rts
join_12:
    lda status
    cmp VALUE_SYMBOL_FULL
    beq yes_13
    jmp join_15
yes_13:
    lda ASSEMBLE_SYMBOL_FULL
    rts
join_15:
    lda status
    cmp VALUE_SCOPE_ERROR
    beq yes_16
    jmp join_18
yes_16:
    lda ASSEMBLE_SCOPE_ERROR
    rts
join_18:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
