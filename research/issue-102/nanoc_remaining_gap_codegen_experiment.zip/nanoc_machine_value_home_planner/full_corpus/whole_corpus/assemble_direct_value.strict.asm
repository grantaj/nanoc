* = $0800
__rh = $0014
ASSEMBLE_BAD_INSTRUCTION = $4000
ASSEMBLE_SCOPE_ERROR = $4002
ASSEMBLE_SYMBOL_FULL = $4004
MODE_RELATIVE = $4006
VALUE_OK = $4008
VALUE_PREFIX_NONE = $400a
VALUE_SCOPE_ERROR = $400c
VALUE_SYMBOL_FULL = $400e
VALUE_UNRESOLVED = $4010
__L_assemble_direct_value_index = $4012
__L_assemble_direct_value_length = $4014
__L_assemble_direct_value_long_mode = $4016
__L_assemble_direct_value_long_opcode = $4018
__L_assemble_direct_value_mnemonic = $401a
__L_assemble_direct_value_mode = $401c
__L_assemble_direct_value_opcode = $401e
__L_assemble_direct_value_short_mode = $4020
__L_assemble_direct_value_short_opcode = $4022
__L_assemble_direct_value_status = $4024
__L_assemble_direct_value_text = $4026
__T_assemble_direct_value___v10 = $4028
__T_assemble_direct_value___v11 = $402a
__T_assemble_direct_value___v12 = $402c
__T_assemble_direct_value___v14 = $402e
__T_assemble_direct_value___v15 = $4030
__T_assemble_direct_value___v3 = $4032
__T_assemble_direct_value___v32 = $4034
__T_assemble_direct_value___v34 = $4036
__T_assemble_direct_value___v36 = $4038
__T_assemble_direct_value___v37 = $403a
__T_assemble_direct_value___v39 = $403c
__T_assemble_direct_value___v4 = $403e
__T_assemble_direct_value___v40 = $4040
__T_assemble_direct_value___v51 = $4042
__T_assemble_direct_value___v52 = $4044
__T_assemble_direct_value___v53 = $4046
__T_assemble_direct_value___v58 = $4048
__T_assemble_direct_value___v59 = $404a
__T_assemble_direct_value___v60 = $404c
__T_assemble_direct_value___v79 = $404e
__T_assemble_direct_value___v80 = $4050
__T_assemble_direct_value___v81 = $4052
__T_assemble_direct_value___v82 = $4054
__T_assemble_direct_value___v83 = $4056
__T_assemble_direct_value___v9 = $4058
__call_assemble_mode_value_0 = $405a
__call_assemble_mode_value_1 = $405c
__call_assemble_mode_value_2 = $405e
__call_assemble_mode_value_3 = $4060
__call_find_opcode_0 = $4062
__call_find_opcode_1 = $4064
__call_long_mode_for_index_0 = $4066
__call_parse_value_0 = $4068
__call_parse_value_1 = $406a
__call_short_mode_for_index_0 = $406c
__call_stage_resolved_instruction_0 = $406e
__call_stage_resolved_instruction_1 = $4070
__call_stage_resolved_instruction_2 = $4072
__call_stage_unresolved_instruction_0 = $4074
__call_stage_unresolved_instruction_1 = $4076
__call_stage_unresolved_instruction_2 = $4078
__call_stage_unresolved_instruction_3 = $407a
__call_stage_unresolved_instruction_4 = $407c
assemble_mode_value = $407e
captured_addend = $4080
captured_prefix = $4082
captured_symbol = $4084
find_opcode = $4086
long_mode_for_index = $4088
parse_value = $408a
short_mode_for_index = $408c
stage_resolved_instruction = $408e
stage_unresolved_instruction = $4090
value_result = $4092
assemble_direct_value:
__F_assemble_direct_value_entry:
    lda __L_assemble_direct_value_index
    cmp #$00
    beq __F_assemble_direct_value_yes_1
    jmp __F_assemble_direct_value_join_3
__F_assemble_direct_value_yes_1:
    lda __L_assemble_direct_value_mnemonic
    sta __T_assemble_direct_value___v3
    lda MODE_RELATIVE
    sta __T_assemble_direct_value___v4
    lda __T_assemble_direct_value___v3
    sta __call_find_opcode_0
    lda __T_assemble_direct_value___v4
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_direct_value_opcode
    stx __L_assemble_direct_value_opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_direct_value_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_direct_value___sel1
    bne __F_assemble_direct_value___sel2
    lda __L_assemble_direct_value_opcode
    cmp #$00
    bcc __F_assemble_direct_value___sel1
    bne __F_assemble_direct_value___sel2
    jmp __F_assemble_direct_value___sel3
__F_assemble_direct_value___sel1:
    jmp __F_assemble_direct_value_join_3
__F_assemble_direct_value___sel2:
    jmp __F_assemble_direct_value_yes_4
__F_assemble_direct_value___sel3:
    jmp __F_assemble_direct_value_yes_4
__F_assemble_direct_value_yes_4:
    lda __L_assemble_direct_value_mnemonic
    sta __T_assemble_direct_value___v9
    lda MODE_RELATIVE
    sta __T_assemble_direct_value___v10
    lda __L_assemble_direct_value_text
    sta __T_assemble_direct_value___v11
    lda __L_assemble_direct_value_text+1
    sta __T_assemble_direct_value___v11+1
    lda __L_assemble_direct_value_length
    sta __T_assemble_direct_value___v12
    lda __T_assemble_direct_value___v9
    sta __call_assemble_mode_value_0
    lda __T_assemble_direct_value___v10
    sta __call_assemble_mode_value_1
    lda __T_assemble_direct_value___v11
    sta __call_assemble_mode_value_2
    lda __T_assemble_direct_value___v11+1
    sta __call_assemble_mode_value_2+1
    lda __T_assemble_direct_value___v12
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    ldx #$00
    rts
__F_assemble_direct_value_join_3:
    lda __L_assemble_direct_value_text
    sta __T_assemble_direct_value___v14
    lda __L_assemble_direct_value_text+1
    sta __T_assemble_direct_value___v14+1
    lda __L_assemble_direct_value_length
    sta __T_assemble_direct_value___v15
    lda __T_assemble_direct_value___v14
    sta __call_parse_value_0
    lda __T_assemble_direct_value___v14+1
    sta __call_parse_value_0+1
    lda __T_assemble_direct_value___v15
    sta __call_parse_value_1
    jsr parse_value
    sta __L_assemble_direct_value_status
    lda __L_assemble_direct_value_status
    cmp VALUE_OK
    bne __F_assemble_direct_value_yes_7
    jmp __F_assemble_direct_value_join_9
__F_assemble_direct_value_yes_7:
    lda __L_assemble_direct_value_status
    cmp VALUE_UNRESOLVED
    bne __F_assemble_direct_value_yes_10
    jmp __F_assemble_direct_value_join_9
__F_assemble_direct_value_yes_10:
    lda __L_assemble_direct_value_status
    cmp VALUE_SYMBOL_FULL
    beq __F_assemble_direct_value_yes_13
    jmp __F_assemble_direct_value_join_15
__F_assemble_direct_value_yes_13:
    lda ASSEMBLE_SYMBOL_FULL
    ldx #$00
    rts
__F_assemble_direct_value_join_15:
    lda __L_assemble_direct_value_status
    cmp VALUE_SCOPE_ERROR
    beq __F_assemble_direct_value_yes_16
    jmp __F_assemble_direct_value_join_18
__F_assemble_direct_value_yes_16:
    lda ASSEMBLE_SCOPE_ERROR
    ldx #$00
    rts
__F_assemble_direct_value_join_18:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_direct_value_join_9:
    lda __L_assemble_direct_value_index
    sta __T_assemble_direct_value___v32
    lda __T_assemble_direct_value___v32
    sta __call_short_mode_for_index_0
    jsr short_mode_for_index
    sta __L_assemble_direct_value_short_mode
    lda __L_assemble_direct_value_index
    sta __T_assemble_direct_value___v34
    lda __T_assemble_direct_value___v34
    sta __call_long_mode_for_index_0
    jsr long_mode_for_index
    sta __L_assemble_direct_value_long_mode
    lda __L_assemble_direct_value_mnemonic
    sta __T_assemble_direct_value___v36
    lda __L_assemble_direct_value_short_mode
    sta __T_assemble_direct_value___v37
    lda __T_assemble_direct_value___v36
    sta __call_find_opcode_0
    lda __T_assemble_direct_value___v37
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_direct_value_short_opcode
    stx __L_assemble_direct_value_short_opcode+1
    lda __L_assemble_direct_value_mnemonic
    sta __T_assemble_direct_value___v39
    lda __L_assemble_direct_value_long_mode
    sta __T_assemble_direct_value___v40
    lda __T_assemble_direct_value___v39
    sta __call_find_opcode_0
    lda __T_assemble_direct_value___v40
    sta __call_find_opcode_1
    jsr find_opcode
    sta __L_assemble_direct_value_long_opcode
    stx __L_assemble_direct_value_long_opcode+1
    lda __L_assemble_direct_value_status
    cmp VALUE_OK
    beq __F_assemble_direct_value_yes_19
    jmp __F_assemble_direct_value_join_21
__F_assemble_direct_value_yes_19:
    lda value_result+1
    cmp #$00
    bcc __F_assemble_direct_value___sel4
    bne __F_assemble_direct_value___sel5
    lda value_result
    cmp #$ff
    bcc __F_assemble_direct_value___sel4
    bne __F_assemble_direct_value___sel5
    jmp __F_assemble_direct_value___sel6
__F_assemble_direct_value___sel4:
    jmp __F_assemble_direct_value_yes_22
__F_assemble_direct_value___sel5:
    jmp __F_assemble_direct_value_join_24
__F_assemble_direct_value___sel6:
    jmp __F_assemble_direct_value_yes_22
__F_assemble_direct_value_yes_22:
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_direct_value_short_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_direct_value___sel7
    bne __F_assemble_direct_value___sel8
    lda __L_assemble_direct_value_short_opcode
    cmp #$00
    bcc __F_assemble_direct_value___sel7
    bne __F_assemble_direct_value___sel8
    jmp __F_assemble_direct_value___sel9
__F_assemble_direct_value___sel7:
    jmp __F_assemble_direct_value_join_24
__F_assemble_direct_value___sel8:
    jmp __F_assemble_direct_value_yes_25
__F_assemble_direct_value___sel9:
    jmp __F_assemble_direct_value_yes_25
__F_assemble_direct_value_yes_25:
    lda __L_assemble_direct_value_short_opcode
    sta __T_assemble_direct_value___v51
    lda __L_assemble_direct_value_short_opcode+1
    sta __T_assemble_direct_value___v51+1
    lda __L_assemble_direct_value_short_mode
    sta __T_assemble_direct_value___v52
    lda value_result
    sta __T_assemble_direct_value___v53
    lda value_result+1
    sta __T_assemble_direct_value___v53+1
    lda __T_assemble_direct_value___v51
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_direct_value___v51+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_direct_value___v52
    sta __call_stage_resolved_instruction_1
    lda __T_assemble_direct_value___v53
    sta __call_stage_resolved_instruction_2
    lda __T_assemble_direct_value___v53+1
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_direct_value_join_24:
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_direct_value_long_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_direct_value___sel10
    bne __F_assemble_direct_value___sel11
    lda __L_assemble_direct_value_long_opcode
    cmp #$00
    bcc __F_assemble_direct_value___sel10
    bne __F_assemble_direct_value___sel11
    jmp __F_assemble_direct_value___sel12
__F_assemble_direct_value___sel10:
    jmp __F_assemble_direct_value_join_30
__F_assemble_direct_value___sel11:
    jmp __F_assemble_direct_value_yes_28
__F_assemble_direct_value___sel12:
    jmp __F_assemble_direct_value_yes_28
__F_assemble_direct_value_yes_28:
    lda __L_assemble_direct_value_long_opcode
    sta __T_assemble_direct_value___v58
    lda __L_assemble_direct_value_long_opcode+1
    sta __T_assemble_direct_value___v58+1
    lda __L_assemble_direct_value_long_mode
    sta __T_assemble_direct_value___v59
    lda value_result
    sta __T_assemble_direct_value___v60
    lda value_result+1
    sta __T_assemble_direct_value___v60+1
    lda __T_assemble_direct_value___v58
    sta __call_stage_resolved_instruction_0
    lda __T_assemble_direct_value___v58+1
    sta __call_stage_resolved_instruction_0+1
    lda __T_assemble_direct_value___v59
    sta __call_stage_resolved_instruction_1
    lda __T_assemble_direct_value___v60
    sta __call_stage_resolved_instruction_2
    lda __T_assemble_direct_value___v60+1
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    ldx #$00
    rts
__F_assemble_direct_value_join_30:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_direct_value_join_21:
    lda __L_assemble_direct_value_long_mode
    sta __L_assemble_direct_value_mode
    lda __L_assemble_direct_value_long_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_long_opcode+1
    sta __L_assemble_direct_value_opcode+1
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    bne __F_assemble_direct_value_yes_31
    jmp __F_assemble_direct_value_no_32
__F_assemble_direct_value_yes_31:
    lda __L_assemble_direct_value_short_mode
    sta __L_assemble_direct_value_mode
    lda __L_assemble_direct_value_short_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_short_opcode+1
    sta __L_assemble_direct_value_opcode+1
    jmp __F_assemble_direct_value_join_33
__F_assemble_direct_value_no_32:
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_direct_value_long_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_direct_value___sel13
    bne __F_assemble_direct_value___sel14
    lda __L_assemble_direct_value_long_opcode
    cmp #$00
    bcc __F_assemble_direct_value___sel13
    bne __F_assemble_direct_value___sel14
    jmp __F_assemble_direct_value___sel15
__F_assemble_direct_value___sel13:
    jmp __F_assemble_direct_value_yes_34
__F_assemble_direct_value___sel14:
    jmp __F_assemble_direct_value_join_33
__F_assemble_direct_value___sel15:
    jmp __F_assemble_direct_value_join_33
__F_assemble_direct_value_yes_34:
    lda __L_assemble_direct_value_short_mode
    sta __L_assemble_direct_value_mode
    lda __L_assemble_direct_value_short_opcode
    sta __L_assemble_direct_value_opcode
    lda __L_assemble_direct_value_short_opcode+1
    sta __L_assemble_direct_value_opcode+1
__F_assemble_direct_value_join_33:
    lda #$00
    eor #$80
    sta __rh
    lda __L_assemble_direct_value_opcode+1
    eor #$80
    cmp __rh
    bcc __F_assemble_direct_value___sel16
    bne __F_assemble_direct_value___sel17
    lda __L_assemble_direct_value_opcode
    cmp #$00
    bcc __F_assemble_direct_value___sel16
    bne __F_assemble_direct_value___sel17
    jmp __F_assemble_direct_value___sel18
__F_assemble_direct_value___sel16:
    jmp __F_assemble_direct_value_yes_37
__F_assemble_direct_value___sel17:
    jmp __F_assemble_direct_value_join_39
__F_assemble_direct_value___sel18:
    jmp __F_assemble_direct_value_join_39
__F_assemble_direct_value_yes_37:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_assemble_direct_value_join_39:
    lda __L_assemble_direct_value_opcode
    sta __T_assemble_direct_value___v79
    lda __L_assemble_direct_value_opcode+1
    sta __T_assemble_direct_value___v79+1
    lda __L_assemble_direct_value_mode
    sta __T_assemble_direct_value___v80
    lda captured_symbol
    sta __T_assemble_direct_value___v81
    lda captured_symbol+1
    sta __T_assemble_direct_value___v81+1
    lda captured_addend
    sta __T_assemble_direct_value___v82
    lda captured_addend+1
    sta __T_assemble_direct_value___v82+1
    lda captured_prefix
    sta __T_assemble_direct_value___v83
    lda __T_assemble_direct_value___v79
    sta __call_stage_unresolved_instruction_0
    lda __T_assemble_direct_value___v79+1
    sta __call_stage_unresolved_instruction_0+1
    lda __T_assemble_direct_value___v80
    sta __call_stage_unresolved_instruction_1
    lda __T_assemble_direct_value___v81
    sta __call_stage_unresolved_instruction_2
    lda __T_assemble_direct_value___v81+1
    sta __call_stage_unresolved_instruction_2+1
    lda __T_assemble_direct_value___v82
    sta __call_stage_unresolved_instruction_3
    lda __T_assemble_direct_value___v82+1
    sta __call_stage_unresolved_instruction_3+1
    lda __T_assemble_direct_value___v83
    sta __call_stage_unresolved_instruction_4
    jsr stage_unresolved_instruction
    ldx #$00
    rts
