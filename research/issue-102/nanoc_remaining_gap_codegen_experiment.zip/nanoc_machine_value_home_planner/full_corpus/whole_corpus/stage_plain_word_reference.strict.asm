* = $0800
__ap = $0010
__ix = $0012
ASSEMBLE_OK = $4000
__L_stage_plain_word_reference_old_head = $4002
__L_stage_plain_word_reference_stage = $4004
__L_stage_plain_word_reference_status = $4006
__L_stage_plain_word_reference_symbol = $4008
__T_stage_plain_word_reference___v14 = $400a
__T_stage_plain_word_reference___v16 = $400c
__T_stage_plain_word_reference___v23 = $400e
__T_stage_plain_word_reference___v26 = $4010
__T_stage_plain_word_reference___v3 = $4012
__T_stage_plain_word_reference___v6 = $4014
__call_stage_byte_0 = $4016
ass_image_length = $4018
stage_byte = $401a
symbol_payload = $401c
stage_plain_word_reference:
__F_stage_plain_word_reference_entry:
    lda ass_image_length
    sta __L_stage_plain_word_reference_stage
    lda ass_image_length+1
    sta __L_stage_plain_word_reference_stage+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __L_stage_plain_word_reference_symbol
    asl
    sta __ix
    lda __L_stage_plain_word_reference_symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_stage_plain_word_reference___v3
    iny
    lda (__ap),y
    sta __T_stage_plain_word_reference___v3+1
    lda __T_stage_plain_word_reference___v3
    sta __L_stage_plain_word_reference_old_head
    lda __T_stage_plain_word_reference___v3+1
    sta __L_stage_plain_word_reference_old_head+1
    lda __L_stage_plain_word_reference_old_head
    and #$ff
    sta __T_stage_plain_word_reference___v6
    lda __L_stage_plain_word_reference_old_head+1
    and #$00
    sta __T_stage_plain_word_reference___v6+1
    lda __T_stage_plain_word_reference___v6
    sta __call_stage_byte_0
    lda __T_stage_plain_word_reference___v6+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_plain_word_reference_status
    lda __L_stage_plain_word_reference_status
    cmp ASSEMBLE_OK
    bne __F_stage_plain_word_reference_yes_1
    jmp __F_stage_plain_word_reference_join_3
__F_stage_plain_word_reference_yes_1:
    lda __L_stage_plain_word_reference_status
    ldx #$00
    rts
__F_stage_plain_word_reference_join_3:
    lda __L_stage_plain_word_reference_old_head
    sta __T_stage_plain_word_reference___v14
    lda __L_stage_plain_word_reference_old_head+1
    sta __T_stage_plain_word_reference___v14+1
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14+1
    cmp #$80
    ror
    sta __T_stage_plain_word_reference___v14+1
    ror __T_stage_plain_word_reference___v14
    lda __T_stage_plain_word_reference___v14
    and #$ff
    sta __T_stage_plain_word_reference___v16
    lda __T_stage_plain_word_reference___v14+1
    and #$00
    sta __T_stage_plain_word_reference___v16+1
    lda __T_stage_plain_word_reference___v16
    sta __call_stage_byte_0
    lda __T_stage_plain_word_reference___v16+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_plain_word_reference_status
    lda __L_stage_plain_word_reference_status
    cmp ASSEMBLE_OK
    bne __F_stage_plain_word_reference_yes_4
    jmp __F_stage_plain_word_reference_join_6
__F_stage_plain_word_reference_yes_4:
    lda __L_stage_plain_word_reference_status
    ldx #$00
    rts
__F_stage_plain_word_reference_join_6:
    lda __L_stage_plain_word_reference_symbol
    sta __T_stage_plain_word_reference___v23
    lda __L_stage_plain_word_reference_symbol+1
    sta __T_stage_plain_word_reference___v23+1
    lda __L_stage_plain_word_reference_stage
    clc
    adc #$01
    sta __T_stage_plain_word_reference___v26
    lda __L_stage_plain_word_reference_stage+1
    adc #$00
    sta __T_stage_plain_word_reference___v26+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda __T_stage_plain_word_reference___v23
    asl
    sta __ix
    lda __T_stage_plain_word_reference___v23+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_stage_plain_word_reference___v26
    sta (__ap),y
    iny
    lda __T_stage_plain_word_reference___v26+1
    sta (__ap),y
    lda ASSEMBLE_OK
    ldx #$00
    rts
