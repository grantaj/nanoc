entry:
    lda name
    sta __call_find_mnemonic_0
    lda name+1
    sta __call_find_mnemonic_0+1
    lda name_length
    sta __call_find_mnemonic_1
    jsr find_mnemonic
    sta mnemonic
    stx mnemonic+1
    lda #$00
    eor #$80
    sta __rh
    lda mnemonic+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda mnemonic
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp yes_1
__sel2:
    jmp join_3
__sel3:
    jmp join_3
yes_1:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_3:
    lda argument_length
    cmp #$00
    beq yes_4
    jmp join_6
yes_4:
    lda mnemonic
    sta __call_find_opcode_0
    lda MODE_IMPLIED
    sta __call_find_opcode_1
    jsr find_opcode
    sta opcode
    stx opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda opcode+1
    eor #$80
    cmp __rh
    bcc __sel4
    bne __sel5
    lda opcode
    cmp #$00
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp join_9
__sel5:
    jmp yes_7
__sel6:
    jmp yes_7
yes_7:
    lda opcode
    sta __call_stage_resolved_instruction_0
    lda MODE_IMPLIED
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    lda #$00
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    rts
join_9:
    lda mnemonic
    sta __call_find_opcode_0
    lda MODE_ACCUMULATOR
    sta __call_find_opcode_1
    jsr find_opcode
    sta opcode
    stx opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda opcode+1
    eor #$80
    cmp __rh
    bcc __sel7
    bne __sel8
    lda opcode
    cmp #$00
    bcc __sel7
    bne __sel8
    jmp __sel9
__sel7:
    jmp join_12
__sel8:
    jmp yes_10
__sel9:
    jmp yes_10
yes_10:
    lda opcode
    sta __call_stage_resolved_instruction_0
    lda MODE_ACCUMULATOR
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    lda #$00
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    rts
join_12:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_6:
    lda argument_length
    cmp #$01
    beq yes_13
    jmp join_15
yes_13:
    ldy #$00
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __v37
    lda __v37
    cmp #$41
    beq yes_16
    jmp join_15
yes_16:
    lda mnemonic
    sta __call_find_opcode_0
    lda MODE_ACCUMULATOR
    sta __call_find_opcode_1
    jsr find_opcode
    sta opcode
    stx opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda opcode+1
    eor #$80
    cmp __rh
    bcc __sel10
    bne __sel11
    lda opcode
    cmp #$00
    bcc __sel10
    bne __sel11
    jmp __sel12
__sel10:
    jmp yes_19
__sel11:
    jmp join_21
__sel12:
    jmp join_21
yes_19:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_21:
    lda opcode
    sta __call_stage_resolved_instruction_0
    lda MODE_ACCUMULATOR
    sta __call_stage_resolved_instruction_1
    lda #$00
    sta __call_stage_resolved_instruction_2
    lda #$00
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    rts
join_15:
    ldy #$00
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda (__ap),y
    sta __v53
    lda __v53
    cmp #$23
    beq yes_22
    jmp join_24
yes_22:
    lda argument_length
    cmp #$02
    bcc yes_25
    jmp join_27
yes_25:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_27:
    lda argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda argument_length
    sec
    sbc #$01
    sta __v67
    lda #$00
    sbc #$00
    sta __v67+1
    lda mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_IMMEDIATE
    sta __call_assemble_mode_value_1
    lda __v67
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    rts
join_24:
    ldy #$00
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda (__ap),y
    sta __v71
    lda __v71
    cmp #$28
    beq yes_28
    jmp join_30
yes_28:
    lda argument_length
    cmp #$03
    bcc yes_31
    jmp join_33
yes_31:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_33:
    lda argument_length
    sec
    sbc #$01
    sta __v81
    lda #$00
    sbc #$00
    sta __v81+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v81
    sta __ix
    lda __v81+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __v83
    lda __v83
    cmp #$59
    beq yes_34
    jmp join_36
yes_34:
    lda argument_length
    sec
    sbc #$02
    sta __v89
    lda #$00
    sbc #$00
    sta __v89+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v89
    sta __ix
    lda __v89+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v90
    lda __v90
    cmp #$2c
    beq yes_37
    jmp join_36
yes_37:
    lda argument_length
    sec
    sbc #$03
    sta __v96
    lda #$00
    sbc #$00
    sta __v96+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v96
    sta __ix
    lda __v96+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v97
    lda __v97
    cmp #$29
    bne yes_40
    jmp join_42
yes_40:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_42:
    lda argument_length
    sec
    sbc #$04
    sta core_length
    lda core_length
    cmp #$00
    bcc yes_43
    beq yes_43
    jmp join_45
yes_43:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_45:
    lda argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_INDIRECT_Y
    sta __call_assemble_mode_value_1
    lda core_length
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    rts
join_36:
    lda argument_length
    sec
    sbc #$01
    sta __v118
    lda #$00
    sbc #$00
    sta __v118+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v118
    sta __ix
    lda __v118+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v119
    lda __v119
    cmp #$29
    bne yes_46
    jmp join_48
yes_46:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_48:
    lda argument_length
    sec
    sbc #$02
    sta __v126
    lda #$00
    sbc #$00
    sta __v126+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v126
    sta __ix
    lda __v126+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __v128
    lda __v128
    cmp #$58
    beq yes_49
    jmp join_51
yes_49:
    lda argument_length
    cmp #$05
    bcc yes_52
    jmp join_54
yes_52:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_54:
    lda argument_length
    sec
    sbc #$03
    sta __v138
    lda #$00
    sbc #$00
    sta __v138+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v138
    sta __ix
    lda __v138+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v139
    lda __v139
    cmp #$2c
    bne yes_55
    jmp join_57
yes_55:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_57:
    lda argument_length
    sec
    sbc #$04
    sta core_length
    lda argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_INDIRECT_X
    sta __call_assemble_mode_value_1
    lda core_length
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    rts
join_51:
    lda argument_length
    sec
    sbc #$02
    sta core_length
    lda argument
    clc
    adc #$01
    sta __call_assemble_mode_value_2
    lda argument+1
    adc #$00
    sta __call_assemble_mode_value_2+1
    lda mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_INDIRECT
    sta __call_assemble_mode_value_1
    lda core_length
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    rts
join_30:
    lda #$00
    sta index
    lda argument_length
    sta core_length
    lda argument_length
    cmp #$03
    bcs yes_58
    jmp join_60
yes_58:
    lda argument_length
    sec
    sbc #$02
    sta __v171
    lda #$00
    sbc #$00
    sta __v171+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v171
    sta __ix
    lda __v171+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v172
    lda __v172
    cmp #$2c
    beq yes_61
    jmp join_60
yes_61:
    lda argument_length
    sec
    sbc #$01
    sta __v178
    lda #$00
    sbc #$00
    sta __v178+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v178
    sta __ix
    lda __v178+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __v180
    lda __v180
    cmp #$58
    beq yes_64
    jmp no_65
yes_64:
    lda #$01
    sta index
    lda argument_length
    sec
    sbc #$02
    sta core_length
    jmp join_60
no_65:
    lda argument_length
    sec
    sbc #$01
    sta __v190
    lda #$00
    sbc #$00
    sta __v190+1
    lda argument
    sta __ap
    lda argument+1
    sta __ap+1
    lda __v190
    sta __ix
    lda __v190+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __v192
    lda __v192
    cmp #$59
    beq yes_67
    jmp join_60
yes_67:
    lda #$02
    sta index
    lda argument_length
    sec
    sbc #$02
    sta core_length
join_60:
    lda mnemonic
    sta __call_assemble_direct_value_0
    lda argument
    sta __call_assemble_direct_value_1
    lda argument+1
    sta __call_assemble_direct_value_1+1
    lda core_length
    sta __call_assemble_direct_value_2
    lda index
    sta __call_assemble_direct_value_3
    jsr assemble_direct_value
    rts
