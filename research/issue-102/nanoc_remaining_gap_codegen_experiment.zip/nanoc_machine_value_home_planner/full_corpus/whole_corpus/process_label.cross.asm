entry:
    lda length
    cmp #$00
    beq yes_1
    jmp join_3
yes_1:
    lda ASSEMBLE_BAD_STATEMENT
    rts
join_3:
    ldy #$00
    lda name
    sta __ap
    lda name+1
    sta __ap+1
    lda (__ap),y
    sta __v6
    cmp #$2e
    beq yes_4
    jmp no_5
yes_4:
    lda current_scope
    cmp #$00
    beq yes_7
    jmp join_6
yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    rts
no_5:
    lda current_scope
    cmp #$ff
    beq yes_10
    jmp join_12
yes_10:
    lda ASSEMBLE_SCOPE_ERROR
    rts
join_12:
    inc current_scope
join_6:
    lda #$00
    sta origin_allowed
    lda ass_origin
    clc
    adc ass_image_length
    sta __v23
    lda ass_origin+1
    adc ass_image_length+1
    sta __v23+1
    lda __v23
    sta __v25
    lda __v23+1
    sta __v25+1
    lda __v25
    sta value
    lda __v25+1
    sta value+1
    lda name
    sta __call_define_label_0
    lda name+1
    sta __call_define_label_0+1
    lda length
    sta __call_define_label_1
    lda value
    sta __call_define_label_2
    lda value+1
    sta __call_define_label_2+1
    jsr define_label
    sta status
    lda status
    rts
