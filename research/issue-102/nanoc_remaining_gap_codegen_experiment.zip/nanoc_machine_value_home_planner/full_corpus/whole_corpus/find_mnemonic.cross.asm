entry:
    lda length
    cmp #$03
    bne yes_1
    jmp join_3
yes_1:
    sec
    lda #$00
    sbc #$01
    sta __v4
    lda #$00
    sbc #$00
    sta __v4+1
    lda __v4
    ldx __v4+1
    rts
join_3:
    lda #$00
    sta candidate
while_4:
    lda candidate
    cmp #$38
    bcc body_5
    jmp after_6
body_5:
    lda #$00
    sta __v11
    sta __v11+1
    lda candidate
    sta __mw
    lda #$00
    sta __mw+1
    clc
    lda __v11
    adc __mw
    sta __v11
    lda __v11+1
    adc __mw+1
    sta __v11+1
    asl __mw
    rol __mw+1
    clc
    lda __v11
    adc __mw
    sta __v11
    lda __v11+1
    adc __mw+1
    sta __v11+1
    lda __v11
    sta offset
    ldy #$00
    lda name
    sta __ap
    lda name+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __v15
    ldy offset
    lda mnemonic_table,y
    sta __v18
    lda __v15
    cmp __v18
    beq yes_7
    jmp join_9
yes_7:
    ldy #$01
    lda name
    sta __ap
    lda name+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __v23
    lda offset
    clc
    adc #$01
    sta __v27
    lda #$00
    adc #$00
    sta __v27+1
    lda #<mnemonic_table
    sta __ap
    lda #>mnemonic_table
    sta __ap+1
    lda __v27
    sta __ix
    lda __v27+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v28
    lda __v23
    cmp __v28
    beq yes_10
    jmp join_9
yes_10:
    ldy #$02
    lda name
    sta __ap
    lda name+1
    sta __ap+1
    lda (__ap),y
    sta __call_upper_char_0
    jsr upper_char
    sta __v33
    lda offset
    clc
    adc #$02
    sta __v37
    lda #$00
    adc #$00
    sta __v37+1
    lda #<mnemonic_table
    sta __ap
    lda #>mnemonic_table
    sta __ap+1
    lda __v37
    sta __ix
    lda __v37+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v38
    lda __v33
    cmp __v38
    beq yes_13
    jmp join_9
yes_13:
    lda candidate
    ldx #$00
    rts
join_9:
    inc candidate
    jmp while_4
after_6:
    sec
    lda #$00
    sbc #$01
    sta __v45
    lda #$00
    sbc #$00
    sta __v45+1
    lda __v45
    ldx __v45+1
    rts
