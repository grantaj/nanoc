* = $0800
ASSEMBLE_BAD_INSTRUCTION = $4000
ASSEMBLE_OK = $4002
FIXUP_BYTE = $4004
FIXUP_RELATIVE = $4006
FIXUP_WORD = $4008
MODE_RELATIVE = $400a
VALUE_PREFIX_NONE = $400c
__L_stage_unresolved_instruction_addend = $400e
__L_stage_unresolved_instruction_kind = $4010
__L_stage_unresolved_instruction_mode = $4012
__L_stage_unresolved_instruction_opcode = $4014
__L_stage_unresolved_instruction_prefix = $4016
__L_stage_unresolved_instruction_stage = $4018
__L_stage_unresolved_instruction_status = $401a
__L_stage_unresolved_instruction_symbol = $401c
__L_stage_unresolved_instruction_width = $401e
__T_stage_unresolved_instruction___v18 = $4020
__T_stage_unresolved_instruction___v21 = $4022
__T_stage_unresolved_instruction___v3 = $4024
__T_stage_unresolved_instruction___v35 = $4026
__T_stage_unresolved_instruction___v36 = $4028
__T_stage_unresolved_instruction___v37 = $402a
__T_stage_unresolved_instruction___v38 = $402c
__T_stage_unresolved_instruction___v39 = $402e
__T_stage_unresolved_instruction___v56 = $4030
__T_stage_unresolved_instruction___v57 = $4032
__T_stage_unresolved_instruction___v58 = $4034
__T_stage_unresolved_instruction___v59 = $4036
__T_stage_unresolved_instruction___v60 = $4038
__call_append_fixup_0 = $403a
__call_append_fixup_1 = $403c
__call_append_fixup_2 = $403e
__call_append_fixup_3 = $4040
__call_append_fixup_4 = $4042
__call_stage_byte_0 = $4044
__call_stage_plain_word_reference_0 = $4046
append_fixup = $4048
ass_image_length = $404a
mode_width = $404c
stage_byte = $404e
stage_plain_word_reference = $4050
stage_unresolved_instruction:
__F_stage_unresolved_instruction_entry:
    ldy __L_stage_unresolved_instruction_mode
    lda mode_width,y
    sta __L_stage_unresolved_instruction_width
    lda __L_stage_unresolved_instruction_opcode
    sta __T_stage_unresolved_instruction___v3
    lda __T_stage_unresolved_instruction___v3
    sta __call_stage_byte_0
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    lda __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_unresolved_instruction_yes_1
    jmp __F_stage_unresolved_instruction_join_3
__F_stage_unresolved_instruction_yes_1:
    lda __L_stage_unresolved_instruction_status
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_3:
    lda ass_image_length
    sta __L_stage_unresolved_instruction_stage
    lda ass_image_length+1
    sta __L_stage_unresolved_instruction_stage+1
    lda __L_stage_unresolved_instruction_width
    cmp #$02
    beq __F_stage_unresolved_instruction_yes_4
    jmp __F_stage_unresolved_instruction_join_6
__F_stage_unresolved_instruction_yes_4:
    lda __L_stage_unresolved_instruction_prefix
    cmp VALUE_PREFIX_NONE
    beq __F_stage_unresolved_instruction_yes_7
    jmp __F_stage_unresolved_instruction_join_9
__F_stage_unresolved_instruction_yes_7:
    lda __L_stage_unresolved_instruction_addend
    sta __T_stage_unresolved_instruction___v18
    lda __L_stage_unresolved_instruction_addend+1
    sta __T_stage_unresolved_instruction___v18+1
    lda __T_stage_unresolved_instruction___v18+1
    cmp #$00
    bne __F_stage_unresolved_instruction_join_9
    lda __T_stage_unresolved_instruction___v18
    cmp #$00
    beq __F_stage_unresolved_instruction_yes_10
    jmp __F_stage_unresolved_instruction_join_9
__F_stage_unresolved_instruction_yes_10:
    lda __L_stage_unresolved_instruction_symbol
    sta __T_stage_unresolved_instruction___v21
    lda __L_stage_unresolved_instruction_symbol+1
    sta __T_stage_unresolved_instruction___v21+1
    lda __T_stage_unresolved_instruction___v21
    sta __call_stage_plain_word_reference_0
    lda __T_stage_unresolved_instruction___v21+1
    sta __call_stage_plain_word_reference_0+1
    jsr stage_plain_word_reference
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_9:
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    lda __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_unresolved_instruction_yes_13
    jmp __F_stage_unresolved_instruction_join_15
__F_stage_unresolved_instruction_yes_13:
    lda __L_stage_unresolved_instruction_status
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_15:
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    lda __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_unresolved_instruction_yes_16
    jmp __F_stage_unresolved_instruction_join_18
__F_stage_unresolved_instruction_yes_16:
    lda __L_stage_unresolved_instruction_status
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_18:
    lda FIXUP_WORD
    sta __T_stage_unresolved_instruction___v35
    lda __L_stage_unresolved_instruction_stage
    sta __T_stage_unresolved_instruction___v36
    lda __L_stage_unresolved_instruction_stage+1
    sta __T_stage_unresolved_instruction___v36+1
    lda __L_stage_unresolved_instruction_symbol
    sta __T_stage_unresolved_instruction___v37
    lda __L_stage_unresolved_instruction_symbol+1
    sta __T_stage_unresolved_instruction___v37+1
    lda __L_stage_unresolved_instruction_addend
    sta __T_stage_unresolved_instruction___v38
    lda __L_stage_unresolved_instruction_addend+1
    sta __T_stage_unresolved_instruction___v38+1
    lda __L_stage_unresolved_instruction_prefix
    sta __T_stage_unresolved_instruction___v39
    lda __T_stage_unresolved_instruction___v35
    sta __call_append_fixup_0
    lda __T_stage_unresolved_instruction___v36
    sta __call_append_fixup_1
    lda __T_stage_unresolved_instruction___v36+1
    sta __call_append_fixup_1+1
    lda __T_stage_unresolved_instruction___v37
    sta __call_append_fixup_2
    lda __T_stage_unresolved_instruction___v37+1
    sta __call_append_fixup_2+1
    lda __T_stage_unresolved_instruction___v38
    sta __call_append_fixup_3
    lda __T_stage_unresolved_instruction___v38+1
    sta __call_append_fixup_3+1
    lda __T_stage_unresolved_instruction___v39
    sta __call_append_fixup_4
    jsr append_fixup
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_6:
    lda __L_stage_unresolved_instruction_width
    cmp #$01
    bne __F_stage_unresolved_instruction_yes_19
    jmp __F_stage_unresolved_instruction_join_21
__F_stage_unresolved_instruction_yes_19:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_21:
    lda #$00
    sta __call_stage_byte_0
    lda #$00
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_unresolved_instruction_status
    lda __L_stage_unresolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_unresolved_instruction_yes_22
    jmp __F_stage_unresolved_instruction_join_24
__F_stage_unresolved_instruction_yes_22:
    lda __L_stage_unresolved_instruction_status
    ldx #$00
    rts
__F_stage_unresolved_instruction_join_24:
    lda FIXUP_BYTE
    sta __L_stage_unresolved_instruction_kind
    lda __L_stage_unresolved_instruction_mode
    cmp MODE_RELATIVE
    beq __F_stage_unresolved_instruction_yes_25
    jmp __F_stage_unresolved_instruction_join_27
__F_stage_unresolved_instruction_yes_25:
    lda FIXUP_RELATIVE
    sta __L_stage_unresolved_instruction_kind
__F_stage_unresolved_instruction_join_27:
    lda __L_stage_unresolved_instruction_kind
    sta __T_stage_unresolved_instruction___v56
    lda __L_stage_unresolved_instruction_stage
    sta __T_stage_unresolved_instruction___v57
    lda __L_stage_unresolved_instruction_stage+1
    sta __T_stage_unresolved_instruction___v57+1
    lda __L_stage_unresolved_instruction_symbol
    sta __T_stage_unresolved_instruction___v58
    lda __L_stage_unresolved_instruction_symbol+1
    sta __T_stage_unresolved_instruction___v58+1
    lda __L_stage_unresolved_instruction_addend
    sta __T_stage_unresolved_instruction___v59
    lda __L_stage_unresolved_instruction_addend+1
    sta __T_stage_unresolved_instruction___v59+1
    lda __L_stage_unresolved_instruction_prefix
    sta __T_stage_unresolved_instruction___v60
    lda __T_stage_unresolved_instruction___v56
    sta __call_append_fixup_0
    lda __T_stage_unresolved_instruction___v57
    sta __call_append_fixup_1
    lda __T_stage_unresolved_instruction___v57+1
    sta __call_append_fixup_1+1
    lda __T_stage_unresolved_instruction___v58
    sta __call_append_fixup_2
    lda __T_stage_unresolved_instruction___v58+1
    sta __call_append_fixup_2+1
    lda __T_stage_unresolved_instruction___v59
    sta __call_append_fixup_3
    lda __T_stage_unresolved_instruction___v59+1
    sta __call_append_fixup_3+1
    lda __T_stage_unresolved_instruction___v60
    sta __call_append_fixup_4
    jsr append_fixup
    ldx #$00
    rts
