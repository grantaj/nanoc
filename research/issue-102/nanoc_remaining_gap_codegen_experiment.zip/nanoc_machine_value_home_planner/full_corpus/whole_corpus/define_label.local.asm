entry:
    lda name
    sta __call_find_symbol_0
    lda name+1
    sta __call_find_symbol_0+1
    lda length
    sta __call_find_symbol_1
    jsr find_symbol
    sta symbol
    stx symbol+1
    sec
    lda #$00
    sbc #$02
    sta __v5
    lda #$00
    sbc #$00
    sta __v5+1
    lda symbol+1
    cmp __v5+1
    bne join_3
    lda symbol
    cmp __v5
    beq yes_1
    jmp join_3
yes_1:
    lda ASSEMBLE_SCOPE_ERROR
    rts
join_3:
    lda #$00
    eor #$80
    sta __rh
    lda symbol+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda symbol
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp yes_4
__sel2:
    jmp join_6
__sel3:
    jmp join_6
yes_4:
    lda name
    sta __call_allocate_symbol_0
    lda name+1
    sta __call_allocate_symbol_0+1
    lda length
    sta __call_allocate_symbol_1
    lda SYMBOL_LABEL_DEFINED
    sta __call_allocate_symbol_2
    lda value
    sta __call_allocate_symbol_3
    lda value+1
    sta __call_allocate_symbol_3+1
    jsr allocate_symbol
    sta symbol
    stx symbol+1
    sec
    lda #$00
    sbc #$02
    sta __v18
    lda #$00
    sbc #$00
    sta __v18+1
    lda symbol+1
    cmp __v18+1
    bne join_9
    lda symbol
    cmp __v18
    beq yes_7
    jmp join_9
yes_7:
    lda ASSEMBLE_SCOPE_ERROR
    rts
join_9:
    lda #$00
    eor #$80
    sta __rh
    lda symbol+1
    eor #$80
    cmp __rh
    bcc __sel4
    bne __sel5
    lda symbol
    cmp #$00
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp yes_10
__sel5:
    jmp join_12
__sel6:
    jmp join_12
yes_10:
    lda ASSEMBLE_SYMBOL_FULL
    rts
join_12:
    lda ASSEMBLE_OK
    rts
join_6:
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda symbol
    sta __ix
    lda symbol+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v28
    lda __v28
    cmp SYMBOL_LABEL_UNDEFINED
    bne yes_13
    jmp join_15
yes_13:
    lda ASSEMBLE_BAD_SYMBOL
    rts
join_15:
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda symbol
    asl
    sta __ix
    lda symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v34
    iny
    lda (__ap),y
    sta __v34+1
    lda __v34
    sta old_head
    lda __v34+1
    sta old_head+1
    lda value
    sta __v39
    lda value+1
    sta __v39+1
    lda #<symbol_payload
    sta __ap
    lda #>symbol_payload
    sta __ap+1
    lda symbol
    asl
    sta __ix
    lda symbol+1
    rol
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __v39
    sta (__ap),y
    iny
    lda __v39+1
    sta (__ap),y
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda symbol
    sta __ix
    lda symbol+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda SYMBOL_LABEL_DEFINED
    sta (__ap),y
    lda old_head
    sta __call_patch_word_chain_0
    lda old_head+1
    sta __call_patch_word_chain_0+1
    lda value
    sta __call_patch_word_chain_1
    lda value+1
    sta __call_patch_word_chain_1+1
    jsr patch_word_chain
    sta status
    lda status
    cmp ASSEMBLE_OK
    bne yes_16
    jmp join_18
yes_16:
    lda status
    rts
join_18:
    lda symbol
    sta __call_resolve_fixups_for_symbol_0
    lda symbol+1
    sta __call_resolve_fixups_for_symbol_0+1
    jsr resolve_fixups_for_symbol
    rts
