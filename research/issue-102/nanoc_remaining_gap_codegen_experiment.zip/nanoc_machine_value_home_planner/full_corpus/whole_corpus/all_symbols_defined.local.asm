entry:
    lda #$00
    sta i
    lda #$00
    sta i+1
while_1:
    lda symbol_count+1
    eor #$80
    sta __rh
    lda i+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda i
    cmp symbol_count
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp body_2
__sel2:
    jmp after_3
__sel3:
    jmp after_3
body_2:
    lda #<symbol_kind
    sta __ap
    lda #>symbol_kind
    sta __ap+1
    lda i
    sta __ix
    lda i+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __v6
    lda __v6
    cmp SYMBOL_LABEL_UNDEFINED
    beq yes_4
    jmp join_6
yes_4:
    lda #$00
    rts
join_6:
    lda i
    clc
    adc #$01
    sta __v12
    lda i+1
    adc #$00
    sta __v12+1
    lda __v12
    sta i
    lda __v12+1
    sta i+1
    jmp while_1
after_3:
    lda #$01
    rts
