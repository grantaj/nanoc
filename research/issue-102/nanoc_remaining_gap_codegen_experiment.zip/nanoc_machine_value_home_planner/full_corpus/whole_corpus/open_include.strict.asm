* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
ASSEMBLE_BAD_STATEMENT = $4000
ASSEMBLE_INCLUDE_DEPTH = $4002
ASSEMBLE_IO_ERROR = $4004
ASSEMBLE_OK = $4006
__L_open_include_argument = $4008
__L_open_include_handle = $400a
__L_open_include_i = $400c
__L_open_include_input_length = $400e
__L_open_include_input_start = $4010
__L_open_include_length = $4012
__L_open_include_output = $4014
__L_open_include_parent_path = $4016
__T_open_include___v107 = $4018
__T_open_include___v109 = $401a
__T_open_include___v110 = $401c
__T_open_include___v13 = $401e
__T_open_include___v14 = $4020
__T_open_include___v33 = $4022
__T_open_include___v39 = $4024
__T_open_include___v40 = $4026
__T_open_include___v46 = $4028
__T_open_include___v47 = $402a
__T_open_include___v6 = $402c
__T_open_include___v65 = $402e
__T_open_include___v68 = $4030
__T_open_include___v77 = $4032
__T_open_include___v86 = $4034
__T_open_include___v90 = $4036
__T_open_include___v91 = $4038
__T_open_include___v99 = $403a
__call_io_open_0 = $403c
__call_io_open_1 = $403e
io_open = $4040
source_depth = $4042
source_directory = $4044
source_directory_length = $4046
source_handle = $4048
source_path = $404a
open_include:
__F_open_include_entry:
    lda __L_open_include_length
    cmp #$03
    bcc __F_open_include_yes_1
    jmp __F_open_include_join_3
__F_open_include_yes_1:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_open_include_join_3:
    ldy #$00
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda (__ap),y
    sta __T_open_include___v6
    cmp #$22
    bne __F_open_include_yes_4
    jmp __F_open_include_join_6
__F_open_include_yes_4:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_open_include_join_6:
    lda __L_open_include_length
    sec
    sbc #$01
    sta __T_open_include___v13
    lda #$00
    sbc #$00
    sta __T_open_include___v13+1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda __T_open_include___v13
    sta __ix
    lda __T_open_include___v13+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_open_include___v14
    cmp #$22
    bne __F_open_include_yes_7
    jmp __F_open_include_join_9
__F_open_include_yes_7:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_open_include_join_9:
    lda #$00
    eor #$80
    sta __rh
    lda source_depth+1
    eor #$80
    cmp __rh
    bcc __F_open_include___sel1
    bne __F_open_include___sel2
    lda source_depth
    cmp #$04
    bcc __F_open_include___sel1
    bne __F_open_include___sel2
    jmp __F_open_include___sel3
__F_open_include___sel1:
    jmp __F_open_include_join_12
__F_open_include___sel2:
    jmp __F_open_include_yes_10
__F_open_include___sel3:
    jmp __F_open_include_yes_10
__F_open_include_yes_10:
    lda ASSEMBLE_INCLUDE_DEPTH
    ldx #$00
    rts
__F_open_include_join_12:
    lda #$01
    sta __L_open_include_input_start
    lda __L_open_include_length
    sec
    sbc #$02
    sta __L_open_include_input_length
    lda #$00
    sta __L_open_include_output
    lda #$00
    sta __L_open_include_parent_path
    lda __L_open_include_input_length
    cmp #$03
    bcs __F_open_include_yes_13
    jmp __F_open_include_join_15
__F_open_include_yes_13:
    ldy __L_open_include_input_start
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda (__ap),y
    sta __T_open_include___v33
    cmp #$2e
    beq __F_open_include_yes_16
    jmp __F_open_include_join_15
__F_open_include_yes_16:
    lda __L_open_include_input_start
    clc
    adc #$01
    sta __T_open_include___v39
    lda #$00
    adc #$00
    sta __T_open_include___v39+1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda __T_open_include___v39
    sta __ix
    lda __T_open_include___v39+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_open_include___v40
    cmp #$2e
    beq __F_open_include_yes_19
    jmp __F_open_include_join_15
__F_open_include_yes_19:
    lda __L_open_include_input_start
    clc
    adc #$02
    sta __T_open_include___v46
    lda #$00
    adc #$00
    sta __T_open_include___v46+1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda __T_open_include___v46
    sta __ix
    lda __T_open_include___v46+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_open_include___v47
    cmp #$2f
    beq __F_open_include_yes_22
    jmp __F_open_include_join_15
__F_open_include_yes_22:
    lda #$01
    sta __L_open_include_parent_path
    lda __L_open_include_input_start
    clc
    adc #$03
    sta __L_open_include_input_start
    lda __L_open_include_input_length
    sec
    sbc #$03
    sta __L_open_include_input_length
__F_open_include_join_15:
    lda __L_open_include_parent_path
    cmp #$00
    beq __F_open_include_yes_25
    jmp __F_open_include_join_27
__F_open_include_yes_25:
    lda #$00
    sta __L_open_include_i
__F_open_include_while_28:
    lda __L_open_include_i
    cmp source_directory_length
    bcc __F_open_include_body_29
    jmp __F_open_include_join_27
__F_open_include_body_29:
    lda __L_open_include_output
    sta __T_open_include___v65
    ldy __L_open_include_i
    lda source_directory
    sta __ap
    lda source_directory+1
    sta __ap+1
    lda (__ap),y
    sta __T_open_include___v68
    ldy __T_open_include___v65
    lda __T_open_include___v68
    sta source_path,y
    inc __L_open_include_output
    inc __L_open_include_i
    jmp __F_open_include_while_28
__F_open_include_join_27:
    lda __L_open_include_output
    clc
    adc __L_open_include_input_length
    sta __T_open_include___v77
    lda #$00
    adc #$00
    sta __T_open_include___v77+1
    lda #$00
    eor #$80
    sta __rh
    lda __T_open_include___v77+1
    eor #$80
    cmp __rh
    bcc __F_open_include___sel4
    bne __F_open_include___sel5
    lda __T_open_include___v77
    cmp #$ff
    bcc __F_open_include___sel4
    bne __F_open_include___sel5
    jmp __F_open_include___sel6
__F_open_include___sel4:
    jmp __F_open_include_join_33
__F_open_include___sel5:
    jmp __F_open_include_yes_31
__F_open_include___sel6:
    jmp __F_open_include_join_33
__F_open_include_yes_31:
    lda ASSEMBLE_BAD_STATEMENT
    ldx #$00
    rts
__F_open_include_join_33:
    lda #$00
    sta __L_open_include_i
__F_open_include_while_34:
    lda __L_open_include_i
    cmp __L_open_include_input_length
    bcc __F_open_include_body_35
    jmp __F_open_include_after_36
__F_open_include_body_35:
    lda __L_open_include_output
    sta __T_open_include___v86
    lda __L_open_include_input_start
    clc
    adc __L_open_include_i
    sta __T_open_include___v90
    lda #$00
    adc #$00
    sta __T_open_include___v90+1
    lda __L_open_include_argument
    sta __ap
    lda __L_open_include_argument+1
    sta __ap+1
    lda __T_open_include___v90
    sta __ix
    lda __T_open_include___v90+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __T_open_include___v91
    ldy __T_open_include___v86
    lda __T_open_include___v91
    sta source_path,y
    inc __L_open_include_output
    inc __L_open_include_i
    jmp __F_open_include_while_34
__F_open_include_after_36:
    lda __L_open_include_output
    sta __T_open_include___v99
    lda #<source_path
    sta __call_io_open_0
    lda __T_open_include___v99
    sta __call_io_open_1
    jsr io_open
    sta __L_open_include_handle
    stx __L_open_include_handle+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_open_include_handle+1
    eor #$80
    cmp __rh
    bcc __F_open_include___sel7
    bne __F_open_include___sel8
    lda __L_open_include_handle
    cmp #$00
    bcc __F_open_include___sel7
    bne __F_open_include___sel8
    jmp __F_open_include___sel9
__F_open_include___sel7:
    jmp __F_open_include_yes_37
__F_open_include___sel8:
    jmp __F_open_include_join_39
__F_open_include___sel9:
    jmp __F_open_include_join_39
__F_open_include_yes_37:
    lda ASSEMBLE_IO_ERROR
    ldx #$00
    rts
__F_open_include_join_39:
    lda source_depth
    clc
    adc #$01
    sta __T_open_include___v107
    lda source_depth+1
    adc #$00
    sta __T_open_include___v107+1
    lda __T_open_include___v107
    sta source_depth
    lda __T_open_include___v107+1
    sta source_depth+1
    lda source_depth
    sta __T_open_include___v109
    lda source_depth+1
    sta __T_open_include___v109+1
    lda __L_open_include_handle
    sta __T_open_include___v110
    lda __L_open_include_handle+1
    sta __T_open_include___v110+1
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda __T_open_include___v109
    sta __ix
    lda __T_open_include___v109+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_open_include___v110
    sta (__ap),y
    lda ASSEMBLE_OK
    ldx #$00
    rts
