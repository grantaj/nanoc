entry:
    lda c
    cmp #$61
    bcs yes_1
    jmp join_3
yes_1:
    lda c
    cmp #$7a
    bcc yes_4
    beq yes_4
    jmp join_3
yes_4:
    lda c
    sec
    sbc #$20
    sta __v8
    lda #$00
    sbc #$00
    sta __v8+1
    lda __v8
    rts
join_3:
    lda c
    rts
