entry:
    lda index
    cmp #$00
    beq yes_1
    jmp join_3
yes_1:
    lda mnemonic
    sta __call_find_opcode_0
    lda MODE_RELATIVE
    sta __call_find_opcode_1
    jsr find_opcode
    sta opcode
    stx opcode+1
    lda #$00
    eor #$80
    sta __rh
    lda opcode+1
    eor #$80
    cmp __rh
    bcc __sel1
    bne __sel2
    lda opcode
    cmp #$00
    bcc __sel1
    bne __sel2
    jmp __sel3
__sel1:
    jmp join_3
__sel2:
    jmp yes_4
__sel3:
    jmp yes_4
yes_4:
    lda mnemonic
    sta __call_assemble_mode_value_0
    lda MODE_RELATIVE
    sta __call_assemble_mode_value_1
    lda text
    sta __call_assemble_mode_value_2
    lda text+1
    sta __call_assemble_mode_value_2+1
    lda length
    sta __call_assemble_mode_value_3
    jsr assemble_mode_value
    rts
join_3:
    lda text
    sta __call_parse_value_0
    lda text+1
    sta __call_parse_value_0+1
    lda length
    sta __call_parse_value_1
    jsr parse_value
    sta status
    lda status
    cmp VALUE_OK
    bne yes_7
    jmp join_9
yes_7:
    lda status
    cmp VALUE_UNRESOLVED
    bne yes_10
    jmp join_9
yes_10:
    lda status
    cmp VALUE_SYMBOL_FULL
    beq yes_13
    jmp join_15
yes_13:
    lda ASSEMBLE_SYMBOL_FULL
    rts
join_15:
    lda status
    cmp VALUE_SCOPE_ERROR
    beq yes_16
    jmp join_18
yes_16:
    lda ASSEMBLE_SCOPE_ERROR
    rts
join_18:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_9:
    lda index
    sta __call_short_mode_for_index_0
    jsr short_mode_for_index
    sta short_mode
    lda index
    sta __call_long_mode_for_index_0
    jsr long_mode_for_index
    sta long_mode
    lda mnemonic
    sta __call_find_opcode_0
    lda short_mode
    sta __call_find_opcode_1
    jsr find_opcode
    sta short_opcode
    stx short_opcode+1
    lda mnemonic
    sta __call_find_opcode_0
    lda long_mode
    sta __call_find_opcode_1
    jsr find_opcode
    sta long_opcode
    stx long_opcode+1
    lda status
    cmp VALUE_OK
    beq yes_19
    jmp join_21
yes_19:
    lda value_result+1
    cmp #$00
    bcc __sel4
    bne __sel5
    lda value_result
    cmp #$ff
    bcc __sel4
    bne __sel5
    jmp __sel6
__sel4:
    jmp yes_22
__sel5:
    jmp join_24
__sel6:
    jmp yes_22
yes_22:
    lda #$00
    eor #$80
    sta __rh
    lda short_opcode+1
    eor #$80
    cmp __rh
    bcc __sel7
    bne __sel8
    lda short_opcode
    cmp #$00
    bcc __sel7
    bne __sel8
    jmp __sel9
__sel7:
    jmp join_24
__sel8:
    jmp yes_25
__sel9:
    jmp yes_25
yes_25:
    lda short_opcode
    sta __call_stage_resolved_instruction_0
    lda short_mode
    sta __call_stage_resolved_instruction_1
    lda value_result
    sta __call_stage_resolved_instruction_2
    lda value_result+1
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    rts
join_24:
    lda #$00
    eor #$80
    sta __rh
    lda long_opcode+1
    eor #$80
    cmp __rh
    bcc __sel10
    bne __sel11
    lda long_opcode
    cmp #$00
    bcc __sel10
    bne __sel11
    jmp __sel12
__sel10:
    jmp join_30
__sel11:
    jmp yes_28
__sel12:
    jmp yes_28
yes_28:
    lda long_opcode
    sta __call_stage_resolved_instruction_0
    lda long_mode
    sta __call_stage_resolved_instruction_1
    lda value_result
    sta __call_stage_resolved_instruction_2
    lda value_result+1
    sta __call_stage_resolved_instruction_2+1
    jsr stage_resolved_instruction
    rts
join_30:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_21:
    lda long_mode
    sta mode
    lda long_opcode
    sta opcode
    lda long_opcode+1
    sta opcode+1
    lda captured_prefix
    cmp VALUE_PREFIX_NONE
    bne yes_31
    jmp no_32
yes_31:
    lda short_mode
    sta mode
    lda short_opcode
    sta opcode
    lda short_opcode+1
    sta opcode+1
    jmp join_33
no_32:
    lda #$00
    eor #$80
    sta __rh
    lda long_opcode+1
    eor #$80
    cmp __rh
    bcc __sel13
    bne __sel14
    lda long_opcode
    cmp #$00
    bcc __sel13
    bne __sel14
    jmp __sel15
__sel13:
    jmp yes_34
__sel14:
    jmp join_33
__sel15:
    jmp join_33
yes_34:
    lda short_mode
    sta mode
    lda short_opcode
    sta opcode
    lda short_opcode+1
    sta opcode+1
join_33:
    lda #$00
    eor #$80
    sta __rh
    lda opcode+1
    eor #$80
    cmp __rh
    bcc __sel16
    bne __sel17
    lda opcode
    cmp #$00
    bcc __sel16
    bne __sel17
    jmp __sel18
__sel16:
    jmp yes_37
__sel17:
    jmp join_39
__sel18:
    jmp join_39
yes_37:
    lda ASSEMBLE_BAD_INSTRUCTION
    rts
join_39:
    lda opcode
    sta __call_stage_unresolved_instruction_0
    lda mode
    sta __call_stage_unresolved_instruction_1
    lda captured_symbol
    sta __call_stage_unresolved_instruction_2
    lda captured_symbol+1
    sta __call_stage_unresolved_instruction_2+1
    lda captured_addend
    sta __call_stage_unresolved_instruction_3
    lda captured_addend+1
    sta __call_stage_unresolved_instruction_3+1
    lda captured_prefix
    sta __call_stage_unresolved_instruction_4
    jsr stage_unresolved_instruction
    rts
