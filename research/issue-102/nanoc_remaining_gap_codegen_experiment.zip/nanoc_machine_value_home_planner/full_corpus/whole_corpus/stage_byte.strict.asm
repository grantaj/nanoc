* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
ASSEMBLE_OK = $4000
ASSEMBLE_WORK_FULL = $4002
__L_stage_byte_value = $4004
__T_stage_byte___v11 = $4006
__T_stage_byte___v5 = $4008
__T_stage_byte___v8 = $400a
ass_image = $400c
ass_image_length = $400e
stage_byte:
__F_stage_byte_entry:
    lda #$2c
    eor #$80
    sta __rh
    lda ass_image_length+1
    eor #$80
    cmp __rh
    bcc __F_stage_byte___sel1
    bne __F_stage_byte___sel2
    lda ass_image_length
    cmp #$00
    bcc __F_stage_byte___sel1
    bne __F_stage_byte___sel2
    jmp __F_stage_byte___sel3
__F_stage_byte___sel1:
    jmp __F_stage_byte_join_3
__F_stage_byte___sel2:
    jmp __F_stage_byte_yes_1
__F_stage_byte___sel3:
    jmp __F_stage_byte_yes_1
__F_stage_byte_yes_1:
    lda ASSEMBLE_WORK_FULL
    ldx #$00
    rts
__F_stage_byte_join_3:
    lda ass_image_length
    sta __T_stage_byte___v5
    lda ass_image_length+1
    sta __T_stage_byte___v5+1
    lda __L_stage_byte_value
    and #$ff
    sta __T_stage_byte___v8
    lda #$00
    and #$00
    sta __T_stage_byte___v8+1
    lda #<ass_image
    sta __ap
    lda #>ass_image
    sta __ap+1
    lda __T_stage_byte___v5
    sta __ix
    lda __T_stage_byte___v5+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda __T_stage_byte___v8
    sta (__ap),y
    lda ass_image_length
    clc
    adc #$01
    sta __T_stage_byte___v11
    lda ass_image_length+1
    adc #$00
    sta __T_stage_byte___v11+1
    lda __T_stage_byte___v11
    sta ass_image_length
    lda __T_stage_byte___v11+1
    sta ass_image_length+1
    lda ASSEMBLE_OK
    ldx #$00
    rts
