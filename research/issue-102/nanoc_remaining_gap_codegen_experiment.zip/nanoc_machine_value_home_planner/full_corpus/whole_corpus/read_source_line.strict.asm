* = $0800
__ap = $0010
__ix = $0012
__rh = $0014
__L_read_source_line_c = $4000
__L_read_source_line_handle = $4002
__T_read_source_line___v12 = $4004
__T_read_source_line___v18 = $4006
__T_read_source_line___v23 = $4008
__T_read_source_line___v28 = $400a
__T_read_source_line___v35 = $400c
__T_read_source_line___v42 = $400e
__T_read_source_line___v44 = $4010
__T_read_source_line___v45 = $4012
__T_read_source_line___v5 = $4014
__call_io_read_0 = $4016
io_read = $4018
source_depth = $401a
source_handle = $401c
source_line = $401e
source_line_length = $4020
read_source_line:
__F_read_source_line_entry:
    lda #$00
    sta source_line_length
    lda #<source_handle
    sta __ap
    lda #>source_handle
    sta __ap+1
    lda source_depth
    sta __ix
    lda source_depth+1
    sta __ix+1
    clc
    lda __ap
    adc __ix
    sta __ap
    lda __ap+1
    adc __ix+1
    sta __ap+1
    ldy #$00
    lda (__ap),y
    sta __L_read_source_line_handle
__F_read_source_line_while_1:
    lda #$01
    ora #$00
    bne __F_read_source_line_body_2
    jmp __F_read_source_line_after_3
__F_read_source_line_body_2:
    lda __L_read_source_line_handle
    sta __T_read_source_line___v5
    lda __T_read_source_line___v5
    sta __call_io_read_0
    jsr io_read
    sta __L_read_source_line_c
    stx __L_read_source_line_c+1
    lda #$00
    eor #$80
    sta __rh
    lda __L_read_source_line_c+1
    eor #$80
    cmp __rh
    bcc __F_read_source_line___sel1
    bne __F_read_source_line___sel2
    lda __L_read_source_line_c
    cmp #$00
    bcc __F_read_source_line___sel1
    bne __F_read_source_line___sel2
    jmp __F_read_source_line___sel3
__F_read_source_line___sel1:
    jmp __F_read_source_line_yes_4
__F_read_source_line___sel2:
    jmp __F_read_source_line_join_6
__F_read_source_line___sel3:
    jmp __F_read_source_line_join_6
__F_read_source_line_yes_4:
    sec
    lda #$00
    sbc #$01
    sta __T_read_source_line___v12
    lda #$00
    sbc #$00
    sta __T_read_source_line___v12+1
    lda __L_read_source_line_c+1
    cmp __T_read_source_line___v12+1
    bne __F_read_source_line_join_9
    lda __L_read_source_line_c
    cmp __T_read_source_line___v12
    beq __F_read_source_line_yes_7
    jmp __F_read_source_line_join_9
__F_read_source_line_yes_7:
    lda source_line_length
    cmp #$00
    bne __F_read_source_line_yes_10
    jmp __F_read_source_line_join_12
__F_read_source_line_yes_10:
    lda source_line_length
    sta __T_read_source_line___v18
    ldy __T_read_source_line___v18
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
__F_read_source_line_join_12:
    lda #$00
    ldx #$00
    rts
__F_read_source_line_join_9:
    sec
    lda #$00
    sbc #$01
    sta __T_read_source_line___v23
    lda #$00
    sbc #$00
    sta __T_read_source_line___v23+1
    lda __T_read_source_line___v23
    ldx __T_read_source_line___v23+1
    rts
__F_read_source_line_join_6:
    lda __L_read_source_line_c+1
    cmp #$00
    bne __F_read_source_line_join_15
    lda __L_read_source_line_c
    cmp #$0d
    beq __F_read_source_line_yes_13
    jmp __F_read_source_line_join_15
__F_read_source_line_yes_13:
    lda source_line_length
    sta __T_read_source_line___v28
    ldy __T_read_source_line___v28
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
__F_read_source_line_join_15:
    lda __L_read_source_line_c+1
    cmp #$00
    bne __F_read_source_line_join_18
    lda __L_read_source_line_c
    cmp #$0a
    beq __F_read_source_line_yes_16
    jmp __F_read_source_line_join_18
__F_read_source_line_yes_16:
    lda source_line_length
    sta __T_read_source_line___v35
    ldy __T_read_source_line___v35
    lda #$00
    sta source_line,y
    lda #$01
    ldx #$00
    rts
__F_read_source_line_join_18:
    lda source_line_length
    cmp #$ff
    bcs __F_read_source_line_yes_19
    jmp __F_read_source_line_join_21
__F_read_source_line_yes_19:
    sec
    lda #$00
    sbc #$02
    sta __T_read_source_line___v42
    lda #$00
    sbc #$00
    sta __T_read_source_line___v42+1
    lda __T_read_source_line___v42
    ldx __T_read_source_line___v42+1
    rts
__F_read_source_line_join_21:
    lda source_line_length
    sta __T_read_source_line___v44
    lda __L_read_source_line_c
    sta __T_read_source_line___v45
    lda __L_read_source_line_c+1
    sta __T_read_source_line___v45+1
    ldy __T_read_source_line___v44
    lda __T_read_source_line___v45
    sta source_line,y
    inc source_line_length
    jmp __F_read_source_line_while_1
__F_read_source_line_after_3:
    lda #$00
    ldx #$00
    rts
