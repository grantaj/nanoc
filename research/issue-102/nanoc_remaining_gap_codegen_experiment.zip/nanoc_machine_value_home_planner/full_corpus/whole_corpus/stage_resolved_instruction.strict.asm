* = $0800
ASSEMBLE_BAD_INSTRUCTION = $4000
ASSEMBLE_OK = $4002
__L_stage_resolved_instruction_mode = $4004
__L_stage_resolved_instruction_opcode = $4006
__L_stage_resolved_instruction_status = $4008
__L_stage_resolved_instruction_value = $400a
__L_stage_resolved_instruction_width = $400c
__T_stage_resolved_instruction___v10 = $400e
__T_stage_resolved_instruction___v22 = $4010
__T_stage_resolved_instruction___v33 = $4012
__T_stage_resolved_instruction___v35 = $4014
__call_stage_byte_0 = $4016
mode_width = $4018
stage_byte = $401a
stage_resolved_instruction:
__F_stage_resolved_instruction_entry:
    ldy __L_stage_resolved_instruction_mode
    lda mode_width,y
    sta __L_stage_resolved_instruction_width
    lda __L_stage_resolved_instruction_width
    cmp #$01
    beq __F_stage_resolved_instruction_yes_1
    jmp __F_stage_resolved_instruction_join_3
__F_stage_resolved_instruction_yes_1:
    lda __L_stage_resolved_instruction_value+1
    cmp #$00
    bcc __F_stage_resolved_instruction___sel1
    bne __F_stage_resolved_instruction___sel2
    lda __L_stage_resolved_instruction_value
    cmp #$ff
    bcc __F_stage_resolved_instruction___sel1
    bne __F_stage_resolved_instruction___sel2
    jmp __F_stage_resolved_instruction___sel3
__F_stage_resolved_instruction___sel1:
    jmp __F_stage_resolved_instruction_join_3
__F_stage_resolved_instruction___sel2:
    jmp __F_stage_resolved_instruction_yes_4
__F_stage_resolved_instruction___sel3:
    jmp __F_stage_resolved_instruction_join_3
__F_stage_resolved_instruction_yes_4:
    lda ASSEMBLE_BAD_INSTRUCTION
    ldx #$00
    rts
__F_stage_resolved_instruction_join_3:
    lda __L_stage_resolved_instruction_opcode
    sta __T_stage_resolved_instruction___v10
    lda __T_stage_resolved_instruction___v10
    sta __call_stage_byte_0
    jsr stage_byte
    sta __L_stage_resolved_instruction_status
    lda __L_stage_resolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_resolved_instruction_yes_7
    jmp __F_stage_resolved_instruction_join_9
__F_stage_resolved_instruction_yes_7:
    lda __L_stage_resolved_instruction_status
    ldx #$00
    rts
__F_stage_resolved_instruction_join_9:
    lda __L_stage_resolved_instruction_width
    cmp #$00
    beq __F_stage_resolved_instruction_yes_10
    jmp __F_stage_resolved_instruction_join_12
__F_stage_resolved_instruction_yes_10:
    lda ASSEMBLE_OK
    ldx #$00
    rts
__F_stage_resolved_instruction_join_12:
    lda __L_stage_resolved_instruction_value
    and #$ff
    sta __T_stage_resolved_instruction___v22
    lda __L_stage_resolved_instruction_value+1
    and #$00
    sta __T_stage_resolved_instruction___v22+1
    lda __T_stage_resolved_instruction___v22
    sta __call_stage_byte_0
    lda __T_stage_resolved_instruction___v22+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    sta __L_stage_resolved_instruction_status
    lda __L_stage_resolved_instruction_status
    cmp ASSEMBLE_OK
    bne __F_stage_resolved_instruction_yes_13
    jmp __F_stage_resolved_instruction_join_15
__F_stage_resolved_instruction_yes_13:
    lda __L_stage_resolved_instruction_status
    ldx #$00
    rts
__F_stage_resolved_instruction_join_15:
    lda __L_stage_resolved_instruction_width
    cmp #$02
    beq __F_stage_resolved_instruction_yes_16
    jmp __F_stage_resolved_instruction_join_18
__F_stage_resolved_instruction_yes_16:
    lda __L_stage_resolved_instruction_value
    sta __T_stage_resolved_instruction___v33
    lda __L_stage_resolved_instruction_value+1
    sta __T_stage_resolved_instruction___v33+1
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lsr __T_stage_resolved_instruction___v33+1
    ror __T_stage_resolved_instruction___v33
    lda __T_stage_resolved_instruction___v33
    and #$ff
    sta __T_stage_resolved_instruction___v35
    lda __T_stage_resolved_instruction___v33+1
    and #$00
    sta __T_stage_resolved_instruction___v35+1
    lda __T_stage_resolved_instruction___v35
    sta __call_stage_byte_0
    lda __T_stage_resolved_instruction___v35+1
    sta __call_stage_byte_0+1
    jsr stage_byte
    ldx #$00
    rts
__F_stage_resolved_instruction_join_18:
    lda ASSEMBLE_OK
    ldx #$00
    rts
